When(/^I navigate to Customer Service >> Message > Create Message$/) do
  on_page(SendMessagePage).goto
end

When(/^I send a Customer Service message of type Payment Center$/) do
  on_page(SendMessagePage).submit_form({ 'service_type' => "Payment Center", 'comment' => "automation check for type Payment Center"})
end

