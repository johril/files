When(/^I navigate to Customer Service >> Research Request$/) do
  on_page(SendRequestPage).goto
end

When(/^I send a Research Request of type Payment Center$/) do
  on_page(SendRequestPage).submit_form({ 'service_type' => "Payment Center", 'comment' => "automation check for type Payment Center"})
end
