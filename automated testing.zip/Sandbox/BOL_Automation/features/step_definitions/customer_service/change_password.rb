And /^Navigate to the Customer Service > CHANGE PASSWORD$/ do
  on_page ChangePasswordPage do |page|
    sleep(*4)
    #page.Customer_Service
    #sleep(*2)
    #page.Change_Password_tab
    page.goto
    sleep(*2)
  end

end

And /^I have entered a "(.*?)" in the Current Password field$/ do    |arg1|
  on_page ChangePasswordPage do |page|
    sleep(*3)
    page.current_password_label
    sleep(*1)
    page.current_password = "password1"

  end

end

And(/^I have entered a "(.*?)" in the New Password field$/) do  |arg1|
  on_page ChangePasswordPage do |page|
    sleep(*2)
    page.new_password_label
    sleep(*1)
    page.new_password = "password2"

  end

end


And(/^I have entered a "(.*?)" in the Re\-Enter New Password field$/) do |arg1|
  on_page ChangePasswordPage do |page|
    sleep(*2)
    page.re_enter_new_password_label
    sleep(*1)
    page.re_enter_new_password = "password2"

  end

end

When(/^I click the Change Password button$/) do
  on_page ChangePasswordPage do |page|
    sleep(*2)
    page.change_password
    sleep(*1)
  end
end

Then(/^the following success message will be displayed: "Your password has been changed successfully. Next time you are required to log in to Business Online you will need to use this new password."$/) do
  expected_message = "Your password has been changed successfully. Next time you are required to log in to Business Online you will need to use this new password."

  on_page ChangePasswordPage do |page|
    sleep(*3)
    page.success_message.should == expected_message
    sleep(*5)
  end

end

Then(/^change the password as "(.*?)"$/) do |arg1|
  on_page ChangePasswordPage do |page|
    sleep(*2)
    page.current_password = "password2"
    sleep(*1)
    page.new_password = "password1"
    sleep(*1)
    page.re_enter_new_password = "password1"
    sleep(*1)
    page.change_password
    sleep(*2)

  end
end

