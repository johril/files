And(/^I have navigated to Administration>>User Service Permissions$/) do
  on_page(BOLMenu) {|page| page.navigate(BOLMenu::LINK_ADMINISTRATION, BOLMenu::LINK_ADMINISTRATION_USER)}
  on_page UserServicePermissions do |page|
    if $OLD_BOL_ADMIN_UI
      page.user_service_permission
    else
      page.service_permission
      page.wait_until(30) { page.service_permission_element.parent.element.attribute("class").downcase.include?("ui-tabs-selected") }
    end
  end
end

And /^select a User$/ do
  on_page UserServicePermissions do |page|
    page.select_user = 'donteditme, donteditme'
    page.wait_until(80){page.user_function_matrix_pagetitle == 'User Function Matrix'}
  end

end
#And(/^I have navigated to Administration>>User Function Matrix$/) do

#end

Then(/^I will not see Business Card Statements on user service permissions page$/) do
  on_page UserServicePermissions do |page|
    entitlement_row = page.getEntitlementRow(page.information_reporting_entitlements_element, "Business Card Statements")
    raise "Business Card Statements entitlement exists" unless entitlement_row.nil?
  end
end

When(/^I view the Payment Center section on the User Service Permissions tab$/) do
  on_page UserServicePermissions do |page|
    raise "Payment Center section does not exist" unless page.paymentCenterSectionExists?
  end
end

Then(/^I am able to check and uncheck the Enable Payment Center entitlement$/) do
  on_page UserServicePermissions do |page|
    page.checkAndUncheckPaymentCenter
  end
end

Then(/^I will see the following user entitlements under the Additional Payment Services subsection$/) do |entitlement_title_table|
  # |user_title           | user_entitlement            |
  on_page UserServicePermissions do |page|
    entitlement_title_table.hashes.each do |row|
      user_title = row['user_title']
      user_entitlement = row['user_entitlement']
      page.getAdditionalPaymentEntitlement(user_title, user_entitlement)
    end
  end
end

When(/^I am entitled to Payment Center$/) do
  on_page UserServicePermissions do |page|
    page.entitleUserToPaymentCenter
  end
end

When(/^I have checked the Enable ACH entitlement$/) do
  on_page UserServicePermissions do |page|
    page.entitleUserToACH(false)
  end
end

When(/^I have checked the Enable Wire Inquiry entitlement$/) do
  on_page UserServicePermissions do |page|
    page.entitleUserToWireInquiry(false)
  end
end

When(/^I click Update Service Permissions$/) do
  on_page UserServicePermissions do |page|
    page.save()
  end
end

Then(/^I will be entitled to ACH$/) do
  on_page BOLMenu do |page|
    page.navigate('PAYMENTS & TRANSFERS', 'ACH', -1)
    sleep(5) #wait for the window to open
    checkForErrorsInNewWindow
  end
end

Then(/^I will be entitled to Wires$/) do
  on_page BOLMenu do |page|
    page.navigate('PAYMENTS & TRANSFERS', 'Wire Transfers', -1)
    sleep(5) #wait for the window to open
    checkForErrorsInNewWindow
  end
end

def checkForErrorsInNewWindow
    errText = ''

    wait = Selenium::WebDriver::Wait.new(:timeout => 60)
    wait.until { @browser.title.downcase != 'serviceredirect' && @browser.title.downcase != ''  }

    #check the new window for the error page
    #NOTE: this will not work if the page that opens times out.  we need to fix this
    @browser.switch_to.window (@browser.window_handles.last) do
      case @browser.title.downcase
      when 'business online error'
        on_page ErrorPage do |err|
          errText = "There was a problem with the Wires entitlement: #{err.getErrorText(@browser.find_element(:id=>'content'))}"
        end
      when 'internet explorer cannot display the webpage'
        errText = 'The redirect timed out or there was another unavoidable error'
      end

      #close the popup
      @browser.close

      #report errors if needed
      raise errText unless errText == ''
    end
end
