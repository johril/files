
When /^I navigate to the Administration and User Service Matrix$/ do
  on_page UserServiceMatrix do |page|
    page.goto()
  end
end

And /^Select a User on Service matrix$/ do
  on_page UserServiceMatrix do |page|
    page.selectedUser = "donteditme" + ", " + "donteditme"
  end
end

Then /^I will not see Payment Center Column listed$/ do
  on_page UserServiceMatrix do |page|
    if (page.text.include? "Payment Center") == true
      fail("Payment Center visible")
    end
  end
end

