AUTOMATION_USER_FIRSTNAME = "donteditme"
AUTOMATION_USER_LASTNAME = "donteditme"


And /^I will see the new user has access to Payment Center$/ do
  on_page UserServicePermissions do |page|
    page.goto()
    page.selectedUser = $test_create_user['last_name'] + ", " + $test_create_user['first_name']
    page.wait_until {page.text.include? "Payment Center"}
    page.enablePaymentCenter_checked? == true
  end
end


And /^I make a change to a Payment Center entitlement that requires an approval$/ do
   on_page UserServicePermissions do |page|
     page.goto()
     page.selectedUser = AUTOMATION_USER_LASTNAME + ", " + AUTOMATION_USER_FIRSTNAME
     page.wait_until {page.text.include? "Enable Payment Center"}
     if page.enablePaymentCenter_checked? == true
       page.uncheck_enablePaymentCenter
     else
       page.check_enablePaymentCenter
     end
     page.updatePermissions

     begin
       alert = @browser.switch_to.alert
       alert.accept
     rescue
       # suppress error here to ensure test can continue even if alert doesn't show up
     ensure
       page.wait_until {page.text.include? "User Permissions have been updated"}
     end
   end
end

When /^I navigate to Administrations > Approvals > Approve$/ do
  on_page Approvals do |page|
    page.goto()
  end
end

Then /^I will see the pending approval$/ do
   on_page Approvals do |page|
     page.approvalsTransactions
     page.approvalsTransactions_element.count.should > 1
   end
end

Then /^I will be able to Modify Payment Center Approval$/ do
   on_page Approvals do |page|
     page.getApprovalLink(AUTOMATION_USER_LASTNAME, AUTOMATION_USER_FIRSTNAME).click
   end
end

When /^I approve the pending transaction and I see success message$/ do
   on_page ApprovalDetails do |page|
     page.approve
     page.wait_until(20) {page.text.include? "The modification has been approved"}
     (page.text.include? "The modification has been approved").should == true
   end
end

Then /^I can view the edits in the Approvals Transaction Reports$/ do
    on_page ApprovalsTransactionReport do |page|
      page.goto()
      page.viewReport
      page.wait_until(20) { page.resultsTable_element.nil? == false }
    end
end

And /^I can drill down into the details of an Approval$/ do
  on_page ApprovalsTransactionReport do |page|
    page.resultsTable_element[1].link_element().click
    page.wait_until(20) {page.text.include? "Status Information"}
    (page.text.include? "Status Information").should == true
  end

end

When /^I DENY the pending transaction  and I see success message$/ do
    on_page ApprovalDetails do |page|
      page.deny
      page.wait_until(20) {page.text.include? "The modification has been denied"}
      (page.text.include? "The modification has been denied").should == true
    end
end