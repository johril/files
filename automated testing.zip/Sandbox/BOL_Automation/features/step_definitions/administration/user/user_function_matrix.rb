When /^I navigate to the Administration and User Function Matrix$/ do
  on_page(BOLMenu) do |menu|
    menu.navigate(BOLMenu::LINK_ADMINISTRATION, BOLMenu::LINK_ADMINISTRATION_USER)
  end
  on_page UserList do |page|
    page.wait_until(30) do
      page.page_header == UserList::HEADER_TEXT
    end

    page.function_matrix_tab
  end
  on_page UserFunctionMatrix do |page|
    page.wait_until(30) do
      page.text.include? UserFunctionMatrix::SELECT_USER_LABEL_TEXT
    end
  end
end

And(/^I select the user from the dropdown$/) do
  on_page UserFunctionMatrix do |page|
    page.select_user = $bol_user['list_display_name']

    page.main_content_panel_element.when_visible(30) do
      page.continue
    end
  end
end

Then(/^I will not see the Business Card Statements column on user function matrix$/) do
  on_page UserFunctionMatrix do |page|
    begin
      page.business_card_statement_column
    rescue
      puts ("Business Card Statement Has been removed from user function matrix")
    end

  end
end


Then /^I will see a column for Business Card Detail on user function matrix$/ do
  puts ("Remove this after  :for PBI20901 need to add check for business detail on user function matrix")
  #ToDo: need to do this
end

And /^under the title I will see in bold red$/ do
  puts ("Remove this after : for PBI20901 need to add check for business detail on user function matrix")
#ToDo: add asserstion, also add the color code
end