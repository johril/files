And(/^I navigate to the Administration and Modify Account Names$/) do
  on_page ModifyAccountNames do |page|
    page.goto()
    page.wait_until(80) { page.edit_account_names? }
  end
end



Then(/^I will not see "(.*?)" column$/) do |column_title|
  on_page ModifyAccountNames do |page|
      page.get_column_header_text(column_title).empty?.should == true
  end
end

But(/^I will see "(.*?)" column$/) do |column_title|
  on_page ModifyAccountNames do |page|
    page.get_column_header_text(column_title).empty?.should == false
  end
end