And(/^I have navigated to Administration>>Company Function Matrix$/) do
  on_page(BOLMenu){|page| page.navigate('ADMINISTRATION', 'Company')}

  on_page CompanyFunctionMatrix do |page|

   if $OLD_BOL_ADMIN_UI
     page.company_tab
     page.company_function_matrix
     sleep(3)
   else
     page.function_matrix_tab
   end
end
end

Then(/^I will not see the Business Card Statements column$/) do
  on_page CompanyFunctionMatrix do |page|
    begin
      page.business_card_statement_column
      raise "Business Card Statements column found"
    rescue Selenium::WebDriver::Error::NoSuchElementError
      puts("Business Card Statement Has been removed from company function matrix")
    end
  end
end