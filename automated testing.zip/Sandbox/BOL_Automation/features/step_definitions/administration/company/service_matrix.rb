
And /^my company is entitled to Payment Center$/ do
  on_page CompanyServicePermissions do |page|
    page.goto()
  end
end

When /^I navigate to the Administration and Company Service Matrix$/ do
  on_page CompanyServiceMatrix do |page|
    page.goto()
  end
end

Then /^I will see Payment Center Column listed$/ do
  #this should be defined in the CompanyServiceMatrix class --JR
  on_page CompanyServiceMatrix do |page|
    if !(page.text.include? "Payment Center")
      fail("Payment Center not visible")
    end
  end
end



Then /^I see only DDA & GL accounts are entitled$/ do
  on_page CompanyServiceMatrix do |page|
     #implement using the direct query to database
    page.goto()
  end
end

But /^I will not be able to check or uncheck accounts under Payment Center column$/ do
  on_page CompanyServiceMatrix do |page|
    #use nokogiri gem to parse the table
    page.checkServiceDisabled(page.html, "3")
  end
end


And /^I will not be able to check or uncheck accounts under Wire Accounts column$/ do
  on_page CompanyServiceMatrix do |page|
    #use nokogiri gem to parse the table
    page.checkServiceDisabled(page.html, "4")
  end
end