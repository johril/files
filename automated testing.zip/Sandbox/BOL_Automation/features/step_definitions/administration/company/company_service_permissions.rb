And(/^I have navigated to Administration>>Company Service Permissions$/) do
  on_page(BOLMenu) do |page|
    page.navigate(BOLMenu::LINK_ADMINISTRATION, BOLMenu::LINK_ADMINISTRATION_COMPANY)
  end
  on_page CompanyProfile do |page|
    page.wait_until(30) do
      page.page_header == CompanyProfile::HEADER_TEXT
    end

    page.company_service_permission
  end
  on_page CompanyServicePermissions do |page|
    page.wait_until(30) do
      page.text.include? CompanyServicePermissions::COMPANY_MAINTENANCE_TEXT
    end
  end
end


And(/^I am viewing the Information Reporting section$/) do
  on_page CompanyServicePermissions do |page|
    page.information_reporting
  end

end


When(/^I look at the Statements\/Invoices sub\-section$/) do
  on_page CompanyServicePermissions do |page|
    page.statement_invoices
  end

end


Then(/^I will not see Business Card Statements$/) do
  on_page CompanyServicePermissions do |page|
    begin
      page.business_card_statement
    rescue
      puts ("Business Card Statement Has been removed from company service permission")
    end
  end
end

And(/^the Enable Payment Center entitlement exists and is disabled$/) do
  step "my company is entitled to Payment Center in Company Administration"
end

When(/^I view the Payments & Transfers section on the Company Service Permissions tab$/) do
  on_page CompanyServicePermissions do |page|
      raise "Payments & Transfers section does not exist" unless page.payments_transfers_title
  end
end

When(/^I view the Additional Payment Services subsection under the Payments & Transfers section$/) do
  on_page CompanyServicePermissions do |page|
    raise "Payments & Transfers section does not exist" unless page.payments_transfers_title
    raise "The Additional Payment Services subsection does not exist" unless page.subsectionExists?("Additional Payment Services")
  end
end

Then(/^I will see the following subheaders and service entitlements$/) do |entitlement_title_table|
  on_page CompanyServicePermissions do |page|
    entitlement_title_table.hashes.each do |row|
      comp_title = row['comp_title']
      comp_entitlement = row['comp_entitlement']
      raise "The subheader #{comp_title} does not exist" unless page.subheaderExists?(comp_title)
      raise "The entitlement #{comp_entitlement} does not exist" unless page.getEntitlementRow(comp_entitlement)
    end

  end
end

When(/^my company is entitled to Payment Center in Company Administration$/) do
  on_page CompanyServicePermissions do |page|
    page.isEntitledToPaymentCenter?
  end
end