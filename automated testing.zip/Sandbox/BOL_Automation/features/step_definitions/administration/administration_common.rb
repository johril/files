require 'yaml'

password = ""

And /^I will see the new user has been created$/ do
  on_page UserList do |page|
    page.goto()
    page.getUserLink($test_create_user['user_id']).nil?.should == false
  end
end

And /^I have created a new user with full access$/ do
  on_page AddNewUser do |page|
    page.goto()

    page.userId = $test_create_user['user_id']
    page.firstName = $test_create_user['first_name']
    page.lastName = $test_create_user['last_name']
    page.email = "test@test.com"
    page.businessPhone = "123-456-7890"
    page.address = "123 Test St"
    page.city = "Columbus"
    page.state = "OH"
    page.zip = "43230"
    page.copyEntitlements = "Give User Full Access"
    page.addUser
    if page.newPassword? == true
      password = page.newPassword
    end
  end
end

Then /^I am logged into Bol as the new user and change the password$/ do
  visit_page (LoginPage)

  on_page LoginPage do |page|
    page.company = $test_create_user['company_id']
    page.user = $test_create_user['user_id']
    page.password = PASSWORD
    page.login
    sleep(3.00)
    page.oldPassword = PASSWORD
    page.newPassword = $test_create_user['password']
    page.newConfirmPassword = $test_create_user['password']

    begin
      page.changePassword
      page.wait_until(20) {page.text.include? "Your password has been changed successfully."}
      page.continueToBOL
    rescue

      # error handling here to ensure tests can continue even in the
      # non-unlikely event that the reporting svc is not responding
    ensure
      page.wait_until {@browser.title == "OVERVIEW"}
    end
  end
end

And /^I can delete the new user I have created$/ do
  on_page UserList do |page|
    page.goto()
    page.wait_until {page.text.include? "Company Users"}
    page.getUserLink($test_create_user['user_id']).click
  end

  on_page EditUser do |page|
    page.wait_until {page.text.include? "Edit User"}
    page.deleteButton
    sleep(1)
    alert = @browser.switch_to.alert
    alert.accept
    page.wait_until(20) {page.text.include? "User " + $test_create_user['user_id'] + " has been Deleted."}
    page.text.include? "User " + $test_create_user['user_id'] + " has been Deleted."
  end
end

When /^I have created a new user with entitlements copied from another user with full access$/ do
  on_page AddNewUser do |page|
    page.goto()

    page.userId = $test_create_user['user_id']
    page.firstName = $test_create_user['first_name']
    page.lastName = $test_create_user['last_name']
    page.email = "test@test.com"
    page.businessPhone = "123-456-7890"
    page.address = "123 Test St"
    page.city = "Columbus"
    page.state = "OH"
    page.zip = "43230"
    page.copyEntitlements = $full_access_user['list_display_name']
    page.addUser

  end
end

When /^I can update the user profile information and verify that it was updated for the new user$/ do
  first_name = random_string()
  last_name = random_string()
  email = random_string() + '@' + random_string() + '.com'
  address = random_string()
  address2 = random_string()
  city = random_string()
  business_phone = random_number(100,999).to_s + '-' + random_number(100,999).to_s + '-' + random_number(1000,9999).to_s
  business_phone_ext = random_number(100,999)
  business_mobile = random_number(100,999).to_s + '-' + random_number(100,999).to_s + '-' + random_number(1000,9999).to_s
  personal_phone = random_number(100,999).to_s + '-' + random_number(100,999).to_s + '-' + random_number(1000,9999).to_s
  personal_phone_ext = random_number(100,999)
  personal_mobile = random_number(100,999).to_s + '-' + random_number(100,999).to_s + '-' + random_number(1000,9999).to_s
  alternate_phone = random_number(100,999).to_s + '-' + random_number(100,999).to_s + '-' + random_number(1000,9999).to_s
  alternate_phone_ext = random_number(100,999)
  fax = random_number(100,999).to_s + '-' + random_number(100,999).to_s + '-' + random_number(1000,9999).to_s
  zip = random_number(10000,99999)
  state_index = random_number(1,50)

  on_page UserList do |page|
    page.goto()
    page.getUserLink($test_create_user['user_id']).click
  end

  on_page EditUser do |page|
    page.wait_until {page.text.include? "Edit User"}
    page.firstName = first_name
    page.lastName = last_name
    page.email = email
    page.address = address
    page.address2 = address2
    page.city = city
    page.businessPhone = business_phone
    page.businessPhoneExt = business_phone_ext
    page.businessMobile = business_mobile
    page.personalPhone = personal_phone
    page.personalPhoneExt = personal_phone_ext
    page.personalMobile = personal_mobile
    page.alternatePhone = alternate_phone
    page.alternatePhoneExt = alternate_phone_ext
    page.fax = fax
    page.zip = zip
    page.state = page.state_element.options[state_index].text

    page.updateButton

    page.wait_until(20) {page.text.include? "User has been successfully updated."}
  end

  on_page UserList do |page|
    page.goto()
    page.wait_until {page.text.include? "Company Users"}
    page.getUserLink($test_create_user['user_id']).click
  end

  on_page EditUser do |page|
    page.wait_until {page.text.include? "Edit User"}
    page.firstName.should == first_name
    page.lastName.should == last_name
    page.email.should == email
    page.address.should == address
    page.address2.should == address2
    page.city.should == city
    page.businessPhone.should == business_phone
    page.businessPhoneExt.should == business_phone_ext.to_s
    page.businessMobile.should == business_mobile
    page.personalPhone.should == personal_phone
    page.personalPhoneExt.should == personal_phone_ext.to_s
    page.personalMobile.should == personal_mobile
    page.alternatePhone.should == alternate_phone
    page.alternatePhoneExt.should == alternate_phone_ext.to_s
    page.fax.should == fax
    page.zip.should == zip.to_s
    page.state.should == page.state_element.options[state_index].text

  end

end

And /^my company and my user is entitled to the "(.*?)" service permission$/ do |functionDisplayText|
  CommonInfo.EntitleUserToFunction($bol_user['company_id'], $bol_user['user_id'], functionDisplayText)
end

And /^my user is not entitled to the "(.*?)" service permission$/ do |functionDisplayText|
  CommonInfo.UnEntitleUserFromFunction($bol_user['company_id'], $bol_user['user_id'], functionDisplayText)
end

And /^approvals are turned (.*?) for my company$/ do |status|
  CommonInfo.UpdateCompanyApprovals($bol_user['company_id'], status == "on")
end

#does not support token. Token Required is defaulted to 0
And /^"(.*?)" is set to "(.*?)" in Company Settings$/ do  |displayText, modifiedValue|
  CommonInfo.UpdateCompanySettings($bol_user['company_id'], displayText, modifiedValue, 0)
end

And /^the new user is not entitled to the "(.*?)" service permission$/ do |functionDisplayText|
  CommonInfo.UnEntitleUserFromFunction($test_create_user['company_id'], $test_create_user['user_id'], functionDisplayText)
end