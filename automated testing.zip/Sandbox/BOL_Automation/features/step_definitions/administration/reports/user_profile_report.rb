require 'yaml'

And /^I navigate to Administration>> Reports >> User Profile$/ do
  on_page UserProfileReport do |page|
    page.goto()
  end
end


And /^I select BOLUser$/ do
    on_page UserProfileReport do |page|
      chk = page.selectUser($bol_user['user_id'])

      @browser.execute_script("document.getElementById('" + chk.attribute("id") + "').checked = true")

    end


end


When /^I click View Report$/ do
  on_page UserProfileReport do |page|
    page.viewReportButton
    page.wait_until(60) {page.text.include? "User Information"}
  end

end


And /^I  will see Payment Center as the group and Enable Payment Center as the function under Group\/Functions$/ do
  on_page UserProfileReport do |page|
    page.paymentCenterGroup?.should
    page.paymentCenterFunction?.should
  end
end