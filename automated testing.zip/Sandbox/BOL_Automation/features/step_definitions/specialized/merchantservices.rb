When(/^I navigate to Specialized >> Merchant Services$/) do
  on_page MerchantServices do |page|
    page.goto()
  end
end

When(/^I click on 'Log in to Merchant Services'$/) do
  on_page MerchantServices do |page|
    begin
      page.loginButton
    rescue Errno::ECONNREFUSED
    end
  end
end

Then(/^I will be redirected to the Merchant Services third-party website$/) do
  begin
    @browser.switch_to.window (@browser.window_handles.last)
    (@browser.current_url.include? "myclientline.net").should
  rescue Errno::ECONNREFUSED
  end

end

Then(/^I will see a menu item for 'Merchant Services' under the 'Specialized' header$/) do
  on_page OverviewPage do |page|
    page.merchant_services?
  end
end
