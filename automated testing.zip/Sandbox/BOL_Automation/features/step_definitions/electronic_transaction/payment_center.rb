Then /^I am redirected to the Payment Center website$/ do
  @browser.switch_to.window (@browser.window_handles.last)

  @current_page.wait_until(30) { (@browser.current_url.include? "dvliweb01.huntington.com") }

  (@browser.current_url.include? "dvliweb01.huntington.com").should

end