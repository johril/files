
And(/^I will see "PAYMENTS & TRANSFERS" instead of Electronic Transaction/) do
  @menuIem = "PAYMENTS & TRANSFERS"
  on_page OverviewPage do |page|
    page.payments_transfers  ==  @menuIem
  end
end

When /^I select Payments & Transfers tab$/ do
  on_page OverviewPage do |page|
    page.payments_transfers?
  end
end

Then /^I will see "Additional Payment Services" in the submenu$/ do
  on_page AdditionalPaymentServices do |page|
    page.additional_payment_services?
  end
end

When /^I click Additional Payment Services$/ do
  on_page AdditionalPaymentServices do |page|
    page.goto()
  end
end

Then /^I will see SmartTax, PowerPay Card and Payroll$/ do
  on_page AdditionalPaymentServices do |page|
    page.smart_tax
    page.power_pay_card
    page.payroll
  end
end

And /^I will see following message :$/ do |table|
  table.map_headers! { |header| header.downcase }
  expected_lines = table.hashes

  on_page AdditionalPaymentServices do |page|
    actual_lines = page.error_message.split("\n")

    not_authorized_line =  expected_lines[0]["message"]
    not_authorized_line.should  == actual_lines[0]

    not_authorized_help_line =  expected_lines[1]["message"]
    not_authorized_help_line.should  == actual_lines[1]
  end
end

And /^I navigate to Payments & Transfers >> Additional Payment Services$/ do
  on_page AdditionalPaymentServices do |page|
    page.goto()
  end
end

And /^I click on 'Log in to Payroll'$/ do
  on_page AdditionalPaymentServices do |page|
    page.payrollButton
  end
end

And /^I click on 'Log in to SmartTax'$/ do
  on_page AdditionalPaymentServices do |page|
    page.smartTaxButton
  end
end

And /^I click on 'Log in to PowerPay Card'$/ do
  on_page AdditionalPaymentServices do |page|
    page.powerPayButton
  end
end

Then /^I will be redirected to the Payroll services page$/ do
  @browser.switch_to.window (@browser.window_handles.last)

  @current_page.wait_until(30) { (@browser.current_url.include? "businessonlinepayroll") }

  (@browser.current_url.include? "businessonlinepayroll").should == true

end

Then /^I will be redirected to the SmartTax service page$/ do
  @browser.switch_to.window (@browser.window_handles.last)

  @current_page.wait_until(30) { (@browser.current_url.include? "govone.com") }

  (@browser.current_url.include? "govone.com").should == true

end

Then /^I will be redirected to the PowerPay Card service page$/ do
  @browser.switch_to.window (@browser.window_handles.last)

  @current_page.wait_until(30) { (@browser.current_url.include? "paycardsolutions.com") }

  (@browser.current_url.include? "paycardsolutions.com").should == true

end

Then /^I will receive a message that I am not authorized for the service$/ do
  @browser.switch_to.window (@browser.window_handles.last)
  @current_page.wait_until(30) { (@browser.current_url.include? "BusinessOnlineError") }
  on_page AdditionalPaymentServices do |page|
    (page.text.include? "You are currently not entitled to this service").should == true
  end
end
