require 'yaml'

And(/^I navigate to the Transfer Activity$/) do
  on_page AccountTransfer do |page|
    page.navigate_to_activity
  end
  on_page TransferActivity do |page|
    page.confirm_page_loaded
  end
end


Then(/^I select User, accounts and set my date$/) do
  on_page TransferActivity do |page|
    page.select_user($bol_user['list_display_name'])
  end
end


When(/^I click Search I will see the transaction results as following:$/) do  |table|
  @currentUserId = $bol_user['user_id']
  @amount = '$0.02'


  table.map_headers! { |header| header.downcase }
  expected_lines = table.hashes

  on_page TransferActivity do |page|
    @sourceAccountNumber = page.get_result_formatted_account($bol_user['accounts']['dda1'])
    @destinationAccountNumber = page.get_result_formatted_account($bol_user['accounts']['dda2'])
    page.submit_request(true)

    effective_date_header = expected_lines[0]["column header"]
    expect(page.get_results_effective_date(0)).to eq(effective_date_header)

    from_acct_header = expected_lines[1]["column header"]
    expect( page.get_results_from_account(0)).to eq(from_acct_header)

    to_acct_header = expected_lines[2]["column header"]
    expect(page.get_results_to_account(0)).to eq(to_acct_header)

    amount_header = expected_lines[3]["column header"]
    expect(page.get_results_amount(0)).to eq(amount_header)

    frequency_header = expected_lines[4]["column header"]
    expect(page.get_results_frequency(0)).to eq(frequency_header)

    start_date_header = expected_lines[5]["column header"]
    expect(page.get_results_start_end_date(0)).to eq(start_date_header)

    status_confirmation_header = expected_lines[6]["column header"]
    expect(page.get_results_status(0)).to eq(status_confirmation_header)

    user_id_header = expected_lines[7]["column header"]
    expect(page.get_results_user(0)).to eq(user_id_header)

    transaction_date_line = $currentDate.strftime("%-m/%-d/%Y")
    expect(page.get_results_effective_date(1)).to eq(transaction_date_line)

    #verify actual data
    expect(page.get_results_from_account(1)).to eq(@sourceAccountNumber)
    expect(page.get_results_to_account(1)).to eq(@destinationAccountNumber)
    expect(page.get_results_amount(1)).to eq(@amount)

    expected_frequency = expected_lines[4]["value"]
    expect(page.get_results_frequency(1)).to eq(expected_frequency)

    expected_start_date = $currentDate.strftime("%-m/%-d/%Y") << "\nN/A"
    expect(page.get_results_start_end_date(1)).to eq(expected_start_date)

    expected_status = $confirmation_number
    expected_status = "Successful\n" << expected_status
    expect(page.get_results_status(1)).to eq(expected_status)

    #expected_user = @currentUserId << "\n" << $currentDate.strftime("%-m/%-d/%Y %I:%M %p")
    #expect(page.get_results_user(1)).to eq(expected_user)
    #can't do this assertion because we don't get the transaction date time in the result message



  end

end
