
require 'yaml'


And(/^I navigate to the Account Transfer >> Initiate Transfer page$/) do
  on_page AccountTransfer do |page|
    page.goto()
  end
end

And (/^I input a one-time transfer$/) do
  on_page AccountTransfer do |page|
    $currentDate = Date.today
    page.configure_onetime_transfer($bol_user['accounts']['dda1'],
                           $bol_user['accounts']['dda2'],
                           '.02',
                           $currentDate.strftime("%m/%d/%Y"))
    sleep(1)
  end
end

When (/^I click Schedule transfer button  I will see the success message$/) do
  on_page AccountTransfer do |page|
    page.schedule_transfer_with_success
  end
end

Then /^I will see a same day one\-time transfer success message with the following:$/ do |table|
  # table is a Cucumber::Ast::Table
  @currentUserId = $bol_user['user_id']
  @amount = '0.02'
  table.map_headers! { |header| header.downcase }
  expected_lines = table.hashes

  on_page(AccountTransfer) do |page|
    @sourceAccountNumber = page.get_formatted_account_message($bol_user['accounts']['dda1'])
    @destinationAccountNumber = page.get_formatted_account_message($bol_user['accounts']['dda2'])
    actual_lines = page.success_message.split("\n")

    successful_transfer_line = expected_lines[0]["value"]
    successful_transfer_line.should == actual_lines[0]

    confirmation_number_line = Regexp.new("^#{expected_lines[1]['label']} \\d{13}$")
    confirmation_number_line.match(actual_lines[1]).should_not == nil
    $confirmation_number = actual_lines[1].delete 'Confirmation #:'

    from_account_line = "#{expected_lines[2]["label"]} #{@sourceAccountNumber}"
    from_account_line.should == actual_lines[2]

    to_account_line = "#{expected_lines[3]["label"]} #{@destinationAccountNumber}"
    to_account_line.should == actual_lines[3]

    user_id_line = "#{expected_lines[4]["label"]} #{@currentUserId}"
    user_id_line.should == actual_lines[4]

    amount_line = "#{expected_lines[5]["label"]} $#{@amount}"
    amount_line.should == actual_lines[5]

    frequency = "#{expected_lines[6]["label"]} #{expected_lines[6]["value"]}"
    frequency.should == actual_lines[6]

    transaction_date_line = "#{expected_lines[7]["label"]} #{$currentDate.strftime("%m/%d/%Y")}"
    transaction_date_line.should == actual_lines[7]

    transfer_date_line = "#{expected_lines[8]["label"]} #{$currentDate.strftime("%m/%d/%Y")}"
    transfer_date_line.should == actual_lines[8]
    $one_time_transfer_date =  actual_lines[8].delete 'Transfer Date: '

    effective_date_line = "#{expected_lines[9]["label"]} #{$currentDate.strftime("%m/%d/%Y")}"
    effective_date_line.should == actual_lines[9]

    actual_lines[10].should == ""

    transfer_successful_line = expected_lines[11]["value"]
    transfer_successful_line.should == actual_lines[11]

    actual_lines[12].should == ""

    future_dated_disclaimer_line = expected_lines[13]["value"]
    future_dated_disclaimer_line.should == actual_lines[13]


  end
end


Then(/^I will see the Business Card accounts to which I am entitled are displayed in the dropdown$/) do
  #Todo: need to get this done
end

And(/^the account should follow standard masking and truncating rules$/) do
#Todo:  pending # express the regexp above with the code you wish you had
end

When /^information should contain  Masked Account Number and  Account Nickname and  Available Cash$/ do
  #Todo: need to get this done
end

When(/^I select a Business Card \(RCC\) account in the Transfer From dropdown box$/) do

end

Then(/^I will see that the Frequency dropdown box is disabled and defaulted to One Time and cannot be changed\.$/) do
#Todo: need to get this done
end

And(/^I have Business Card \(RCC\) and DDA accounts entitled to Account Transfer$/) do
#Todo: need to get this done
end

When(/^I select SCHEDULE TRANSFER$/) do
#Todo: Need to get this done
end


Then(/^I will see a pop up message with "(.*?)"$/) do |arg1|
#Todo: Need to get this done
end


And(/^I will see an OK button$/) do
#Todo: need to get this done
end

And(/^I will see a Cancel button$/) do
  #Todo: need to get this done
end

When(/^I select the Cancel button$/) do
#Todo: need to get this done
end

#And(/^I will remain on the Account Transfer – Initiate Transfer page with all of my information entered as before$/) do
# pending # express the regexp above with the code you wish you had
#end


When(/^I select the OK button$/) do
#Todo: need to get this done
end

Then(/^the pop\-up box will disappear$/) do
#Todo: need to get this done
end

And(/^my Transfer will be processed\.$/) do
#Todo: need to get thi done
end

Then(/^the amount for the transfer will be submitted$/) do
#Todo: need to get this done
end

And(/^I will see the following success message:"(.*?)"$/) do |arg1|
#Todo: need to get this done
end
And /^I will remain on the Account Transfer and Initiate Transfer page with all of my information entered as before$/ do
  #Todo: need this done
end

And(/^I have Business Card accounts entitled to Account Transfer$/) do
  #Todo: pending # express the regexp above with the code you wish you had
end

Then(/^I will see the closed Business Card accounts to which I am entitled are NOT displayed in the dropdown$/) do
  #Todo:pending # express the regexp above with the code you wish you had
end