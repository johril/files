When (/^I navigate to Home >> Explore All Services/) do
  on_page ExploreAllServices do |page|
    page.goto()
  end
end

And (/^I will see that the service description for "(.*?)" is "(.*?)"/) do |serviceName, serviceDescription|
   on_page ExploreAllServices do |page|
       page.getDescriptionTextForService(serviceName).should == serviceDescription
   end
end