require 'yaml'

Given /^I am logged into Bol as a  (.*)$/ do |user|
  visit_page (LoginPage)

  on_page LoginPage do |page|
    if user == 'BOLUser'
      $bol_user = FigNewton.users.bol_user.to_hash
    elsif user == 'InvalidBOLUser'
      $bol_user = FigNewton.users.bol_bad_user.to_hash
    elsif user == 'ApprovalsUser'
      $bol_user = FigNewton.users.bol_approval_user.to_hash
    elsif user == 'NewUser'
      $bol_user = FigNewton.users.test_create_user.to_hash
    elsif user == 'NotEntitledUser'
      $bol_user = FigNewton.users.bol_user_not_entitled.to_hash
    else
      $bol_user = FigNewton.users.bol_user.to_hash
    end

    page.company = $bol_user['company_id']
    page.user = $bol_user['user_id']
    page.password = $bol_user['password']

    begin
      page.login
    rescue
      # error handling here to ensure tests can continue even in the
      # non-unlikely event that the reporting svc is not responding
    ensure
      page.wait_until(90) {@browser.title == "OVERVIEW" or "WELCOME TO BUSINESS ONLINE"}
    end
  end
end

And /^I * log out of BOL$/ do
  log_out_from_bol()
  #on_page BolPageObjectBase do |page|
  #  page.log_out
  #  page.wait_until { page.text.include? "Welcome to Business Online" }
  #end
end


When(/^I log out and log in as a (.*)/) do |user|
  log_out_from_bol()
  step "I am logged into Bol as a  #{user}"
end
