BODY_IFRAME = "Body"
WORKSPACE_IFRAME = "Workspace"
NAV_IFRAME = "Navigation"


Given /^I am logged into RM as an  RMUser$/ do



  on_page BankAdminHome do |page|

      page.goto()

      @browser.switch_to.default_content
      @browser.switch_to.frame BODY_IFRAME
      @browser.switch_to.frame WORKSPACE_IFRAME

      page.userID = "admin"
      @browser.execute_script("document.getElementById('PIN').value = '123456'")

      page.submitButton
      page.wait_until(60) { page.text.include? "LOGIN AUTHORIZED"}
      page.continueButton

      page.wait_until(60) { page.text.include? "Welcome to Relationship Manager"}
      #switch back out to main window, then to frame
      @browser.switch_to.default_content
      @browser.switch_to.frame BODY_IFRAME
      @browser.switch_to.frame NAV_IFRAME

      page.customLink


      @browser.switch_to.default_content
      @browser.switch_to.frame BODY_IFRAME
      @browser.switch_to.frame WORKSPACE_IFRAME

      page.wait_until(60) { page.text.include? "Menu Choice"}
      page.businessOnlineMenuLink
  end



end