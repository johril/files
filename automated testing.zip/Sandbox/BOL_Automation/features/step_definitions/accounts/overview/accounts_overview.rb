##OVERVIEW Page

Then(/^I will see "(.*?)" account type$/) do |account_type|
  on_page OverviewPage do |page|
    page.return_account_number(account_type)
  end
end

Then /^I click the Transaction search link$/ do
  on_page OverviewPage do |page|
    page.transactionSearch_id
    page.wait_until {@browser.title == "TRANSACTION SEARCH"}
  end
end

Given(/^I am on Overview page as "(.*?)" with "(.*?)"account$/) do |user, account_type|
  step "I am logged into Bol as a  #{user}"
  step "I will see \"#{account_type}\" account type"
  step "I will see \"#{account_type}\" account type"
end

Then(/^"(.*?)" Total for my "(.*?)" account is correct$/) do |total, account_type|
  on_page OverviewPage do |page|
    page.account_total(total, account_type)
  end
end





