Then(/^I will see a success message with text "(.*?)"$/) do |message|
  @current_page.wait_until(80) { @current_page.success_message? }
  @current_page.success_message.should include message
end

Then(/^I will see a validation error message with text "(.*?)"$/) do |message|
  @current_page.wait_until(80) { @current_page.error_messages }
  @current_page.error_messages.should include message
end

Then(/^I will see the title of the page is "(.*?)"$/) do |title|
  @current_page.wait_until(80) {title.should == @browser.title}
end

Then(/^I will see the page contains the text "([^"]*)"$/) do |text|
  @current_page.text.should include text
end

When(/^I can close the popup window$/) do
  begin
    @browser.close
  rescue Errno::ECONNREFUSED
  end
end

Then(/^an error page will popup that says I am not entitled to this service$/) do
  @browser.switch_to.window (@browser.window_handles.last)
  @current_page.wait_until(30) {@browser.current_url.include? "BusinessOnlineError"}
  @current_page.text.should include "You are currently not entitled to this service."
end

Then(/^I click on the "([^"]*)" link under the "([^"]*)" menu$/) do |linkText, parentMenuItemText|
  on_page BOLMenu do |page|
     page.navigate(parentMenuItemText, linkText)
  end
end

Then (/^I will not see the "([^"]*)" link under the "([^"]*)" menu$/) do |linkText, parentMenuLinkText|
  on_page BOLMenu do |page|
     !page.isLinkVisible(linkText).should
  end
end