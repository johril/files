require 'rubygems'
require 'selenium-webdriver'
require 'page-object'
require 'page-object/page_factory'
require 'fig_newton'

#PageObject configuration
World(PageObject::PageFactory)
PageObject.javascript_framework = :jquery

$base_url = FigNewton.base_url
$bankadmin_url = FigNewton.rm_url
$db_commoninfo = FigNewton.databases.CommonInfo.to_hash #converted to hash due to errors applying pack on key/iv/password


#browser config
if ENV['browser'].nil? == false
  if ENV['browser'] == 'firefox'
    $browser = Selenium::WebDriver.for :firefox
  elsif ENV['browser'] == 'chrome'
    $browser = Selenium::WebDriver.for :chrome
  else
    $browser = Selenium::WebDriver.for :ie
  end
else
  $browser = Selenium::WebDriver.for :firefox
end

$browser.manage.window.maximize

#user config
$bol_user = FigNewton.users.bol_user.to_hash
$full_access_user = FigNewton.users.bol_user.to_hash
$test_create_user = FigNewton.users.test_create_user.to_hash




