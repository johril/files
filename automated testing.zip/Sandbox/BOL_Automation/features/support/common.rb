def log_out_from_bol()
  on_page LoginPage do |page|
    if page.log_out?
      page.log_out()
    end
  end
end


def login_with(company_id, user_id, password)
  visit_page(LoginPage)

  on_page(LoginPage) do |login_page|
    login_page.login_with(company_id, user_id, password)
  end

  on_page(BolPageObjectBase) do |current_page|
    # Wait until Log Out link available (that is, user is logged in.)
    current_page.wait_until(180) do
      current_page.log_out?
    end
  end
end

def check_checkbox(checkboxId)
  @browser.execute_script("document.getElementById('" + checkboxId + "').checked = true")
end

def uncheck_checkbox(checkboxId)
  @browser.execute_script("document.getElementById('" + checkboxId + "').checked = false")
end

def random_string()
  rand(36**10).to_s(36)
end

def random_number(min, max)
  Random.new.rand(min..max)
end