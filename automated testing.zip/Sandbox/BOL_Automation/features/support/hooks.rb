require 'net/smtp'


Before do |scenario|
  puts "Starting scenario:  #{scenario.name}"
end

After do |scenario|
  puts "Failed scenario : #{scenario.name}" if scenario.failed?
end

Before do
  @browser = $browser
end

Before do |scenario|
  @browser = $browser
end


After do |scenario|
  begin
    if (scenario.failed?)
      filename_without_extension = "#{scenario.title}-#{DateTime.now.strftime("%Y-%m-%d-%H.%M.%S.%L")}"
      @browser.save_screenshot("C:\\screenshots\\FAILED-#{filename_without_extension}.png")
      encoded_img = @browser.screenshot_as(:base64)
      embed("data:image/png;base64,#{encoded_img}",'image/png')


      # TODO: Write a log file indicating the scenario.exception.message

    end
  rescue
    # TODO: Write log indicating the scenario screen shot couldn't be saved
    #ensure
    # log_out_from_bol()
  ensure
    #CommonInfo.EntitleCompanyAndUserToAllFunctions($bol_user['company_id'], $bol_user['user_id'])
  end
end

Before('@NewUser') do
  if !$createNewUser
    step "approvals are turned off for my company"
    step "I am logged into Bol as a  BOLUser"
    step "I can delete the new user I have created"
    step "I have created a new user with full access"
    step "I am logged into Bol as the new user and change the password"
    step "approvals are turned on for my company"
    $createNewUser = true
  end
end


=begin
at_exit do

  filename = "FirefoxRunResult.html"
# Read a file and encode it into base64 format
  filecontent = File.read(filename)
  encodedcontent = [filecontent].pack("m")   # base64

  marker = "AUNIQUEMARKER"

  body =<<EOF
Attached is our weekly automation run result.

Automation test suite will be executed every Friday evening at 5:00PM. Hopefully we will have all green soon.

Above test suite was executed in following environment
#$base_url
EOF

# Define the main headers.
  @time = Time.new


  part1 =<<EOF
From: BOL_AUTOMATION <donotreply@huntington.com>
To: BOL Automation Team <automation@huntington.com>;Sarala Pandey <Sarala.Pandey@huntington.com>
Subject: Automation Run Result #@time
MIME-Version: 1.0
Content-Type: multipart/mixed; boundary=#{marker} ;html
--#{marker}
EOF

# Define the message action
  part2 =<<EOF
Content-Type: text/plain
Content-Transfer-Encoding:8bit

#{body}
--#{marker}
EOF

# Define the attachment section
  part3 =<<EOF
Content-Type: multipart/mixed; name=\"#{filename}\"
Content-Transfer-Encoding:base64
Content-Disposition: attachment; filename="#{filename}"

#{encodedcontent}
--#{marker}--
EOF

  mailtext = part1 + part2 + part3

  bol_mailinglist = ['Sarala.Pandey@huntington.com','Alex.Engelmann@huntington.com','Anupama.Kashyap@contractor.huntington.com','Bhupesh.Dahal@contractor.huntington.com','Brian.Dunzweiler@contractor.huntington.com','David.Houchens@contractor.huntington.com','Duncan.George@huntington.com','Inga.Stimmel@huntington.com','John.Riley@contractor.huntington.com','Kris.Wear@huntington.com','Laura.Elliott@huntington.com','Rick.Taylor@huntington.com','Tyler.Jones@huntington.com','Venkata.Gembali@contractor.huntington.com']
    mailinglist = ['bhupesh.dahal@contractor.huntington.com']
  begin
    Net::SMTP.start('mailgw.huntington.com', 25) do |smtp|
      smtp.sendmail(mailtext, 'donotreply@huntington.com',
                    [mailinglist])
    end
  rescue Exception => e
    print "Exception occured: " + e
  end

  $browser.quit


end

=end

