require 'yaml'
require 'active_record'

class CommonInfo < ActiveRecord::Base
  decipher = OpenSSL::Cipher::AES.new(256, :CBC)
  decipher.decrypt
  decipher.key = $db_commoninfo['key'].pack('c*')
  decipher.iv = $db_commoninfo['iv'].pack('c*')


  ActiveRecord::Base.establish_connection(
      :adapter => 'sqlserver',
      :host => $db_commoninfo['server_name'],
      :database => $db_commoninfo['db_name'],
      :username => $db_commoninfo['user_name'],
      :password => decipher.update($db_commoninfo['password'].pack('c*')) + decipher.final
  )

  def self.EntitleUserToFunction(companyId, signOnId, functionDisplayText)
    self.connection.execute("exec AutomatedTest_EntitleUserToFunction '#{companyId}', '#{signOnId}', '#{functionDisplayText}'")
  end

  def self.UnEntitleUserFromFunction(companyId, signOnId, functionDisplayText)
    self.connection.execute("exec AutomatedTest_UnentitleUserFromFunction '#{companyId}', '#{signOnId}', '#{functionDisplayText}'")
  end

  def self.EntitleCompanyAndUserToAllFunctions(companyId, signOnId)
    self.connection.execute("exec AutomatedTest_EntitleCompanyAndUserToAllFunctions '#{companyId}', '#{signOnId}'")
  end

  def self.UpdateCompanyApprovals(companyId, enabled)
    self.connection.execute("exec AutomatedTest_ToggleApprovalsForCompany '#{companyId}', " + (enabled ? "1" : "0"))
  end

  def self.EntitleUserAndAccountToFunction(companyId, signOnId, functionDisplayText, accountNumber)
    self.connection.execute("exec AutomatedTest_EntitleUserAccountToFunction '#{companyId}', '#{signOnId}', '#{functionDisplayText}', '#{accountNumber}'")
  end

  def self.UnentitleUserAndAccountFromFunction(companyId, signOnId, functionDisplayText, accountNumber)
    self.connection.execute("exec AutomatedTest_UnentitleUserAccountFromFunction '#{companyId}', '#{signOnId}', '#{functionDisplayText}', '#{accountNumber}'")
  end

  def self.EntitleUserAndAccountToService(companyId, signOnId, serviceDisplayText, accountNumber)
    self.connection.execute("exec AutomatedTest_EntitleUserAccountToService '#{companyId}', '#{signOnId}', '#{serviceDisplayText}', '#{accountNumber}'")
  end

  def self.UnentitleUserAndAccountFromService(companyId, signOnId, serviceDisplayText, accountNumber)
    self.connection.execute("exec AutomatedTest_UnentitleUserAccountFromService '#{companyId}', '#{signOnId}', '#{serviceDisplayText}', '#{accountNumber}'")
  end

  def self.UpdateCompanySettings(companyId, displayText, modifiedvalue, tokenRequired)
    self.connection.execute("exec AutomatedTest_CompanySettingsUpdate '#{companyId}', '#{displayText}', '#{modifiedvalue}', '#{tokenRequired}'")
  end

end