
class UserList < BolPageObjectBase
  HEADER_TEXT = 'USER'

  page_url($base_url + "CustomerAdmin/UserList.aspx?Page=ADMINISTRATION_USER_USERLIST" )
  span(:page_title, :id=>"pageInfo_lblPageTitle")
  link(:function_matrix_tab, :link_text=>"FUNCTION MATRIX")

  table(:usersTable, :id=> "mainContent_DGUsers")






  def getUserLink(userId)
    usersTable_element.link_element(identifier = {:link_text=> userId})
  end
end
