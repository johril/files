
class AddNewUser < BolPageObjectBase

  page_url($base_url + "CustomerAdmin/User.aspx?Add=Y&uID=-1")

  text_field(:userId, :id=> "mainContent_tbSignOnID")
  text_field(:firstName, :id=> "mainContent_tbFirstName")
  text_field(:lastName, :id=> "mainContent_tbLastName")
  text_field(:email, :id=> "mainContent_tbEmail")
  text_field(:businessPhone, :id=> "mainContent_txtPhone")
  text_field(:address, :id=> "mainContent_txtAddress")
  text_field(:city, :id=> "mainContent_txtCity")
  select_list(:state, :id=> "mainContent_ddState")
  text_field(:zip, :id=> "mainContent_txtZip")
  select_list(:copyEntitlements, :id=> "mainContent_ddCopyEntitlements")
  link(:addUser, :id=> "mainContent_btAdd")
  div(:newPassword, :xpath=> ".//*[@id='Credentials']/table/tbody/tr[3]/descendant::b")

end
