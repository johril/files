class UserServicePermissions < BolPageObjectBase

  FUNCTION_NAME_COLUMN = 2
  attr_accessor :dirty

  SUBSECTION_COL_IDX = 1
  ENTITLEMENT_COL_IDX = 2
  CHECKBOX_COLUMN = 3

  page_url($base_url + "CustomerAdmin/UserPermissions.aspx")

  select_list(:selectedUser, :id=> "mainContent_ddUsers")
  checkbox(:enablePaymentCenter, :xpath=> ".//*[@id='mainContent_pnl_PAYMENTCENTER']/table/descendant::table[@class='panelContents']/descendant::input[@type='checkbox']")
  checkbox(:enableSmartTax, :xpath=> ".//*[@id='mainContent_pnl_ADDITIONALPAYMENTSERVICES']/table/descendant::table[@class='panelContents']/descendant::span[@functionname='ET_SMARTTAX']/input[@type='checkbox']")
  checkbox(:enablePowerPayCard, :xpath=> ".//*[@id='mainContent_pnl_ADDITIONALPAYMENTSERVICES']/table/descendant::table[@class='panelContents']/descendant::span[@functionname='ET_PAYROLLCARD']/input[@type='checkbox']")
  checkbox(:enablePayroll, :xpath=> ".//*[@id='mainContent_pnl_ADDITIONALPAYMENTSERVICES']/table/descendant::table[@class='panelContents']/descendant::span[@functionname='IR_PAYROLL_LINK']/input[@type='checkbox']")  
  link(:updatePermissions, :id=> "mainContent_btnUpdate")

  div(:firstPermissionsContainer, :class=> "HeadlineText")
  div(:container, :class=> "DialogGridContent")
  link(:user_tab,:link_text=> "User")
  link(:user_function_tab, :id=> "MenuLevelThree_87")
  link(:user_service_permission, :text=>"User Service Permissions")
  div(:main_content_panel, :id=>  "mainContent_pnl_ADMIN")
  div(:status_message, :id=>"mainContent_valsum1")

  if $OLD_ADMIN_UI
    select_list(:select_user, :id=>"ContentPlaceHolder1_ddUsers")
  else
    select_list(:select_user, :id=>"mainContent_ddUsers")
  end
  cell(:user_service_permission_information_report, :id=>"ctl00$ContentPlaceHolder1$pnl_IR:Caption0")
  cell(:user_service_permission_business_card_statement, :text=>"Business Card Statement")
  cell(:user_function_matrix_page_title, :text=>"User Function Matrix")
  select_list(:select_service_function, :id=>"ContentPlaceHolder1_ddlSelectService")
  link(:service_permission, :text=>"SERVICE PERMISSIONS")

  #information reporting
  div(:information_reporting_section, :id=>'mainContent_pnl_IR')
  table(:information_reporting_entitlements) {|page| page.information_reporting_section_element.table_element.table_element}

  #payment center
  div(:payment_center_section, :id=>"mainContent_pnl_PAYMENTCENTER")
  table(:payment_center_entitlements) {|page| page.payment_center_section_element.table_element.table_element}

  #Additional Payment Services
  div(:additional_payment_services_section, :id=>"mainContent_pnl_ADDITIONALPAYMENTSERVICES")
  table(:additional_payment_services_entitlements) {|page| page.additional_payment_services_section_element.table_element.table_element}

  #ACH
  div(:ach_section, :id=>"mainContent_pnl_ACH")
  table(:ach_entitlements) {|page| page.ach_section_element.table_element.table_element}

  #Wires
  div(:wire_transfers_section, :id=>"mainContent_pnl_WIRE")
  table(:wire_transfers_entitlements) {|page| page.wire_transfers_section_element.table_element.table_element}

  #save
  button(:update_button, :id=>"mainContent_btnUpdate")

  def getCheckboxForPermission(permissionName)
    container_element.cell_element(:text=> permissionName).parent().checkbox_element()
  end

  def subsectionExists?(subsectionName)
    subsections = @browser.find_elements(:css => 'td.custAdminSectionHeader')
    subsections.each do |subsection|
      return true if subsection.text.strip == subsectionName
    end

    return false
  end

  def paymentCenterSectionExists?
    subsectionExists?("Payment Center")
  end

  def checkUncheckEntitlement(span_element)
    span_element.checkbox_elements.each do |checkbox|
      checkbox.check
      checkbox.uncheck
    end
  end

  def checkAndUncheckPaymentCenter
    checkUncheckEntitlement(payment_center_entitlements_element)
  end

  def getAdditionalPaymentSubsection(subsection_text)
    begin
      return getEntitlementRow(additional_payment_services_entitlements_element, subsection_text)
    rescue
      raise "Additional Payment Subsection #{subsection_text} not found"
    end
  end

  def getEntitlementRow(entitlement_section_element, entitlement_text)
    return entitlement_section_element.find {|row| row[ENTITLEMENT_COL_IDX].text == entitlement_text unless row[ENTITLEMENT_COL_IDX].nil?}
  end

  def getAdditionalPaymentEntitlementElement(entitlement_text)
    begin
      return getEntitlementRow(additional_payment_services_entitlements_element, entitlement_text)
    rescue
      raise "Entitlement #{entitlement_text} not found in Additional Payment Subsection"
    end
  end

  def getAdditionalPaymentEntitlement(subsection_text, entitlement_text)
    subsection = getAdditionalPaymentSubsection(subsection_text)
    entitlement = getAdditionalPaymentEntitlementElement(entitlement_text)
  end

  def entitle(checkbox)
    if !checkbox.checked?
      checkbox.check
      dirty = true
    end
  end

  def unentitle(checkbox)
    if checkbox.checked?
      checkbox.uncheck
      dirty = true
    end
  end

  def save
    if dirty
      update_button()
      wait_until(30) { status_message.text.downcase.strip == "user permissions have been updated" }
    end
  end

  def checkEntitlementAndSave(entitlement_element, entitlement_text, do_save = true)
    entitlement_row = entitlement_element.find {|row| row[ENTITLEMENT_COL_IDX].text == entitlement_text unless row[ENTITLEMENT_COL_IDX].nil?}
    checkbox = entitlement_row[CHECKBOX_COLUMN].checkbox_element
    entitle(checkbox)
    save() if do_save
  end

  def entitleUserToPaymentCenter(do_save = true)
    checkEntitlementAndSave(payment_center_entitlements_element, "Enable Payment Center", do_save)
  end

  def entitleUserToACH(do_save = true)
    checkEntitlementAndSave(ach_entitlements_element, "Enable ACH", do_save)
  end

  def entitleUserToWireInquiry(do_save = true)
    checkEntitlementAndSave(wire_transfers_entitlements_element, "Wire Inquiry", do_save)
  end
end

class ModifyAccountNames < BolPageObjectBase
  include PageObject
  page_url($base_url + "CustomerAdmin/Accounts.aspx" )
  div(:edit_account_names, :class=> "DialogCaption")
  table(:grid, :id=> "mainContent_DGAccounts")

  def get_column_header_text(header_text)
    if grid_element[0][header_text].nil?
      ""
    else
      grid_element[0][header_text].text
    end
  end
end
