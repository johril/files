

class UserServiceMatrix < BolPageObjectBase
  page_url($base_url + "CustomerAdmin/UserServices.aspx")

  select_list(:selectedUser, :id=> 'mainContent_ddUsers')
end