class UserFunctionMatrix < BolPageObjectBase
  SELECT_USER_LABEL_TEXT = 'Select a User'

  link(:function_matrix_tab, :link_text=>'FUNCTION MATRIX')
  cell(:business_card_statement_column, :text=>'Business Card Statement')
  label(:select_user_label, :id=>'mainContent_lblSelectUser')
  select_list(:select_user, :id=>'mainContent_ddUsers')
  div(:main_content_panel, :id=>'mainContent_pnl_ADMIN') #if the administration panel is found then...

end