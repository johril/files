# User Profile Report

class UserProfileReport < BolPageObjectBase

  CHECKBOX_COLUMN = 0
  USERNAME_COLUMN = 1


  page_url($base_url + "CustomerAdmin/UserProfileRpt.aspx?Page=ADMINISTRATION_REPORTS_USERPROFILEREPORT")

  table(:usersTable, :id=> "mainContent_SelectUsersDataGrid")
  link(:viewReportButton, :id=> 'mainContent_btUser')

  cell(:paymentCenterGroup, :text=> "Payment Center")
  cell(:paymentCenterFunction, :text=> "Enable Payment Center")


  def selectUser(name)

    selectedRow = usersTable_element.find { |row| row[USERNAME_COLUMN].text == name }
    selectedRow.checkbox_element(identifier = {:index => 0})
  end


end
