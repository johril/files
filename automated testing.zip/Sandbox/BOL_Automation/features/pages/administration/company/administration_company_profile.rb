class CompanyProfile < BolPageObjectBase
  HEADER_TEXT = 'COMPANY'

  #include PageObject
  page_url($base_url + "CustomerAdmin/CompanyProfile.aspx?Page=ADMINISTRATION_COMPANY_COMPANYPROFILE" )
  link(:administration, :link_text=> "ADMINISTRATION")
  span(:page_header, :id=>"pageInfo_lblPageTitle")
  ### Company Tab
  link(:company_tab, :link_text=> "Company")
  div(:company_profile_title, :text=>"Company Information")
  link(:company_service_permission, :link_text=>"SERVICE PERMISSIONS")
  ## Under Company Service Permission
  div(:company_administration, :text=>"Company Information")
  div(:information_reporting, :text=> "Information Reporting")
  div(:statement_invoices, :text=>"Statements/Invoices:")
  div(:business_card_statement, :text=> "Business Card Statement")
  ##########Under Company Function Matrix
  link(:company_function_matrix, :link_text=>"Company Function Matrix")
  cell(:business_card_statement_column, :text=>"Business Card Statement")
  ###############
  link(:company_modify_account_name, :link_text=>"Modify Account Names")
  link(:company_settings, :link_text=>"Company Settings")
  link(:company_profile, :link_text=>"Company Profile")
  link(:company_service_matrix, :link_text=>"Company Service Matrix")

end