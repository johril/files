  require 'nokogiri'

  class CompanyServiceMatrix < BolPageObjectBase
    page_url($base_url + "CustomerAdmin/CompanyServices.aspx")

    table(:serviceMatrixTable, :xpath=> ".//*[@id='mainContent_pnl_1']/table")

    def checkServiceDisabled(html,column)
      doc = Nokogiri::HTML(html)
      table = doc.xpath(".//*[@id='mainContent_pnl_1']/table")
      rows = table.search('tr')[1..-1]
      rows.each do |row|
         if !(row.xpath('string(td[%s]/span/@class)' %[column])  == "aspNetDisabled")
           fail("Company Service Matrix enabled at column : %s" %[column])
         end
      end
    end

    def getPaymentCenterAccounts(html)
      doc = Nokogiri::HTML(html)
      table = doc.xpath(".//*[@id='mainContent_pnl_1']/table")
      rows = table.search('tr')[1..-1]
      rows.each do |row|
        if !(row.xpath('string(td[%s]/span/input/@CHECKED)' %[column]).exists?)
          fail("Company Service Matrix enabled at column : %s" %[column])
        end
      end
    end

  end