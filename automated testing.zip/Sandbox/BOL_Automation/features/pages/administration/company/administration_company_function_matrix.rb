class CompanyFunctionMatrix < BolPageObjectBase
  HEADER_TEXT = 'USER'
  page_url($base_url + "CustomerAdmin/CompanyProfile.aspx?Page=ADMINISTRATION_COMPANY_COMPANYPROFILE" )

  ### Company Tab
  link(:company_tab, :link_text=> "Company")
  ##########Under Company Function Matrix
  link(:company_function_matrix, :link_text=>"Company Function Matrix")
  cell(:business_card_statement_column, :text=>"Business Card Statement")
  link(:function_matrix_tab, :link_text=>"FUNCTION MATRIX")


end