class ModifyAccountNames < BolPageObjectBase
  include PageObject
  page_url($base_url + "CustomerAdmin/Accounts.aspx" )
  div(:edit_account_names, :class=> "DialogCaption")
  table(:grid, :id=> "mainContent_DGAccounts")

  def get_column_header_text(header_text)
    if grid_element[0][header_text].nil?
      ''
    else
      grid_element[0][header_text].text
    end
  end
end