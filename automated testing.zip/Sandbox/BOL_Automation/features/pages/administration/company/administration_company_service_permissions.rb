require 'nokogiri'

class CompanyServicePermissions < BolPageObjectBase
  HEADER_TEXT = 'COMPANY'
  COMPANY_MAINTENANCE_TEXT = 'Company Maintenance'
  page_url($base_url + "CustomerAdmin/CompanyPermissions.aspx")
  span(:page_header, :id=>"pageInfo_lblPageTitle")
  link(:updatePermissions, :id=> "mainContent_btnUpdate")
  link(:administration, :link_text=> "ADMINISTRATION")
  div(:company_profile_title, :text=>"Company Information")
  link(:company_service_permission, :link_text=>"Company Service Permissions")
  ## Under Company Service Permission
  div(:information_reporting, :text=> "Information Reporting")
  div(:statement_invoices, :text=>"Statements/Invoices:")
  div(:business_card_statement, :text=> "Business Card Statement")
  div(:payments_transfers_title, :text=>"Payments & Transfers")
  ###############
  link(:company_modify_account_name, :link_text=>"Modify Account Names")
  link(:company_settings, :link_text=>"Company Settings")
  link(:company_profile, :link_text=>"Company Profile")
  link(:company_service_matrix, :link_text=>"Company Service Matrix")
  link(:service_permission_tab, :link_text=>"SERVICE PERMISSIONS")
  element(:main_table, :table, :class=>"LargeDialog")



  def getEntitlementRow(entitlementText)
    doc = Nokogiri::HTML(self.html)
    tables = doc.xpath(".//*[@class='custAdminDefaultAlign']/div/table")
    tables.find {|td| td.text.include?(entitlementText)}
  end

  def subsectionExists?(subsectionName)
    subsections = @browser.find_elements(:css => 'td.custAdminApprovalHeader')
    subsections.each do |subsection|
      return true if subsection.text == subsectionName
    end

    return false
  end

  def subheaderExists?(subheaderName)
    #e.g. SmartTax:, PowerPay Card:, Payroll: -- an item on the page without the checkbox.
    doc = Nokogiri::HTML(self.html)
    div = doc.xpath(".//*[@class='custAdminSubHeader']").find {|div| div.text.include?(subheaderName)}
    return !div.nil?
  end

  def isCompanyEntitled?(entitlementText)
    entitlement_row = getEntitlementRow(entitlementText)
    raise "Entitlement #{entitlementText} was not found" unless entitlement_row
    checkbox = entitlement_row.css('input').first
    raise "The #{entitlementText} is editable" unless checkbox.attribute('disabled') != 'disabled'
    return (checkbox.attribute('checked') == 'checked')
  end

  def isEntitledToPaymentCenter?
    isCompanyEntitled?("Enable Payment Center")
  end

  def sectionExists?(sectionText)
    headlines = @browser.find_elements(:css => 'div.HeadlineText').each do |headline|
      return true if headline.text == sectionText
    end

    return false
    end
end