
class ApprovalsTransactionReport < BolPageObjectBase

  page_url($base_url + "CustomerAdmin/Approvals/ApprovalsReport.aspx")

  link(:viewReport, :id=> "mainContent_btnViewReport")
  table(:resultsTable, :id=> "mainContent_grdTransactions")

end
