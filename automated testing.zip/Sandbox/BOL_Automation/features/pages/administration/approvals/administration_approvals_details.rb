
class ApprovalDetails < BolPageObjectBase

  link(:approve, :id=> "mainContent_btnApprove")
  link(:deny, :id=> "mainContent_btnDeny")



end
