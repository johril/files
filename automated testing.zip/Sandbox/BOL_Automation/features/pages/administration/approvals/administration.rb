#class Users < BolPageObjectBase
#  #include PageObject
#  page_url($base_url + "CustomerAdmin/UserList.aspx?Page=ADMINISTRATION_USER_USERLIST" )
#  link(:user_tab,:link_text=> "User")
#  link(:user_function_tab, :id=> "MenuLevelThree_87")
#  link(:user_service_permission, :text=>"User Service Permissions")
#  select_list(:select_user, :id=>"ContentPlaceHolder1_ddUsers")
#  cell(:user_service_permission_information_report, :id=>"ctl00$ContentPlaceHolder1$pnl_IR:Caption0")
#  cell(:user_service_permission_business_card_statement, :text=>"Business Card Statement")
#  cell(:user_function_matrix_page_title, :text=>"User Function Matrix")
#  select_list(:select_service_function, :id=>"ContentPlaceHolder1_ddlSelectService")
#  cell(:business_card_statement_column, :text=>"Business Card Statement")
#end




