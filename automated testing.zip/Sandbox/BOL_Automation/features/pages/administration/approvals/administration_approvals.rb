
class Approvals < BolPageObjectBase

  page_url($base_url + "CustomerAdmin/Approvals/Approve.aspx?Page=ADMINISTRATION_APPROVALS_APPROVE")

  table(:approvalsTransactions, :id=> "mainContent_grdTransactions")
  button(:approveSelected, :id=> "mainContent_btnApprove")
  button(:denySelected, :id=> "mainContent_btnDeny")
  link(:transactionReport, :title=> "TRANSACTION REPORT")

  def getApprovalLink(userLastName, userFirstName)
    approvalsTransactions_element.link_element(identifier = {:link_text=> userLastName + ", " + userFirstName})
  end

  def getApprovalCheckbox()
    approvalsTransactions_element[1].checkbox_element()
  end

end
