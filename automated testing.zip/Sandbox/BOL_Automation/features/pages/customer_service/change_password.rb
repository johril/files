


class ChangePasswordPage < BolPageObjectBase

  link(:customer_service,:text=>"Customer Service")
  link(:change_password_tab, :text=>"CHANGE PASSWORD")
  page_url($base_url + "/CustomerService/ChangePassword.aspx" )
  label(:current_password_label, :text=>"Current Password")
  text_field(:current_password, :id=>"mainContent_mainContent_txtOldPassword")
  label(:new_password_label, :text=>"New Password")
  text_field(:new_password, :id=>"mainContent_mainContent_txtNewPassword")
  label(:re_enter_new_password_label, :text=>"Re-Enter New Password")
  text_field(:re_enter_new_password, :id=>"mainContent_mainContent_txtConfirmNewPassword")
  button(:change_password, :id=>"footerContent_footerContent_btnChangePassword")


end



