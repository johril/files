class SendMessagePage < BolPageObjectBase
  DEFAULT_DATA = {
      'service_type' => "ACH",
      'comment' => "automation testing comment"
  }
  page_url($base_url + "/CustomerService/SendMessage.aspx" )
  select_list(:service_type,:id=>"ddlSubject")
  select_list(:account, :id=>"mainContent_ddlAccounts")
  text_field(:comment, :id=> "mainContent_txtBody")
  button(:send_message, :id=>"footerContent_btSend")

  def submit_form(data = {})
    data = DEFAULT_DATA.merge(data)
    firstAccount = self.account_options[1]
    self.service_type_element.select(data['service_type'])
    #above action causes a postback without consistently changing the DOM for us to verify the postback is complete
    sleep(10)
    self.account_element.select(if data['account'].nil? then firstAccount else data['account'] end)
    self.comment = data['comment']
    self.send_message
  end
end