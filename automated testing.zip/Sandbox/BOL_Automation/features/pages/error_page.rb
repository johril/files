class ErrorPage < BolPageObjectBase

  def getErrorText(div_element)
    errText = ''
    span_elements = div_element.find_elements(:tag_name=>'span')
    span_elements.each do |span|
      errText = errText + span.text
    end

    errText
  end

end