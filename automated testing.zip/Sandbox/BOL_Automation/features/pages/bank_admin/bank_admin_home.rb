
class BankAdminHome < BolPageObjectBase

      SERVICE_PERMISSIONS_NAME_COLUMN = 2
      SERVICE_PERMISSIONS_APPROVALS_COLUMN = 4

      page_url($RM_url)

      text_field(:userID, :id=> "UserID")
      text_field(:companyID, :id=> "contentMain_tbID")

      button(:submitButton, :id=> "btnSubmit")
      button(:continueButton, :id=> "btnContinue")
      button(:companySearchButton, :id=> "contentMain_btSubmit")

      table(:companySearchResults, :id=> "contentMain_dgCompanies")

      link(:customLink, :title=> "Custom")
      link(:businessOnlineMenuLink, :text=> "Business Online")
      link(:companyServicePermissions, :text=> "Company Service Permissions")
      link(:userList, :text=> "User List")
      link(:userServicePermissions, :text=> "User Service Permissions")
      link(:companySettings, :text=> "Company Settings")

      #add a new user
      link(:addUser, :text=> "Add a new user")
      text_field(:newUserID, :id=> "contentMain_tbSignOnID")
      text_field(:firstName, :id=> "contentMain_tbFirstName")
      text_field(:lastName, :id=> "contentMain_tbLastName")
      text_field(:email, :id=> "contentMain_tbEmail")
      select(:entitlements, :id=> "contentMain_ddCopyEntitlements")
      button(:addNewUser, :id=> "contentMain_btAdd")
      div(:successUserCreated, :id=> "Credentials")

      #delete user
      button(:deleteUserbutton, :id=> "contentMain_btDelete")

      div(:administrationPermissions, :id=> "contentMain_pnl_ADMIN")
      table(:administrationCompanyPermissions, :xpath=> ".//*[@id='contentMain_pnl_ADMIN']/table/descendant::table[@class='panelContents']")
      span(:updateCompanyServicePermissions, :id=> "contentMain_btUpdate")

      #Company Settings
      checkbox(:displayAllTabs, :xpath=> ".//*[@id='contentMain_pnl_ADMIN']/table/descendant::table[@class='panelContents']/descendant::span[@CompanyRuleID='67']/input[@type='checkbox']")
      span(:updateCompanySettings, :id=> 'contentMain_btUpdate')

      select(:userServicePermissionsSelectUser, :id=> "contentMain_ddUsers")
      table(:administrationUserPermissions, :xpath=> ".//*[@id='contentMain_pnl_ADMIN']/table/descendant::table[@class='panelContents']")
      span(:updateUserServicePermissions, :id=> "contentMain_btUpdate")

      def getCompanyLink(companyId)
        companySearchResults_element.link_element(identifier = {:link_text=> companyId})
      end

      def getCompanyPermissionsApprovalsCheckbox()
        selectedRow = administrationCompanyPermissions_element.find { |row| row[SERVICE_PERMISSIONS_NAME_COLUMN].text == "User Maintenance" }
        selectedRow[SERVICE_PERMISSIONS_APPROVALS_COLUMN].checkbox_element()
      end

      def getUserPermissionsApprovalsCheckbox()
        selectedRow = administrationUserPermissions_element.find { |row| row[SERVICE_PERMISSIONS_NAME_COLUMN].text == "Approve" }
        selectedRow.checkbox_element()
      end
end
