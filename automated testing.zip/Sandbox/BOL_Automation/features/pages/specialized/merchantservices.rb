class MerchantServices < BolPageObjectBase

  page_url($base_url + "Specialized/MerchantServices.aspx")

  div(:content, :id => "contentContainer")
  button(:loginButton, :id => "btnLogin")


end