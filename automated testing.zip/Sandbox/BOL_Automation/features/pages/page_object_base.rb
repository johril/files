class BolPageObjectBase
  include PageObject
  include DataMagic


#  if defined?($BASE_URLS) && defined?($CURRENT_ENVIRONMENT)
#   @@base_url = $BASE_URLS[$CURRENT_ENVIRONMENT]["BOL"]
# else
#  @@base_url = "http://localhost/BusinessOnline/"
#end

  link(:log_out, :link_text => "Log Out")
  div(:success_message, :class => "status-message-success")
  div(:error_div, :id => "validationSummary")
  div(:confirmation_div, :class => "validationSuccess")
  unordered_list(:error_messages) do |page|
    page.error_div_element.unordered_list_element
  end

  def select_option_by_pattern(element, pattern)
    # There has to be a better way by leveraging the PageObject select_list itself
    matching_index = element.options.find_index { |option|
      option.text.match(pattern)
    }

    if nil != matching_index
      element.options[matching_index].click
    else
      puts 'no match found'
    end
  end
end