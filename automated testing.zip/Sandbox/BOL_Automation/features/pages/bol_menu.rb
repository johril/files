class BOLMenu < BolPageObjectBase
  LINK_ADMINISTRATION = 'ADMINISTRATION'
  LINK_ADMINISTRATION_COMPANY = 'Company'
  LINK_ADMINISTRATION_USER = 'User'

  unordered_list(:top_menu, :id => "topNav")
  unordered_list(:secondary_menu, :class => 'secondary')


  def navigate(menu_item_text, submenu_item_text, wait_time_for_nav_complete = 15)
    #save the title for later
    my_title = title

    menu_item = top_menu_element.link_element(identifier = {:link_text=> menu_item_text})
    menu_item.click

    sleep(1)

    #get the list (parent of the menu item) where the sub-menu items are
    i = 0
    submenu_item = nil
    while (i < menu_item.parent.unordered_list_element.link_elements.length) do
      if menu_item.parent.unordered_list_element.link_elements[i].html.include? submenu_item_text
           submenu_item = menu_item.parent.unordered_list_element.link_elements[i]
            break
      end
      i+=1
    end

    raise "Menu item #{submenu_item_text} not found under #{menu_item_text} menu" unless !submenu_item.nil?
    submenu_item.click

    #wait until the title changes -- unless we are on a service redirect page, then there is a popup and the title will not change.
    if (wait_time_for_nav_complete >= 0)
      begin
        wait_until(wait_time_for_nav_complete) {title != my_title}
      rescue Selenium::WebDriver::Error::TimeOutError
        #just eat this.  it might be the same title (especially on adin pages)
      end

    end
  end

  def isLinkVisible(menu_item_text)
    menu_item = top_menu_element.link_element(identifier = {:link_text=> menu_item_text})
    !menu_item.nil?
  end
end