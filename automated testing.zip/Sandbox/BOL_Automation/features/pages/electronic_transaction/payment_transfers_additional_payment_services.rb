# Payments and Transfers


class AdditionalPaymentServices < BolPageObjectBase
  page_url($base_url + "ElectronicTransactions/PaymentServices/AdditionalPaymentServices.aspx")
  link(:payments_transfers, :id=> "navBar_NavigationList_lnkMenuItem_2")
  link(:additional_payment_services, :id=> "navBar_NavigationList_SubNavigationList_2_lnkMenuItem_6")
  div(:smart_tax, :id=> "mainContent_mainContent_pnlSmartTax")
  div(:power_pay_card, :id=> "mainContent_mainContent_pnlPowerPayCard")
  div(:payroll, :id=> "mainContent_mainContent_pnlPayroll")
  button(:payrollButton, :id=> "btnPayroll")
  button(:powerPayButton, :id=> "btnPowerPayCard")
  button(:smartTaxButton, :id=> "btnSmartTax")
  #div(:error_message, :class=> "status-message-warning" )

end