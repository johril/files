class TransferActivity < BolPageObjectBase
  RESULTS_EFFECTIVE_DATE_COL = 0
  RESULTS_FROM_ACCOUNT_COL = 1
  RESULTS_TO_ACCOUNT_COL = 2
  RESULTS_AMOUNT_COL = 3
  RESULTS_FREQUENCY_COL = 4
  RESULTS_START_END_DATE_COL = 5
  RESULTS_STATUS_COL = 6
  RESULTS_USER_COL = 7

  # To change this template use File | Settings | File Templates.
  select_list(:user_filter, :id=> 'ddlSelectUsers')
  span(:page_title, :id=>'pageInfo_lblPageTitle')
  button(:submit, :id=>'mainContent_mainContent_btnUpdateReport')
  div(:results_panel, :id=>'mainContent_mainContent_pnlTransferResultsPanel')
  table(:results_grid, :id=>'mainContent_mainContent_grdTransferActivity')
  link(:user_id_link, :text=>"User ID /\nDate")

  def confirm_page_loaded()
    page_title_element.when_present
  end

  def select_user(user)
    self.user_filter = user
  end

  def submit_request(sort_by_date_desc)
    submit
    results_panel_element.when_visible(45)
    if sort_by_date_desc
      user_id_link#clicks the header link to force descending sort
      results_panel_element.when_visible(45)
    end
  end

  def get_result_formatted_account(account = {})
    "...#{account['masked_number']}\n#{account['name']}..."
  end

  def get_results_effective_date(row_number)
    results_grid_element[row_number][RESULTS_EFFECTIVE_DATE_COL].text
  end

  def get_results_from_account(row_number)
    results_grid_element[row_number][RESULTS_FROM_ACCOUNT_COL].text
  end

  def get_results_to_account(row_number)
    results_grid_element[row_number][RESULTS_TO_ACCOUNT_COL].text
  end

  def get_results_amount(row_number)
    results_grid_element[row_number][RESULTS_AMOUNT_COL].text
  end

  def get_results_frequency(row_number)
    results_grid_element[row_number][RESULTS_FREQUENCY_COL].text
  end

  def get_results_start_end_date(row_number)
    results_grid_element[row_number][RESULTS_START_END_DATE_COL].text
  end

  def get_results_status(row_number)
    results_grid_element[row_number][RESULTS_STATUS_COL].text
  end

  def get_results_user(row_number)
    results_grid_element[row_number][RESULTS_USER_COL].text
  end
end