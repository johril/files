# Electronic Transaction

class AccountTransfer < BolPageObjectBase
  #expected_element(:schedule_transfer, 50)
  image(:spinner, :xpath=>".//*[@id='pnlFromAccount']/dl/dd/span/img")
  page_url($base_url + "ElectronicTransactions/AcctTransfer.aspx")
  link(:transfer_activity_tab, :text=> "TRANSFER ACTIVITY")
  select_list(:transfer_from_dropdown,:id=>"FromAccountNumber")
  select_list(:transfer_to_dropdown,:id=>"ToAccountNumber")
  text_field(:amount, :id=>"Amount")
  select_list(:frequency_dropdown,:id=>"Frequency")
  text_field(:transfer_date, :id => "StartDate")
  button(:submit, :id => "footerContent_footerContent_btnSubmit")
  span(:spinner, :xpath=>".//*[@id='pnlFromAccount']/dl/dd/span")



  def select_accounts(from_account, to_account)
    spinner_element.when_not_visible(50)
    select_option_by_pattern(transfer_from_dropdown_element, get_formatted_account_selection(from_account))
    select_option_by_pattern(transfer_to_dropdown_element, get_formatted_account_selection(to_account))
  end

  def get_formatted_account_selection(account = {})
    "...#{account['masked_number']} / #{account['name']}..."
  end

  def get_formatted_account_message(account = {})
    "...#{account['masked_number']} / #{account['name']}..."
  end

  def configure_onetime_transfer(from_account = {}, to_account = {}, amount, start_date)
    select_accounts(from_account, to_account)
    self.amount= amount
    self.frequency_dropdown= 'One Time'
    self.transfer_date= start_date
  end

  def schedule_transfer_with_success()
    submit
    success_message_element.when_visible(30)
  end

  def navigate_to_activity()
    transfer_activity_tab
  end

end