
class PayBills < BolPageObjectBase
  page_url($base_url + "BillPay/PayBills.aspx")

end
class Payees <   BolPageObjectBase
  page_url($base_url + "BillPay/PayeeList.aspx")


end

class Scheduled < BolPageObjectBase
  page_url($base_url + "BillPay/FuturePayments.aspx")
end

class History < BolPageObjectBase
  page_url($base_url + "BillPay/PaymentHist.aspx")
end
