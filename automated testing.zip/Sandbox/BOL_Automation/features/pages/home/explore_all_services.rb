require 'nokogiri'

class ExploreAllServices < BolPageObjectBase
  # include PageObject
  page_url($base_url + "CustomerService/ServiceDetails.aspx")

  div(:details, :class => "serviceDetails")


  def getDescriptionTextForService(serviceName)
    i = 0
    dtList = details_element.find_elements(:tag_name => 'dt')
    while i < dtList.length do
      link = dtList[i].find_element(:tag_name => 'a')
      break if link.text == serviceName
      i += 1
    end

    details_element.find_elements(:tag_name => 'dd')[i].text

  end


end