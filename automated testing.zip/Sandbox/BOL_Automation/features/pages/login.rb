require_relative "page_object_base"

class LoginPage < BolPageObjectBase

  page_url($base_url + "BOLHome/BusinessOnlineLogin.aspx")

  text_field(:company, :id => "mainContent_txtCompanyID")
  text_field(:user, :id => "mainContent_txtUserID")
  text_field(:password, :id => "mainContent_txtPassword")

  button(:login, :id => "btnLogin")
  button(:logout, :id=>"welcomeBox_lnkLogOut")

  text_field(:oldPassword, :id=> "txtOldPassword")
  text_field(:newPassword, :id=> "txtNewPassword")
  text_field(:newConfirmPassword, :id=> "txtConfirmNewPassword")

  button(:changePassword, :id=> "btnChangePassword")
  button(:continueToBOL, :id=> "btnEnter")

  def login_with(company_id, user_id, password)
    self.goto()

    self.wait_until(120) do
      login_element.visible?
    end

    self.company = company_id
    self.user = user_id
    self.password = password

    self.login()
  end
end

