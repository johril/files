 require_relative "page_object_base"
class OverviewPage < BolPageObjectBase

  page_url($base_url + "OtherReporting/AcctSummary.aspx")
  link(:transaction_search, :text => "Transaction Search")
  link(:payments_transfers, :text=> "PAYMENTS & TRANSFERS")
  link(:additional_payment_services, :text=> "Additional Payment Services")
  link(:merchant_services, :text=> "Merchant Services")
  text_field(:date, :id => "mainContent_bdpFromDate")
  table(:dda, :id => "mainContent_grdDeposits")
  table(:eqp, :id=>"mainContent_grdEquipmentFinance")
  table(:inv, :id=>"mainContent_grdInvestments")  # verify if this property is correct
  table(:commercialcard, :id=>"mainContent_grdCommercialCard")
  table(:credit_line, :id=>"mainContent_grdCreditLines")
  table(:loan, :id=>"mainContent_grdLoans")
  table(:certificate_deposit, :id=>"mainContent_grdCDsAndIras")


  def return_account_number(no_row,yaml_key,type)
    @counter =1
    begin
      account_number =  @current_page.type[@counter]['Account Number'].text
      account_number[7,4].should == yaml_key
    rescue
      @counter +=1
      retry if @counter <= no_row
         ##raise "This account number does not exist #{account_number} "

    end
  end

    def get_account_number(account_type)

      if account_type == 'dda'
          yaml_key = FigNewton.users.bol_user.accounts.dda1.masked_number
          type = dda_element

        elsif account_type == 'Equipment'
          yaml_key = FigNewton.users.bol_user.accounts.eqp1.masked_number
          type = eqp_element

        elsif account_type == 'Investment'
          yaml_key = FigNewton.users.bol_user.accounts.inv2.masked_number
          type = inv_element

        elsif account_type == 'Commercial'
          yaml_key = FigNewton.users.bol_user.accounts.cc1.masked_number
          type = commercialcard_element

        elsif account_type == 'Credit Line'
          yaml_key =  FigNewton.users.bol_user.accounts.cl1.masked_number
          type = credit_line_element

        elsif account_type == 'Loan line'
          yaml_key = FigNewton.users.bol_user.accounts.loan1.masked_number
          type = loan_element

        elsif account_type == 'CD'
          yaml_key = FigNewton.users.bol_user.accounts.cod1.masked_number
          type = certificate_deposit_element

        end
      no_row = type.find_elements(:tag_name => 'tr').length
      return_account_number(no_row,yaml_key,type)
    end

end

