require 'rubygems'
require 'cucumber'
require 'cucumber/rake/task'
require 'selenium/client/extensions'

task :say_hello do
  puts "hello world"
end

Cucumber::Rake::Task.new(:testing) do |t|
  puts "I am testing code"
end