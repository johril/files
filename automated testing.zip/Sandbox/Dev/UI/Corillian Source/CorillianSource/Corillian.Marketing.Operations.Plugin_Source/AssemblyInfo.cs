using System.Runtime.InteropServices;
// Assembly Corillian.Marketing.Operations.Plugin, Version 4.0.0.0

[assembly: System.Reflection.AssemblyVersion("4.0.0.0")]
[assembly: System.Runtime.CompilerServices.CompilationRelaxations(8)]
[assembly: System.Reflection.AssemblyConfiguration("http://subversion/svn/vpsd/suite/release/4.0/dev/CampaignManager -r45842")]
[assembly: System.Runtime.CompilerServices.RuntimeCompatibility(WrapNonExceptionThrows=true)]
//[assembly: System.Diagnostics.Debuggable(System.Diagnostics.DebuggableAttribute.DebuggingModes.DisableOptimizations | System.Diagnostics.DebuggableAttribute.DebuggingModes.EnableEditAndContinue | System.Diagnostics.DebuggableAttribute.DebuggingModes.IgnoreSymbolStoreSequencePoints)]
[assembly: System.Reflection.AssemblyCompany("Corillian Corporation")]
[assembly: System.Reflection.AssemblyCopyright("\x00a9 2004 - 2010 Corillian Corporation")]
[assembly: System.Reflection.AssemblyFileVersion("4.0.0.45841")]

[assembly: ComVisibleAttribute(false)]
