namespace Corillian.Marketing.Messages.Plugin
{
    using Corillian.Marketing.Domain.Plugin;
    using Corillian.Voyager.Common;
    using Corillian.Voyager.Common.Attributes;
    using System;
    using System.Xml.Serialization;

    [Serializable, VoyagerRequestSerializable, XmlRoot(Namespace="http://www.corillian.com/corillian/marketing/messages/2007/05", ElementName="SaveCampaignRequest"), XmlType(Namespace="http://www.corillian.com/corillian/marketing/messages/2007/05", TypeName="SaveCampaignRequest"), Transaction(TRX="CMSaveCampaign")]
    public class SaveCampaignRequest : Request, IFormattable
    {
        private Corillian.Marketing.Domain.Plugin.Campaign _campaign;
        private CampaignContextMapCollection _campaigncontextmaps;
        private CampaignInstanceCompositionMapCollection _campaigninstancecompositionmaps;
        private Corillian.Voyager.Common.Session _session;
        private WebPageAdSpaceCampaignMapCollection _webpageadspacecampaignmaps;

        public virtual string ToString(string format)
        {
            return FormattableObject.ToString(this, format, null);
        }

        public virtual string ToString(string format, IFormatProvider formatProvider)
        {
            if (format == null)
            {
                return base.ToString();
            }
            return FormattableObject.ToString(this, format, formatProvider);
        }

        [XmlElement(ElementName="Campaign", Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05")]
        public Corillian.Marketing.Domain.Plugin.Campaign Campaign
        {
            get
            {
                return this._campaign;
            }
            set
            {
                this._campaign = value;
            }
        }

        [XmlElement(ElementName="CampaignContextMap", Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05")]
        public CampaignContextMapCollection CampaignContextMapList
        {
            get
            {
                return this._campaigncontextmaps;
            }
            set
            {
                this._campaigncontextmaps = value;
            }
        }

        [XmlElement(ElementName="CampaignInstanceCompositionMap", Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05")]
        public CampaignInstanceCompositionMapCollection CampaignInstanceCompositionMapList
        {
            get
            {
                return this._campaigninstancecompositionmaps;
            }
            set
            {
                this._campaigninstancecompositionmaps = value;
            }
        }

        [TagName(""), Scope(PropertyScopeType.HI), XmlElement(ElementName="Session", Namespace="http://www.corillian.com/operations/2004/11")]
        public Corillian.Voyager.Common.Session Session
        {
            get
            {
                return this._session;
            }
            set
            {
                this._session = value;
            }
        }

        [XmlElement(ElementName="WebPageAdSpaceCampaignMap", Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05")]
        public WebPageAdSpaceCampaignMapCollection WebPageAdSpaceCampaignMapList
        {
            get
            {
                return this._webpageadspacecampaignmaps;
            }
            set
            {
                this._webpageadspacecampaignmaps = value;
            }
        }
    }
}

