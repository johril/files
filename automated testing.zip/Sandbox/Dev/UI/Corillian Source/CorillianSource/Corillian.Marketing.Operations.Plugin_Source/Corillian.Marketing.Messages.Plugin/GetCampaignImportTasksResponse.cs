namespace Corillian.Marketing.Messages.Plugin
{
    using Corillian.Marketing.Domain.Plugin;
    using Corillian.Voyager.Common;
    using System;
    using System.Xml.Serialization;

    [Serializable, XmlType(Namespace="http://www.corillian.com/corillian/marketing/messages/2007/05", TypeName="GetCampaignImportTasksResponse"), XmlRoot(Namespace="http://www.corillian.com/corillian/marketing/messages/2007/05", ElementName="GetCampaignImportTasksResponse")]
    public class GetCampaignImportTasksResponse : Response, IFormattable
    {
        private CampaignImportTaskCollection _campaignimporttaskss;

        public virtual string ToString(string format)
        {
            return FormattableObject.ToString(this, format, null);
        }

        public virtual string ToString(string format, IFormatProvider formatProvider)
        {
            if (format == null)
            {
                return base.ToString();
            }
            return FormattableObject.ToString(this, format, formatProvider);
        }

        [XmlElement(ElementName="CampaignImportTasks", Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05")]
        public CampaignImportTaskCollection CampaignImportTasksList
        {
            get
            {
                return this._campaignimporttaskss;
            }
            set
            {
                this._campaignimporttaskss = value;
            }
        }
    }
}

