namespace Corillian.Marketing.Messages.Plugin
{
    using Corillian.Voyager.Common;
    using Corillian.Voyager.Common.Attributes;
    using System;
    using System.Xml.Serialization;

    [Serializable, XmlType(Namespace="http://www.corillian.com/corillian/marketing/messages/2007/05", TypeName="DeleteCriterionRequest"), XmlRoot(Namespace="http://www.corillian.com/corillian/marketing/messages/2007/05", ElementName="DeleteCriterionRequest"), Transaction(TRX="CMDeleteCriterion"), VoyagerRequestSerializable]
    public class DeleteCriterionRequest : Request, IFormattable
    {
        private int _criterionid;
        private Corillian.Voyager.Common.Session _session;
        [XmlIgnore, Ignore]
        public bool CriterionIDSpecified;

        public virtual string ToString(string format)
        {
            return FormattableObject.ToString(this, format, null);
        }

        public virtual string ToString(string format, IFormatProvider formatProvider)
        {
            if (format == null)
            {
                return base.ToString();
            }
            return FormattableObject.ToString(this, format, formatProvider);
        }

        [XmlElement(ElementName="CriterionID", Namespace="http://www.corillian.com/corillian/marketing/messages/2007/05", DataType="int")]
        public int CriterionID
        {
            get
            {
                return this._criterionid;
            }
            set
            {
                this.CriterionIDSpecified = true;
                this._criterionid = value;
            }
        }

        [Scope(PropertyScopeType.HI), XmlElement(ElementName="Session", Namespace="http://www.corillian.com/operations/2004/11"), TagName("")]
        public Corillian.Voyager.Common.Session Session
        {
            get
            {
                return this._session;
            }
            set
            {
                this._session = value;
            }
        }
    }
}

