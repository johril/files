namespace Corillian.Marketing.Messages.Plugin
{
    using Corillian.Marketing.Domain.Plugin;
    using Corillian.Voyager.Common;
    using Corillian.Voyager.Common.Attributes;
    using System;
    using System.Xml.Serialization;

    [Serializable, XmlRoot(Namespace="http://www.corillian.com/corillian/marketing/messages/2007/05", ElementName="LogCampaignCustomerInteractionRequest"), Transaction(TRX="CMLogCampaignCustomerInteraction"), VoyagerRequestSerializable, XmlType(Namespace="http://www.corillian.com/corillian/marketing/messages/2007/05", TypeName="LogCampaignCustomerInteractionRequest")]
    public class LogCampaignCustomerInteractionRequest : Request, IFormattable
    {
        private string _admediaguid;
        private long _campaigncompositionid;
        private string _campaigninstanceguid;
        private long _cmcustomerid;
        private Corillian.Marketing.Domain.Plugin.CMCustomerInfo _cmcustomerinfo;
        private string _ruleguid;
        private string _ruleinstanceguid;
        private Corillian.Voyager.Common.Session _session;
        private int _webpageid;
        private string _webpagename;
        [Ignore, XmlIgnore]
        public bool CampaignCompositionIdSpecified;
        [XmlIgnore, Ignore]
        public bool CMCustomerIdSpecified;
        [Ignore, XmlIgnore]
        public bool WebPageIdSpecified;

        public virtual string ToString(string format)
        {
            return FormattableObject.ToString(this, format, null);
        }

        public virtual string ToString(string format, IFormatProvider formatProvider)
        {
            if (format == null)
            {
                return base.ToString();
            }
            return FormattableObject.ToString(this, format, formatProvider);
        }

        [XmlElement(ElementName="AdMediaGuid", Namespace="http://www.corillian.com/corillian/marketing/messages/2007/05", DataType="string")]
        public string AdMediaGuid
        {
            get
            {
                return this._admediaguid;
            }
            set
            {
                this._admediaguid = value;
            }
        }

        [XmlElement(ElementName="CampaignCompositionId", Namespace="http://www.corillian.com/corillian/marketing/messages/2007/05", DataType="long")]
        public long CampaignCompositionId
        {
            get
            {
                return this._campaigncompositionid;
            }
            set
            {
                this.CampaignCompositionIdSpecified = true;
                this._campaigncompositionid = value;
            }
        }

        [XmlElement(ElementName="CampaignInstanceGuid", Namespace="http://www.corillian.com/corillian/marketing/messages/2007/05", DataType="string")]
        public string CampaignInstanceGuid
        {
            get
            {
                return this._campaigninstanceguid;
            }
            set
            {
                this._campaigninstanceguid = value;
            }
        }

        [IgnoreWhenEmpty, XmlElement(ElementName="CMCustomerId", Namespace="http://www.corillian.com/corillian/marketing/messages/2007/05", DataType="long"), Scope(PropertyScopeType.HI)]
        public long CMCustomerId
        {
            get
            {
                return this._cmcustomerid;
            }
            set
            {
                this.CMCustomerIdSpecified = true;
                this._cmcustomerid = value;
            }
        }

        [TagName(""), XmlElement(ElementName="CMCustomerInfo", Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05"), Scope(PropertyScopeType.HI)]
        public Corillian.Marketing.Domain.Plugin.CMCustomerInfo CMCustomerInfo
        {
            get
            {
                return this._cmcustomerinfo;
            }
            set
            {
                this._cmcustomerinfo = value;
            }
        }

        [XmlElement(ElementName="RuleGuid", Namespace="http://www.corillian.com/corillian/marketing/messages/2007/05", DataType="string")]
        public string RuleGuid
        {
            get
            {
                return this._ruleguid;
            }
            set
            {
                this._ruleguid = value;
            }
        }

        [XmlElement(ElementName="RuleInstanceGuid", Namespace="http://www.corillian.com/corillian/marketing/messages/2007/05", DataType="string")]
        public string RuleInstanceGuid
        {
            get
            {
                return this._ruleinstanceguid;
            }
            set
            {
                this._ruleinstanceguid = value;
            }
        }

        [XmlElement(ElementName="Session", Namespace="http://www.corillian.com/operations/2004/11"), Scope(PropertyScopeType.HI), TagName("")]
        public Corillian.Voyager.Common.Session Session
        {
            get
            {
                return this._session;
            }
            set
            {
                this._session = value;
            }
        }

        [XmlElement(ElementName="WebPageId", Namespace="http://www.corillian.com/corillian/marketing/messages/2007/05", DataType="int")]
        public int WebPageId
        {
            get
            {
                return this._webpageid;
            }
            set
            {
                this.WebPageIdSpecified = true;
                this._webpageid = value;
            }
        }

        [XmlElement(ElementName="WebPageName", Namespace="http://www.corillian.com/corillian/marketing/messages/2007/05", DataType="string")]
        public string WebPageName
        {
            get
            {
                return this._webpagename;
            }
            set
            {
                this._webpagename = value;
            }
        }
    }
}

