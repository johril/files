namespace Corillian.Marketing.Messages.Plugin
{
    using Corillian.Voyager.Common;
    using Corillian.Voyager.Common.Attributes;
    using System;
    using System.Xml.Serialization;

    [Serializable, XmlRoot(Namespace="http://www.corillian.com/corillian/marketing/messages/2007/05", ElementName="DeleteAdMediaResponse"), XmlType(Namespace="http://www.corillian.com/corillian/marketing/messages/2007/05", TypeName="DeleteAdMediaResponse")]
    public class DeleteAdMediaResponse : Response, IFormattable
    {
        private int _result;
        [Ignore, XmlIgnore]
        public bool resultSpecified;

        public virtual string ToString(string format)
        {
            return FormattableObject.ToString(this, format, null);
        }

        public virtual string ToString(string format, IFormatProvider formatProvider)
        {
            if (format == null)
            {
                return base.ToString();
            }
            return FormattableObject.ToString(this, format, formatProvider);
        }

        [XmlElement(ElementName="result", Namespace="http://www.corillian.com/corillian/marketing/messages/2007/05", DataType="int")]
        public int result
        {
            get
            {
                return this._result;
            }
            set
            {
                this.resultSpecified = true;
                this._result = value;
            }
        }
    }
}

