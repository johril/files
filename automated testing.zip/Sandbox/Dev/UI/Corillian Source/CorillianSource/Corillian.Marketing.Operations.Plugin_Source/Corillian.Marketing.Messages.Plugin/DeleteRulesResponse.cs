namespace Corillian.Marketing.Messages.Plugin
{
    using Corillian.Voyager.Common;
    using Corillian.Voyager.Common.Attributes;
    using System;
    using System.Xml.Serialization;

    [Serializable, XmlType(Namespace="http://www.corillian.com/corillian/marketing/messages/2007/05", TypeName="DeleteRulesResponse"), XmlRoot(Namespace="http://www.corillian.com/corillian/marketing/messages/2007/05", ElementName="DeleteRulesResponse")]
    public class DeleteRulesResponse : Response, IFormattable
    {
        private int _result;
        [Ignore, XmlIgnore]
        public bool ResultSpecified;

        public virtual string ToString(string format)
        {
            return FormattableObject.ToString(this, format, null);
        }

        public virtual string ToString(string format, IFormatProvider formatProvider)
        {
            if (format == null)
            {
                return base.ToString();
            }
            return FormattableObject.ToString(this, format, formatProvider);
        }

        [XmlElement(ElementName="Result", Namespace="http://www.corillian.com/corillian/marketing/messages/2007/05", DataType="int")]
        public int Result
        {
            get
            {
                return this._result;
            }
            set
            {
                this.ResultSpecified = true;
                this._result = value;
            }
        }
    }
}

