namespace Corillian.Marketing.Messages.Plugin
{
    using Corillian.Marketing.Domain.Plugin;
    using Corillian.Voyager.Common;
    using System;
    using System.Xml.Serialization;

    [Serializable, XmlRoot(Namespace="http://www.corillian.com/corillian/marketing/messages/2007/05", ElementName="CreateCriterionResponse"), XmlType(Namespace="http://www.corillian.com/corillian/marketing/messages/2007/05", TypeName="CreateCriterionResponse")]
    public class CreateCriterionResponse : Response, IFormattable
    {
        private Corillian.Marketing.Domain.Plugin.Criterion _criterion;

        public virtual string ToString(string format)
        {
            return FormattableObject.ToString(this, format, null);
        }

        public virtual string ToString(string format, IFormatProvider formatProvider)
        {
            if (format == null)
            {
                return base.ToString();
            }
            return FormattableObject.ToString(this, format, formatProvider);
        }

        [XmlElement(ElementName="Criterion", Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05")]
        public Corillian.Marketing.Domain.Plugin.Criterion Criterion
        {
            get
            {
                return this._criterion;
            }
            set
            {
                this._criterion = value;
            }
        }
    }
}

