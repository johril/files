namespace Corillian.Marketing.Messages.Plugin
{
    using Corillian.Voyager.Common;
    using Corillian.Voyager.Common.Attributes;
    using System;
    using System.Xml.Serialization;

    [Serializable, XmlType(Namespace="http://www.corillian.com/corillian/marketing/messages/2007/05", TypeName="GetAdMediasRequest"), XmlRoot(Namespace="http://www.corillian.com/corillian/marketing/messages/2007/05", ElementName="GetAdMediasRequest"), Transaction(TRX="CMGetAdMedias"), VoyagerRequestSerializable]
    public class GetAdMediasRequest : Request, IFormattable
    {
        private bool _getflash;
        private bool _getimages;
        private bool _gettext;
        private Corillian.Voyager.Common.Session _session;
        [Ignore, XmlIgnore]
        public bool GetFlashSpecified;
        [Ignore, XmlIgnore]
        public bool GetImagesSpecified;
        [XmlIgnore, Ignore]
        public bool GetTextSpecified;

        public virtual string ToString(string format)
        {
            return FormattableObject.ToString(this, format, null);
        }

        public virtual string ToString(string format, IFormatProvider formatProvider)
        {
            if (format == null)
            {
                return base.ToString();
            }
            return FormattableObject.ToString(this, format, formatProvider);
        }

        [XmlElement(ElementName="GetFlash", Namespace="http://www.corillian.com/corillian/marketing/messages/2007/05", DataType="boolean")]
        public bool GetFlash
        {
            get
            {
                return this._getflash;
            }
            set
            {
                this.GetFlashSpecified = true;
                this._getflash = value;
            }
        }

        [XmlElement(ElementName="GetImages", Namespace="http://www.corillian.com/corillian/marketing/messages/2007/05", DataType="boolean")]
        public bool GetImages
        {
            get
            {
                return this._getimages;
            }
            set
            {
                this.GetImagesSpecified = true;
                this._getimages = value;
            }
        }

        [XmlElement(ElementName="GetText", Namespace="http://www.corillian.com/corillian/marketing/messages/2007/05", DataType="boolean")]
        public bool GetText
        {
            get
            {
                return this._gettext;
            }
            set
            {
                this.GetTextSpecified = true;
                this._gettext = value;
            }
        }

        [TagName(""), XmlElement(ElementName="Session", Namespace="http://www.corillian.com/operations/2004/11"), Scope(PropertyScopeType.HI)]
        public Corillian.Voyager.Common.Session Session
        {
            get
            {
                return this._session;
            }
            set
            {
                this._session = value;
            }
        }
    }
}

