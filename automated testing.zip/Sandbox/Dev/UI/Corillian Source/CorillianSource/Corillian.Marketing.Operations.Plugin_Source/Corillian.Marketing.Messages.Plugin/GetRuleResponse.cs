namespace Corillian.Marketing.Messages.Plugin
{
    using Corillian.Marketing.Domain.Plugin;
    using Corillian.Voyager.Common;
    using System;
    using System.Xml.Serialization;

    [Serializable, XmlType(Namespace="http://www.corillian.com/corillian/marketing/messages/2007/05", TypeName="GetRuleResponse"), XmlRoot(Namespace="http://www.corillian.com/corillian/marketing/messages/2007/05", ElementName="GetRuleResponse")]
    public class GetRuleResponse : Response, IFormattable
    {
        private Corillian.Marketing.Domain.Plugin.Rule _rule;
        private RuleExpressionCollection _ruleexpressions;

        public virtual string ToString(string format)
        {
            return FormattableObject.ToString(this, format, null);
        }

        public virtual string ToString(string format, IFormatProvider formatProvider)
        {
            if (format == null)
            {
                return base.ToString();
            }
            return FormattableObject.ToString(this, format, formatProvider);
        }

        [XmlElement(ElementName="Rule", Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05")]
        public Corillian.Marketing.Domain.Plugin.Rule Rule
        {
            get
            {
                return this._rule;
            }
            set
            {
                this._rule = value;
            }
        }

        [XmlElement(ElementName="RuleExpression", Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05")]
        public RuleExpressionCollection RuleExpressionList
        {
            get
            {
                return this._ruleexpressions;
            }
            set
            {
                this._ruleexpressions = value;
            }
        }
    }
}

