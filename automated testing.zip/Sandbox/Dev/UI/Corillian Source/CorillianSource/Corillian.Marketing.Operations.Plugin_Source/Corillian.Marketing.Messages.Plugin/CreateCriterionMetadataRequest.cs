namespace Corillian.Marketing.Messages.Plugin
{
    using Corillian.Marketing.Domain.Plugin;
    using Corillian.Voyager.Common;
    using Corillian.Voyager.Common.Attributes;
    using System;
    using System.Xml.Serialization;

    [Serializable, Transaction(TRX="CMCreateCriterionMetadata"), XmlType(Namespace="http://www.corillian.com/corillian/marketing/messages/2007/05", TypeName="CreateCriterionMetadataRequest"), XmlRoot(Namespace="http://www.corillian.com/corillian/marketing/messages/2007/05", ElementName="CreateCriterionMetadataRequest"), VoyagerRequestSerializable]
    public class CreateCriterionMetadataRequest : Request, IFormattable
    {
        private Corillian.Marketing.Domain.Plugin.CriterionMetadata _criterionmetadata;
        private Corillian.Voyager.Common.Session _session;

        public virtual string ToString(string format)
        {
            return FormattableObject.ToString(this, format, null);
        }

        public virtual string ToString(string format, IFormatProvider formatProvider)
        {
            if (format == null)
            {
                return base.ToString();
            }
            return FormattableObject.ToString(this, format, formatProvider);
        }

        [XmlElement(ElementName="CriterionMetadata", Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05")]
        public Corillian.Marketing.Domain.Plugin.CriterionMetadata CriterionMetadata
        {
            get
            {
                return this._criterionmetadata;
            }
            set
            {
                this._criterionmetadata = value;
            }
        }

        [Scope(PropertyScopeType.HI), XmlElement(ElementName="Session", Namespace="http://www.corillian.com/operations/2004/11"), TagName("")]
        public Corillian.Voyager.Common.Session Session
        {
            get
            {
                return this._session;
            }
            set
            {
                this._session = value;
            }
        }
    }
}

