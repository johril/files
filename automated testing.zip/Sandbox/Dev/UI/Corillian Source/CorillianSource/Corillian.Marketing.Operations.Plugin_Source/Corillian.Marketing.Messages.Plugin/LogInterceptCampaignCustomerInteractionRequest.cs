namespace Corillian.Marketing.Messages.Plugin
{
    using Corillian.Marketing.Domain.Plugin;
    using Corillian.Voyager.Common;
    using Corillian.Voyager.Common.Attributes;
    using System;
    using System.Xml.Serialization;

    [Serializable, Transaction(TRX="CMLogInterceptCampaignCustomerInteraction"), VoyagerRequestSerializable, XmlRoot(Namespace="http://www.corillian.com/corillian/marketing/messages/2007/05", ElementName="LogInterceptCampaignCustomerInteractionRequest"), XmlType(Namespace="http://www.corillian.com/corillian/marketing/messages/2007/05", TypeName="LogInterceptCampaignCustomerInteractionRequest")]
    public class LogInterceptCampaignCustomerInteractionRequest : Request, IFormattable
    {
        private Corillian.Marketing.Domain.Plugin.Campaign _campaign;
        private string _campaignguid;
        private long _cmcustomerid;
        private Corillian.Marketing.Domain.Plugin.CMCustomerInfo _cmcustomerinfo;
        private int _interceptactiontype;
        private Corillian.Voyager.Common.Session _session;
        [Ignore, XmlIgnore]
        public bool CMCustomerIdSpecified;
        [Ignore, XmlIgnore]
        public bool InterceptActionTypeSpecified;

        public virtual string ToString(string format)
        {
            return FormattableObject.ToString(this, format, null);
        }

        public virtual string ToString(string format, IFormatProvider formatProvider)
        {
            if (format == null)
            {
                return base.ToString();
            }
            return FormattableObject.ToString(this, format, formatProvider);
        }

        [XmlElement(ElementName="Campaign", Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05")]
        public Corillian.Marketing.Domain.Plugin.Campaign Campaign
        {
            get
            {
                return this._campaign;
            }
            set
            {
                this._campaign = value;
            }
        }

        [XmlElement(ElementName="CampaignGuid", Namespace="http://www.corillian.com/corillian/marketing/messages/2007/05", DataType="string")]
        public string CampaignGuid
        {
            get
            {
                return this._campaignguid;
            }
            set
            {
                this._campaignguid = value;
            }
        }

        [IgnoreWhenEmpty, XmlElement(ElementName="CMCustomerId", Namespace="http://www.corillian.com/corillian/marketing/messages/2007/05", DataType="long"), Scope(PropertyScopeType.HI)]
        public long CMCustomerId
        {
            get
            {
                return this._cmcustomerid;
            }
            set
            {
                this.CMCustomerIdSpecified = true;
                this._cmcustomerid = value;
            }
        }

        [TagName(""), XmlElement(ElementName="CMCustomerInfo", Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05"), Scope(PropertyScopeType.HI)]
        public Corillian.Marketing.Domain.Plugin.CMCustomerInfo CMCustomerInfo
        {
            get
            {
                return this._cmcustomerinfo;
            }
            set
            {
                this._cmcustomerinfo = value;
            }
        }

        [XmlElement(ElementName="InterceptActionType", Namespace="http://www.corillian.com/corillian/marketing/messages/2007/05", DataType="int")]
        public int InterceptActionType
        {
            get
            {
                return this._interceptactiontype;
            }
            set
            {
                this.InterceptActionTypeSpecified = true;
                this._interceptactiontype = value;
            }
        }

        [TagName(""), Scope(PropertyScopeType.HI), XmlElement(ElementName="Session", Namespace="http://www.corillian.com/operations/2004/11")]
        public Corillian.Voyager.Common.Session Session
        {
            get
            {
                return this._session;
            }
            set
            {
                this._session = value;
            }
        }
    }
}

