namespace Corillian.Marketing.Messages.Plugin
{
    using Corillian.Voyager.Common;
    using Corillian.Voyager.Common.Attributes;
    using System;
    using System.Xml.Serialization;

    [Serializable, XmlType(Namespace="http://www.corillian.com/corillian/marketing/messages/2007/05", TypeName="ActivateOrDeactivateCampaignResponse"), XmlRoot(Namespace="http://www.corillian.com/corillian/marketing/messages/2007/05", ElementName="ActivateOrDeactivateCampaignResponse")]
    public class ActivateOrDeactivateCampaignResponse : Response, IFormattable
    {
        private int _actionresult;
        [Ignore, XmlIgnore]
        public bool ActionResultSpecified;

        public virtual string ToString(string format)
        {
            return FormattableObject.ToString(this, format, null);
        }

        public virtual string ToString(string format, IFormatProvider formatProvider)
        {
            if (format == null)
            {
                return base.ToString();
            }
            return FormattableObject.ToString(this, format, formatProvider);
        }

        [XmlElement(ElementName="ActionResult", Namespace="http://www.corillian.com/corillian/marketing/messages/2007/05", DataType="int")]
        public int ActionResult
        {
            get
            {
                return this._actionresult;
            }
            set
            {
                this.ActionResultSpecified = true;
                this._actionresult = value;
            }
        }
    }
}

