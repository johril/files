namespace Corillian.Marketing.Messages.Plugin
{
    using Corillian.Marketing.Domain.Plugin;
    using Corillian.Voyager.Common;
    using System;
    using System.Xml.Serialization;

    [Serializable, XmlRoot(Namespace="http://www.corillian.com/corillian/marketing/messages/2007/05", ElementName="GetCriterionMetadataResponse"), XmlType(Namespace="http://www.corillian.com/corillian/marketing/messages/2007/05", TypeName="GetCriterionMetadataResponse")]
    public class GetCriterionMetadataResponse : Response, IFormattable
    {
        private CriterionMetadataCollection _criterionmetadatas;

        public virtual string ToString(string format)
        {
            return FormattableObject.ToString(this, format, null);
        }

        public virtual string ToString(string format, IFormatProvider formatProvider)
        {
            if (format == null)
            {
                return base.ToString();
            }
            return FormattableObject.ToString(this, format, formatProvider);
        }

        [XmlElement(ElementName="CriterionMetadata", Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05")]
        public CriterionMetadataCollection CriterionMetadataList
        {
            get
            {
                return this._criterionmetadatas;
            }
            set
            {
                this._criterionmetadatas = value;
            }
        }
    }
}

