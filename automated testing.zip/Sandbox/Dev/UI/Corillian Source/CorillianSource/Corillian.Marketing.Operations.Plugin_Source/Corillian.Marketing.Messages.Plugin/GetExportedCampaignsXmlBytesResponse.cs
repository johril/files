namespace Corillian.Marketing.Messages.Plugin
{
    using Corillian.Marketing.Domain.Plugin;
    using Corillian.Voyager.Common;
    using Corillian.Voyager.Common.Attributes;
    using System;
    using System.Xml.Serialization;

    [Serializable, XmlRoot(Namespace="http://www.corillian.com/corillian/marketing/messages/2007/05", ElementName="GetExportedCampaignsXmlBytesResponse"), XmlType(Namespace="http://www.corillian.com/corillian/marketing/messages/2007/05", TypeName="GetExportedCampaignsXmlBytesResponse")]
    public class GetExportedCampaignsXmlBytesResponse : Response, IFormattable
    {
        private CampaignCollection _campaignstoexports;
        private byte[] _exportedcampaignsxmlbytes;
        private bool _isexported;
        [XmlIgnore, Ignore]
        public bool IsExportedSpecified;

        public virtual string ToString(string format)
        {
            return FormattableObject.ToString(this, format, null);
        }

        public virtual string ToString(string format, IFormatProvider formatProvider)
        {
            if (format == null)
            {
                return base.ToString();
            }
            return FormattableObject.ToString(this, format, formatProvider);
        }

        [XmlElement(ElementName="CampaignsToExport", Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05")]
        public CampaignCollection CampaignsToExportList
        {
            get
            {
                return this._campaignstoexports;
            }
            set
            {
                this._campaignstoexports = value;
            }
        }

        [XmlElement(ElementName="ExportedCampaignsXmlBytes", Namespace="http://www.corillian.com/corillian/marketing/messages/2007/05", DataType="base64Binary")]
        public byte[] ExportedCampaignsXmlBytes
        {
            get
            {
                return this._exportedcampaignsxmlbytes;
            }
            set
            {
                this._exportedcampaignsxmlbytes = value;
            }
        }

        [XmlElement(ElementName="IsExported", Namespace="http://www.corillian.com/corillian/marketing/messages/2007/05", DataType="boolean")]
        public bool IsExported
        {
            get
            {
                return this._isexported;
            }
            set
            {
                this.IsExportedSpecified = true;
                this._isexported = value;
            }
        }
    }
}

