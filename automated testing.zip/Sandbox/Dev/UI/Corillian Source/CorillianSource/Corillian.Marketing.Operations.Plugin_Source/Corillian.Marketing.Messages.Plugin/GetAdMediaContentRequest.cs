namespace Corillian.Marketing.Messages.Plugin
{
    using Corillian.Voyager.Common;
    using Corillian.Voyager.Common.Attributes;
    using System;
    using System.Xml.Serialization;

    [Serializable, Transaction(TRX="CMGetAdMediaContent"), XmlType(Namespace="http://www.corillian.com/corillian/marketing/messages/2007/05", TypeName="GetAdMediaContentRequest"), XmlRoot(Namespace="http://www.corillian.com/corillian/marketing/messages/2007/05", ElementName="GetAdMediaContentRequest"), VoyagerRequestSerializable]
    public class GetAdMediaContentRequest : Request, IFormattable
    {
        private string _admediaguid;
        private Corillian.Voyager.Common.Session _session;

        public virtual string ToString(string format)
        {
            return FormattableObject.ToString(this, format, null);
        }

        public virtual string ToString(string format, IFormatProvider formatProvider)
        {
            if (format == null)
            {
                return base.ToString();
            }
            return FormattableObject.ToString(this, format, formatProvider);
        }

        [XmlElement(ElementName="AdMediaGuid", Namespace="http://www.corillian.com/corillian/marketing/messages/2007/05", DataType="string")]
        public string AdMediaGuid
        {
            get
            {
                return this._admediaguid;
            }
            set
            {
                this._admediaguid = value;
            }
        }

        [Scope(PropertyScopeType.HI), TagName(""), XmlElement(ElementName="Session", Namespace="http://www.corillian.com/operations/2004/11")]
        public Corillian.Voyager.Common.Session Session
        {
            get
            {
                return this._session;
            }
            set
            {
                this._session = value;
            }
        }
    }
}

