namespace Corillian.Marketing.Messages.Plugin
{
    using Corillian.Voyager.Common;
    using Corillian.Voyager.Common.Attributes;
    using System;
    using System.Xml.Serialization;

    [Serializable, XmlType(Namespace="http://www.corillian.com/corillian/marketing/messages/2007/05", TypeName="GetCampaignsRequest"), XmlRoot(Namespace="http://www.corillian.com/corillian/marketing/messages/2007/05", ElementName="GetCampaignsRequest"), Transaction(TRX="CMGetCampaigns"), VoyagerRequestSerializable]
    public class GetCampaignsRequest : Request, IFormattable
    {
        private int _campaignstate;
        private Corillian.Voyager.Common.Session _session;
        [XmlIgnore, Ignore]
        public bool CampaignStateSpecified;

        public virtual string ToString(string format)
        {
            return FormattableObject.ToString(this, format, null);
        }

        public virtual string ToString(string format, IFormatProvider formatProvider)
        {
            if (format == null)
            {
                return base.ToString();
            }
            return FormattableObject.ToString(this, format, formatProvider);
        }

        [XmlElement(ElementName="CampaignState", Namespace="http://www.corillian.com/corillian/marketing/messages/2007/05", DataType="int")]
        public int CampaignState
        {
            get
            {
                return this._campaignstate;
            }
            set
            {
                this.CampaignStateSpecified = true;
                this._campaignstate = value;
            }
        }

        [XmlElement(ElementName="Session", Namespace="http://www.corillian.com/operations/2004/11"), TagName(""), Scope(PropertyScopeType.HI)]
        public Corillian.Voyager.Common.Session Session
        {
            get
            {
                return this._session;
            }
            set
            {
                this._session = value;
            }
        }
    }
}

