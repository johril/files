namespace Corillian.Marketing.Messages.Plugin
{
    using Corillian.Voyager.Common;
    using Corillian.Voyager.Common.Attributes;
    using System;
    using System.Xml.Serialization;

    [Serializable, XmlRoot(Namespace="http://www.corillian.com/corillian/marketing/messages/2007/05", ElementName="GetAdMediaContentHostDirectRequest"), XmlType(Namespace="http://www.corillian.com/corillian/marketing/messages/2007/05", TypeName="GetAdMediaContentHostDirectRequest"), Transaction(TRX="HostDirect"), VoyagerRequestSerializable]
    public class GetAdMediaContentHostDirectRequest : Request, IFormattable
    {
        private string _admediaguid;
        private Corillian.Voyager.Common.Session _session;
        private string _subtrx = "CMGetAdMediaContent";

        public virtual string ToString(string format)
        {
            return FormattableObject.ToString(this, format, null);
        }

        public virtual string ToString(string format, IFormatProvider formatProvider)
        {
            if (format == null)
            {
                return base.ToString();
            }
            return FormattableObject.ToString(this, format, formatProvider);
        }

        [XmlElement(ElementName="AdMediaGuid", Namespace="http://www.corillian.com/corillian/marketing/messages/2007/05", DataType="string")]
        public string AdMediaGuid
        {
            get
            {
                return this._admediaguid;
            }
            set
            {
                this._admediaguid = value;
            }
        }

        [XmlElement(ElementName="Session", Namespace="http://www.corillian.com/operations/2004/11"), TagName(""), Scope(PropertyScopeType.HI)]
        public Corillian.Voyager.Common.Session Session
        {
            get
            {
                return this._session;
            }
            set
            {
                this._session = value;
            }
        }

        [XmlElement(ElementName="SubTrx", Namespace="http://www.corillian.com/corillian/marketing/messages/2007/05", DataType="string"), TagName("SubTrx")]
        public string SubTrx
        {
            get
            {
                return this._subtrx;
            }
            set
            {
                this._subtrx = value;
            }
        }
    }
}

