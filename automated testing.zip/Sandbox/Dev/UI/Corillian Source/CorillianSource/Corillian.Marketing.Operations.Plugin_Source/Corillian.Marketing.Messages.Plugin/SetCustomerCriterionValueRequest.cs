namespace Corillian.Marketing.Messages.Plugin
{
    using Corillian.Marketing.Domain.Plugin;
    using Corillian.Voyager.Common;
    using Corillian.Voyager.Common.Attributes;
    using System;
    using System.Xml.Serialization;

    [Serializable, VoyagerRequestSerializable, XmlType(Namespace="http://www.corillian.com/corillian/marketing/messages/2007/05", TypeName="SetCustomerCriterionValueRequest"), Transaction(TRX="CMSetCustomerCriterionValue"), XmlRoot(Namespace="http://www.corillian.com/corillian/marketing/messages/2007/05", ElementName="SetCustomerCriterionValueRequest")]
    public class SetCustomerCriterionValueRequest : Request, IFormattable
    {
        private Corillian.Marketing.Domain.Plugin.CMCustomerInfo _cmcustomerinfo;
        private Corillian.Marketing.Domain.Plugin.CustomerCriterion _customercriterion;
        private Corillian.Voyager.Common.Session _session;

        public virtual string ToString(string format)
        {
            return FormattableObject.ToString(this, format, null);
        }

        public virtual string ToString(string format, IFormatProvider formatProvider)
        {
            if (format == null)
            {
                return base.ToString();
            }
            return FormattableObject.ToString(this, format, formatProvider);
        }

        [Scope(PropertyScopeType.HI), XmlElement(ElementName="CMCustomerInfo", Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05"), TagName("")]
        public Corillian.Marketing.Domain.Plugin.CMCustomerInfo CMCustomerInfo
        {
            get
            {
                return this._cmcustomerinfo;
            }
            set
            {
                this._cmcustomerinfo = value;
            }
        }

        [XmlElement(ElementName="CustomerCriterion", Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05")]
        public Corillian.Marketing.Domain.Plugin.CustomerCriterion CustomerCriterion
        {
            get
            {
                return this._customercriterion;
            }
            set
            {
                this._customercriterion = value;
            }
        }

        [XmlElement(ElementName="Session", Namespace="http://www.corillian.com/operations/2004/11"), Scope(PropertyScopeType.HI), TagName("")]
        public Corillian.Voyager.Common.Session Session
        {
            get
            {
                return this._session;
            }
            set
            {
                this._session = value;
            }
        }
    }
}

