namespace Corillian.Marketing.Messages.Plugin
{
    using Corillian.Voyager.Common;
    using Corillian.Voyager.Common.Attributes;
    using System;
    using System.Xml.Serialization;

    [Serializable, XmlRoot(Namespace="http://www.corillian.com/corillian/marketing/messages/2007/05", ElementName="GetCampaignImportTasksRequest"), Transaction(TRX="CMGetCampaignImportTasks"), VoyagerRequestSerializable, XmlType(Namespace="http://www.corillian.com/corillian/marketing/messages/2007/05", TypeName="GetCampaignImportTasksRequest")]
    public class GetCampaignImportTasksRequest : Request, IFormattable
    {
        private DateTime _enddate;
        private Corillian.Voyager.Common.Session _session;
        private DateTime _startdate;
        [XmlIgnore, Ignore]
        public bool EndDateSpecified;
        [XmlIgnore, Ignore]
        public bool StartDateSpecified;

        public virtual string ToString(string format)
        {
            return FormattableObject.ToString(this, format, null);
        }

        public virtual string ToString(string format, IFormatProvider formatProvider)
        {
            if (format == null)
            {
                return base.ToString();
            }
            return FormattableObject.ToString(this, format, formatProvider);
        }

        [XmlElement(ElementName="EndDate", Namespace="http://www.corillian.com/corillian/marketing/messages/2007/05", DataType="date")]
        public DateTime EndDate
        {
            get
            {
                return this._enddate;
            }
            set
            {
                this.EndDateSpecified = true;
                this._enddate = value;
            }
        }

        [XmlElement(ElementName="Session", Namespace="http://www.corillian.com/operations/2004/11"), TagName(""), Scope(PropertyScopeType.HI)]
        public Corillian.Voyager.Common.Session Session
        {
            get
            {
                return this._session;
            }
            set
            {
                this._session = value;
            }
        }

        [XmlElement(ElementName="StartDate", Namespace="http://www.corillian.com/corillian/marketing/messages/2007/05", DataType="date")]
        public DateTime StartDate
        {
            get
            {
                return this._startdate;
            }
            set
            {
                this.StartDateSpecified = true;
                this._startdate = value;
            }
        }
    }
}

