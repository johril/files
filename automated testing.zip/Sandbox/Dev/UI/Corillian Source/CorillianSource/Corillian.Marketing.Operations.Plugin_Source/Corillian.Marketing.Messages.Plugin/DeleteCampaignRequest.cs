namespace Corillian.Marketing.Messages.Plugin
{
    using Corillian.Voyager.Common;
    using Corillian.Voyager.Common.Attributes;
    using System;
    using System.Xml.Serialization;

    [Serializable, Transaction(TRX="CMDeleteCampaign"), VoyagerRequestSerializable, XmlRoot(Namespace="http://www.corillian.com/corillian/marketing/messages/2007/05", ElementName="DeleteCampaignRequest"), XmlType(Namespace="http://www.corillian.com/corillian/marketing/messages/2007/05", TypeName="DeleteCampaignRequest")]
    public class DeleteCampaignRequest : Request, IFormattable
    {
        private string _campaignguid;
        private int _deleteundelete;
        private Corillian.Voyager.Common.Session _session;
        [XmlIgnore, Ignore]
        public bool DeleteUnDeleteSpecified;

        public virtual string ToString(string format)
        {
            return FormattableObject.ToString(this, format, null);
        }

        public virtual string ToString(string format, IFormatProvider formatProvider)
        {
            if (format == null)
            {
                return base.ToString();
            }
            return FormattableObject.ToString(this, format, formatProvider);
        }

        [XmlElement(ElementName="CampaignGuid", Namespace="http://www.corillian.com/corillian/marketing/messages/2007/05", DataType="string")]
        public string CampaignGuid
        {
            get
            {
                return this._campaignguid;
            }
            set
            {
                this._campaignguid = value;
            }
        }

        [XmlElement(ElementName="DeleteUnDelete", Namespace="http://www.corillian.com/corillian/marketing/messages/2007/05", DataType="int")]
        public int DeleteUnDelete
        {
            get
            {
                return this._deleteundelete;
            }
            set
            {
                this.DeleteUnDeleteSpecified = true;
                this._deleteundelete = value;
            }
        }

        [XmlElement(ElementName="Session", Namespace="http://www.corillian.com/operations/2004/11"), TagName(""), Scope(PropertyScopeType.HI)]
        public Corillian.Voyager.Common.Session Session
        {
            get
            {
                return this._session;
            }
            set
            {
                this._session = value;
            }
        }
    }
}

