namespace Corillian.Marketing.Messages.Plugin
{
    using Corillian.Voyager.Common;
    using System;
    using System.Xml.Serialization;

    [Serializable, XmlType(Namespace="http://www.corillian.com/corillian/marketing/messages/2007/05", TypeName="UpLoadAdMediaResponse"), XmlRoot(Namespace="http://www.corillian.com/corillian/marketing/messages/2007/05", ElementName="UpLoadAdMediaResponse")]
    public class UpLoadAdMediaResponse : Response, IFormattable
    {
        private string _admediaguid;

        public virtual string ToString(string format)
        {
            return FormattableObject.ToString(this, format, null);
        }

        public virtual string ToString(string format, IFormatProvider formatProvider)
        {
            if (format == null)
            {
                return base.ToString();
            }
            return FormattableObject.ToString(this, format, formatProvider);
        }

        [XmlElement(ElementName="AdMediaGuid", Namespace="http://www.corillian.com/corillian/marketing/messages/2007/05", DataType="string")]
        public string AdMediaGuid
        {
            get
            {
                return this._admediaguid;
            }
            set
            {
                this._admediaguid = value;
            }
        }
    }
}

