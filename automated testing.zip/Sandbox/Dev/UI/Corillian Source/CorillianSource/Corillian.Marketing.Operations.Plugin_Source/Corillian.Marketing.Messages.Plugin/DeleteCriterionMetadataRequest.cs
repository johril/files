namespace Corillian.Marketing.Messages.Plugin
{
    using Corillian.Voyager.Common;
    using Corillian.Voyager.Common.Attributes;
    using System;
    using System.Xml.Serialization;

    [Serializable, XmlType(Namespace="http://www.corillian.com/corillian/marketing/messages/2007/05", TypeName="DeleteCriterionMetadataRequest"), XmlRoot(Namespace="http://www.corillian.com/corillian/marketing/messages/2007/05", ElementName="DeleteCriterionMetadataRequest"), Transaction(TRX="CMDeleteCriterionMetadata"), VoyagerRequestSerializable]
    public class DeleteCriterionMetadataRequest : Request, IFormattable
    {
        private int _criterionmetadataid;
        private string _deletedby;
        private bool _deleteundelete;
        private Corillian.Voyager.Common.Session _session;
        [XmlIgnore, Ignore]
        public bool CriterionMetadataIdSpecified;
        [Ignore, XmlIgnore]
        public bool DeleteUnDeleteSpecified;

        public virtual string ToString(string format)
        {
            return FormattableObject.ToString(this, format, null);
        }

        public virtual string ToString(string format, IFormatProvider formatProvider)
        {
            if (format == null)
            {
                return base.ToString();
            }
            return FormattableObject.ToString(this, format, formatProvider);
        }

        [XmlElement(ElementName="CriterionMetadataId", Namespace="http://www.corillian.com/corillian/marketing/messages/2007/05", DataType="int")]
        public int CriterionMetadataId
        {
            get
            {
                return this._criterionmetadataid;
            }
            set
            {
                this.CriterionMetadataIdSpecified = true;
                this._criterionmetadataid = value;
            }
        }

        [XmlElement(ElementName="DeletedBy", Namespace="http://www.corillian.com/corillian/marketing/messages/2007/05", DataType="string")]
        public string DeletedBy
        {
            get
            {
                return this._deletedby;
            }
            set
            {
                this._deletedby = value;
            }
        }

        [XmlElement(ElementName="DeleteUnDelete", Namespace="http://www.corillian.com/corillian/marketing/messages/2007/05", DataType="boolean")]
        public bool DeleteUnDelete
        {
            get
            {
                return this._deleteundelete;
            }
            set
            {
                this.DeleteUnDeleteSpecified = true;
                this._deleteundelete = value;
            }
        }

        [Scope(PropertyScopeType.HI), TagName(""), XmlElement(ElementName="Session", Namespace="http://www.corillian.com/operations/2004/11")]
        public Corillian.Voyager.Common.Session Session
        {
            get
            {
                return this._session;
            }
            set
            {
                this._session = value;
            }
        }
    }
}

