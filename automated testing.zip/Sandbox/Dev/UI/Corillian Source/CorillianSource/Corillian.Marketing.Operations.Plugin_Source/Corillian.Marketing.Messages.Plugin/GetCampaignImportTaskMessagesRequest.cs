namespace Corillian.Marketing.Messages.Plugin
{
    using Corillian.Voyager.Common;
    using Corillian.Voyager.Common.Attributes;
    using System;
    using System.Xml.Serialization;

    [Serializable, XmlType(Namespace="http://www.corillian.com/corillian/marketing/messages/2007/05", TypeName="GetCampaignImportTaskMessagesRequest"), Transaction(TRX="CMGetCampaignImportTaskMessages"), VoyagerRequestSerializable, XmlRoot(Namespace="http://www.corillian.com/corillian/marketing/messages/2007/05", ElementName="GetCampaignImportTaskMessagesRequest")]
    public class GetCampaignImportTaskMessagesRequest : Request, IFormattable
    {
        private int _importtaskid;
        private Corillian.Voyager.Common.Session _session;
        [Ignore, XmlIgnore]
        public bool ImportTaskIdSpecified;

        public virtual string ToString(string format)
        {
            return FormattableObject.ToString(this, format, null);
        }

        public virtual string ToString(string format, IFormatProvider formatProvider)
        {
            if (format == null)
            {
                return base.ToString();
            }
            return FormattableObject.ToString(this, format, formatProvider);
        }

        [XmlElement(ElementName="ImportTaskId", Namespace="http://www.corillian.com/corillian/marketing/messages/2007/05", DataType="int")]
        public int ImportTaskId
        {
            get
            {
                return this._importtaskid;
            }
            set
            {
                this.ImportTaskIdSpecified = true;
                this._importtaskid = value;
            }
        }

        [XmlElement(ElementName="Session", Namespace="http://www.corillian.com/operations/2004/11"), Scope(PropertyScopeType.HI), TagName("")]
        public Corillian.Voyager.Common.Session Session
        {
            get
            {
                return this._session;
            }
            set
            {
                this._session = value;
            }
        }
    }
}

