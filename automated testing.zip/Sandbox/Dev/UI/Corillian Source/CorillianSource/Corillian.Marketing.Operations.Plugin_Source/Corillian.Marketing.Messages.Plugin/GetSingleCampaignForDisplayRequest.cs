namespace Corillian.Marketing.Messages.Plugin
{
    using Corillian.Marketing.Domain.Plugin;
    using Corillian.Voyager.Common;
    using Corillian.Voyager.Common.Attributes;
    using System;
    using System.Xml.Serialization;

    [Serializable, XmlType(Namespace="http://www.corillian.com/corillian/marketing/messages/2007/05", TypeName="GetSingleCampaignForDisplayRequest"), XmlRoot(Namespace="http://www.corillian.com/corillian/marketing/messages/2007/05", ElementName="GetSingleCampaignForDisplayRequest"), Transaction(TRX="CMGetSingleCampaignForDisplay"), VoyagerRequestSerializable]
    public class GetSingleCampaignForDisplayRequest : Request, IFormattable
    {
        private int _adspaceid;
        private string _adspacename;
        private string _campaigncontext;
        private Corillian.Marketing.Domain.Plugin.CMCustomerInfo _cmcustomerinfo;
        private string _pagename;
        private Corillian.Voyager.Common.Session _session;
        [Ignore, XmlIgnore]
        public bool AdSpaceIdSpecified;

        public virtual string ToString(string format)
        {
            return FormattableObject.ToString(this, format, null);
        }

        public virtual string ToString(string format, IFormatProvider formatProvider)
        {
            if (format == null)
            {
                return base.ToString();
            }
            return FormattableObject.ToString(this, format, formatProvider);
        }

        [XmlElement(ElementName="AdSpaceId", Namespace="http://www.corillian.com/corillian/marketing/messages/2007/05", DataType="int")]
        public int AdSpaceId
        {
            get
            {
                return this._adspaceid;
            }
            set
            {
                this.AdSpaceIdSpecified = true;
                this._adspaceid = value;
            }
        }

        [XmlElement(ElementName="AdSpaceName", Namespace="http://www.corillian.com/corillian/marketing/messages/2007/05", DataType="string")]
        public string AdSpaceName
        {
            get
            {
                return this._adspacename;
            }
            set
            {
                this._adspacename = value;
            }
        }

        [XmlElement(ElementName="CampaignContext", Namespace="http://www.corillian.com/corillian/marketing/messages/2007/05", DataType="string")]
        public string CampaignContext
        {
            get
            {
                return this._campaigncontext;
            }
            set
            {
                this._campaigncontext = value;
            }
        }

        [TagName(""), XmlElement(ElementName="CMCustomerInfo", Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05"), Scope(PropertyScopeType.HI)]
        public Corillian.Marketing.Domain.Plugin.CMCustomerInfo CMCustomerInfo
        {
            get
            {
                return this._cmcustomerinfo;
            }
            set
            {
                this._cmcustomerinfo = value;
            }
        }

        [XmlElement(ElementName="PageName", Namespace="http://www.corillian.com/corillian/marketing/messages/2007/05", DataType="string")]
        public string PageName
        {
            get
            {
                return this._pagename;
            }
            set
            {
                this._pagename = value;
            }
        }

        [TagName(""), Scope(PropertyScopeType.HI), XmlElement(ElementName="Session", Namespace="http://www.corillian.com/operations/2004/11")]
        public Corillian.Voyager.Common.Session Session
        {
            get
            {
                return this._session;
            }
            set
            {
                this._session = value;
            }
        }
    }
}

