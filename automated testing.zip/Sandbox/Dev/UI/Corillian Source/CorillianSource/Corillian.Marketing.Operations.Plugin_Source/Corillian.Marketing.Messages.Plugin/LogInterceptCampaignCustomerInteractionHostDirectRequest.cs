namespace Corillian.Marketing.Messages.Plugin
{
    using Corillian.Marketing.Domain.Plugin;
    using Corillian.Voyager.Common;
    using Corillian.Voyager.Common.Attributes;
    using System;
    using System.Xml.Serialization;

    [Serializable, XmlRoot(Namespace="http://www.corillian.com/corillian/marketing/messages/2007/05", ElementName="LogInterceptCampaignCustomerInteractionHostDirectRequest"), Transaction(TRX="HostDirect"), VoyagerRequestSerializable, XmlType(Namespace="http://www.corillian.com/corillian/marketing/messages/2007/05", TypeName="LogInterceptCampaignCustomerInteractionHostDirectRequest")]
    public class LogInterceptCampaignCustomerInteractionHostDirectRequest : Request, IFormattable
    {
        private Corillian.Marketing.Domain.Plugin.Campaign _campaign;
        private string _campaignguid;
        private long _cmcustomerid;
        private int _interceptactiontype;
        private Corillian.Voyager.Common.Session _session;
        private string _subtrx = "CMLogInterceptCampaignCustomerInteraction";
        [XmlIgnore, Ignore]
        public bool CMCustomerIdSpecified;
        [Ignore, XmlIgnore]
        public bool InterceptActionTypeSpecified;

        public virtual string ToString(string format)
        {
            return FormattableObject.ToString(this, format, null);
        }

        public virtual string ToString(string format, IFormatProvider formatProvider)
        {
            if (format == null)
            {
                return base.ToString();
            }
            return FormattableObject.ToString(this, format, formatProvider);
        }

        [XmlElement(ElementName="Campaign", Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05")]
        public Corillian.Marketing.Domain.Plugin.Campaign Campaign
        {
            get
            {
                return this._campaign;
            }
            set
            {
                this._campaign = value;
            }
        }

        [XmlElement(ElementName="CampaignGuid", Namespace="http://www.corillian.com/corillian/marketing/messages/2007/05", DataType="string")]
        public string CampaignGuid
        {
            get
            {
                return this._campaignguid;
            }
            set
            {
                this._campaignguid = value;
            }
        }

        [XmlElement(ElementName="CMCustomerId", Namespace="http://www.corillian.com/corillian/marketing/messages/2007/05", DataType="long"), IgnoreWhenEmpty]
        public long CMCustomerId
        {
            get
            {
                return this._cmcustomerid;
            }
            set
            {
                this.CMCustomerIdSpecified = true;
                this._cmcustomerid = value;
            }
        }

        [XmlElement(ElementName="InterceptActionType", Namespace="http://www.corillian.com/corillian/marketing/messages/2007/05", DataType="int")]
        public int InterceptActionType
        {
            get
            {
                return this._interceptactiontype;
            }
            set
            {
                this.InterceptActionTypeSpecified = true;
                this._interceptactiontype = value;
            }
        }

        [XmlElement(ElementName="Session", Namespace="http://www.corillian.com/operations/2004/11"), Scope(PropertyScopeType.HI), TagName("")]
        public Corillian.Voyager.Common.Session Session
        {
            get
            {
                return this._session;
            }
            set
            {
                this._session = value;
            }
        }

        [XmlElement(ElementName="SubTrx", Namespace="http://www.corillian.com/corillian/marketing/messages/2007/05", DataType="string"), TagName("SubTrx")]
        public string SubTrx
        {
            get
            {
                return this._subtrx;
            }
            set
            {
                this._subtrx = value;
            }
        }
    }
}

