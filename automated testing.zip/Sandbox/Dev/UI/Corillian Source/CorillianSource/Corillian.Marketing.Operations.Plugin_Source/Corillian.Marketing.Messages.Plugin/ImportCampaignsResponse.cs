namespace Corillian.Marketing.Messages.Plugin
{
    using Corillian.Marketing.Domain.Plugin;
    using Corillian.Voyager.Common;
    using System;
    using System.Xml.Serialization;

    [Serializable, XmlType(Namespace="http://www.corillian.com/corillian/marketing/messages/2007/05", TypeName="ImportCampaignsResponse"), XmlRoot(Namespace="http://www.corillian.com/corillian/marketing/messages/2007/05", ElementName="ImportCampaignsResponse")]
    public class ImportCampaignsResponse : Response, IFormattable
    {
        private Corillian.Marketing.Domain.Plugin.CampaignImportTask _campaignimporttask;
        private CampaignCollection _campaignstoimports;

        public virtual string ToString(string format)
        {
            return FormattableObject.ToString(this, format, null);
        }

        public virtual string ToString(string format, IFormatProvider formatProvider)
        {
            if (format == null)
            {
                return base.ToString();
            }
            return FormattableObject.ToString(this, format, formatProvider);
        }

        [XmlElement(ElementName="CampaignImportTask", Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05")]
        public Corillian.Marketing.Domain.Plugin.CampaignImportTask CampaignImportTask
        {
            get
            {
                return this._campaignimporttask;
            }
            set
            {
                this._campaignimporttask = value;
            }
        }

        [XmlElement(ElementName="CampaignsToImport", Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05")]
        public CampaignCollection CampaignsToImportList
        {
            get
            {
                return this._campaignstoimports;
            }
            set
            {
                this._campaignstoimports = value;
            }
        }
    }
}

