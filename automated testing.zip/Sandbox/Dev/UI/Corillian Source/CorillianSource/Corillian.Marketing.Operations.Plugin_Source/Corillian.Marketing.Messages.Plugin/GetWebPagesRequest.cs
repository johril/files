namespace Corillian.Marketing.Messages.Plugin
{
    using Corillian.Voyager.Common;
    using Corillian.Voyager.Common.Attributes;
    using System;
    using System.Xml.Serialization;

    [Serializable, VoyagerRequestSerializable, XmlRoot(Namespace="http://www.corillian.com/corillian/marketing/messages/2007/05", ElementName="GetWebPagesRequest"), XmlType(Namespace="http://www.corillian.com/corillian/marketing/messages/2007/05", TypeName="GetWebPagesRequest"), Transaction(TRX="CMGetWebPages")]
    public class GetWebPagesRequest : Request, IFormattable
    {
        private int _adspaceid;
        private Corillian.Voyager.Common.Session _session;
        [XmlIgnore, Ignore]
        public bool AdSpaceIDSpecified;

        public virtual string ToString(string format)
        {
            return FormattableObject.ToString(this, format, null);
        }

        public virtual string ToString(string format, IFormatProvider formatProvider)
        {
            if (format == null)
            {
                return base.ToString();
            }
            return FormattableObject.ToString(this, format, formatProvider);
        }

        [XmlElement(ElementName="AdSpaceID", Namespace="http://www.corillian.com/corillian/marketing/messages/2007/05", DataType="int")]
        public int AdSpaceID
        {
            get
            {
                return this._adspaceid;
            }
            set
            {
                this.AdSpaceIDSpecified = true;
                this._adspaceid = value;
            }
        }

        [TagName(""), Scope(PropertyScopeType.HI), XmlElement(ElementName="Session", Namespace="http://www.corillian.com/operations/2004/11")]
        public Corillian.Voyager.Common.Session Session
        {
            get
            {
                return this._session;
            }
            set
            {
                this._session = value;
            }
        }
    }
}

