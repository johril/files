namespace Corillian.Marketing.Messages.Plugin
{
    using Corillian.Voyager.Common;
    using Corillian.Voyager.Common.Attributes;
    using System;
    using System.Xml.Serialization;

    [Serializable, VoyagerRequestSerializable, XmlRoot(Namespace="http://www.corillian.com/corillian/marketing/messages/2007/05", ElementName="GetBaseContextsRequest"), XmlType(Namespace="http://www.corillian.com/corillian/marketing/messages/2007/05", TypeName="GetBaseContextsRequest"), Transaction(TRX="CMGetBaseContexts")]
    public class GetBaseContextsRequest : Request, IFormattable
    {
        private Corillian.Voyager.Common.Session _session;
        private string _webpageidlist;

        public virtual string ToString(string format)
        {
            return FormattableObject.ToString(this, format, null);
        }

        public virtual string ToString(string format, IFormatProvider formatProvider)
        {
            if (format == null)
            {
                return base.ToString();
            }
            return FormattableObject.ToString(this, format, formatProvider);
        }

        [Scope(PropertyScopeType.HI), XmlElement(ElementName="Session", Namespace="http://www.corillian.com/operations/2004/11"), TagName("")]
        public Corillian.Voyager.Common.Session Session
        {
            get
            {
                return this._session;
            }
            set
            {
                this._session = value;
            }
        }

        [XmlElement(ElementName="WebPageIdList", Namespace="http://www.corillian.com/corillian/marketing/messages/2007/05", DataType="string")]
        public string WebPageIdList
        {
            get
            {
                return this._webpageidlist;
            }
            set
            {
                this._webpageidlist = value;
            }
        }
    }
}

