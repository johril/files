namespace Corillian.Marketing.Messages.Plugin
{
    using Corillian.Marketing.Domain.Plugin;
    using Corillian.Voyager.Common;
    using System;
    using System.Xml.Serialization;

    [Serializable, XmlRoot(Namespace="http://www.corillian.com/corillian/marketing/messages/2007/05", ElementName="GetMcifImportTasksResponse"), XmlType(Namespace="http://www.corillian.com/corillian/marketing/messages/2007/05", TypeName="GetMcifImportTasksResponse")]
    public class GetMcifImportTasksResponse : Response, IFormattable
    {
        private McifImportTaskCollection _mcifimporttasks;

        public virtual string ToString(string format)
        {
            return FormattableObject.ToString(this, format, null);
        }

        public virtual string ToString(string format, IFormatProvider formatProvider)
        {
            if (format == null)
            {
                return base.ToString();
            }
            return FormattableObject.ToString(this, format, formatProvider);
        }

        [XmlElement(ElementName="McifImportTask", Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05")]
        public McifImportTaskCollection McifImportTaskList
        {
            get
            {
                return this._mcifimporttasks;
            }
            set
            {
                this._mcifimporttasks = value;
            }
        }
    }
}

