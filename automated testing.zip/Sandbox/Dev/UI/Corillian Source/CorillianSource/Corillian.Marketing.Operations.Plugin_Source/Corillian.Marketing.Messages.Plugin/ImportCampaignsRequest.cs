namespace Corillian.Marketing.Messages.Plugin
{
    using Corillian.Marketing.Domain.Plugin;
    using Corillian.Voyager.Common;
    using Corillian.Voyager.Common.Attributes;
    using System;
    using System.Xml.Serialization;

    [Serializable, XmlType(Namespace="http://www.corillian.com/corillian/marketing/messages/2007/05", TypeName="ImportCampaignsRequest"), Transaction(TRX="CMImportCampaigns"), VoyagerRequestSerializable, XmlRoot(Namespace="http://www.corillian.com/corillian/marketing/messages/2007/05", ElementName="ImportCampaignsRequest")]
    public class ImportCampaignsRequest : Request, IFormattable
    {
        private CampaignCollection _campaignstoimports;
        private byte[] _exportedcampaignsxmlbytes;
        private string _filename;
        private string _filepath;
        private string _importedby;
        private string _importedthrough;
        private Corillian.Voyager.Common.Session _session;

        public virtual string ToString(string format)
        {
            return FormattableObject.ToString(this, format, null);
        }

        public virtual string ToString(string format, IFormatProvider formatProvider)
        {
            if (format == null)
            {
                return base.ToString();
            }
            return FormattableObject.ToString(this, format, formatProvider);
        }

        [XmlElement(ElementName="CampaignsToImport", Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05")]
        public CampaignCollection CampaignsToImportList
        {
            get
            {
                return this._campaignstoimports;
            }
            set
            {
                this._campaignstoimports = value;
            }
        }

        [XmlElement(ElementName="ExportedCampaignsXmlBytes", Namespace="http://www.corillian.com/corillian/marketing/messages/2007/05", DataType="base64Binary")]
        public byte[] ExportedCampaignsXmlBytes
        {
            get
            {
                return this._exportedcampaignsxmlbytes;
            }
            set
            {
                this._exportedcampaignsxmlbytes = value;
            }
        }

        [XmlElement(ElementName="FileName", Namespace="http://www.corillian.com/corillian/marketing/messages/2007/05", DataType="string")]
        public string FileName
        {
            get
            {
                return this._filename;
            }
            set
            {
                this._filename = value;
            }
        }

        [XmlElement(ElementName="FilePath", Namespace="http://www.corillian.com/corillian/marketing/messages/2007/05", DataType="string")]
        public string FilePath
        {
            get
            {
                return this._filepath;
            }
            set
            {
                this._filepath = value;
            }
        }

        [XmlElement(ElementName="ImportedBy", Namespace="http://www.corillian.com/corillian/marketing/messages/2007/05", DataType="string")]
        public string ImportedBy
        {
            get
            {
                return this._importedby;
            }
            set
            {
                this._importedby = value;
            }
        }

        [XmlElement(ElementName="ImportedThrough", Namespace="http://www.corillian.com/corillian/marketing/messages/2007/05", DataType="string")]
        public string ImportedThrough
        {
            get
            {
                return this._importedthrough;
            }
            set
            {
                this._importedthrough = value;
            }
        }

        [XmlElement(ElementName="Session", Namespace="http://www.corillian.com/operations/2004/11"), Scope(PropertyScopeType.HI), TagName("")]
        public Corillian.Voyager.Common.Session Session
        {
            get
            {
                return this._session;
            }
            set
            {
                this._session = value;
            }
        }
    }
}

