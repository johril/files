namespace Corillian.Marketing.Messages.Plugin
{
    using Corillian.Voyager.Common;
    using Corillian.Voyager.Common.Attributes;
    using System;
    using System.Xml.Serialization;

    [Serializable, XmlRoot(Namespace="http://www.corillian.com/corillian/marketing/messages/2007/05", ElementName="ActivateOrDeactivateCampaignRequest"), Transaction(TRX="CMActivateOrDeactivateCampaign"), VoyagerRequestSerializable, XmlType(Namespace="http://www.corillian.com/corillian/marketing/messages/2007/05", TypeName="ActivateOrDeactivateCampaignRequest")]
    public class ActivateOrDeactivateCampaignRequest : Request, IFormattable
    {
        private bool _activatedeactivateflag;
        private string _campaignguid;
        private string _modifiedby;
        private Corillian.Voyager.Common.Session _session;
        [Ignore, XmlIgnore]
        public bool ActivateDeactivateFlagSpecified;

        public virtual string ToString(string format)
        {
            return FormattableObject.ToString(this, format, null);
        }

        public virtual string ToString(string format, IFormatProvider formatProvider)
        {
            if (format == null)
            {
                return base.ToString();
            }
            return FormattableObject.ToString(this, format, formatProvider);
        }

        [XmlElement(ElementName="ActivateDeactivateFlag", Namespace="http://www.corillian.com/corillian/marketing/messages/2007/05", DataType="boolean")]
        public bool ActivateDeactivateFlag
        {
            get
            {
                return this._activatedeactivateflag;
            }
            set
            {
                this.ActivateDeactivateFlagSpecified = true;
                this._activatedeactivateflag = value;
            }
        }

        [XmlElement(ElementName="CampaignGuid", Namespace="http://www.corillian.com/corillian/marketing/messages/2007/05", DataType="string")]
        public string CampaignGuid
        {
            get
            {
                return this._campaignguid;
            }
            set
            {
                this._campaignguid = value;
            }
        }

        [XmlElement(ElementName="ModifiedBy", Namespace="http://www.corillian.com/corillian/marketing/messages/2007/05", DataType="string")]
        public string ModifiedBy
        {
            get
            {
                return this._modifiedby;
            }
            set
            {
                this._modifiedby = value;
            }
        }

        [Scope(PropertyScopeType.HI), TagName(""), XmlElement(ElementName="Session", Namespace="http://www.corillian.com/operations/2004/11")]
        public Corillian.Voyager.Common.Session Session
        {
            get
            {
                return this._session;
            }
            set
            {
                this._session = value;
            }
        }
    }
}

