namespace Corillian.Marketing.Messages.Plugin
{
    using Corillian.Marketing.Domain.Plugin;
    using Corillian.Voyager.Common;
    using Corillian.Voyager.Common.Attributes;
    using System;
    using System.Xml.Serialization;

    [Serializable, XmlRoot(Namespace="http://www.corillian.com/corillian/marketing/messages/2007/05", ElementName="GetSingleCampaignForDisplayResponse"), XmlType(Namespace="http://www.corillian.com/corillian/marketing/messages/2007/05", TypeName="GetSingleCampaignForDisplayResponse")]
    public class GetSingleCampaignForDisplayResponse : Response, IFormattable
    {
        private Corillian.Marketing.Domain.Plugin.Campaign _campaign;
        private Corillian.Marketing.Domain.Plugin.CMCustomerInfo _cmcustomerinfo;

        public virtual string ToString(string format)
        {
            return FormattableObject.ToString(this, format, null);
        }

        public virtual string ToString(string format, IFormatProvider formatProvider)
        {
            if (format == null)
            {
                return base.ToString();
            }
            return FormattableObject.ToString(this, format, formatProvider);
        }

        [XmlElement(ElementName="Campaign", Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05")]
        public Corillian.Marketing.Domain.Plugin.Campaign Campaign
        {
            get
            {
                return this._campaign;
            }
            set
            {
                this._campaign = value;
            }
        }

        [XmlElement(ElementName="CMCustomerInfo", Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05"), TagName(""), Scope(PropertyScopeType.HI)]
        public Corillian.Marketing.Domain.Plugin.CMCustomerInfo CMCustomerInfo
        {
            get
            {
                return this._cmcustomerinfo;
            }
            set
            {
                this._cmcustomerinfo = value;
            }
        }
    }
}

