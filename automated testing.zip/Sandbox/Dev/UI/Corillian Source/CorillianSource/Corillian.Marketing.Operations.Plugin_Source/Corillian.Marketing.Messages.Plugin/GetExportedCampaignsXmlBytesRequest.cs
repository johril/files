namespace Corillian.Marketing.Messages.Plugin
{
    using Corillian.Marketing.Domain.Plugin;
    using Corillian.Voyager.Common;
    using Corillian.Voyager.Common.Attributes;
    using System;
    using System.Xml.Serialization;

    [Serializable, Transaction(TRX="CMGetExportedCampaignsXmlBytes"), XmlType(Namespace="http://www.corillian.com/corillian/marketing/messages/2007/05", TypeName="GetExportedCampaignsXmlBytesRequest"), VoyagerRequestSerializable, XmlRoot(Namespace="http://www.corillian.com/corillian/marketing/messages/2007/05", ElementName="GetExportedCampaignsXmlBytesRequest")]
    public class GetExportedCampaignsXmlBytesRequest : Request, IFormattable
    {
        private CampaignCollection _campaignstoexports;
        private string _exportedby;
        private Corillian.Voyager.Common.Session _session;

        public virtual string ToString(string format)
        {
            return FormattableObject.ToString(this, format, null);
        }

        public virtual string ToString(string format, IFormatProvider formatProvider)
        {
            if (format == null)
            {
                return base.ToString();
            }
            return FormattableObject.ToString(this, format, formatProvider);
        }

        [XmlElement(ElementName="CampaignsToExport", Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05")]
        public CampaignCollection CampaignsToExportList
        {
            get
            {
                return this._campaignstoexports;
            }
            set
            {
                this._campaignstoexports = value;
            }
        }

        [XmlElement(ElementName="ExportedBy", Namespace="http://www.corillian.com/corillian/marketing/messages/2007/05", DataType="string")]
        public string ExportedBy
        {
            get
            {
                return this._exportedby;
            }
            set
            {
                this._exportedby = value;
            }
        }

        [TagName(""), XmlElement(ElementName="Session", Namespace="http://www.corillian.com/operations/2004/11"), Scope(PropertyScopeType.HI)]
        public Corillian.Voyager.Common.Session Session
        {
            get
            {
                return this._session;
            }
            set
            {
                this._session = value;
            }
        }
    }
}

