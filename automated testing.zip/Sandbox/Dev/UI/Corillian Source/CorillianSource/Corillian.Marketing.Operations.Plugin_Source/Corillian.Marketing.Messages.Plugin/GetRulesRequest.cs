namespace Corillian.Marketing.Messages.Plugin
{
    using Corillian.Voyager.Common;
    using Corillian.Voyager.Common.Attributes;
    using System;
    using System.Xml.Serialization;

    [Serializable, XmlType(Namespace="http://www.corillian.com/corillian/marketing/messages/2007/05", TypeName="GetRulesRequest"), Transaction(TRX="CMGetRules"), VoyagerRequestSerializable, XmlRoot(Namespace="http://www.corillian.com/corillian/marketing/messages/2007/05", ElementName="GetRulesRequest")]
    public class GetRulesRequest : Request, IFormattable
    {
        private Corillian.Voyager.Common.Session _session;
        private int _showrulesinuse;
        private int _showruleswithtestcells;
        private int _showsystemgenerated;
        [Ignore, XmlIgnore]
        public bool ShowRulesInUseSpecified;
        [Ignore, XmlIgnore]
        public bool ShowRulesWithTestCellsSpecified;
        [Ignore, XmlIgnore]
        public bool ShowSystemGeneratedSpecified;

        public virtual string ToString(string format)
        {
            return FormattableObject.ToString(this, format, null);
        }

        public virtual string ToString(string format, IFormatProvider formatProvider)
        {
            if (format == null)
            {
                return base.ToString();
            }
            return FormattableObject.ToString(this, format, formatProvider);
        }

        [XmlElement(ElementName="Session", Namespace="http://www.corillian.com/operations/2004/11"), TagName(""), Scope(PropertyScopeType.HI)]
        public Corillian.Voyager.Common.Session Session
        {
            get
            {
                return this._session;
            }
            set
            {
                this._session = value;
            }
        }

        [XmlElement(ElementName="ShowRulesInUse", Namespace="http://www.corillian.com/corillian/marketing/messages/2007/05", DataType="int")]
        public int ShowRulesInUse
        {
            get
            {
                return this._showrulesinuse;
            }
            set
            {
                this.ShowRulesInUseSpecified = true;
                this._showrulesinuse = value;
            }
        }

        [XmlElement(ElementName="ShowRulesWithTestCells", Namespace="http://www.corillian.com/corillian/marketing/messages/2007/05", DataType="int")]
        public int ShowRulesWithTestCells
        {
            get
            {
                return this._showruleswithtestcells;
            }
            set
            {
                this.ShowRulesWithTestCellsSpecified = true;
                this._showruleswithtestcells = value;
            }
        }

        [XmlElement(ElementName="ShowSystemGenerated", Namespace="http://www.corillian.com/corillian/marketing/messages/2007/05", DataType="int")]
        public int ShowSystemGenerated
        {
            get
            {
                return this._showsystemgenerated;
            }
            set
            {
                this.ShowSystemGeneratedSpecified = true;
                this._showsystemgenerated = value;
            }
        }
    }
}

