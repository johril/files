namespace Corillian.Marketing.Messages.Plugin
{
    using Corillian.Marketing.Domain.Plugin;
    using Corillian.Voyager.Common;
    using Corillian.Voyager.Common.Attributes;
    using System;
    using System.Xml.Serialization;

    [Serializable, VoyagerRequestSerializable, XmlRoot(Namespace="http://www.corillian.com/corillian/marketing/messages/2007/05", ElementName="LogCampaignCustomerInteractionHostDirectRequest"), XmlType(Namespace="http://www.corillian.com/corillian/marketing/messages/2007/05", TypeName="LogCampaignCustomerInteractionHostDirectRequest"), Transaction(TRX="HostDirect")]
    public class LogCampaignCustomerInteractionHostDirectRequest : Request, IFormattable
    {
        private string _admediaguid;
        private long _campaigncompositionid;
        private string _campaigninstanceguid;
        private long _cmcustomerid;
        private Corillian.Marketing.Domain.Plugin.CMCustomerInfo _cmcustomerinfo;
        private string _ruleguid;
        private string _ruleinstanceguid;
        private Corillian.Voyager.Common.Session _session;
        private string _subtrx = "CMLogCampaignCustomerInteraction";
        private int _webpageid;
        private string _webpagename;
        [Ignore, XmlIgnore]
        public bool CampaignCompositionIdSpecified;
        [Ignore, XmlIgnore]
        public bool CMCustomerIdSpecified;
        [XmlIgnore, Ignore]
        public bool WebPageIdSpecified;

        public virtual string ToString(string format)
        {
            return FormattableObject.ToString(this, format, null);
        }

        public virtual string ToString(string format, IFormatProvider formatProvider)
        {
            if (format == null)
            {
                return base.ToString();
            }
            return FormattableObject.ToString(this, format, formatProvider);
        }

        [XmlElement(ElementName="AdMediaGuid", Namespace="http://www.corillian.com/corillian/marketing/messages/2007/05", DataType="string")]
        public string AdMediaGuid
        {
            get
            {
                return this._admediaguid;
            }
            set
            {
                this._admediaguid = value;
            }
        }

        [XmlElement(ElementName="CampaignCompositionId", Namespace="http://www.corillian.com/corillian/marketing/messages/2007/05", DataType="long")]
        public long CampaignCompositionId
        {
            get
            {
                return this._campaigncompositionid;
            }
            set
            {
                this.CampaignCompositionIdSpecified = true;
                this._campaigncompositionid = value;
            }
        }

        [XmlElement(ElementName="CampaignInstanceGuid", Namespace="http://www.corillian.com/corillian/marketing/messages/2007/05", DataType="string")]
        public string CampaignInstanceGuid
        {
            get
            {
                return this._campaigninstanceguid;
            }
            set
            {
                this._campaigninstanceguid = value;
            }
        }

        [XmlElement(ElementName="CMCustomerId", Namespace="http://www.corillian.com/corillian/marketing/messages/2007/05", DataType="long"), IgnoreWhenEmpty]
        public long CMCustomerId
        {
            get
            {
                return this._cmcustomerid;
            }
            set
            {
                this.CMCustomerIdSpecified = true;
                this._cmcustomerid = value;
            }
        }

        [Scope(PropertyScopeType.HI), TagName(""), XmlElement(ElementName="CMCustomerInfo", Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05")]
        public Corillian.Marketing.Domain.Plugin.CMCustomerInfo CMCustomerInfo
        {
            get
            {
                return this._cmcustomerinfo;
            }
            set
            {
                this._cmcustomerinfo = value;
            }
        }

        [XmlElement(ElementName="RuleGuid", Namespace="http://www.corillian.com/corillian/marketing/messages/2007/05", DataType="string")]
        public string RuleGuid
        {
            get
            {
                return this._ruleguid;
            }
            set
            {
                this._ruleguid = value;
            }
        }

        [XmlElement(ElementName="RuleInstanceGuid", Namespace="http://www.corillian.com/corillian/marketing/messages/2007/05", DataType="string")]
        public string RuleInstanceGuid
        {
            get
            {
                return this._ruleinstanceguid;
            }
            set
            {
                this._ruleinstanceguid = value;
            }
        }

        [TagName(""), Scope(PropertyScopeType.HI), XmlElement(ElementName="Session", Namespace="http://www.corillian.com/operations/2004/11")]
        public Corillian.Voyager.Common.Session Session
        {
            get
            {
                return this._session;
            }
            set
            {
                this._session = value;
            }
        }

        [XmlElement(ElementName="SubTrx", Namespace="http://www.corillian.com/corillian/marketing/messages/2007/05", DataType="string"), TagName("SubTrx")]
        public string SubTrx
        {
            get
            {
                return this._subtrx;
            }
            set
            {
                this._subtrx = value;
            }
        }

        [XmlElement(ElementName="WebPageId", Namespace="http://www.corillian.com/corillian/marketing/messages/2007/05", DataType="int")]
        public int WebPageId
        {
            get
            {
                return this._webpageid;
            }
            set
            {
                this.WebPageIdSpecified = true;
                this._webpageid = value;
            }
        }

        [XmlElement(ElementName="WebPageName", Namespace="http://www.corillian.com/corillian/marketing/messages/2007/05", DataType="string")]
        public string WebPageName
        {
            get
            {
                return this._webpagename;
            }
            set
            {
                this._webpagename = value;
            }
        }
    }
}

