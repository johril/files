namespace Corillian.Marketing.Messages.Plugin
{
    using Corillian.Marketing.Domain.Plugin;
    using Corillian.Voyager.Common;
    using Corillian.Voyager.Common.Attributes;
    using System;
    using System.Xml.Serialization;

    [Serializable, XmlType(Namespace="http://www.corillian.com/corillian/marketing/messages/2007/05", TypeName="SaveRuleRequest"), VoyagerRequestSerializable, Transaction(TRX="CMSaveRule"), XmlRoot(Namespace="http://www.corillian.com/corillian/marketing/messages/2007/05", ElementName="SaveRuleRequest")]
    public class SaveRuleRequest : Request, IFormattable
    {
        private Corillian.Marketing.Domain.Plugin.Rule _rule;
        private RuleExpressionCollection _ruleexpressions;
        private Corillian.Voyager.Common.Session _session;

        public virtual string ToString(string format)
        {
            return FormattableObject.ToString(this, format, null);
        }

        public virtual string ToString(string format, IFormatProvider formatProvider)
        {
            if (format == null)
            {
                return base.ToString();
            }
            return FormattableObject.ToString(this, format, formatProvider);
        }

        [XmlElement(ElementName="Rule", Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05")]
        public Corillian.Marketing.Domain.Plugin.Rule Rule
        {
            get
            {
                return this._rule;
            }
            set
            {
                this._rule = value;
            }
        }

        [XmlElement(ElementName="RuleExpression", Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05")]
        public RuleExpressionCollection RuleExpressionList
        {
            get
            {
                return this._ruleexpressions;
            }
            set
            {
                this._ruleexpressions = value;
            }
        }

        [Scope(PropertyScopeType.HI), XmlElement(ElementName="Session", Namespace="http://www.corillian.com/operations/2004/11"), TagName("")]
        public Corillian.Voyager.Common.Session Session
        {
            get
            {
                return this._session;
            }
            set
            {
                this._session = value;
            }
        }
    }
}

