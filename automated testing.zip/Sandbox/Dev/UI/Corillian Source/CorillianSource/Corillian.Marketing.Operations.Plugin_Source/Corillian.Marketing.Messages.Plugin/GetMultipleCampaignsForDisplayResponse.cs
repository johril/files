namespace Corillian.Marketing.Messages.Plugin
{
    using Corillian.Marketing.Domain.Plugin;
    using Corillian.Voyager.Common;
    using Corillian.Voyager.Common.Attributes;
    using System;
    using System.Xml.Serialization;

    [Serializable, XmlType(Namespace="http://www.corillian.com/corillian/marketing/messages/2007/05", TypeName="GetMultipleCampaignsForDisplayResponse"), XmlRoot(Namespace="http://www.corillian.com/corillian/marketing/messages/2007/05", ElementName="GetMultipleCampaignsForDisplayResponse")]
    public class GetMultipleCampaignsForDisplayResponse : Response, IFormattable
    {
        private CampaignCollection _campaigns;
        private Corillian.Marketing.Domain.Plugin.CMCustomerInfo _cmcustomerinfo;

        public virtual string ToString(string format)
        {
            return FormattableObject.ToString(this, format, null);
        }

        public virtual string ToString(string format, IFormatProvider formatProvider)
        {
            if (format == null)
            {
                return base.ToString();
            }
            return FormattableObject.ToString(this, format, formatProvider);
        }

        [XmlElement(ElementName="Campaign", Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05"), IgnoreWhenEmpty]
        public CampaignCollection CampaignList
        {
            get
            {
                return this._campaigns;
            }
            set
            {
                this._campaigns = value;
            }
        }

        [TagName(""), Scope(PropertyScopeType.HI), XmlElement(ElementName="CMCustomerInfo", Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05")]
        public Corillian.Marketing.Domain.Plugin.CMCustomerInfo CMCustomerInfo
        {
            get
            {
                return this._cmcustomerinfo;
            }
            set
            {
                this._cmcustomerinfo = value;
            }
        }
    }
}

