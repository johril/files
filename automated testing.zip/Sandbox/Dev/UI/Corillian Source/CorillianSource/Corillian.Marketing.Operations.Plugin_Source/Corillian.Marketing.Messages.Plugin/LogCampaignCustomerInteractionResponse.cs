namespace Corillian.Marketing.Messages.Plugin
{
    using Corillian.Voyager.Common;
    using System;
    using System.Xml.Serialization;

    [Serializable, XmlType(Namespace="http://www.corillian.com/corillian/marketing/messages/2007/05", TypeName="LogCampaignCustomerInteractionResponse"), XmlRoot(Namespace="http://www.corillian.com/corillian/marketing/messages/2007/05", ElementName="LogCampaignCustomerInteractionResponse")]
    public class LogCampaignCustomerInteractionResponse : Response, IFormattable
    {
        public virtual string ToString(string format)
        {
            return FormattableObject.ToString(this, format, null);
        }

        public virtual string ToString(string format, IFormatProvider formatProvider)
        {
            if (format == null)
            {
                return base.ToString();
            }
            return FormattableObject.ToString(this, format, formatProvider);
        }
    }
}

