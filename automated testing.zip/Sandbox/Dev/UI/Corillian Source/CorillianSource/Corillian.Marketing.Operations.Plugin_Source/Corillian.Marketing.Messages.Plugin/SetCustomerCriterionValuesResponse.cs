namespace Corillian.Marketing.Messages.Plugin
{
    using Corillian.Marketing.Domain.Plugin;
    using Corillian.Voyager.Common;
    using Corillian.Voyager.Common.Attributes;
    using System;
    using System.Xml.Serialization;

    [Serializable, XmlType(Namespace="http://www.corillian.com/corillian/marketing/messages/2007/05", TypeName="SetCustomerCriterionValuesResponse"), XmlRoot(Namespace="http://www.corillian.com/corillian/marketing/messages/2007/05", ElementName="SetCustomerCriterionValuesResponse")]
    public class SetCustomerCriterionValuesResponse : Response, IFormattable
    {
        private Corillian.Marketing.Domain.Plugin.CMCustomerInfo _cmcustomerinfo;

        public virtual string ToString(string format)
        {
            return FormattableObject.ToString(this, format, null);
        }

        public virtual string ToString(string format, IFormatProvider formatProvider)
        {
            if (format == null)
            {
                return base.ToString();
            }
            return FormattableObject.ToString(this, format, formatProvider);
        }

        [Scope(PropertyScopeType.HI), XmlElement(ElementName="CMCustomerInfo", Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05"), TagName("")]
        public Corillian.Marketing.Domain.Plugin.CMCustomerInfo CMCustomerInfo
        {
            get
            {
                return this._cmcustomerinfo;
            }
            set
            {
                this._cmcustomerinfo = value;
            }
        }
    }
}

