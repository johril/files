namespace Corillian.Marketing.Messages.Plugin
{
    using Corillian.Marketing.Domain.Plugin;
    using Corillian.Voyager.Common;
    using System;
    using System.Xml.Serialization;

    [Serializable, XmlRoot(Namespace="http://www.corillian.com/corillian/marketing/messages/2007/05", ElementName="GetCampaignResponse"), XmlType(Namespace="http://www.corillian.com/corillian/marketing/messages/2007/05", TypeName="GetCampaignResponse")]
    public class GetCampaignResponse : Response, IFormattable
    {
        private Corillian.Marketing.Domain.Plugin.Campaign _campaign;
        private CampaignContextMapCollection _campaigncontextmaps;
        private CampaignInstanceCompositionMapCollection _campaigninstancecompositionmaps;
        private WebPageAdSpaceCampaignMapCollection _webpageadspacecampaignmaps;

        public virtual string ToString(string format)
        {
            return FormattableObject.ToString(this, format, null);
        }

        public virtual string ToString(string format, IFormatProvider formatProvider)
        {
            if (format == null)
            {
                return base.ToString();
            }
            return FormattableObject.ToString(this, format, formatProvider);
        }

        [XmlElement(ElementName="Campaign", Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05")]
        public Corillian.Marketing.Domain.Plugin.Campaign Campaign
        {
            get
            {
                return this._campaign;
            }
            set
            {
                this._campaign = value;
            }
        }

        [XmlElement(ElementName="CampaignContextMap", Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05")]
        public CampaignContextMapCollection CampaignContextMapList
        {
            get
            {
                return this._campaigncontextmaps;
            }
            set
            {
                this._campaigncontextmaps = value;
            }
        }

        [XmlElement(ElementName="CampaignInstanceCompositionMap", Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05")]
        public CampaignInstanceCompositionMapCollection CampaignInstanceCompositionMapList
        {
            get
            {
                return this._campaigninstancecompositionmaps;
            }
            set
            {
                this._campaigninstancecompositionmaps = value;
            }
        }

        [XmlElement(ElementName="WebPageAdSpaceCampaignMap", Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05")]
        public WebPageAdSpaceCampaignMapCollection WebPageAdSpaceCampaignMapList
        {
            get
            {
                return this._webpageadspacecampaignmaps;
            }
            set
            {
                this._webpageadspacecampaignmaps = value;
            }
        }
    }
}

