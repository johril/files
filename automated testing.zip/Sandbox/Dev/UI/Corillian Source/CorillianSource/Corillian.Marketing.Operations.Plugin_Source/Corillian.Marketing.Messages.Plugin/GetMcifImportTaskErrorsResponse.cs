namespace Corillian.Marketing.Messages.Plugin
{
    using Corillian.Marketing.Domain.Plugin;
    using Corillian.Voyager.Common;
    using System;
    using System.Xml.Serialization;

    [Serializable, XmlType(Namespace="http://www.corillian.com/corillian/marketing/messages/2007/05", TypeName="GetMcifImportTaskErrorsResponse"), XmlRoot(Namespace="http://www.corillian.com/corillian/marketing/messages/2007/05", ElementName="GetMcifImportTaskErrorsResponse")]
    public class GetMcifImportTaskErrorsResponse : Response, IFormattable
    {
        private Corillian.Marketing.Domain.Plugin.McifImportTask _mcifimporttask;
        private McifImportTaskErrorCollection _mcifimporttaskerrors;

        public virtual string ToString(string format)
        {
            return FormattableObject.ToString(this, format, null);
        }

        public virtual string ToString(string format, IFormatProvider formatProvider)
        {
            if (format == null)
            {
                return base.ToString();
            }
            return FormattableObject.ToString(this, format, formatProvider);
        }

        [XmlElement(ElementName="McifImportTask", Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05")]
        public Corillian.Marketing.Domain.Plugin.McifImportTask McifImportTask
        {
            get
            {
                return this._mcifimporttask;
            }
            set
            {
                this._mcifimporttask = value;
            }
        }

        [XmlElement(ElementName="McifImportTaskError", Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05")]
        public McifImportTaskErrorCollection McifImportTaskErrorList
        {
            get
            {
                return this._mcifimporttaskerrors;
            }
            set
            {
                this._mcifimporttaskerrors = value;
            }
        }
    }
}

