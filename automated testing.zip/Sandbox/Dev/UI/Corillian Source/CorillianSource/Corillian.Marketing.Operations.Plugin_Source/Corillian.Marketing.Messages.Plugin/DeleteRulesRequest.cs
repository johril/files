namespace Corillian.Marketing.Messages.Plugin
{
    using Corillian.Voyager.Common;
    using Corillian.Voyager.Common.Attributes;
    using System;
    using System.Xml.Serialization;

    [Serializable, XmlType(Namespace="http://www.corillian.com/corillian/marketing/messages/2007/05", TypeName="DeleteRulesRequest"), XmlRoot(Namespace="http://www.corillian.com/corillian/marketing/messages/2007/05", ElementName="DeleteRulesRequest"), Transaction(TRX="CMDeleteRules"), VoyagerRequestSerializable]
    public class DeleteRulesRequest : Request, IFormattable
    {
        private int _deleteundelete;
        private string _ruleguid;
        private Corillian.Voyager.Common.Session _session;
        [XmlIgnore, Ignore]
        public bool DeleteUnDeleteSpecified;

        public virtual string ToString(string format)
        {
            return FormattableObject.ToString(this, format, null);
        }

        public virtual string ToString(string format, IFormatProvider formatProvider)
        {
            if (format == null)
            {
                return base.ToString();
            }
            return FormattableObject.ToString(this, format, formatProvider);
        }

        [XmlElement(ElementName="DeleteUnDelete", Namespace="http://www.corillian.com/corillian/marketing/messages/2007/05", DataType="int")]
        public int DeleteUnDelete
        {
            get
            {
                return this._deleteundelete;
            }
            set
            {
                this.DeleteUnDeleteSpecified = true;
                this._deleteundelete = value;
            }
        }

        [XmlElement(ElementName="RuleGUID", Namespace="http://www.corillian.com/corillian/marketing/messages/2007/05", DataType="string")]
        public string RuleGUID
        {
            get
            {
                return this._ruleguid;
            }
            set
            {
                this._ruleguid = value;
            }
        }

        [Scope(PropertyScopeType.HI), TagName(""), XmlElement(ElementName="Session", Namespace="http://www.corillian.com/operations/2004/11")]
        public Corillian.Voyager.Common.Session Session
        {
            get
            {
                return this._session;
            }
            set
            {
                this._session = value;
            }
        }
    }
}

