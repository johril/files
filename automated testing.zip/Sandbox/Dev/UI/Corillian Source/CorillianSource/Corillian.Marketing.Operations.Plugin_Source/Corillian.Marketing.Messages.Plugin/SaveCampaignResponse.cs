namespace Corillian.Marketing.Messages.Plugin
{
    using Corillian.Voyager.Common;
    using Corillian.Voyager.Common.Attributes;
    using System;
    using System.Xml.Serialization;

    [Serializable, XmlRoot(Namespace="http://www.corillian.com/corillian/marketing/messages/2007/05", ElementName="SaveCampaignResponse"), XmlType(Namespace="http://www.corillian.com/corillian/marketing/messages/2007/05", TypeName="SaveCampaignResponse")]
    public class SaveCampaignResponse : Response, IFormattable
    {
        private string _campaignguid;
        private bool _hierarchyvalueexists;
        private bool _iscampaignsaved;
        private bool _isdefaultexists;
        [XmlIgnore, Ignore]
        public bool HierarchyValueExistsSpecified;
        [Ignore, XmlIgnore]
        public bool IsCampaignSavedSpecified;
        [Ignore, XmlIgnore]
        public bool IsDefaultExistsSpecified;

        public virtual string ToString(string format)
        {
            return FormattableObject.ToString(this, format, null);
        }

        public virtual string ToString(string format, IFormatProvider formatProvider)
        {
            if (format == null)
            {
                return base.ToString();
            }
            return FormattableObject.ToString(this, format, formatProvider);
        }

        [XmlElement(ElementName="CampaignGuid", Namespace="http://www.corillian.com/corillian/marketing/messages/2007/05", DataType="string")]
        public string CampaignGuid
        {
            get
            {
                return this._campaignguid;
            }
            set
            {
                this._campaignguid = value;
            }
        }

        [XmlElement(ElementName="HierarchyValueExists", Namespace="http://www.corillian.com/corillian/marketing/messages/2007/05", DataType="boolean")]
        public bool HierarchyValueExists
        {
            get
            {
                return this._hierarchyvalueexists;
            }
            set
            {
                this.HierarchyValueExistsSpecified = true;
                this._hierarchyvalueexists = value;
            }
        }

        [XmlElement(ElementName="IsCampaignSaved", Namespace="http://www.corillian.com/corillian/marketing/messages/2007/05", DataType="boolean")]
        public bool IsCampaignSaved
        {
            get
            {
                return this._iscampaignsaved;
            }
            set
            {
                this.IsCampaignSavedSpecified = true;
                this._iscampaignsaved = value;
            }
        }

        [XmlElement(ElementName="IsDefaultExists", Namespace="http://www.corillian.com/corillian/marketing/messages/2007/05", DataType="boolean")]
        public bool IsDefaultExists
        {
            get
            {
                return this._isdefaultexists;
            }
            set
            {
                this.IsDefaultExistsSpecified = true;
                this._isdefaultexists = value;
            }
        }
    }
}

