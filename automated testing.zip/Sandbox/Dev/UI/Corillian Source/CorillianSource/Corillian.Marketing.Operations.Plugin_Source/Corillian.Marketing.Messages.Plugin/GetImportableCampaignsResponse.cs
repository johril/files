namespace Corillian.Marketing.Messages.Plugin
{
    using Corillian.Marketing.Domain.Plugin;
    using Corillian.Voyager.Common;
    using Corillian.Voyager.Common.Attributes;
    using System;
    using System.Xml.Serialization;

    [Serializable, XmlType(Namespace="http://www.corillian.com/corillian/marketing/messages/2007/05", TypeName="GetImportableCampaignsResponse"), XmlRoot(Namespace="http://www.corillian.com/corillian/marketing/messages/2007/05", ElementName="GetImportableCampaignsResponse")]
    public class GetImportableCampaignsResponse : Response, IFormattable
    {
        private CampaignCollection _campaignstoimports;
        private string _exportedby;
        private DateTime _exportedon;
        [XmlIgnore, Ignore]
        public bool ExportedOnSpecified;

        public virtual string ToString(string format)
        {
            return FormattableObject.ToString(this, format, null);
        }

        public virtual string ToString(string format, IFormatProvider formatProvider)
        {
            if (format == null)
            {
                return base.ToString();
            }
            return FormattableObject.ToString(this, format, formatProvider);
        }

        [XmlElement(ElementName="CampaignsToImport", Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05")]
        public CampaignCollection CampaignsToImportList
        {
            get
            {
                return this._campaignstoimports;
            }
            set
            {
                this._campaignstoimports = value;
            }
        }

        [XmlElement(ElementName="ExportedBy", Namespace="http://www.corillian.com/corillian/marketing/messages/2007/05", DataType="string")]
        public string ExportedBy
        {
            get
            {
                return this._exportedby;
            }
            set
            {
                this._exportedby = value;
            }
        }

        [XmlElement(ElementName="ExportedOn", Namespace="http://www.corillian.com/corillian/marketing/messages/2007/05", DataType="date")]
        public DateTime ExportedOn
        {
            get
            {
                return this._exportedon;
            }
            set
            {
                this.ExportedOnSpecified = true;
                this._exportedon = value;
            }
        }
    }
}

