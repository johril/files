namespace Corillian.Marketing.Operations.Plugin
{
    using Corillian.Marketing.Messages.Plugin;
    using Corillian.Voyager.Common;
    using Corillian.Voyager.Common.Attributes;
    using Corillian.Voyager.ExecutionServices.Transaction;
    using System;

    [Transaction("GetCampaigns")]
    public class TrxImpGetCampaigns : Trx
    {
        private GetCampaignsRequest _requestParams = new GetCampaignsRequest();
        private GetCampaignsResponse _responseParams = new GetCampaignsResponse();

        public override Corillian.Voyager.Common.Request Request
        {
            get
            {
                return this._requestParams;
            }
            set
            {
                this._requestParams = (GetCampaignsRequest) value;
            }
        }

        public GetCampaignsRequest RequestParameters
        {
            get
            {
                return this._requestParams;
            }
        }

        public override Corillian.Voyager.Common.Response Response
        {
            get
            {
                return this._responseParams;
            }
            set
            {
                this._responseParams = (GetCampaignsResponse) value;
            }
        }

        public GetCampaignsResponse ResponseParameters
        {
            get
            {
                return this._responseParams;
            }
        }
    }
}

