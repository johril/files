namespace Corillian.Marketing.Operations.Plugin
{
    using Corillian.Marketing.Messages.Plugin;
    using Corillian.Voyager.Common;
    using Corillian.Voyager.Common.Attributes;
    using Corillian.Voyager.ExecutionServices.Transaction;
    using System;

    [Transaction("GetCampaignImportTasks")]
    public class TrxImpGetCampaignImportTasks : Trx
    {
        private GetCampaignImportTasksRequest _requestParams = new GetCampaignImportTasksRequest();
        private GetCampaignImportTasksResponse _responseParams = new GetCampaignImportTasksResponse();

        public override Corillian.Voyager.Common.Request Request
        {
            get
            {
                return this._requestParams;
            }
            set
            {
                this._requestParams = (GetCampaignImportTasksRequest) value;
            }
        }

        public GetCampaignImportTasksRequest RequestParameters
        {
            get
            {
                return this._requestParams;
            }
        }

        public override Corillian.Voyager.Common.Response Response
        {
            get
            {
                return this._responseParams;
            }
            set
            {
                this._responseParams = (GetCampaignImportTasksResponse) value;
            }
        }

        public GetCampaignImportTasksResponse ResponseParameters
        {
            get
            {
                return this._responseParams;
            }
        }
    }
}

