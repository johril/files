namespace Corillian.Marketing.Operations.Plugin
{
    using Corillian.Marketing.Messages.Plugin;
    using Corillian.Voyager.Common;
    using Corillian.Voyager.Common.Attributes;
    using Corillian.Voyager.ExecutionServices.Transaction;
    using System;

    [Transaction("GetRuleTokenTypes")]
    public class TrxImpGetRuleTokenTypes : Trx
    {
        private GetRuleTokenTypesRequest _requestParams = new GetRuleTokenTypesRequest();
        private GetRuleTokenTypesResponse _responseParams = new GetRuleTokenTypesResponse();

        public override Corillian.Voyager.Common.Request Request
        {
            get
            {
                return this._requestParams;
            }
            set
            {
                this._requestParams = (GetRuleTokenTypesRequest) value;
            }
        }

        public GetRuleTokenTypesRequest RequestParameters
        {
            get
            {
                return this._requestParams;
            }
        }

        public override Corillian.Voyager.Common.Response Response
        {
            get
            {
                return this._responseParams;
            }
            set
            {
                this._responseParams = (GetRuleTokenTypesResponse) value;
            }
        }

        public GetRuleTokenTypesResponse ResponseParameters
        {
            get
            {
                return this._responseParams;
            }
        }
    }
}

