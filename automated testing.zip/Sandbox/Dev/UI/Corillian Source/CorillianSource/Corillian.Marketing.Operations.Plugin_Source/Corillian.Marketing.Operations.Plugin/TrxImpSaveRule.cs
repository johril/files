namespace Corillian.Marketing.Operations.Plugin
{
    using Corillian.Marketing.Messages.Plugin;
    using Corillian.Voyager.Common;
    using Corillian.Voyager.Common.Attributes;
    using Corillian.Voyager.ExecutionServices.Transaction;
    using System;

    [Transaction("SaveRule")]
    public class TrxImpSaveRule : Trx
    {
        private SaveRuleRequest _requestParams = new SaveRuleRequest();
        private SaveRuleResponse _responseParams = new SaveRuleResponse();

        public override Corillian.Voyager.Common.Request Request
        {
            get
            {
                return this._requestParams;
            }
            set
            {
                this._requestParams = (SaveRuleRequest) value;
            }
        }

        public SaveRuleRequest RequestParameters
        {
            get
            {
                return this._requestParams;
            }
        }

        public override Corillian.Voyager.Common.Response Response
        {
            get
            {
                return this._responseParams;
            }
            set
            {
                this._responseParams = (SaveRuleResponse) value;
            }
        }

        public SaveRuleResponse ResponseParameters
        {
            get
            {
                return this._responseParams;
            }
        }
    }
}

