namespace Corillian.Marketing.Operations.Plugin
{
    using Corillian.Marketing.Messages.Plugin;
    using Corillian.Voyager.Common;
    using Corillian.Voyager.Common.Attributes;
    using Corillian.Voyager.ExecutionServices.Transaction;
    using System;

    [Transaction("DeleteRules")]
    public class TrxImpDeleteRules : Trx
    {
        private DeleteRulesRequest _requestParams = new DeleteRulesRequest();
        private DeleteRulesResponse _responseParams = new DeleteRulesResponse();

        public override Corillian.Voyager.Common.Request Request
        {
            get
            {
                return this._requestParams;
            }
            set
            {
                this._requestParams = (DeleteRulesRequest) value;
            }
        }

        public DeleteRulesRequest RequestParameters
        {
            get
            {
                return this._requestParams;
            }
        }

        public override Corillian.Voyager.Common.Response Response
        {
            get
            {
                return this._responseParams;
            }
            set
            {
                this._responseParams = (DeleteRulesResponse) value;
            }
        }

        public DeleteRulesResponse ResponseParameters
        {
            get
            {
                return this._responseParams;
            }
        }
    }
}

