namespace Corillian.Marketing.Operations.Plugin
{
    using Corillian.Marketing.Messages.Plugin;
    using Corillian.Voyager.Common;
    using Corillian.Voyager.Common.Attributes;
    using Corillian.Voyager.ExecutionServices.Transaction;
    using System;

    [Transaction("DeleteCriterionMetadata")]
    public class TrxImpDeleteCriterionMetadata : Trx
    {
        private DeleteCriterionMetadataRequest _requestParams = new DeleteCriterionMetadataRequest();
        private DeleteCriterionMetadataResponse _responseParams = new DeleteCriterionMetadataResponse();

        public override Corillian.Voyager.Common.Request Request
        {
            get
            {
                return this._requestParams;
            }
            set
            {
                this._requestParams = (DeleteCriterionMetadataRequest) value;
            }
        }

        public DeleteCriterionMetadataRequest RequestParameters
        {
            get
            {
                return this._requestParams;
            }
        }

        public override Corillian.Voyager.Common.Response Response
        {
            get
            {
                return this._responseParams;
            }
            set
            {
                this._responseParams = (DeleteCriterionMetadataResponse) value;
            }
        }

        public DeleteCriterionMetadataResponse ResponseParameters
        {
            get
            {
                return this._responseParams;
            }
        }
    }
}

