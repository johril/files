namespace Corillian.Marketing.Operations.Plugin
{
    using Corillian.Marketing.Messages.Plugin;
    using Corillian.Voyager.Common;
    using Corillian.Voyager.Common.Attributes;
    using Corillian.Voyager.ExecutionServices.Transaction;
    using System;

    [Transaction("GetWebPages")]
    public class TrxImpGetWebPages : Trx
    {
        private GetWebPagesRequest _requestParams = new GetWebPagesRequest();
        private GetWebPagesResponse _responseParams = new GetWebPagesResponse();

        public override Corillian.Voyager.Common.Request Request
        {
            get
            {
                return this._requestParams;
            }
            set
            {
                this._requestParams = (GetWebPagesRequest) value;
            }
        }

        public GetWebPagesRequest RequestParameters
        {
            get
            {
                return this._requestParams;
            }
        }

        public override Corillian.Voyager.Common.Response Response
        {
            get
            {
                return this._responseParams;
            }
            set
            {
                this._responseParams = (GetWebPagesResponse) value;
            }
        }

        public GetWebPagesResponse ResponseParameters
        {
            get
            {
                return this._responseParams;
            }
        }
    }
}

