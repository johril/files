namespace Corillian.Marketing.Operations.Plugin
{
    using Corillian.Marketing.Messages.Plugin;
    using Corillian.Voyager.Common;
    using Corillian.Voyager.Common.Attributes;
    using Corillian.Voyager.ExecutionServices.Transaction;
    using System;

    [Transaction("GetCampaignImportTaskMessages")]
    public class TrxImpGetCampaignImportTaskMessages : Trx
    {
        private GetCampaignImportTaskMessagesRequest _requestParams = new GetCampaignImportTaskMessagesRequest();
        private GetCampaignImportTaskMessagesResponse _responseParams = new GetCampaignImportTaskMessagesResponse();

        public override Corillian.Voyager.Common.Request Request
        {
            get
            {
                return this._requestParams;
            }
            set
            {
                this._requestParams = (GetCampaignImportTaskMessagesRequest) value;
            }
        }

        public GetCampaignImportTaskMessagesRequest RequestParameters
        {
            get
            {
                return this._requestParams;
            }
        }

        public override Corillian.Voyager.Common.Response Response
        {
            get
            {
                return this._responseParams;
            }
            set
            {
                this._responseParams = (GetCampaignImportTaskMessagesResponse) value;
            }
        }

        public GetCampaignImportTaskMessagesResponse ResponseParameters
        {
            get
            {
                return this._responseParams;
            }
        }
    }
}

