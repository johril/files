namespace Corillian.Marketing.Operations.Plugin
{
    using Corillian.Marketing.Messages.Plugin;
    using Corillian.Voyager.Common;
    using Corillian.Voyager.Common.Attributes;
    using Corillian.Voyager.ExecutionServices.Transaction;
    using System;

    [Transaction("GetExportedCampaignsXmlBytes")]
    public class TrxImpGetExportedCampaignsXmlBytes : Trx
    {
        private GetExportedCampaignsXmlBytesRequest _requestParams = new GetExportedCampaignsXmlBytesRequest();
        private GetExportedCampaignsXmlBytesResponse _responseParams = new GetExportedCampaignsXmlBytesResponse();

        public override Corillian.Voyager.Common.Request Request
        {
            get
            {
                return this._requestParams;
            }
            set
            {
                this._requestParams = (GetExportedCampaignsXmlBytesRequest) value;
            }
        }

        public GetExportedCampaignsXmlBytesRequest RequestParameters
        {
            get
            {
                return this._requestParams;
            }
        }

        public override Corillian.Voyager.Common.Response Response
        {
            get
            {
                return this._responseParams;
            }
            set
            {
                this._responseParams = (GetExportedCampaignsXmlBytesResponse) value;
            }
        }

        public GetExportedCampaignsXmlBytesResponse ResponseParameters
        {
            get
            {
                return this._responseParams;
            }
        }
    }
}

