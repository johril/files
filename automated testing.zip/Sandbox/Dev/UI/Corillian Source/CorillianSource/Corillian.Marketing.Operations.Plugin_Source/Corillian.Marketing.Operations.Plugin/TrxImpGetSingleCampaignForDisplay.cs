namespace Corillian.Marketing.Operations.Plugin
{
    using Corillian.Marketing.Messages.Plugin;
    using Corillian.Voyager.Common;
    using Corillian.Voyager.Common.Attributes;
    using Corillian.Voyager.ExecutionServices.Transaction;
    using System;

    [Transaction("GetSingleCampaignForDisplay")]
    public class TrxImpGetSingleCampaignForDisplay : Trx
    {
        private GetSingleCampaignForDisplayRequest _requestParams = new GetSingleCampaignForDisplayRequest();
        private GetSingleCampaignForDisplayResponse _responseParams = new GetSingleCampaignForDisplayResponse();

        public override Corillian.Voyager.Common.Request Request
        {
            get
            {
                return this._requestParams;
            }
            set
            {
                this._requestParams = (GetSingleCampaignForDisplayRequest) value;
            }
        }

        public GetSingleCampaignForDisplayRequest RequestParameters
        {
            get
            {
                return this._requestParams;
            }
        }

        public override Corillian.Voyager.Common.Response Response
        {
            get
            {
                return this._responseParams;
            }
            set
            {
                this._responseParams = (GetSingleCampaignForDisplayResponse) value;
            }
        }

        public GetSingleCampaignForDisplayResponse ResponseParameters
        {
            get
            {
                return this._responseParams;
            }
        }
    }
}

