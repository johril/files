namespace Corillian.Marketing.Operations.Plugin
{
    using Corillian.Marketing.Messages.Plugin;
    using Corillian.Voyager.Common;
    using Corillian.Voyager.Common.Attributes;
    using Corillian.Voyager.ExecutionServices.Transaction;
    using System;

    [Transaction("GetCampaign")]
    public class TrxImpGetCampaign : Trx
    {
        private GetCampaignRequest _requestParams = new GetCampaignRequest();
        private GetCampaignResponse _responseParams = new GetCampaignResponse();

        public override Corillian.Voyager.Common.Request Request
        {
            get
            {
                return this._requestParams;
            }
            set
            {
                this._requestParams = (GetCampaignRequest) value;
            }
        }

        public GetCampaignRequest RequestParameters
        {
            get
            {
                return this._requestParams;
            }
        }

        public override Corillian.Voyager.Common.Response Response
        {
            get
            {
                return this._responseParams;
            }
            set
            {
                this._responseParams = (GetCampaignResponse) value;
            }
        }

        public GetCampaignResponse ResponseParameters
        {
            get
            {
                return this._responseParams;
            }
        }
    }
}

