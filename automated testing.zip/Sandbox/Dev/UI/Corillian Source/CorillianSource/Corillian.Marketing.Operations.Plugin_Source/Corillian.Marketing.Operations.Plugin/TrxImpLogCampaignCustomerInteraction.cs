namespace Corillian.Marketing.Operations.Plugin
{
    using Corillian.Marketing.Messages.Plugin;
    using Corillian.Voyager.Common;
    using Corillian.Voyager.Common.Attributes;
    using Corillian.Voyager.ExecutionServices.Transaction;
    using System;

    [Transaction("LogCampaignCustomerInteraction")]
    public class TrxImpLogCampaignCustomerInteraction : Trx
    {
        private LogCampaignCustomerInteractionRequest _requestParams = new LogCampaignCustomerInteractionRequest();
        private LogCampaignCustomerInteractionResponse _responseParams = new LogCampaignCustomerInteractionResponse();

        public override Corillian.Voyager.Common.Request Request
        {
            get
            {
                return this._requestParams;
            }
            set
            {
                this._requestParams = (LogCampaignCustomerInteractionRequest) value;
            }
        }

        public LogCampaignCustomerInteractionRequest RequestParameters
        {
            get
            {
                return this._requestParams;
            }
        }

        public override Corillian.Voyager.Common.Response Response
        {
            get
            {
                return this._responseParams;
            }
            set
            {
                this._responseParams = (LogCampaignCustomerInteractionResponse) value;
            }
        }

        public LogCampaignCustomerInteractionResponse ResponseParameters
        {
            get
            {
                return this._responseParams;
            }
        }
    }
}

