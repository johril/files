namespace Corillian.Marketing.Operations.Plugin
{
    using Corillian.Marketing.Messages.Plugin;
    using Corillian.Voyager.Common;
    using Corillian.Voyager.Common.Attributes;
    using Corillian.Voyager.ExecutionServices.Transaction;
    using System;

    [Transaction("GetCriterionMetadata")]
    public class TrxImpGetCriterionMetadata : Trx
    {
        private GetCriterionMetadataRequest _requestParams = new GetCriterionMetadataRequest();
        private GetCriterionMetadataResponse _responseParams = new GetCriterionMetadataResponse();

        public override Corillian.Voyager.Common.Request Request
        {
            get
            {
                return this._requestParams;
            }
            set
            {
                this._requestParams = (GetCriterionMetadataRequest) value;
            }
        }

        public GetCriterionMetadataRequest RequestParameters
        {
            get
            {
                return this._requestParams;
            }
        }

        public override Corillian.Voyager.Common.Response Response
        {
            get
            {
                return this._responseParams;
            }
            set
            {
                this._responseParams = (GetCriterionMetadataResponse) value;
            }
        }

        public GetCriterionMetadataResponse ResponseParameters
        {
            get
            {
                return this._responseParams;
            }
        }
    }
}

