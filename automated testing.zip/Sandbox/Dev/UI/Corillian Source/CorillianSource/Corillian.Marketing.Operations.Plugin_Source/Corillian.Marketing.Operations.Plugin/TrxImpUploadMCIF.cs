namespace Corillian.Marketing.Operations.Plugin
{
    using Corillian.Marketing.Messages.Plugin;
    using Corillian.Voyager.Common;
    using Corillian.Voyager.Common.Attributes;
    using Corillian.Voyager.ExecutionServices.Transaction;
    using System;

    [Transaction("UploadMCIF")]
    public class TrxImpUploadMCIF : Trx
    {
        private UploadMCIFRequest _requestParams = new UploadMCIFRequest();
        private UploadMCIFResponse _responseParams = new UploadMCIFResponse();

        public override Corillian.Voyager.Common.Request Request
        {
            get
            {
                return this._requestParams;
            }
            set
            {
                this._requestParams = (UploadMCIFRequest) value;
            }
        }

        public UploadMCIFRequest RequestParameters
        {
            get
            {
                return this._requestParams;
            }
        }

        public override Corillian.Voyager.Common.Response Response
        {
            get
            {
                return this._responseParams;
            }
            set
            {
                this._responseParams = (UploadMCIFResponse) value;
            }
        }

        public UploadMCIFResponse ResponseParameters
        {
            get
            {
                return this._responseParams;
            }
        }
    }
}

