namespace Corillian.Marketing.Operations.Plugin
{
    using Corillian.Marketing.Messages.Plugin;
    using Corillian.Voyager.Common;
    using Corillian.Voyager.Common.Attributes;
    using Corillian.Voyager.ExecutionServices.Transaction;
    using System;

    [Transaction("GetAdSpaces")]
    public class TrxImpGetAdSpaces : Trx
    {
        private GetAdSpacesRequest _requestParams = new GetAdSpacesRequest();
        private GetAdSpacesResponse _responseParams = new GetAdSpacesResponse();

        public override Corillian.Voyager.Common.Request Request
        {
            get
            {
                return this._requestParams;
            }
            set
            {
                this._requestParams = (GetAdSpacesRequest) value;
            }
        }

        public GetAdSpacesRequest RequestParameters
        {
            get
            {
                return this._requestParams;
            }
        }

        public override Corillian.Voyager.Common.Response Response
        {
            get
            {
                return this._responseParams;
            }
            set
            {
                this._responseParams = (GetAdSpacesResponse) value;
            }
        }

        public GetAdSpacesResponse ResponseParameters
        {
            get
            {
                return this._responseParams;
            }
        }
    }
}

