namespace Corillian.Marketing.Operations.Plugin
{
    using Corillian.Marketing.Messages.Plugin;
    using Corillian.Voyager.Common;
    using Corillian.Voyager.Common.Attributes;
    using Corillian.Voyager.ExecutionServices.Transaction;
    using System;

    [Transaction("GetMultipleCampaignsForDisplay")]
    public class TrxImpGetMultipleCampaignsForDisplay : Trx
    {
        private GetMultipleCampaignsForDisplayRequest _requestParams = new GetMultipleCampaignsForDisplayRequest();
        private GetMultipleCampaignsForDisplayResponse _responseParams = new GetMultipleCampaignsForDisplayResponse();

        public override Corillian.Voyager.Common.Request Request
        {
            get
            {
                return this._requestParams;
            }
            set
            {
                this._requestParams = (GetMultipleCampaignsForDisplayRequest) value;
            }
        }

        public GetMultipleCampaignsForDisplayRequest RequestParameters
        {
            get
            {
                return this._requestParams;
            }
        }

        public override Corillian.Voyager.Common.Response Response
        {
            get
            {
                return this._responseParams;
            }
            set
            {
                this._responseParams = (GetMultipleCampaignsForDisplayResponse) value;
            }
        }

        public GetMultipleCampaignsForDisplayResponse ResponseParameters
        {
            get
            {
                return this._responseParams;
            }
        }
    }
}

