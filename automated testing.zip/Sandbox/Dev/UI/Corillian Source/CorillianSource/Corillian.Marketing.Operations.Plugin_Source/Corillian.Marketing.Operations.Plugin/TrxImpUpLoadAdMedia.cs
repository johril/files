namespace Corillian.Marketing.Operations.Plugin
{
    using Corillian.Marketing.Messages.Plugin;
    using Corillian.Voyager.Common;
    using Corillian.Voyager.Common.Attributes;
    using Corillian.Voyager.ExecutionServices.Transaction;
    using System;

    [Transaction("UpLoadAdMedia")]
    public class TrxImpUpLoadAdMedia : Trx
    {
        private UpLoadAdMediaRequest _requestParams = new UpLoadAdMediaRequest();
        private UpLoadAdMediaResponse _responseParams = new UpLoadAdMediaResponse();

        public override Corillian.Voyager.Common.Request Request
        {
            get
            {
                return this._requestParams;
            }
            set
            {
                this._requestParams = (UpLoadAdMediaRequest) value;
            }
        }

        public UpLoadAdMediaRequest RequestParameters
        {
            get
            {
                return this._requestParams;
            }
        }

        public override Corillian.Voyager.Common.Response Response
        {
            get
            {
                return this._responseParams;
            }
            set
            {
                this._responseParams = (UpLoadAdMediaResponse) value;
            }
        }

        public UpLoadAdMediaResponse ResponseParameters
        {
            get
            {
                return this._responseParams;
            }
        }
    }
}

