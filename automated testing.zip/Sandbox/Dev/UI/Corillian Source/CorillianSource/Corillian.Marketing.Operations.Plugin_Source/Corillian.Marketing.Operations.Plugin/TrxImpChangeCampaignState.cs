namespace Corillian.Marketing.Operations.Plugin
{
    using Corillian.Marketing.Messages.Plugin;
    using Corillian.Voyager.Common;
    using Corillian.Voyager.Common.Attributes;
    using Corillian.Voyager.ExecutionServices.Transaction;
    using System;

    [Transaction("ChangeCampaignState")]
    public class TrxImpChangeCampaignState : Trx
    {
        private ChangeCampaignStateRequest _requestParams = new ChangeCampaignStateRequest();
        private ChangeCampaignStateResponse _responseParams = new ChangeCampaignStateResponse();

        public override Corillian.Voyager.Common.Request Request
        {
            get
            {
                return this._requestParams;
            }
            set
            {
                this._requestParams = (ChangeCampaignStateRequest) value;
            }
        }

        public ChangeCampaignStateRequest RequestParameters
        {
            get
            {
                return this._requestParams;
            }
        }

        public override Corillian.Voyager.Common.Response Response
        {
            get
            {
                return this._responseParams;
            }
            set
            {
                this._responseParams = (ChangeCampaignStateResponse) value;
            }
        }

        public ChangeCampaignStateResponse ResponseParameters
        {
            get
            {
                return this._responseParams;
            }
        }
    }
}

