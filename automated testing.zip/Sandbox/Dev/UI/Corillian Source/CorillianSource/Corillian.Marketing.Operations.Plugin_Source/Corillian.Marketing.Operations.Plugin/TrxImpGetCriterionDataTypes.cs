namespace Corillian.Marketing.Operations.Plugin
{
    using Corillian.Marketing.Messages.Plugin;
    using Corillian.Voyager.Common;
    using Corillian.Voyager.Common.Attributes;
    using Corillian.Voyager.ExecutionServices.Transaction;
    using System;

    [Transaction("GetCriterionDataTypes")]
    public class TrxImpGetCriterionDataTypes : Trx
    {
        private GetCriterionDataTypesRequest _requestParams = new GetCriterionDataTypesRequest();
        private GetCriterionDataTypesResponse _responseParams = new GetCriterionDataTypesResponse();

        public override Corillian.Voyager.Common.Request Request
        {
            get
            {
                return this._requestParams;
            }
            set
            {
                this._requestParams = (GetCriterionDataTypesRequest) value;
            }
        }

        public GetCriterionDataTypesRequest RequestParameters
        {
            get
            {
                return this._requestParams;
            }
        }

        public override Corillian.Voyager.Common.Response Response
        {
            get
            {
                return this._responseParams;
            }
            set
            {
                this._responseParams = (GetCriterionDataTypesResponse) value;
            }
        }

        public GetCriterionDataTypesResponse ResponseParameters
        {
            get
            {
                return this._responseParams;
            }
        }
    }
}

