namespace Corillian.Marketing.Operations.Plugin
{
    using Corillian.Marketing.Messages.Plugin;
    using Corillian.Voyager.Common;
    using Corillian.Voyager.Common.Attributes;
    using Corillian.Voyager.ExecutionServices.Transaction;
    using System;

    [Transaction("DeleteCampaign")]
    public class TrxImpDeleteCampaign : Trx
    {
        private DeleteCampaignRequest _requestParams = new DeleteCampaignRequest();
        private DeleteCampaignResponse _responseParams = new DeleteCampaignResponse();

        public override Corillian.Voyager.Common.Request Request
        {
            get
            {
                return this._requestParams;
            }
            set
            {
                this._requestParams = (DeleteCampaignRequest) value;
            }
        }

        public DeleteCampaignRequest RequestParameters
        {
            get
            {
                return this._requestParams;
            }
        }

        public override Corillian.Voyager.Common.Response Response
        {
            get
            {
                return this._responseParams;
            }
            set
            {
                this._responseParams = (DeleteCampaignResponse) value;
            }
        }

        public DeleteCampaignResponse ResponseParameters
        {
            get
            {
                return this._responseParams;
            }
        }
    }
}

