namespace Corillian.Marketing.Operations.Plugin
{
    using Corillian.Marketing.Messages.Plugin;
    using Corillian.Voyager.Common;
    using Corillian.Voyager.Common.Attributes;
    using Corillian.Voyager.ExecutionServices.Transaction;
    using System;

    [Transaction("CreateCriterion")]
    public class TrxImpCreateCriterion : Trx
    {
        private CreateCriterionRequest _requestParams = new CreateCriterionRequest();
        private CreateCriterionResponse _responseParams = new CreateCriterionResponse();

        public override Corillian.Voyager.Common.Request Request
        {
            get
            {
                return this._requestParams;
            }
            set
            {
                this._requestParams = (CreateCriterionRequest) value;
            }
        }

        public CreateCriterionRequest RequestParameters
        {
            get
            {
                return this._requestParams;
            }
        }

        public override Corillian.Voyager.Common.Response Response
        {
            get
            {
                return this._responseParams;
            }
            set
            {
                this._responseParams = (CreateCriterionResponse) value;
            }
        }

        public CreateCriterionResponse ResponseParameters
        {
            get
            {
                return this._responseParams;
            }
        }
    }
}

