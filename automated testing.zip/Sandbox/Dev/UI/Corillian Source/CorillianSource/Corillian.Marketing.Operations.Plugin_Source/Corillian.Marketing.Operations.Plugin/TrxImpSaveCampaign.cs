namespace Corillian.Marketing.Operations.Plugin
{
    using Corillian.Marketing.Messages.Plugin;
    using Corillian.Voyager.Common;
    using Corillian.Voyager.Common.Attributes;
    using Corillian.Voyager.ExecutionServices.Transaction;
    using System;

    [Transaction("SaveCampaign")]
    public class TrxImpSaveCampaign : Trx
    {
        private SaveCampaignRequest _requestParams = new SaveCampaignRequest();
        private SaveCampaignResponse _responseParams = new SaveCampaignResponse();

        public override Corillian.Voyager.Common.Request Request
        {
            get
            {
                return this._requestParams;
            }
            set
            {
                this._requestParams = (SaveCampaignRequest) value;
            }
        }

        public SaveCampaignRequest RequestParameters
        {
            get
            {
                return this._requestParams;
            }
        }

        public override Corillian.Voyager.Common.Response Response
        {
            get
            {
                return this._responseParams;
            }
            set
            {
                this._responseParams = (SaveCampaignResponse) value;
            }
        }

        public SaveCampaignResponse ResponseParameters
        {
            get
            {
                return this._responseParams;
            }
        }
    }
}

