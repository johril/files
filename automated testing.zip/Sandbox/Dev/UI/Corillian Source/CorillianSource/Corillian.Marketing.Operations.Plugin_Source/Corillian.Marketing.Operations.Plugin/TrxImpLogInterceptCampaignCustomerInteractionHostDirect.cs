namespace Corillian.Marketing.Operations.Plugin
{
    using Corillian.Marketing.Messages.Plugin;
    using Corillian.Voyager.Common;
    using Corillian.Voyager.Common.Attributes;
    using Corillian.Voyager.ExecutionServices.Transaction;
    using System;

    [Transaction("LogInterceptCampaignCustomerInteractionHostDirect")]
    public class TrxImpLogInterceptCampaignCustomerInteractionHostDirect : Trx
    {
        private LogInterceptCampaignCustomerInteractionHostDirectRequest _requestParams = new LogInterceptCampaignCustomerInteractionHostDirectRequest();
        private LogInterceptCampaignCustomerInteractionResponse _responseParams = new LogInterceptCampaignCustomerInteractionResponse();

        public override Corillian.Voyager.Common.Request Request
        {
            get
            {
                return this._requestParams;
            }
            set
            {
                this._requestParams = (LogInterceptCampaignCustomerInteractionHostDirectRequest) value;
            }
        }

        public LogInterceptCampaignCustomerInteractionHostDirectRequest RequestParameters
        {
            get
            {
                return this._requestParams;
            }
        }

        public override Corillian.Voyager.Common.Response Response
        {
            get
            {
                return this._responseParams;
            }
            set
            {
                this._responseParams = (LogInterceptCampaignCustomerInteractionResponse) value;
            }
        }

        public LogInterceptCampaignCustomerInteractionResponse ResponseParameters
        {
            get
            {
                return this._responseParams;
            }
        }
    }
}

