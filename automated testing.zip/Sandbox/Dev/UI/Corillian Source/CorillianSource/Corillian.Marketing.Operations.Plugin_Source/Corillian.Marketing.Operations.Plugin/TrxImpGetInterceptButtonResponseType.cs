namespace Corillian.Marketing.Operations.Plugin
{
    using Corillian.Marketing.Messages.Plugin;
    using Corillian.Voyager.Common;
    using Corillian.Voyager.Common.Attributes;
    using Corillian.Voyager.ExecutionServices.Transaction;
    using System;

    [Transaction("GetInterceptButtonResponseType")]
    public class TrxImpGetInterceptButtonResponseType : Trx
    {
        private GetInterceptButtonResponseTypeRequest _requestParams = new GetInterceptButtonResponseTypeRequest();
        private GetInterceptButtonResponseTypeResponse _responseParams = new GetInterceptButtonResponseTypeResponse();

        public override Corillian.Voyager.Common.Request Request
        {
            get
            {
                return this._requestParams;
            }
            set
            {
                this._requestParams = (GetInterceptButtonResponseTypeRequest) value;
            }
        }

        public GetInterceptButtonResponseTypeRequest RequestParameters
        {
            get
            {
                return this._requestParams;
            }
        }

        public override Corillian.Voyager.Common.Response Response
        {
            get
            {
                return this._responseParams;
            }
            set
            {
                this._responseParams = (GetInterceptButtonResponseTypeResponse) value;
            }
        }

        public GetInterceptButtonResponseTypeResponse ResponseParameters
        {
            get
            {
                return this._responseParams;
            }
        }
    }
}

