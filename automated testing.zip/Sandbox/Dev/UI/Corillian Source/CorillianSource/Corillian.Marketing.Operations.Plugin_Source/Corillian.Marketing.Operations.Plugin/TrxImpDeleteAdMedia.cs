namespace Corillian.Marketing.Operations.Plugin
{
    using Corillian.Marketing.Messages.Plugin;
    using Corillian.Voyager.Common;
    using Corillian.Voyager.Common.Attributes;
    using Corillian.Voyager.ExecutionServices.Transaction;
    using System;

    [Transaction("DeleteAdMedia")]
    public class TrxImpDeleteAdMedia : Trx
    {
        private DeleteAdMediaRequest _requestParams = new DeleteAdMediaRequest();
        private DeleteAdMediaResponse _responseParams = new DeleteAdMediaResponse();

        public override Corillian.Voyager.Common.Request Request
        {
            get
            {
                return this._requestParams;
            }
            set
            {
                this._requestParams = (DeleteAdMediaRequest) value;
            }
        }

        public DeleteAdMediaRequest RequestParameters
        {
            get
            {
                return this._requestParams;
            }
        }

        public override Corillian.Voyager.Common.Response Response
        {
            get
            {
                return this._responseParams;
            }
            set
            {
                this._responseParams = (DeleteAdMediaResponse) value;
            }
        }

        public DeleteAdMediaResponse ResponseParameters
        {
            get
            {
                return this._responseParams;
            }
        }
    }
}

