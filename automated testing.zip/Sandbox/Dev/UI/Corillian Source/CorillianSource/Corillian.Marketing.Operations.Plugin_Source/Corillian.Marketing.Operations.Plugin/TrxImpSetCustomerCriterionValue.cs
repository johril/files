namespace Corillian.Marketing.Operations.Plugin
{
    using Corillian.Marketing.Messages.Plugin;
    using Corillian.Voyager.Common;
    using Corillian.Voyager.Common.Attributes;
    using Corillian.Voyager.ExecutionServices.Transaction;
    using System;

    [Transaction("SetCustomerCriterionValue")]
    public class TrxImpSetCustomerCriterionValue : Trx
    {
        private SetCustomerCriterionValueRequest _requestParams = new SetCustomerCriterionValueRequest();
        private SetCustomerCriterionValueResponse _responseParams = new SetCustomerCriterionValueResponse();

        public override Corillian.Voyager.Common.Request Request
        {
            get
            {
                return this._requestParams;
            }
            set
            {
                this._requestParams = (SetCustomerCriterionValueRequest) value;
            }
        }

        public SetCustomerCriterionValueRequest RequestParameters
        {
            get
            {
                return this._requestParams;
            }
        }

        public override Corillian.Voyager.Common.Response Response
        {
            get
            {
                return this._responseParams;
            }
            set
            {
                this._responseParams = (SetCustomerCriterionValueResponse) value;
            }
        }

        public SetCustomerCriterionValueResponse ResponseParameters
        {
            get
            {
                return this._responseParams;
            }
        }
    }
}

