namespace Corillian.Marketing.Operations.Plugin
{
    using Corillian.Marketing.Messages.Plugin;
    using Corillian.Voyager.Common;
    using Corillian.Voyager.Common.Attributes;
    using Corillian.Voyager.ExecutionServices.Transaction;
    using System;

    [Transaction("CreateCriterionMetadata")]
    public class TrxImpCreateCriterionMetadata : Trx
    {
        private CreateCriterionMetadataRequest _requestParams = new CreateCriterionMetadataRequest();
        private CreateCriterionMetadataResponse _responseParams = new CreateCriterionMetadataResponse();

        public override Corillian.Voyager.Common.Request Request
        {
            get
            {
                return this._requestParams;
            }
            set
            {
                this._requestParams = (CreateCriterionMetadataRequest) value;
            }
        }

        public CreateCriterionMetadataRequest RequestParameters
        {
            get
            {
                return this._requestParams;
            }
        }

        public override Corillian.Voyager.Common.Response Response
        {
            get
            {
                return this._responseParams;
            }
            set
            {
                this._responseParams = (CreateCriterionMetadataResponse) value;
            }
        }

        public CreateCriterionMetadataResponse ResponseParameters
        {
            get
            {
                return this._responseParams;
            }
        }
    }
}

