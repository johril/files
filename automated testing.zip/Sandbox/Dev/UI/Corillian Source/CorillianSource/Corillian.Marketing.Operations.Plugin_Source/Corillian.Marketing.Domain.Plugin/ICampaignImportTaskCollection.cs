namespace Corillian.Marketing.Domain.Plugin
{
    using System;

    public interface ICampaignImportTaskCollection
    {
        void CopyTo(CampaignImportTask[] array, int arrayIndex);
        ICampaignImportTaskEnumerator GetEnumerator();

        int Count { get; }

        bool IsSynchronized { get; }

        object SyncRoot { get; }
    }
}

