namespace Corillian.Marketing.Domain.Plugin
{
    using System;
    using System.Reflection;

    public interface IAdMediaList : IAdMediaCollection
    {
        int Add(AdMedia value);
        void Clear();
        bool Contains(AdMedia value);
        int IndexOf(AdMedia value);
        void Insert(int index, AdMedia value);
        void Remove(AdMedia value);
        void RemoveAt(int index);

        bool IsFixedSize { get; }

        bool IsReadOnly { get; }

        AdMedia this[int index] { get; set; }
    }
}

