namespace Corillian.Marketing.Domain.Plugin
{
    using Corillian.Voyager.Common;
    using Corillian.Voyager.Common.Attributes;
    using System;
    using System.Xml.Serialization;

    [Serializable, XmlRoot(Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", ElementName="AdSpace"), XmlType(Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", TypeName="AdSpace")]
    public class AdSpace : IFormattable
    {
        private string _adspacedescription;
        private int _adspaceid;
        private string _adspacename;
        private int _adspacenamechecksum;
        private Corillian.Marketing.Domain.Plugin.CampaignType _campaigntype;
        private string _defaultcampaignguid;
        private int _fiid;
        private int _height;
        private int _width;
        [XmlIgnore, Ignore]
        public bool AdSpaceIdSpecified;
        [Ignore, XmlIgnore]
        public bool AdSpaceNameCheckSumSpecified;
        [XmlIgnore, Ignore]
        public bool FiidSpecified;
        [XmlIgnore, Ignore]
        public bool HeightSpecified;
        [XmlIgnore, Ignore]
        public bool WidthSpecified;

        public virtual string ToString(string format)
        {
            return FormattableObject.ToString(this, format, null);
        }

        public virtual string ToString(string format, IFormatProvider formatProvider)
        {
            if (format == null)
            {
                return base.ToString();
            }
            return FormattableObject.ToString(this, format, formatProvider);
        }

        [XmlElement(ElementName="AdSpaceDescription", Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", DataType="string")]
        public string AdSpaceDescription
        {
            get
            {
                return this._adspacedescription;
            }
            set
            {
                this._adspacedescription = value;
            }
        }

        [XmlElement(ElementName="AdSpaceId", Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", DataType="int")]
        public int AdSpaceId
        {
            get
            {
                return this._adspaceid;
            }
            set
            {
                this.AdSpaceIdSpecified = true;
                this._adspaceid = value;
            }
        }

        [XmlElement(ElementName="AdSpaceName", Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", DataType="string")]
        public string AdSpaceName
        {
            get
            {
                return this._adspacename;
            }
            set
            {
                this._adspacename = value;
            }
        }

        [XmlElement(ElementName="AdSpaceNameCheckSum", Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", DataType="int")]
        public int AdSpaceNameCheckSum
        {
            get
            {
                return this._adspacenamechecksum;
            }
            set
            {
                this.AdSpaceNameCheckSumSpecified = true;
                this._adspacenamechecksum = value;
            }
        }

        [XmlElement(ElementName="CampaignType", Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05")]
        public Corillian.Marketing.Domain.Plugin.CampaignType CampaignType
        {
            get
            {
                return this._campaigntype;
            }
            set
            {
                this._campaigntype = value;
            }
        }

        [XmlElement(ElementName="DefaultCampaignGuid", Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", DataType="string")]
        public string DefaultCampaignGuid
        {
            get
            {
                return this._defaultcampaignguid;
            }
            set
            {
                this._defaultcampaignguid = value;
            }
        }

        [XmlElement(ElementName="Fiid", Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", DataType="int")]
        public int Fiid
        {
            get
            {
                return this._fiid;
            }
            set
            {
                this.FiidSpecified = true;
                this._fiid = value;
            }
        }

        [XmlElement(ElementName="Height", Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", DataType="int")]
        public int Height
        {
            get
            {
                return this._height;
            }
            set
            {
                this.HeightSpecified = true;
                this._height = value;
            }
        }

        [XmlElement(ElementName="Width", Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", DataType="int")]
        public int Width
        {
            get
            {
                return this._width;
            }
            set
            {
                this.WidthSpecified = true;
                this._width = value;
            }
        }
    }
}

