namespace Corillian.Marketing.Domain.Plugin
{
    using System;

    public interface IRuleTokenTypeCollection
    {
        void CopyTo(RuleTokenType[] array, int arrayIndex);
        IRuleTokenTypeEnumerator GetEnumerator();

        int Count { get; }

        bool IsSynchronized { get; }

        object SyncRoot { get; }
    }
}

