namespace Corillian.Marketing.Domain.Plugin
{
    using System;

    public interface ICampaignSpaceEnumerator
    {
        bool MoveNext();
        void Reset();

        CampaignSpace Current { get; }
    }
}

