namespace Corillian.Marketing.Domain.Plugin
{
    using System;

    public interface IRuleInstanceEnumerator
    {
        bool MoveNext();
        void Reset();

        RuleInstance Current { get; }
    }
}

