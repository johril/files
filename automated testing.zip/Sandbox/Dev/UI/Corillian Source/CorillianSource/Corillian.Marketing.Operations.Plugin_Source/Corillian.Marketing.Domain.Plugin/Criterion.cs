namespace Corillian.Marketing.Domain.Plugin
{
    using Corillian.Voyager.Common;
    using Corillian.Voyager.Common.Attributes;
    using System;
    using System.Xml.Serialization;

    [Serializable, XmlRoot(Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", ElementName="Criterion"), XmlType(Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", TypeName="Criterion")]
    public class Criterion : IFormattable
    {
        private Corillian.Marketing.Domain.Plugin.CriterionDataType _criteriondatatype;
        private string _description;
        private int _id;
        private string _tag;
        private bool _voyagercriterion;
        [Ignore, XmlIgnore]
        public bool IdSpecified;
        [Ignore, XmlIgnore]
        public bool VoyagerCriterionSpecified;

        public virtual string ToString(string format)
        {
            return FormattableObject.ToString(this, format, null);
        }

        public virtual string ToString(string format, IFormatProvider formatProvider)
        {
            if (format == null)
            {
                return base.ToString();
            }
            return FormattableObject.ToString(this, format, formatProvider);
        }

        [XmlElement(ElementName="CriterionDataType", Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05")]
        public Corillian.Marketing.Domain.Plugin.CriterionDataType CriterionDataType
        {
            get
            {
                return this._criteriondatatype;
            }
            set
            {
                this._criteriondatatype = value;
            }
        }

        [XmlElement(ElementName="Description", Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", DataType="string")]
        public string Description
        {
            get
            {
                return this._description;
            }
            set
            {
                this._description = value;
            }
        }

        [XmlElement(ElementName="Id", Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", DataType="int")]
        public int Id
        {
            get
            {
                return this._id;
            }
            set
            {
                this.IdSpecified = true;
                this._id = value;
            }
        }

        [XmlElement(ElementName="Tag", Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", DataType="string")]
        public string Tag
        {
            get
            {
                return this._tag;
            }
            set
            {
                this._tag = value;
            }
        }

        [XmlElement(ElementName="VoyagerCriterion", Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", DataType="boolean")]
        public bool VoyagerCriterion
        {
            get
            {
                return this._voyagercriterion;
            }
            set
            {
                this.VoyagerCriterionSpecified = true;
                this._voyagercriterion = value;
            }
        }
    }
}

