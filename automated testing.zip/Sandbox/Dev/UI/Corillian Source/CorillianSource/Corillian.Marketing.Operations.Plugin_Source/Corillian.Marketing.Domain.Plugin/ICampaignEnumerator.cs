namespace Corillian.Marketing.Domain.Plugin
{
    using System;

    public interface ICampaignEnumerator
    {
        bool MoveNext();
        void Reset();

        Campaign Current { get; }
    }
}

