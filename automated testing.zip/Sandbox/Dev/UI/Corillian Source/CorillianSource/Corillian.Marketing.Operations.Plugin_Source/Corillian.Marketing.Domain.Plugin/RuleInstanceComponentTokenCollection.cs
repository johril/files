namespace Corillian.Marketing.Domain.Plugin
{
    using Corillian.Voyager.Common;
    using System;
    using System.Collections;
    using System.Collections.Generic;
    using System.Reflection;

    [Serializable]
    public class RuleInstanceComponentTokenCollection : IRuleInstanceComponentTokenList, IRuleInstanceComponentTokenCollection, IList, ICollection, ICloneable, ICorillianCollection, IList<RuleInstanceComponentToken>, ICollection<RuleInstanceComponentToken>, IEnumerable<RuleInstanceComponentToken>, IEnumerable
    {
        private RuleInstanceComponentToken[] _array;
        private int _count;
        private const int _defaultCapacity = 0x10;
        private int _rows;
        [NonSerialized]
        private int _version;

        public RuleInstanceComponentTokenCollection()
        {
            this._array = null;
            this._count = 0;
            this._version = 0;
            this._array = new RuleInstanceComponentToken[0x10];
        }

        public RuleInstanceComponentTokenCollection(RuleInstanceComponentTokenCollection collection)
        {
            this._array = null;
            this._count = 0;
            this._version = 0;
            if (collection == null)
            {
                throw new ArgumentNullException("collection");
            }
            this._array = new RuleInstanceComponentToken[collection.Count];
            this.AddRange(collection);
        }

        private RuleInstanceComponentTokenCollection(Tag tag)
        {
            this._array = null;
            this._count = 0;
            this._version = 0;
        }

        public RuleInstanceComponentTokenCollection(int capacity)
        {
            this._array = null;
            this._count = 0;
            this._version = 0;
            if (capacity < 0)
            {
                throw new ArgumentOutOfRangeException("capacity", capacity, "Argument cannot be negative.");
            }
            this._array = new RuleInstanceComponentToken[capacity];
        }

        public RuleInstanceComponentTokenCollection(RuleInstanceComponentToken[] array)
        {
            this._array = null;
            this._count = 0;
            this._version = 0;
            if (array == null)
            {
                throw new ArgumentNullException("array");
            }
            this._array = new RuleInstanceComponentToken[array.Length];
            this.AddRange(array);
        }

        public virtual int Add(RuleInstanceComponentToken value)
        {
            if (this._count == this._array.Length)
            {
                this.EnsureCapacity(this._count + 1);
            }
            this._version++;
            this._array[this._count] = value;
            return this._count++;
        }

        public virtual void AddRange(RuleInstanceComponentToken[] array)
        {
            if (array == null)
            {
                throw new ArgumentNullException("array");
            }
            if (array.Length != 0)
            {
                if ((this._count + array.Length) > this._array.Length)
                {
                    this.EnsureCapacity(this._count + array.Length);
                }
                this._version++;
                Array.Copy(array, 0, this._array, this._count, array.Length);
                this._count += array.Length;
            }
        }

        public virtual void AddRange(RuleInstanceComponentTokenCollection collection)
        {
            if (collection == null)
            {
                throw new ArgumentNullException("collection");
            }
            if (collection.Count != 0)
            {
                if ((this._count + collection.Count) > this._array.Length)
                {
                    this.EnsureCapacity(this._count + collection.Count);
                }
                this._version++;
                Array.Copy(collection._array, 0, this._array, this._count, collection.Count);
                this._count += collection.Count;
            }
        }

        public virtual int BinarySearch(RuleInstanceComponentToken value)
        {
            return Array.BinarySearch<RuleInstanceComponentToken>(this._array, 0, this._count, value);
        }

        private void CheckEnumIndex(int index)
        {
            if ((index < 0) || (index >= this._count))
            {
                throw new InvalidOperationException("Enumerator is not on a collection element.");
            }
        }

        private void CheckEnumVersion(int version)
        {
            if (version != this._version)
            {
                throw new InvalidOperationException("Enumerator invalidated by modification to collection.");
            }
        }

        private void CheckTargetArray(Array array, int arrayIndex)
        {
            if (array == null)
            {
                throw new ArgumentNullException("array");
            }
            if (array.Rank > 1)
            {
                throw new ArgumentException("Argument cannot be multidimensional.", "array");
            }
            if (arrayIndex < 0)
            {
                throw new ArgumentOutOfRangeException("arrayIndex", arrayIndex, "Argument cannot be negative.");
            }
            if (arrayIndex >= array.Length)
            {
                throw new ArgumentException("Argument must be less than array length.", "arrayIndex");
            }
            if (this._count > (array.Length - arrayIndex))
            {
                throw new ArgumentException("Argument section must be large enough for collection.", "array");
            }
        }

        public virtual void Clear()
        {
            if (this._count != 0)
            {
                this._version++;
                Array.Clear(this._array, 0, this._count);
                this._count = 0;
            }
        }

        public virtual object Clone()
        {
            RuleInstanceComponentTokenCollection tokens = new RuleInstanceComponentTokenCollection(this._count);
            Array.Copy(this._array, 0, tokens._array, 0, this._count);
            tokens._count = this._count;
            tokens._version = this._version;
            return tokens;
        }

        public virtual bool Contains(RuleInstanceComponentToken value)
        {
            return (this.IndexOf(value) >= 0);
        }

        public virtual void CopyTo(RuleInstanceComponentToken[] array)
        {
            this.CheckTargetArray(array, 0);
            Array.Copy(this._array, array, this._count);
        }

        public virtual void CopyTo(RuleInstanceComponentToken[] array, int arrayIndex)
        {
            this.CheckTargetArray(array, arrayIndex);
            Array.Copy(this._array, 0, array, arrayIndex, this._count);
        }

        private void EnsureCapacity(int minimum)
        {
            int num = (this._array.Length == 0) ? 0x10 : (this._array.Length * 2);
            if (num < minimum)
            {
                num = minimum;
            }
            this.Capacity = num;
        }

        public virtual IRuleInstanceComponentTokenEnumerator GetEnumerator()
        {
            return new Enumerator(this);
        }

        public virtual int IndexOf(RuleInstanceComponentToken value)
        {
            return Array.IndexOf<RuleInstanceComponentToken>(this._array, value, 0, this._count);
        }

        public virtual void Insert(int index, RuleInstanceComponentToken value)
        {
            if (index < 0)
            {
                throw new ArgumentOutOfRangeException("index", index, "Argument cannot be negative.");
            }
            if (index > this._count)
            {
                throw new ArgumentOutOfRangeException("index", index, "Argument cannot exceed Count.");
            }
            if (this._count == this._array.Length)
            {
                this.EnsureCapacity(this._count + 1);
            }
            this._version++;
            if (index < this._count)
            {
                Array.Copy(this._array, index, this._array, index + 1, this._count - index);
            }
            this._array[index] = value;
            this._count++;
        }

        public static RuleInstanceComponentTokenCollection ReadOnly(RuleInstanceComponentTokenCollection collection)
        {
            if (collection == null)
            {
                throw new ArgumentNullException("collection");
            }
            return new ReadOnlyList(collection);
        }

        public virtual void Remove(RuleInstanceComponentToken value)
        {
            int index = this.IndexOf(value);
            if (index >= 0)
            {
                this.RemoveAt(index);
            }
        }

        public virtual void RemoveAt(int index)
        {
            this.ValidateIndex(index);
            this._version++;
            if (index < --this._count)
            {
                Array.Copy(this._array, index + 1, this._array, index, this._count - index);
            }
            this._array[this._count] = null;
        }

        public virtual void RemoveRange(int index, int count)
        {
            if (index < 0)
            {
                throw new ArgumentOutOfRangeException("index", index, "Argument cannot be negative.");
            }
            if (count < 0)
            {
                throw new ArgumentOutOfRangeException("count", count, "Argument cannot be negative.");
            }
            if ((index + count) > this._count)
            {
                throw new ArgumentException("Arguments denote invalid range of elements.");
            }
            if (count != 0)
            {
                this._version++;
                this._count -= count;
                if (index < this._count)
                {
                    Array.Copy(this._array, index + count, this._array, index, this._count - index);
                }
                Array.Clear(this._array, this._count, count);
            }
        }

        public virtual void Sort()
        {
            if (this._count > 1)
            {
                this._version++;
                Array.Sort<RuleInstanceComponentToken>(this._array, 0, this._count);
            }
        }

        public void Sort(string[] fields)
        {
            this.Sort(fields, new bool[fields.Length]);
        }

        public void Sort(IComparer customComparer)
        {
            Array.Sort(this._array, 0, this._count, customComparer);
        }

        public void Sort(string field)
        {
            this.Sort(new string[] { field });
        }

        public void Sort(string field, bool descending)
        {
            this.Sort(new string[] { field }, new bool[] { descending });
        }

        public void Sort(string[] fields, bool[] descending)
        {
            Array.Sort(this._array, 0, this._count, new ObjectComparer(fields, descending));
        }

        public static RuleInstanceComponentTokenCollection Synchronized(RuleInstanceComponentTokenCollection collection)
        {
            if (collection == null)
            {
                throw new ArgumentNullException("collection");
            }
            return new SyncList(collection);
        }

        void ICollection<RuleInstanceComponentToken>.Add(RuleInstanceComponentToken value)
        {
            this.Add(value);
        }

        bool ICollection<RuleInstanceComponentToken>.Remove(RuleInstanceComponentToken value)
        {
            int index = this.IndexOf(value);
            if (index >= 0)
            {
                this.RemoveAt(index);
                return true;
            }
            return false;
        }

        IEnumerator<RuleInstanceComponentToken> IEnumerable<RuleInstanceComponentToken>.GetEnumerator()
        {
            return new Enumerator(this);
        }

        void ICollection.CopyTo(Array array, int arrayIndex)
        {
            this.CheckTargetArray(array, arrayIndex);
            this.CopyTo((RuleInstanceComponentToken[]) array, arrayIndex);
        }

        IEnumerator IEnumerable.GetEnumerator()
        {
            return (IEnumerator) this.GetEnumerator();
        }

        int IList.Add(object value)
        {
            return this.Add((RuleInstanceComponentToken) value);
        }

        bool IList.Contains(object value)
        {
            return this.Contains((RuleInstanceComponentToken) value);
        }

        int IList.IndexOf(object value)
        {
            return this.IndexOf((RuleInstanceComponentToken) value);
        }

        void IList.Insert(int index, object value)
        {
            this.Insert(index, (RuleInstanceComponentToken) value);
        }

        void IList.Remove(object value)
        {
            this.Remove((RuleInstanceComponentToken) value);
        }

        public virtual RuleInstanceComponentToken[] ToArray()
        {
            RuleInstanceComponentToken[] destinationArray = new RuleInstanceComponentToken[this._count];
            Array.Copy(this._array, destinationArray, this._count);
            return destinationArray;
        }

        public virtual void TrimToSize()
        {
            this.Capacity = this._count;
        }

        private void ValidateIndex(int index)
        {
            if (index < 0)
            {
                throw new ArgumentOutOfRangeException("index", index, "Argument cannot be negative.");
            }
            if (index >= this._count)
            {
                throw new ArgumentOutOfRangeException("index", index, "Argument must be less than Count.");
            }
        }

        public virtual int Capacity
        {
            get
            {
                return this._array.Length;
            }
            set
            {
                if (value != this._array.Length)
                {
                    if (value < this._count)
                    {
                        throw new ArgumentOutOfRangeException("Capacity", value, "Value cannot be less than Count.");
                    }
                    if (value == 0)
                    {
                        this._array = new RuleInstanceComponentToken[0x10];
                    }
                    else
                    {
                        RuleInstanceComponentToken[] destinationArray = new RuleInstanceComponentToken[value];
                        Array.Copy(this._array, destinationArray, this._count);
                        this._array = destinationArray;
                    }
                }
            }
        }

        public virtual int Count
        {
            get
            {
                return this._count;
            }
        }

        public virtual bool IsFixedSize
        {
            get
            {
                return false;
            }
        }

        public virtual bool IsReadOnly
        {
            get
            {
                return false;
            }
        }

        public virtual bool IsSynchronized
        {
            get
            {
                return false;
            }
        }

        public virtual RuleInstanceComponentToken this[int index]
        {
            get
            {
                this.ValidateIndex(index);
                return this._array[index];
            }
            set
            {
                this.ValidateIndex(index);
                this._version++;
                this._array[index] = value;
            }
        }

        public Type ItemType
        {
            get
            {
                return typeof(RuleInstanceComponentToken);
            }
        }

        public int Rows
        {
            get
            {
                return this._rows;
            }
            set
            {
                this._rows = value;
            }
        }

        public virtual object SyncRoot
        {
            get
            {
                return this;
            }
        }

        object IList.this[int index]
        {
            get
            {
                return this[index];
            }
            set
            {
                this[index] = (RuleInstanceComponentToken) value;
            }
        }

        [Serializable]
        private sealed class Enumerator : IRuleInstanceComponentTokenEnumerator, IEnumerator<RuleInstanceComponentToken>, IDisposable, IEnumerator
        {
            private readonly RuleInstanceComponentTokenCollection _collection;
            private int _index;
            private readonly int _version;

            internal Enumerator(RuleInstanceComponentTokenCollection collection)
            {
                this._collection = collection;
                this._version = collection._version;
                this._index = -1;
            }

            public void Dispose()
            {
            }

            public bool MoveNext()
            {
                this._collection.CheckEnumVersion(this._version);
                return (++this._index < this._collection.Count);
            }

            public void Reset()
            {
                this._collection.CheckEnumVersion(this._version);
                this._index = -1;
            }

            public RuleInstanceComponentToken Current
            {
                get
                {
                    this._collection.CheckEnumIndex(this._index);
                    return this._collection[this._index];
                }
            }

            object IEnumerator.Current
            {
                get
                {
                    return this.Current;
                }
            }
        }

        [Serializable]
        private sealed class ReadOnlyList : RuleInstanceComponentTokenCollection
        {
            private RuleInstanceComponentTokenCollection _collection;

            internal ReadOnlyList(RuleInstanceComponentTokenCollection collection) : base(RuleInstanceComponentTokenCollection.Tag.Default)
            {
                this._collection = collection;
            }

            public override int Add(RuleInstanceComponentToken value)
            {
                throw new NotSupportedException("Read-only collections cannot be modified.");
            }

            public override void AddRange(RuleInstanceComponentTokenCollection collection)
            {
                throw new NotSupportedException("Read-only collections cannot be modified.");
            }

            public override void AddRange(RuleInstanceComponentToken[] array)
            {
                throw new NotSupportedException("Read-only collections cannot be modified.");
            }

            public override int BinarySearch(RuleInstanceComponentToken value)
            {
                return this._collection.BinarySearch(value);
            }

            public override void Clear()
            {
                throw new NotSupportedException("Read-only collections cannot be modified.");
            }

            public override object Clone()
            {
                return new RuleInstanceComponentTokenCollection.ReadOnlyList((RuleInstanceComponentTokenCollection) this._collection.Clone());
            }

            public override bool Contains(RuleInstanceComponentToken value)
            {
                return this._collection.Contains(value);
            }

            public override void CopyTo(RuleInstanceComponentToken[] array)
            {
                this._collection.CopyTo(array);
            }

            public override void CopyTo(RuleInstanceComponentToken[] array, int arrayIndex)
            {
                this._collection.CopyTo(array, arrayIndex);
            }

            public override IRuleInstanceComponentTokenEnumerator GetEnumerator()
            {
                return this._collection.GetEnumerator();
            }

            public override int IndexOf(RuleInstanceComponentToken value)
            {
                return this._collection.IndexOf(value);
            }

            public override void Insert(int index, RuleInstanceComponentToken value)
            {
                throw new NotSupportedException("Read-only collections cannot be modified.");
            }

            public override void Remove(RuleInstanceComponentToken value)
            {
                throw new NotSupportedException("Read-only collections cannot be modified.");
            }

            public override void RemoveAt(int index)
            {
                throw new NotSupportedException("Read-only collections cannot be modified.");
            }

            public override void RemoveRange(int index, int count)
            {
                throw new NotSupportedException("Read-only collections cannot be modified.");
            }

            public override void Sort()
            {
                throw new NotSupportedException("Read-only collections cannot be modified.");
            }

            public override RuleInstanceComponentToken[] ToArray()
            {
                return this._collection.ToArray();
            }

            public override void TrimToSize()
            {
                throw new NotSupportedException("Read-only collections cannot be modified.");
            }

            public override int Capacity
            {
                get
                {
                    return this._collection.Capacity;
                }
                set
                {
                    throw new NotSupportedException("Read-only collections cannot be modified.");
                }
            }

            public override int Count
            {
                get
                {
                    return this._collection.Count;
                }
            }

            public override bool IsFixedSize
            {
                get
                {
                    return true;
                }
            }

            public override bool IsReadOnly
            {
                get
                {
                    return true;
                }
            }

            public override bool IsSynchronized
            {
                get
                {
                    return this._collection.IsSynchronized;
                }
            }

            public override RuleInstanceComponentToken this[int index]
            {
                get
                {
                    return this._collection[index];
                }
                set
                {
                    throw new NotSupportedException("Read-only collections cannot be modified.");
                }
            }

            public override object SyncRoot
            {
                get
                {
                    return this._collection.SyncRoot;
                }
            }
        }

        [Serializable]
        private sealed class SyncList : RuleInstanceComponentTokenCollection
        {
            private RuleInstanceComponentTokenCollection _collection;
            private object _root;

            internal SyncList(RuleInstanceComponentTokenCollection collection) : base(RuleInstanceComponentTokenCollection.Tag.Default)
            {
                this._root = collection.SyncRoot;
                this._collection = collection;
            }

            public override int Add(RuleInstanceComponentToken value)
            {
                lock (this._root)
                {
                    return this._collection.Add(value);
                }
            }

            public override void AddRange(RuleInstanceComponentTokenCollection collection)
            {
                lock (this._root)
                {
                    this._collection.AddRange(collection);
                }
            }

            public override void AddRange(RuleInstanceComponentToken[] array)
            {
                lock (this._root)
                {
                    this._collection.AddRange(array);
                }
            }

            public override int BinarySearch(RuleInstanceComponentToken value)
            {
                lock (this._root)
                {
                    return this._collection.BinarySearch(value);
                }
            }

            public override void Clear()
            {
                lock (this._root)
                {
                    this._collection.Clear();
                }
            }

            public override object Clone()
            {
                lock (this._root)
                {
                    return new RuleInstanceComponentTokenCollection.SyncList((RuleInstanceComponentTokenCollection) this._collection.Clone());
                }
            }

            public override bool Contains(RuleInstanceComponentToken value)
            {
                lock (this._root)
                {
                    return this._collection.Contains(value);
                }
            }

            public override void CopyTo(RuleInstanceComponentToken[] array)
            {
                lock (this._root)
                {
                    this._collection.CopyTo(array);
                }
            }

            public override void CopyTo(RuleInstanceComponentToken[] array, int arrayIndex)
            {
                lock (this._root)
                {
                    this._collection.CopyTo(array, arrayIndex);
                }
            }

            public override IRuleInstanceComponentTokenEnumerator GetEnumerator()
            {
                lock (this._root)
                {
                    return this._collection.GetEnumerator();
                }
            }

            public override int IndexOf(RuleInstanceComponentToken value)
            {
                lock (this._root)
                {
                    return this._collection.IndexOf(value);
                }
            }

            public override void Insert(int index, RuleInstanceComponentToken value)
            {
                lock (this._root)
                {
                    this._collection.Insert(index, value);
                }
            }

            public override void Remove(RuleInstanceComponentToken value)
            {
                lock (this._root)
                {
                    this._collection.Remove(value);
                }
            }

            public override void RemoveAt(int index)
            {
                lock (this._root)
                {
                    this._collection.RemoveAt(index);
                }
            }

            public override void RemoveRange(int index, int count)
            {
                lock (this._root)
                {
                    this._collection.RemoveRange(index, count);
                }
            }

            public override void Sort()
            {
                lock (this._root)
                {
                    this._collection.Sort();
                }
            }

            public override RuleInstanceComponentToken[] ToArray()
            {
                lock (this._root)
                {
                    return this._collection.ToArray();
                }
            }

            public override void TrimToSize()
            {
                lock (this._root)
                {
                    this._collection.TrimToSize();
                }
            }

            public override int Capacity
            {
                get
                {
                    lock (this._root)
                    {
                        return this._collection.Capacity;
                    }
                }
                set
                {
                    lock (this._root)
                    {
                        this._collection.Capacity = value;
                    }
                }
            }

            public override int Count
            {
                get
                {
                    lock (this._root)
                    {
                        return this._collection.Count;
                    }
                }
            }

            public override bool IsFixedSize
            {
                get
                {
                    return this._collection.IsFixedSize;
                }
            }

            public override bool IsReadOnly
            {
                get
                {
                    return this._collection.IsReadOnly;
                }
            }

            public override bool IsSynchronized
            {
                get
                {
                    return true;
                }
            }

            public override RuleInstanceComponentToken this[int index]
            {
                get
                {
                    lock (this._root)
                    {
                        return this._collection[index];
                    }
                }
                set
                {
                    lock (this._root)
                    {
                        this._collection[index] = value;
                    }
                }
            }

            public override object SyncRoot
            {
                get
                {
                    return this._root;
                }
            }
        }

        private enum Tag
        {
            Default
        }
    }
}

