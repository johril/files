namespace Corillian.Marketing.Domain.Plugin
{
    using System;

    public interface ICampaignInstanceCompositionMapEnumerator
    {
        bool MoveNext();
        void Reset();

        CampaignInstanceCompositionMap Current { get; }
    }
}

