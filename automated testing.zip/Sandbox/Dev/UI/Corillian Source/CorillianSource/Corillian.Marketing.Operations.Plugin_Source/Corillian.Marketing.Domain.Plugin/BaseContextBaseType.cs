namespace Corillian.Marketing.Domain.Plugin
{
    using Corillian.Voyager.Common;
    using System;
    using System.Xml.Serialization;

    [Serializable, XmlType(Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", TypeName="BaseContextBaseType"), XmlRoot(Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", ElementName="BaseContextBaseType")]
    public class BaseContextBaseType : IFormattable
    {
        private BaseContextCollection _basecontexts;

        public virtual string ToString(string format)
        {
            return FormattableObject.ToString(this, format, null);
        }

        public virtual string ToString(string format, IFormatProvider formatProvider)
        {
            if (format == null)
            {
                return base.ToString();
            }
            return FormattableObject.ToString(this, format, formatProvider);
        }

        [XmlElement(ElementName="BaseContext", Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05")]
        public BaseContextCollection BaseContextList
        {
            get
            {
                return this._basecontexts;
            }
            set
            {
                this._basecontexts = value;
            }
        }
    }
}

