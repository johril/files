namespace Corillian.Marketing.Domain.Plugin
{
    using System;
    using System.Reflection;

    public interface IRuleExpressionList : IRuleExpressionCollection
    {
        int Add(RuleExpression value);
        void Clear();
        bool Contains(RuleExpression value);
        int IndexOf(RuleExpression value);
        void Insert(int index, RuleExpression value);
        void Remove(RuleExpression value);
        void RemoveAt(int index);

        bool IsFixedSize { get; }

        bool IsReadOnly { get; }

        RuleExpression this[int index] { get; set; }
    }
}

