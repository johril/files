namespace Corillian.Marketing.Domain.Plugin
{
    using Corillian.Voyager.Common;
    using System;
    using System.Xml.Serialization;

    [Serializable, XmlType(Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", TypeName="RuleExpressionBaseType"), XmlRoot(Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", ElementName="RuleExpressionBaseType")]
    public class RuleExpressionBaseType : IFormattable
    {
        private RuleExpressionCollection _ruleexpressions;

        public virtual string ToString(string format)
        {
            return FormattableObject.ToString(this, format, null);
        }

        public virtual string ToString(string format, IFormatProvider formatProvider)
        {
            if (format == null)
            {
                return base.ToString();
            }
            return FormattableObject.ToString(this, format, formatProvider);
        }

        [XmlElement(ElementName="RuleExpression", Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05")]
        public RuleExpressionCollection RuleExpressionList
        {
            get
            {
                return this._ruleexpressions;
            }
            set
            {
                this._ruleexpressions = value;
            }
        }
    }
}

