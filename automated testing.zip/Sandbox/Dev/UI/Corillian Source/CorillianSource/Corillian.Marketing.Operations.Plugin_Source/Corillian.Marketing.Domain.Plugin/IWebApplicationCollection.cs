namespace Corillian.Marketing.Domain.Plugin
{
    using System;

    public interface IWebApplicationCollection
    {
        void CopyTo(WebApplication[] array, int arrayIndex);
        IWebApplicationEnumerator GetEnumerator();

        int Count { get; }

        bool IsSynchronized { get; }

        object SyncRoot { get; }
    }
}

