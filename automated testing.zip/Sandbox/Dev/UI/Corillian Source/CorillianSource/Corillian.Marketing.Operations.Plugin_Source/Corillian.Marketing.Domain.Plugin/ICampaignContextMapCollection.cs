namespace Corillian.Marketing.Domain.Plugin
{
    using System;

    public interface ICampaignContextMapCollection
    {
        void CopyTo(CampaignContextMap[] array, int arrayIndex);
        ICampaignContextMapEnumerator GetEnumerator();

        int Count { get; }

        bool IsSynchronized { get; }

        object SyncRoot { get; }
    }
}

