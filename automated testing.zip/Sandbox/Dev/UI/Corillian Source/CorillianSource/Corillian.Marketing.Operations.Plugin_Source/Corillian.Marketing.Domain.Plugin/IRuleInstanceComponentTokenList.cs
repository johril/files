namespace Corillian.Marketing.Domain.Plugin
{
    using System;
    using System.Reflection;

    public interface IRuleInstanceComponentTokenList : IRuleInstanceComponentTokenCollection
    {
        int Add(RuleInstanceComponentToken value);
        void Clear();
        bool Contains(RuleInstanceComponentToken value);
        int IndexOf(RuleInstanceComponentToken value);
        void Insert(int index, RuleInstanceComponentToken value);
        void Remove(RuleInstanceComponentToken value);
        void RemoveAt(int index);

        bool IsFixedSize { get; }

        bool IsReadOnly { get; }

        RuleInstanceComponentToken this[int index] { get; set; }
    }
}

