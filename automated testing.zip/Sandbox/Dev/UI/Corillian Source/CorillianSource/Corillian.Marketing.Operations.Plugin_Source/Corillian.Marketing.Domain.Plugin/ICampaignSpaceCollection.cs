namespace Corillian.Marketing.Domain.Plugin
{
    using System;

    public interface ICampaignSpaceCollection
    {
        void CopyTo(CampaignSpace[] array, int arrayIndex);
        ICampaignSpaceEnumerator GetEnumerator();

        int Count { get; }

        bool IsSynchronized { get; }

        object SyncRoot { get; }
    }
}

