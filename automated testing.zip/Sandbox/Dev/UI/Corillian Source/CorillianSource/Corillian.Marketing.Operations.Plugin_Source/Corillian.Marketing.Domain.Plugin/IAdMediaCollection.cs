namespace Corillian.Marketing.Domain.Plugin
{
    using System;

    public interface IAdMediaCollection
    {
        void CopyTo(AdMedia[] array, int arrayIndex);
        IAdMediaEnumerator GetEnumerator();

        int Count { get; }

        bool IsSynchronized { get; }

        object SyncRoot { get; }
    }
}

