namespace Corillian.Marketing.Domain.Plugin
{
    using System;

    public interface IRuleTokenTypeEnumerator
    {
        bool MoveNext();
        void Reset();

        RuleTokenType Current { get; }
    }
}

