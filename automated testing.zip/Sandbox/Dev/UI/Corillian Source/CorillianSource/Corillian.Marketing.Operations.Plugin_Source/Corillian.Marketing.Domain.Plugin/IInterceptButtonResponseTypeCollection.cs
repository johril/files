namespace Corillian.Marketing.Domain.Plugin
{
    using System;

    public interface IInterceptButtonResponseTypeCollection
    {
        void CopyTo(InterceptButtonResponseType[] array, int arrayIndex);
        IInterceptButtonResponseTypeEnumerator GetEnumerator();

        int Count { get; }

        bool IsSynchronized { get; }

        object SyncRoot { get; }
    }
}

