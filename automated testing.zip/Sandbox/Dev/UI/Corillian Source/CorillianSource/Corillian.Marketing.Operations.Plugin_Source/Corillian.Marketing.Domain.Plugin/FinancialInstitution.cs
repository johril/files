namespace Corillian.Marketing.Domain.Plugin
{
    using Corillian.Voyager.Common;
    using Corillian.Voyager.Common.Attributes;
    using System;
    using System.Xml.Serialization;

    [Serializable, XmlType(Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", TypeName="FinancialInstitution"), XmlRoot(Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", ElementName="FinancialInstitution")]
    public class FinancialInstitution : IFormattable
    {
        private string _fidescription;
        private string _figuid;
        private int _fiid;
        private string _finame;
        [Ignore, XmlIgnore]
        public bool FiidSpecified;

        public virtual string ToString(string format)
        {
            return FormattableObject.ToString(this, format, null);
        }

        public virtual string ToString(string format, IFormatProvider formatProvider)
        {
            if (format == null)
            {
                return base.ToString();
            }
            return FormattableObject.ToString(this, format, formatProvider);
        }

        [XmlElement(ElementName="FiDescription", Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", DataType="string")]
        public string FiDescription
        {
            get
            {
                return this._fidescription;
            }
            set
            {
                this._fidescription = value;
            }
        }

        [XmlElement(ElementName="FiGuid", Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", DataType="string")]
        public string FiGuid
        {
            get
            {
                return this._figuid;
            }
            set
            {
                this._figuid = value;
            }
        }

        [XmlElement(ElementName="Fiid", Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", DataType="int")]
        public int Fiid
        {
            get
            {
                return this._fiid;
            }
            set
            {
                this.FiidSpecified = true;
                this._fiid = value;
            }
        }

        [XmlElement(ElementName="FiName", Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", DataType="string")]
        public string FiName
        {
            get
            {
                return this._finame;
            }
            set
            {
                this._finame = value;
            }
        }
    }
}

