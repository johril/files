namespace Corillian.Marketing.Domain.Plugin
{
    using System;
    using System.Reflection;

    public interface ICriterionDataTypeList : ICriterionDataTypeCollection
    {
        int Add(CriterionDataType value);
        void Clear();
        bool Contains(CriterionDataType value);
        int IndexOf(CriterionDataType value);
        void Insert(int index, CriterionDataType value);
        void Remove(CriterionDataType value);
        void RemoveAt(int index);

        bool IsFixedSize { get; }

        bool IsReadOnly { get; }

        CriterionDataType this[int index] { get; set; }
    }
}

