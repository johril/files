namespace Corillian.Marketing.Domain.Plugin
{
    using Corillian.Voyager.Common;
    using Corillian.Voyager.Common.Attributes;
    using System;
    using System.Xml.Serialization;

    [Serializable, Scope(PropertyScopeType.HI), XmlType(Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", TypeName="CMCustomerInfo"), XmlRoot(Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", ElementName="CMCustomerInfo")]
    public class CMCustomerInfo : IFormattable
    {
        private Corillian.Marketing.Domain.Plugin.CachedCriterions _cachedcriterions;
        private long _customerid;
        private string _fi;
        private string _voyageruserid;
        [XmlIgnore, Ignore]
        public bool CustomerIdSpecified;

        public virtual string ToString(string format)
        {
            return FormattableObject.ToString(this, format, null);
        }

        public virtual string ToString(string format, IFormatProvider formatProvider)
        {
            if (format == null)
            {
                return base.ToString();
            }
            return FormattableObject.ToString(this, format, formatProvider);
        }

        [Scope(PropertyScopeType.HI), XmlElement(ElementName="CachedCriterions", Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05"), TagName("")]
        public Corillian.Marketing.Domain.Plugin.CachedCriterions CachedCriterions
        {
            get
            {
                return this._cachedcriterions;
            }
            set
            {
                this._cachedcriterions = value;
            }
        }

        [TagName("CMCustomerId"), XmlElement(ElementName="CustomerId", Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", DataType="long"), Repository(RepositoryType.Secure), IgnoreWhenEmpty]
        public long CustomerId
        {
            get
            {
                return this._customerid;
            }
            set
            {
                this.CustomerIdSpecified = true;
                this._customerid = value;
            }
        }

        [XmlElement(ElementName="FI", Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", DataType="string"), PreAuth(PreAuthDirection.INOUT), TagName("__UserInfo_FI"), IgnoreWhenEmpty]
        public string FI
        {
            get
            {
                return this._fi;
            }
            set
            {
                this._fi = value;
            }
        }

        [PreAuth(PreAuthDirection.INOUT), IgnoreWhenEmpty, XmlElement(ElementName="VoyagerUserID", Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", DataType="string"), TagName("Signon_User_UserID")]
        public string VoyagerUserID
        {
            get
            {
                return this._voyageruserid;
            }
            set
            {
                this._voyageruserid = value;
            }
        }
    }
}

