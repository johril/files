namespace Corillian.Marketing.Domain.Plugin
{
    using Corillian.Voyager.Common;
    using Corillian.Voyager.Common.Attributes;
    using System;
    using System.Xml.Serialization;

    [Serializable, XmlRoot(Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", ElementName="Rule"), XmlType(Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", TypeName="Rule")]
    public class Rule : IFormattable
    {
        private bool _astestcell;
        private DateTime _createdate;
        private string _createdby;
        private RuleInstance _currentruleinstance;
        private bool _deleted;
        private int _fiid;
        private bool _isinuse;
        private bool _newinimport;
        private string _ruledescription;
        private string _ruleguid;
        private string _rulename;
        private bool _systemgenerated;
        [Ignore, XmlIgnore]
        public bool AsTestCellSpecified;
        [Ignore, XmlIgnore]
        public bool CreateDateSpecified;
        [XmlIgnore, Ignore]
        public bool DeletedSpecified;
        [XmlIgnore, Ignore]
        public bool FiidSpecified;
        [XmlIgnore, Ignore]
        public bool IsInUseSpecified;
        [XmlIgnore, Ignore]
        public bool NewInImportSpecified;
        [XmlIgnore, Ignore]
        public bool SystemGeneratedSpecified;

        public virtual string ToString(string format)
        {
            return FormattableObject.ToString(this, format, null);
        }

        public virtual string ToString(string format, IFormatProvider formatProvider)
        {
            if (format == null)
            {
                return base.ToString();
            }
            return FormattableObject.ToString(this, format, formatProvider);
        }

        [XmlElement(ElementName="AsTestCell", Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", DataType="boolean")]
        public bool AsTestCell
        {
            get
            {
                return this._astestcell;
            }
            set
            {
                this.AsTestCellSpecified = true;
                this._astestcell = value;
            }
        }

        [XmlElement(ElementName="CreateDate", Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", DataType="dateTime")]
        public DateTime CreateDate
        {
            get
            {
                return this._createdate;
            }
            set
            {
                this.CreateDateSpecified = true;
                this._createdate = value;
            }
        }

        [XmlElement(ElementName="CreatedBy", Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", DataType="string")]
        public string CreatedBy
        {
            get
            {
                return this._createdby;
            }
            set
            {
                this._createdby = value;
            }
        }

        [XmlElement(ElementName="CurrentRuleInstance", Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05")]
        public RuleInstance CurrentRuleInstance
        {
            get
            {
                return this._currentruleinstance;
            }
            set
            {
                this._currentruleinstance = value;
            }
        }

        [XmlElement(ElementName="Deleted", Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", DataType="boolean")]
        public bool Deleted
        {
            get
            {
                return this._deleted;
            }
            set
            {
                this.DeletedSpecified = true;
                this._deleted = value;
            }
        }

        [XmlElement(ElementName="Fiid", Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", DataType="int")]
        public int Fiid
        {
            get
            {
                return this._fiid;
            }
            set
            {
                this.FiidSpecified = true;
                this._fiid = value;
            }
        }

        [XmlElement(ElementName="IsInUse", Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", DataType="boolean")]
        public bool IsInUse
        {
            get
            {
                return this._isinuse;
            }
            set
            {
                this.IsInUseSpecified = true;
                this._isinuse = value;
            }
        }

        [XmlElement(ElementName="NewInImport", Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", DataType="boolean")]
        public bool NewInImport
        {
            get
            {
                return this._newinimport;
            }
            set
            {
                this.NewInImportSpecified = true;
                this._newinimport = value;
            }
        }

        [XmlElement(ElementName="RuleDescription", Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", DataType="string")]
        public string RuleDescription
        {
            get
            {
                return this._ruledescription;
            }
            set
            {
                this._ruledescription = value;
            }
        }

        [XmlElement(ElementName="RuleGuid", Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", DataType="string")]
        public string RuleGuid
        {
            get
            {
                return this._ruleguid;
            }
            set
            {
                this._ruleguid = value;
            }
        }

        [XmlElement(ElementName="RuleName", Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", DataType="string")]
        public string RuleName
        {
            get
            {
                return this._rulename;
            }
            set
            {
                this._rulename = value;
            }
        }

        [XmlElement(ElementName="SystemGenerated", Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", DataType="boolean")]
        public bool SystemGenerated
        {
            get
            {
                return this._systemgenerated;
            }
            set
            {
                this.SystemGeneratedSpecified = true;
                this._systemgenerated = value;
            }
        }
    }
}

