namespace Corillian.Marketing.Domain.Plugin
{
    using Corillian.Voyager.Common;
    using System;
    using System.Xml.Serialization;

    [Serializable, XmlType(Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", TypeName="CriterionMetadataBaseType"), XmlRoot(Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", ElementName="CriterionMetadataBaseType")]
    public class CriterionMetadataBaseType : IFormattable
    {
        private CriterionMetadataCollection _criterionmetadatas;

        public virtual string ToString(string format)
        {
            return FormattableObject.ToString(this, format, null);
        }

        public virtual string ToString(string format, IFormatProvider formatProvider)
        {
            if (format == null)
            {
                return base.ToString();
            }
            return FormattableObject.ToString(this, format, formatProvider);
        }

        [XmlElement(ElementName="CriterionMetadata", Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05")]
        public CriterionMetadataCollection CriterionMetadataList
        {
            get
            {
                return this._criterionmetadatas;
            }
            set
            {
                this._criterionmetadatas = value;
            }
        }
    }
}

