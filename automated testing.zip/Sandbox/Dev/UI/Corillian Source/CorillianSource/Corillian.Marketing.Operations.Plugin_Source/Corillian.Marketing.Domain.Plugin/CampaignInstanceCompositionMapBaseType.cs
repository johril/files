namespace Corillian.Marketing.Domain.Plugin
{
    using Corillian.Voyager.Common;
    using System;
    using System.Xml.Serialization;

    [Serializable, XmlType(Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", TypeName="CampaignInstanceCompositionMapBaseType"), XmlRoot(Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", ElementName="CampaignInstanceCompositionMapBaseType")]
    public class CampaignInstanceCompositionMapBaseType : IFormattable
    {
        private CampaignInstanceCompositionMapCollection _campaigninstancecompositionmaps;

        public virtual string ToString(string format)
        {
            return FormattableObject.ToString(this, format, null);
        }

        public virtual string ToString(string format, IFormatProvider formatProvider)
        {
            if (format == null)
            {
                return base.ToString();
            }
            return FormattableObject.ToString(this, format, formatProvider);
        }

        [XmlElement(ElementName="CampaignInstanceCompositionMap", Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05")]
        public CampaignInstanceCompositionMapCollection CampaignInstanceCompositionMapList
        {
            get
            {
                return this._campaigninstancecompositionmaps;
            }
            set
            {
                this._campaigninstancecompositionmaps = value;
            }
        }
    }
}

