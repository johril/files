namespace Corillian.Marketing.Domain.Plugin
{
    using System;

    public interface ICampaignImportTaskMessageEnumerator
    {
        bool MoveNext();
        void Reset();

        CampaignImportTaskMessage Current { get; }
    }
}

