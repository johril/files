namespace Corillian.Marketing.Domain.Plugin
{
    using Corillian.Voyager.Common;
    using Corillian.Voyager.Common.Attributes;
    using System;
    using System.Xml.Serialization;

    [Serializable, XmlRoot(Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", ElementName="InterceptDisplay"), XmlType(Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", TypeName="InterceptDisplay")]
    public class InterceptDisplay : IFormattable
    {
        private long _campaigncompositionid;
        private int _displayfrequency;
        private int _impressions;
        private long _interceptdisplayid;
        private int _interceptreminderduration;
        private long _pscid;
        private string _targeturl;
        private string _title;
        [Ignore, XmlIgnore]
        public bool CampaignCompositionIdSpecified;
        [Ignore, XmlIgnore]
        public bool DisplayFrequencySpecified;
        [Ignore, XmlIgnore]
        public bool ImpressionsSpecified;
        [XmlIgnore, Ignore]
        public bool InterceptDisplayIdSpecified;
        [XmlIgnore, Ignore]
        public bool InterceptReminderDurationSpecified;
        [Ignore, XmlIgnore]
        public bool PscidSpecified;

        public virtual string ToString(string format)
        {
            return FormattableObject.ToString(this, format, null);
        }

        public virtual string ToString(string format, IFormatProvider formatProvider)
        {
            if (format == null)
            {
                return base.ToString();
            }
            return FormattableObject.ToString(this, format, formatProvider);
        }

        [XmlElement(ElementName="CampaignCompositionId", Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", DataType="long")]
        public long CampaignCompositionId
        {
            get
            {
                return this._campaigncompositionid;
            }
            set
            {
                this.CampaignCompositionIdSpecified = true;
                this._campaigncompositionid = value;
            }
        }

        [XmlElement(ElementName="DisplayFrequency", Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", DataType="int")]
        public int DisplayFrequency
        {
            get
            {
                return this._displayfrequency;
            }
            set
            {
                this.DisplayFrequencySpecified = true;
                this._displayfrequency = value;
            }
        }

        [XmlElement(ElementName="Impressions", Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", DataType="int")]
        public int Impressions
        {
            get
            {
                return this._impressions;
            }
            set
            {
                this.ImpressionsSpecified = true;
                this._impressions = value;
            }
        }

        [XmlElement(ElementName="InterceptDisplayId", Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", DataType="long")]
        public long InterceptDisplayId
        {
            get
            {
                return this._interceptdisplayid;
            }
            set
            {
                this.InterceptDisplayIdSpecified = true;
                this._interceptdisplayid = value;
            }
        }

        [XmlElement(ElementName="InterceptReminderDuration", Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", DataType="int")]
        public int InterceptReminderDuration
        {
            get
            {
                return this._interceptreminderduration;
            }
            set
            {
                this.InterceptReminderDurationSpecified = true;
                this._interceptreminderduration = value;
            }
        }

        [XmlElement(ElementName="Pscid", Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", DataType="long")]
        public long Pscid
        {
            get
            {
                return this._pscid;
            }
            set
            {
                this.PscidSpecified = true;
                this._pscid = value;
            }
        }

        [XmlElement(ElementName="TargetUrl", Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", DataType="string")]
        public string TargetUrl
        {
            get
            {
                return this._targeturl;
            }
            set
            {
                this._targeturl = value;
            }
        }

        [XmlElement(ElementName="Title", Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", DataType="string")]
        public string Title
        {
            get
            {
                return this._title;
            }
            set
            {
                this._title = value;
            }
        }
    }
}

