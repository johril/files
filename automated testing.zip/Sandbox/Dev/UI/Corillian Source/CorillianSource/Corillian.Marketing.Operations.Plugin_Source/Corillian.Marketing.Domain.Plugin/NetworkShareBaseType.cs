namespace Corillian.Marketing.Domain.Plugin
{
    using Corillian.Voyager.Common;
    using System;
    using System.Xml.Serialization;

    [Serializable, XmlType(Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", TypeName="NetworkShareBaseType"), XmlRoot(Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", ElementName="NetworkShareBaseType")]
    public class NetworkShareBaseType : IFormattable
    {
        private NetworkShareCollection _networkshares;

        public virtual string ToString(string format)
        {
            return FormattableObject.ToString(this, format, null);
        }

        public virtual string ToString(string format, IFormatProvider formatProvider)
        {
            if (format == null)
            {
                return base.ToString();
            }
            return FormattableObject.ToString(this, format, formatProvider);
        }

        [XmlElement(ElementName="NetworkShare", Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05")]
        public NetworkShareCollection NetworkShareList
        {
            get
            {
                return this._networkshares;
            }
            set
            {
                this._networkshares = value;
            }
        }
    }
}

