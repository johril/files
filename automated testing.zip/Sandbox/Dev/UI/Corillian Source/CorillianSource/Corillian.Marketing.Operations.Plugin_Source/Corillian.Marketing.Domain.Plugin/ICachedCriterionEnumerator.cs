namespace Corillian.Marketing.Domain.Plugin
{
    using System;

    public interface ICachedCriterionEnumerator
    {
        bool MoveNext();
        void Reset();

        CachedCriterion Current { get; }
    }
}

