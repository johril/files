namespace Corillian.Marketing.Domain.Plugin
{
    using System;
    using System.Reflection;

    public interface IMcifImportTaskList : IMcifImportTaskCollection
    {
        int Add(McifImportTask value);
        void Clear();
        bool Contains(McifImportTask value);
        int IndexOf(McifImportTask value);
        void Insert(int index, McifImportTask value);
        void Remove(McifImportTask value);
        void RemoveAt(int index);

        bool IsFixedSize { get; }

        bool IsReadOnly { get; }

        McifImportTask this[int index] { get; set; }
    }
}

