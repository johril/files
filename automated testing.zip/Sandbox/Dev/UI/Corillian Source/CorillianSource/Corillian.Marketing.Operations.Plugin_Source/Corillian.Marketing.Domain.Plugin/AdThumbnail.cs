namespace Corillian.Marketing.Domain.Plugin
{
    using Corillian.Voyager.Common;
    using System;
    using System.Xml.Serialization;

    [Serializable, XmlRoot(Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", ElementName="AdThumbnail"), XmlType(Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", TypeName="AdThumbnail")]
    public class AdThumbnail : IFormattable
    {
        private Corillian.Marketing.Domain.Plugin.AdMedia _admedia;
        private byte[] _tumbnail;

        public virtual string ToString(string format)
        {
            return FormattableObject.ToString(this, format, null);
        }

        public virtual string ToString(string format, IFormatProvider formatProvider)
        {
            if (format == null)
            {
                return base.ToString();
            }
            return FormattableObject.ToString(this, format, formatProvider);
        }

        [XmlElement(ElementName="AdMedia", Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05")]
        public Corillian.Marketing.Domain.Plugin.AdMedia AdMedia
        {
            get
            {
                return this._admedia;
            }
            set
            {
                this._admedia = value;
            }
        }

        [XmlElement(ElementName="Tumbnail", Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", DataType="base64Binary")]
        public byte[] Tumbnail
        {
            get
            {
                return this._tumbnail;
            }
            set
            {
                this._tumbnail = value;
            }
        }
    }
}

