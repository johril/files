namespace Corillian.Marketing.Domain.Plugin
{
    using System;
    using System.Reflection;

    public interface ICampaignContextMapList : ICampaignContextMapCollection
    {
        int Add(CampaignContextMap value);
        void Clear();
        bool Contains(CampaignContextMap value);
        int IndexOf(CampaignContextMap value);
        void Insert(int index, CampaignContextMap value);
        void Remove(CampaignContextMap value);
        void RemoveAt(int index);

        bool IsFixedSize { get; }

        bool IsReadOnly { get; }

        CampaignContextMap this[int index] { get; set; }
    }
}

