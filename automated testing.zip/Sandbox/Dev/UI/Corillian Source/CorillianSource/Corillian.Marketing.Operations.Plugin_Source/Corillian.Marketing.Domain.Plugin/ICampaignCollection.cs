namespace Corillian.Marketing.Domain.Plugin
{
    using System;

    public interface ICampaignCollection
    {
        void CopyTo(Campaign[] array, int arrayIndex);
        ICampaignEnumerator GetEnumerator();

        int Count { get; }

        bool IsSynchronized { get; }

        object SyncRoot { get; }
    }
}

