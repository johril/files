namespace Corillian.Marketing.Domain.Plugin
{
    using System;
    using System.Reflection;

    public interface ICriterionMetadataList : ICriterionMetadataCollection
    {
        int Add(CriterionMetadata value);
        void Clear();
        bool Contains(CriterionMetadata value);
        int IndexOf(CriterionMetadata value);
        void Insert(int index, CriterionMetadata value);
        void Remove(CriterionMetadata value);
        void RemoveAt(int index);

        bool IsFixedSize { get; }

        bool IsReadOnly { get; }

        CriterionMetadata this[int index] { get; set; }
    }
}

