namespace Corillian.Marketing.Domain.Plugin
{
    using System;
    using System.Reflection;

    public interface ICampaignSpaceList : ICampaignSpaceCollection
    {
        int Add(CampaignSpace value);
        void Clear();
        bool Contains(CampaignSpace value);
        int IndexOf(CampaignSpace value);
        void Insert(int index, CampaignSpace value);
        void Remove(CampaignSpace value);
        void RemoveAt(int index);

        bool IsFixedSize { get; }

        bool IsReadOnly { get; }

        CampaignSpace this[int index] { get; set; }
    }
}

