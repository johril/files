namespace Corillian.Marketing.Domain.Plugin
{
    using Corillian.Voyager.Common;
    using Corillian.Voyager.Common.Attributes;
    using System;
    using System.Xml.Serialization;

    [Serializable, XmlRoot(Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", ElementName="InterceptButtonResponseType"), XmlType(Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", TypeName="InterceptButtonResponseType")]
    public class InterceptButtonResponseType : IFormattable
    {
        private string _description;
        private int _id;
        private string _name;
        [Ignore, XmlIgnore]
        public bool IDSpecified;

        public virtual string ToString(string format)
        {
            return FormattableObject.ToString(this, format, null);
        }

        public virtual string ToString(string format, IFormatProvider formatProvider)
        {
            if (format == null)
            {
                return base.ToString();
            }
            return FormattableObject.ToString(this, format, formatProvider);
        }

        [XmlElement(ElementName="Description", Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", DataType="string")]
        public string Description
        {
            get
            {
                return this._description;
            }
            set
            {
                this._description = value;
            }
        }

        [XmlElement(ElementName="ID", Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", DataType="int")]
        public int ID
        {
            get
            {
                return this._id;
            }
            set
            {
                this.IDSpecified = true;
                this._id = value;
            }
        }

        [XmlElement(ElementName="Name", Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", DataType="string")]
        public string Name
        {
            get
            {
                return this._name;
            }
            set
            {
                this._name = value;
            }
        }
    }
}

