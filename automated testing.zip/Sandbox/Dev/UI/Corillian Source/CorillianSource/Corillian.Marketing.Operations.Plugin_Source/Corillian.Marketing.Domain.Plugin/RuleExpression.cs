namespace Corillian.Marketing.Domain.Plugin
{
    using Corillian.Voyager.Common;
    using System;
    using System.Xml.Serialization;

    [Serializable, XmlType(Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", TypeName="RuleExpression"), XmlRoot(Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", ElementName="RuleExpression")]
    public class RuleExpression : IFormattable
    {
        private RuleInstanceComponentToken _lhstoken;
        private RuleInstanceComponentToken _operatortoken;
        private RuleInstanceComponentToken _prefixtoken;
        private RuleInstanceComponentToken _rhsexpressiontoken;
        private RuleInstanceComponentToken _rhstestcell1token;
        private RuleInstanceComponentToken _rhstestcell2token;
        private RuleInstanceComponentToken _rhstestcell3token;
        private RuleInstanceComponentToken _rhstestcell4token;
        private RuleInstanceComponentToken _rhstestcell5token;
        private RuleInstanceComponentToken _rhstestcell6token;
        private RuleInstanceComponentToken _rhstestcell7token;
        private RuleInstanceComponentToken _rhstestcell8token;

        public virtual string ToString(string format)
        {
            return FormattableObject.ToString(this, format, null);
        }

        public virtual string ToString(string format, IFormatProvider formatProvider)
        {
            if (format == null)
            {
                return base.ToString();
            }
            return FormattableObject.ToString(this, format, formatProvider);
        }

        [XmlElement(ElementName="LhsToken", Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05")]
        public RuleInstanceComponentToken LhsToken
        {
            get
            {
                return this._lhstoken;
            }
            set
            {
                this._lhstoken = value;
            }
        }

        [XmlElement(ElementName="OperatorToken", Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05")]
        public RuleInstanceComponentToken OperatorToken
        {
            get
            {
                return this._operatortoken;
            }
            set
            {
                this._operatortoken = value;
            }
        }

        [XmlElement(ElementName="PrefixToken", Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05")]
        public RuleInstanceComponentToken PrefixToken
        {
            get
            {
                return this._prefixtoken;
            }
            set
            {
                this._prefixtoken = value;
            }
        }

        [XmlElement(ElementName="RhsExpressionToken", Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05")]
        public RuleInstanceComponentToken RhsExpressionToken
        {
            get
            {
                return this._rhsexpressiontoken;
            }
            set
            {
                this._rhsexpressiontoken = value;
            }
        }

        [XmlElement(ElementName="RhsTestCell1Token", Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05")]
        public RuleInstanceComponentToken RhsTestCell1Token
        {
            get
            {
                return this._rhstestcell1token;
            }
            set
            {
                this._rhstestcell1token = value;
            }
        }

        [XmlElement(ElementName="RhsTestCell2Token", Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05")]
        public RuleInstanceComponentToken RhsTestCell2Token
        {
            get
            {
                return this._rhstestcell2token;
            }
            set
            {
                this._rhstestcell2token = value;
            }
        }

        [XmlElement(ElementName="RhsTestCell3Token", Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05")]
        public RuleInstanceComponentToken RhsTestCell3Token
        {
            get
            {
                return this._rhstestcell3token;
            }
            set
            {
                this._rhstestcell3token = value;
            }
        }

        [XmlElement(ElementName="RhsTestCell4Token", Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05")]
        public RuleInstanceComponentToken RhsTestCell4Token
        {
            get
            {
                return this._rhstestcell4token;
            }
            set
            {
                this._rhstestcell4token = value;
            }
        }

        [XmlElement(ElementName="RhsTestCell5Token", Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05")]
        public RuleInstanceComponentToken RhsTestCell5Token
        {
            get
            {
                return this._rhstestcell5token;
            }
            set
            {
                this._rhstestcell5token = value;
            }
        }

        [XmlElement(ElementName="RhsTestCell6Token", Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05")]
        public RuleInstanceComponentToken RhsTestCell6Token
        {
            get
            {
                return this._rhstestcell6token;
            }
            set
            {
                this._rhstestcell6token = value;
            }
        }

        [XmlElement(ElementName="RhsTestCell7Token", Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05")]
        public RuleInstanceComponentToken RhsTestCell7Token
        {
            get
            {
                return this._rhstestcell7token;
            }
            set
            {
                this._rhstestcell7token = value;
            }
        }

        [XmlElement(ElementName="RhsTestCell8Token", Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05")]
        public RuleInstanceComponentToken RhsTestCell8Token
        {
            get
            {
                return this._rhstestcell8token;
            }
            set
            {
                this._rhstestcell8token = value;
            }
        }
    }
}

