namespace Corillian.Marketing.Domain.Plugin
{
    using Corillian.Voyager.Common;
    using Corillian.Voyager.Common.Attributes;
    using System;
    using System.Xml.Serialization;

    [Serializable, XmlRoot(Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", ElementName="WebPage"), XmlType(Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", TypeName="WebPage")]
    public class WebPage : IFormattable
    {
        private Corillian.Marketing.Domain.Plugin.WebApplication _webapplication;
        private string _webpagedescription;
        private int _webpageid;
        private string _webpagename;
        private int _webpagenamechecksum;
        [Ignore, XmlIgnore]
        public bool WebPageIdSpecified;
        [Ignore, XmlIgnore]
        public bool WebPageNameCheckSumSpecified;

        public virtual string ToString(string format)
        {
            return FormattableObject.ToString(this, format, null);
        }

        public virtual string ToString(string format, IFormatProvider formatProvider)
        {
            if (format == null)
            {
                return base.ToString();
            }
            return FormattableObject.ToString(this, format, formatProvider);
        }

        [XmlElement(ElementName="WebApplication", Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05")]
        public Corillian.Marketing.Domain.Plugin.WebApplication WebApplication
        {
            get
            {
                return this._webapplication;
            }
            set
            {
                this._webapplication = value;
            }
        }

        [XmlElement(ElementName="WebPageDescription", Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", DataType="string")]
        public string WebPageDescription
        {
            get
            {
                return this._webpagedescription;
            }
            set
            {
                this._webpagedescription = value;
            }
        }

        [XmlElement(ElementName="WebPageId", Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", DataType="int")]
        public int WebPageId
        {
            get
            {
                return this._webpageid;
            }
            set
            {
                this.WebPageIdSpecified = true;
                this._webpageid = value;
            }
        }

        [XmlElement(ElementName="WebPageName", Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", DataType="string")]
        public string WebPageName
        {
            get
            {
                return this._webpagename;
            }
            set
            {
                this._webpagename = value;
            }
        }

        [XmlElement(ElementName="WebPageNameCheckSum", Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", DataType="int")]
        public int WebPageNameCheckSum
        {
            get
            {
                return this._webpagenamechecksum;
            }
            set
            {
                this.WebPageNameCheckSumSpecified = true;
                this._webpagenamechecksum = value;
            }
        }
    }
}

