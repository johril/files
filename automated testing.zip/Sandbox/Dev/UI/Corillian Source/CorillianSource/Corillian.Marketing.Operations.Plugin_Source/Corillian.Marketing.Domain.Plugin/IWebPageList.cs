namespace Corillian.Marketing.Domain.Plugin
{
    using System;
    using System.Reflection;

    public interface IWebPageList : IWebPageCollection
    {
        int Add(WebPage value);
        void Clear();
        bool Contains(WebPage value);
        int IndexOf(WebPage value);
        void Insert(int index, WebPage value);
        void Remove(WebPage value);
        void RemoveAt(int index);

        bool IsFixedSize { get; }

        bool IsReadOnly { get; }

        WebPage this[int index] { get; set; }
    }
}

