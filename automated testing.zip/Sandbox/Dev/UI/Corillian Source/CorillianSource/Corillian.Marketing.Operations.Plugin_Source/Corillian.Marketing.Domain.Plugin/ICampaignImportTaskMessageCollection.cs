namespace Corillian.Marketing.Domain.Plugin
{
    using System;

    public interface ICampaignImportTaskMessageCollection
    {
        void CopyTo(CampaignImportTaskMessage[] array, int arrayIndex);
        ICampaignImportTaskMessageEnumerator GetEnumerator();

        int Count { get; }

        bool IsSynchronized { get; }

        object SyncRoot { get; }
    }
}

