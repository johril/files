namespace Corillian.Marketing.Domain.Plugin
{
    using System;

    public interface IRuleInstanceComponentTokenEnumerator
    {
        bool MoveNext();
        void Reset();

        RuleInstanceComponentToken Current { get; }
    }
}

