namespace Corillian.Marketing.Domain.Plugin
{
    using System;

    public interface IAdSpaceEnumerator
    {
        bool MoveNext();
        void Reset();

        AdSpace Current { get; }
    }
}

