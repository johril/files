namespace Corillian.Marketing.Domain.Plugin
{
    using System;
    using System.Reflection;

    public interface IInterceptButtonResponseTypeList : IInterceptButtonResponseTypeCollection
    {
        int Add(InterceptButtonResponseType value);
        void Clear();
        bool Contains(InterceptButtonResponseType value);
        int IndexOf(InterceptButtonResponseType value);
        void Insert(int index, InterceptButtonResponseType value);
        void Remove(InterceptButtonResponseType value);
        void RemoveAt(int index);

        bool IsFixedSize { get; }

        bool IsReadOnly { get; }

        InterceptButtonResponseType this[int index] { get; set; }
    }
}

