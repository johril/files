namespace Corillian.Marketing.Domain.Plugin
{
    using System;
    using System.Reflection;

    public interface ICustomerCriterionList : ICustomerCriterionCollection
    {
        int Add(CustomerCriterion value);
        void Clear();
        bool Contains(CustomerCriterion value);
        int IndexOf(CustomerCriterion value);
        void Insert(int index, CustomerCriterion value);
        void Remove(CustomerCriterion value);
        void RemoveAt(int index);

        bool IsFixedSize { get; }

        bool IsReadOnly { get; }

        CustomerCriterion this[int index] { get; set; }
    }
}

