namespace Corillian.Marketing.Domain.Plugin
{
    using System;

    public interface IBaseContextEnumerator
    {
        bool MoveNext();
        void Reset();

        BaseContext Current { get; }
    }
}

