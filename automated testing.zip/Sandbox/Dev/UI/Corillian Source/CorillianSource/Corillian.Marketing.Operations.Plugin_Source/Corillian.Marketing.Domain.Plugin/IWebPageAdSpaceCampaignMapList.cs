namespace Corillian.Marketing.Domain.Plugin
{
    using System;
    using System.Reflection;

    public interface IWebPageAdSpaceCampaignMapList : IWebPageAdSpaceCampaignMapCollection
    {
        int Add(WebPageAdSpaceCampaignMap value);
        void Clear();
        bool Contains(WebPageAdSpaceCampaignMap value);
        int IndexOf(WebPageAdSpaceCampaignMap value);
        void Insert(int index, WebPageAdSpaceCampaignMap value);
        void Remove(WebPageAdSpaceCampaignMap value);
        void RemoveAt(int index);

        bool IsFixedSize { get; }

        bool IsReadOnly { get; }

        WebPageAdSpaceCampaignMap this[int index] { get; set; }
    }
}

