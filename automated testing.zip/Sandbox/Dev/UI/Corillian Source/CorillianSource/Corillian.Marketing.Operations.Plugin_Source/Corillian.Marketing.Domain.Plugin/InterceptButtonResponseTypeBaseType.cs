namespace Corillian.Marketing.Domain.Plugin
{
    using Corillian.Voyager.Common;
    using System;
    using System.Xml.Serialization;

    [Serializable, XmlRoot(Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", ElementName="InterceptButtonResponseTypeBaseType"), XmlType(Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", TypeName="InterceptButtonResponseTypeBaseType")]
    public class InterceptButtonResponseTypeBaseType : IFormattable
    {
        private InterceptButtonResponseTypeCollection _interceptbuttonresponsetypes;

        public virtual string ToString(string format)
        {
            return FormattableObject.ToString(this, format, null);
        }

        public virtual string ToString(string format, IFormatProvider formatProvider)
        {
            if (format == null)
            {
                return base.ToString();
            }
            return FormattableObject.ToString(this, format, formatProvider);
        }

        [XmlElement(ElementName="InterceptButtonResponseType", Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05")]
        public InterceptButtonResponseTypeCollection InterceptButtonResponseTypeList
        {
            get
            {
                return this._interceptbuttonresponsetypes;
            }
            set
            {
                this._interceptbuttonresponsetypes = value;
            }
        }
    }
}

