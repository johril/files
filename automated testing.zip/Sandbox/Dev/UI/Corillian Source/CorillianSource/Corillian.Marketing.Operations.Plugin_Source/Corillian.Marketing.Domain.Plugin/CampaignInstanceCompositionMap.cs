namespace Corillian.Marketing.Domain.Plugin
{
    using Corillian.Voyager.Common;
    using Corillian.Voyager.Common.Attributes;
    using System;
    using System.Xml.Serialization;

    [Serializable, XmlType(Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", TypeName="CampaignInstanceCompositionMap"), XmlRoot(Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", ElementName="CampaignInstanceCompositionMap")]
    public class CampaignInstanceCompositionMap : IFormattable
    {
        private Corillian.Marketing.Domain.Plugin.AdMedia _admedia;
        private long _campaigncompositionid;
        private string _campaigninstanceguid;
        private int _componentsequenceid;
        private Corillian.Marketing.Domain.Plugin.InterceptDisplayConfig _interceptdisplayconfig;
        private string _linkid;
        private string _ruleguid;
        private string _testcell;
        [Ignore, XmlIgnore]
        public bool CampaignCompositionIdSpecified;
        [XmlIgnore, Ignore]
        public bool ComponentSequenceIdSpecified;

        public virtual string ToString(string format)
        {
            return FormattableObject.ToString(this, format, null);
        }

        public virtual string ToString(string format, IFormatProvider formatProvider)
        {
            if (format == null)
            {
                return base.ToString();
            }
            return FormattableObject.ToString(this, format, formatProvider);
        }

        [XmlElement(ElementName="AdMedia", Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05")]
        public Corillian.Marketing.Domain.Plugin.AdMedia AdMedia
        {
            get
            {
                return this._admedia;
            }
            set
            {
                this._admedia = value;
            }
        }

        [XmlElement(ElementName="CampaignCompositionId", Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", DataType="long")]
        public long CampaignCompositionId
        {
            get
            {
                return this._campaigncompositionid;
            }
            set
            {
                this.CampaignCompositionIdSpecified = true;
                this._campaigncompositionid = value;
            }
        }

        [XmlElement(ElementName="CampaignInstanceGuid", Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", DataType="string")]
        public string CampaignInstanceGuid
        {
            get
            {
                return this._campaigninstanceguid;
            }
            set
            {
                this._campaigninstanceguid = value;
            }
        }

        [XmlElement(ElementName="ComponentSequenceId", Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", DataType="int")]
        public int ComponentSequenceId
        {
            get
            {
                return this._componentsequenceid;
            }
            set
            {
                this.ComponentSequenceIdSpecified = true;
                this._componentsequenceid = value;
            }
        }

        [XmlElement(ElementName="InterceptDisplayConfig", Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05")]
        public Corillian.Marketing.Domain.Plugin.InterceptDisplayConfig InterceptDisplayConfig
        {
            get
            {
                return this._interceptdisplayconfig;
            }
            set
            {
                this._interceptdisplayconfig = value;
            }
        }

        [XmlElement(ElementName="LinkId", Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", DataType="string")]
        public string LinkId
        {
            get
            {
                return this._linkid;
            }
            set
            {
                this._linkid = value;
            }
        }

        [XmlElement(ElementName="RuleGuid", Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", DataType="string")]
        public string RuleGuid
        {
            get
            {
                return this._ruleguid;
            }
            set
            {
                this._ruleguid = value;
            }
        }

        [XmlElement(ElementName="TestCell", Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", DataType="string")]
        public string TestCell
        {
            get
            {
                return this._testcell;
            }
            set
            {
                this._testcell = value;
            }
        }
    }
}

