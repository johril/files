namespace Corillian.Marketing.Domain.Plugin
{
    using Corillian.Voyager.Common;
    using Corillian.Voyager.Common.Attributes;
    using System;
    using System.Xml.Serialization;

    [Serializable, XmlRoot(Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", ElementName="WebPageAdSpaceCampaignMap"), XmlType(Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", TypeName="WebPageAdSpaceCampaignMap")]
    public class WebPageAdSpaceCampaignMap : IFormattable
    {
        private string _campaigninstanceguid;
        private WebPageAdSpaceMap _pagespacemap;
        private long _pscid;
        [Ignore, XmlIgnore]
        public bool PscidSpecified;

        public virtual string ToString(string format)
        {
            return FormattableObject.ToString(this, format, null);
        }

        public virtual string ToString(string format, IFormatProvider formatProvider)
        {
            if (format == null)
            {
                return base.ToString();
            }
            return FormattableObject.ToString(this, format, formatProvider);
        }

        [XmlElement(ElementName="CampaignInstanceGuid", Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", DataType="string")]
        public string CampaignInstanceGuid
        {
            get
            {
                return this._campaigninstanceguid;
            }
            set
            {
                this._campaigninstanceguid = value;
            }
        }

        [XmlElement(ElementName="PageSpaceMap", Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05")]
        public WebPageAdSpaceMap PageSpaceMap
        {
            get
            {
                return this._pagespacemap;
            }
            set
            {
                this._pagespacemap = value;
            }
        }

        [XmlElement(ElementName="Pscid", Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", DataType="long")]
        public long Pscid
        {
            get
            {
                return this._pscid;
            }
            set
            {
                this.PscidSpecified = true;
                this._pscid = value;
            }
        }
    }
}

