namespace Corillian.Marketing.Domain.Plugin
{
    using Corillian.Voyager.Common;
    using Corillian.Voyager.Common.Attributes;
    using System;
    using System.Xml.Serialization;

    [Serializable, XmlType(Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", TypeName="CachedCriterions"), XmlRoot(Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", ElementName="CachedCriterions")]
    public class CachedCriterions : IFormattable
    {
        private CachedCriterionCollection _cachedcriterions;

        public virtual string ToString(string format)
        {
            return FormattableObject.ToString(this, format, null);
        }

        public virtual string ToString(string format, IFormatProvider formatProvider)
        {
            if (format == null)
            {
                return base.ToString();
            }
            return FormattableObject.ToString(this, format, formatProvider);
        }

        [XmlElement(ElementName="CachedCriterion", Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05"), TagName("CMCriterion."), Repository(RepositoryType.Secure)]
        public CachedCriterionCollection CachedCriterionList
        {
            get
            {
                return this._cachedcriterions;
            }
            set
            {
                this._cachedcriterions = value;
            }
        }
    }
}

