namespace Corillian.Marketing.Domain.Plugin
{
    using Corillian.Voyager.Common;
    using Corillian.Voyager.Common.Attributes;
    using System;
    using System.Xml.Serialization;

    [Serializable, XmlType(Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", TypeName="RuleInstance"), XmlRoot(Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", ElementName="RuleInstance")]
    public class RuleInstance : IFormattable
    {
        private DateTime _createdate;
        private string _createdby;
        private bool _currentinstance;
        private bool _deleted;
        private string _ruleguid;
        private int _ruleinstanceaggchecksum;
        private string _ruleinstanceguid;
        private int _ruleversion;
        [XmlIgnore, Ignore]
        public bool CreateDateSpecified;
        [Ignore, XmlIgnore]
        public bool CurrentInstanceSpecified;
        [XmlIgnore, Ignore]
        public bool DeletedSpecified;
        [Ignore, XmlIgnore]
        public bool RuleInstanceAggChecksumSpecified;
        [Ignore, XmlIgnore]
        public bool RuleVersionSpecified;

        public virtual string ToString(string format)
        {
            return FormattableObject.ToString(this, format, null);
        }

        public virtual string ToString(string format, IFormatProvider formatProvider)
        {
            if (format == null)
            {
                return base.ToString();
            }
            return FormattableObject.ToString(this, format, formatProvider);
        }

        [XmlElement(ElementName="CreateDate", Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", DataType="dateTime")]
        public DateTime CreateDate
        {
            get
            {
                return this._createdate;
            }
            set
            {
                this.CreateDateSpecified = true;
                this._createdate = value;
            }
        }

        [XmlElement(ElementName="CreatedBy", Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", DataType="string")]
        public string CreatedBy
        {
            get
            {
                return this._createdby;
            }
            set
            {
                this._createdby = value;
            }
        }

        [XmlElement(ElementName="CurrentInstance", Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", DataType="boolean")]
        public bool CurrentInstance
        {
            get
            {
                return this._currentinstance;
            }
            set
            {
                this.CurrentInstanceSpecified = true;
                this._currentinstance = value;
            }
        }

        [XmlElement(ElementName="Deleted", Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", DataType="boolean")]
        public bool Deleted
        {
            get
            {
                return this._deleted;
            }
            set
            {
                this.DeletedSpecified = true;
                this._deleted = value;
            }
        }

        [XmlElement(ElementName="RuleGuid", Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", DataType="string")]
        public string RuleGuid
        {
            get
            {
                return this._ruleguid;
            }
            set
            {
                this._ruleguid = value;
            }
        }

        [XmlElement(ElementName="RuleInstanceAggChecksum", Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", DataType="int")]
        public int RuleInstanceAggChecksum
        {
            get
            {
                return this._ruleinstanceaggchecksum;
            }
            set
            {
                this.RuleInstanceAggChecksumSpecified = true;
                this._ruleinstanceaggchecksum = value;
            }
        }

        [XmlElement(ElementName="RuleInstanceGuid", Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", DataType="string")]
        public string RuleInstanceGuid
        {
            get
            {
                return this._ruleinstanceguid;
            }
            set
            {
                this._ruleinstanceguid = value;
            }
        }

        [XmlElement(ElementName="RuleVersion", Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", DataType="int")]
        public int RuleVersion
        {
            get
            {
                return this._ruleversion;
            }
            set
            {
                this.RuleVersionSpecified = true;
                this._ruleversion = value;
            }
        }
    }
}

