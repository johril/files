namespace Corillian.Marketing.Domain.Plugin
{
    using System;

    public interface IInterceptButtonResponseTypeEnumerator
    {
        bool MoveNext();
        void Reset();

        InterceptButtonResponseType Current { get; }
    }
}

