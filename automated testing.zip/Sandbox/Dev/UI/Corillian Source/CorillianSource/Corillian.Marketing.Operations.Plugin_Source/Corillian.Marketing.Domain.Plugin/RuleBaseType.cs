namespace Corillian.Marketing.Domain.Plugin
{
    using Corillian.Voyager.Common;
    using System;
    using System.Xml.Serialization;

    [Serializable, XmlRoot(Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", ElementName="RuleBaseType"), XmlType(Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", TypeName="RuleBaseType")]
    public class RuleBaseType : IFormattable
    {
        private RuleCollection _rules;

        public virtual string ToString(string format)
        {
            return FormattableObject.ToString(this, format, null);
        }

        public virtual string ToString(string format, IFormatProvider formatProvider)
        {
            if (format == null)
            {
                return base.ToString();
            }
            return FormattableObject.ToString(this, format, formatProvider);
        }

        [XmlElement(ElementName="Rule", Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05")]
        public RuleCollection RuleList
        {
            get
            {
                return this._rules;
            }
            set
            {
                this._rules = value;
            }
        }
    }
}

