namespace Corillian.Marketing.Domain.Plugin
{
    using Corillian.Voyager.Common;
    using Corillian.Voyager.Common.Attributes;
    using System;
    using System.Xml.Serialization;

    [Serializable, XmlRoot(Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", ElementName="McifImportTaskError"), XmlType(Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", TypeName="McifImportTaskError")]
    public class McifImportTaskError : IFormattable
    {
        private string _datarow;
        private string _errordescription;
        private long _importtaskerrorid;
        private int _importtaskid;
        [XmlIgnore, Ignore]
        public bool ImportTaskErrorIdSpecified;
        [Ignore, XmlIgnore]
        public bool ImportTaskIdSpecified;

        public virtual string ToString(string format)
        {
            return FormattableObject.ToString(this, format, null);
        }

        public virtual string ToString(string format, IFormatProvider formatProvider)
        {
            if (format == null)
            {
                return base.ToString();
            }
            return FormattableObject.ToString(this, format, formatProvider);
        }

        [XmlElement(ElementName="DataRow", Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", DataType="string")]
        public string DataRow
        {
            get
            {
                return this._datarow;
            }
            set
            {
                this._datarow = value;
            }
        }

        [XmlElement(ElementName="ErrorDescription", Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", DataType="string")]
        public string ErrorDescription
        {
            get
            {
                return this._errordescription;
            }
            set
            {
                this._errordescription = value;
            }
        }

        [XmlElement(ElementName="ImportTaskErrorId", Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", DataType="long")]
        public long ImportTaskErrorId
        {
            get
            {
                return this._importtaskerrorid;
            }
            set
            {
                this.ImportTaskErrorIdSpecified = true;
                this._importtaskerrorid = value;
            }
        }

        [XmlElement(ElementName="ImportTaskId", Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", DataType="int")]
        public int ImportTaskId
        {
            get
            {
                return this._importtaskid;
            }
            set
            {
                this.ImportTaskIdSpecified = true;
                this._importtaskid = value;
            }
        }
    }
}

