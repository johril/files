namespace Corillian.Marketing.Domain.Plugin
{
    using System;
    using System.Reflection;

    public interface ICachedCriterionList : ICachedCriterionCollection
    {
        int Add(CachedCriterion value);
        void Clear();
        bool Contains(CachedCriterion value);
        int IndexOf(CachedCriterion value);
        void Insert(int index, CachedCriterion value);
        void Remove(CachedCriterion value);
        void RemoveAt(int index);

        bool IsFixedSize { get; }

        bool IsReadOnly { get; }

        CachedCriterion this[int index] { get; set; }
    }
}

