namespace Corillian.Marketing.Domain.Plugin
{
    using System;
    using System.Reflection;

    public interface IWebApplicationList : IWebApplicationCollection
    {
        int Add(WebApplication value);
        void Clear();
        bool Contains(WebApplication value);
        int IndexOf(WebApplication value);
        void Insert(int index, WebApplication value);
        void Remove(WebApplication value);
        void RemoveAt(int index);

        bool IsFixedSize { get; }

        bool IsReadOnly { get; }

        WebApplication this[int index] { get; set; }
    }
}

