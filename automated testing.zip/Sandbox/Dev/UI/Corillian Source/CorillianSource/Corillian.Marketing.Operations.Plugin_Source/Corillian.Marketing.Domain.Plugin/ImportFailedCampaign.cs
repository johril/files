namespace Corillian.Marketing.Domain.Plugin
{
    using Corillian.Voyager.Common;
    using System;
    using System.Xml.Serialization;

    [Serializable, XmlRoot(Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", ElementName="ImportFailedCampaign"), XmlType(Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", TypeName="ImportFailedCampaign")]
    public class ImportFailedCampaign : IFormattable
    {
        private string _campaignguid;
        private string _campaignname;
        private string _errornumbers;

        public virtual string ToString(string format)
        {
            return FormattableObject.ToString(this, format, null);
        }

        public virtual string ToString(string format, IFormatProvider formatProvider)
        {
            if (format == null)
            {
                return base.ToString();
            }
            return FormattableObject.ToString(this, format, formatProvider);
        }

        [XmlElement(ElementName="CampaignGuid", Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", DataType="string")]
        public string CampaignGuid
        {
            get
            {
                return this._campaignguid;
            }
            set
            {
                this._campaignguid = value;
            }
        }

        [XmlElement(ElementName="CampaignName", Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", DataType="string")]
        public string CampaignName
        {
            get
            {
                return this._campaignname;
            }
            set
            {
                this._campaignname = value;
            }
        }

        [XmlElement(ElementName="ErrorNumbers", Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", DataType="string")]
        public string ErrorNumbers
        {
            get
            {
                return this._errornumbers;
            }
            set
            {
                this._errornumbers = value;
            }
        }
    }
}

