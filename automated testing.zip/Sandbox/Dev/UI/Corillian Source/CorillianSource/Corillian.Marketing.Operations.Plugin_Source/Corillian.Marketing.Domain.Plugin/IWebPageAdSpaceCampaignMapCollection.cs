namespace Corillian.Marketing.Domain.Plugin
{
    using System;

    public interface IWebPageAdSpaceCampaignMapCollection
    {
        void CopyTo(WebPageAdSpaceCampaignMap[] array, int arrayIndex);
        IWebPageAdSpaceCampaignMapEnumerator GetEnumerator();

        int Count { get; }

        bool IsSynchronized { get; }

        object SyncRoot { get; }
    }
}

