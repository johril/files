namespace Corillian.Marketing.Domain.Plugin
{
    using System;

    public interface IMcifImportTaskErrorEnumerator
    {
        bool MoveNext();
        void Reset();

        McifImportTaskError Current { get; }
    }
}

