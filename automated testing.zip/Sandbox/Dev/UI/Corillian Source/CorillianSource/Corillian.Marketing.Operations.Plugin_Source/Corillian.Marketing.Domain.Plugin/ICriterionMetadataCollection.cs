namespace Corillian.Marketing.Domain.Plugin
{
    using System;

    public interface ICriterionMetadataCollection
    {
        void CopyTo(CriterionMetadata[] array, int arrayIndex);
        ICriterionMetadataEnumerator GetEnumerator();

        int Count { get; }

        bool IsSynchronized { get; }

        object SyncRoot { get; }
    }
}

