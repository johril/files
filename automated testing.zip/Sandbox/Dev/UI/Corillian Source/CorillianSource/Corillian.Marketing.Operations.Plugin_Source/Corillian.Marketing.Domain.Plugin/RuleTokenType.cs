namespace Corillian.Marketing.Domain.Plugin
{
    using Corillian.Voyager.Common;
    using Corillian.Voyager.Common.Attributes;
    using System;
    using System.Xml.Serialization;

    [Serializable, XmlRoot(Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", ElementName="RuleTokenType"), XmlType(Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", TypeName="RuleTokenType")]
    public class RuleTokenType : IFormattable
    {
        private bool _enabled;
        private bool _local;
        private string _tokenname;
        private string _tokentypeclass;
        private int _tokentypeid;
        private string _tokentypesubclass;
        private string _tokentypevalue;
        [XmlIgnore, Ignore]
        public bool EnabledSpecified;
        [Ignore, XmlIgnore]
        public bool LocalSpecified;
        [Ignore, XmlIgnore]
        public bool TokenTypeIdSpecified;

        public virtual string ToString(string format)
        {
            return FormattableObject.ToString(this, format, null);
        }

        public virtual string ToString(string format, IFormatProvider formatProvider)
        {
            if (format == null)
            {
                return base.ToString();
            }
            return FormattableObject.ToString(this, format, formatProvider);
        }

        [XmlElement(ElementName="Enabled", Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", DataType="boolean")]
        public bool Enabled
        {
            get
            {
                return this._enabled;
            }
            set
            {
                this.EnabledSpecified = true;
                this._enabled = value;
            }
        }

        [XmlElement(ElementName="Local", Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", DataType="boolean")]
        public bool Local
        {
            get
            {
                return this._local;
            }
            set
            {
                this.LocalSpecified = true;
                this._local = value;
            }
        }

        [XmlElement(ElementName="TokenName", Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", DataType="string")]
        public string TokenName
        {
            get
            {
                return this._tokenname;
            }
            set
            {
                this._tokenname = value;
            }
        }

        [XmlElement(ElementName="TokenTypeClass", Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", DataType="string")]
        public string TokenTypeClass
        {
            get
            {
                return this._tokentypeclass;
            }
            set
            {
                this._tokentypeclass = value;
            }
        }

        [XmlElement(ElementName="TokenTypeId", Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", DataType="int")]
        public int TokenTypeId
        {
            get
            {
                return this._tokentypeid;
            }
            set
            {
                this.TokenTypeIdSpecified = true;
                this._tokentypeid = value;
            }
        }

        [XmlElement(ElementName="TokenTypeSubClass", Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", DataType="string")]
        public string TokenTypeSubClass
        {
            get
            {
                return this._tokentypesubclass;
            }
            set
            {
                this._tokentypesubclass = value;
            }
        }

        [XmlElement(ElementName="TokenTypeValue", Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", DataType="string")]
        public string TokenTypeValue
        {
            get
            {
                return this._tokentypevalue;
            }
            set
            {
                this._tokentypevalue = value;
            }
        }
    }
}

