namespace Corillian.Marketing.Domain.Plugin
{
    using Corillian.Voyager.Common;
    using System;
    using System.Xml.Serialization;

    [Serializable, XmlType(Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", TypeName="RuleInstanceComponentTokenBaseType"), XmlRoot(Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", ElementName="RuleInstanceComponentTokenBaseType")]
    public class RuleInstanceComponentTokenBaseType : IFormattable
    {
        private RuleInstanceComponentTokenCollection _ruleinstancecomponenttokens;

        public virtual string ToString(string format)
        {
            return FormattableObject.ToString(this, format, null);
        }

        public virtual string ToString(string format, IFormatProvider formatProvider)
        {
            if (format == null)
            {
                return base.ToString();
            }
            return FormattableObject.ToString(this, format, formatProvider);
        }

        [XmlElement(ElementName="RuleInstanceComponentToken", Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05")]
        public RuleInstanceComponentTokenCollection RuleInstanceComponentTokenList
        {
            get
            {
                return this._ruleinstancecomponenttokens;
            }
            set
            {
                this._ruleinstancecomponenttokens = value;
            }
        }
    }
}

