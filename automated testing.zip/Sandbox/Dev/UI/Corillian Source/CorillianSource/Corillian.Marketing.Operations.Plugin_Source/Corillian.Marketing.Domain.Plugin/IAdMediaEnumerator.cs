namespace Corillian.Marketing.Domain.Plugin
{
    using System;

    public interface IAdMediaEnumerator
    {
        bool MoveNext();
        void Reset();

        AdMedia Current { get; }
    }
}

