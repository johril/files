namespace Corillian.Marketing.Domain.Plugin
{
    using System;
    using System.Reflection;

    public interface IMcifImportTaskErrorList : IMcifImportTaskErrorCollection
    {
        int Add(McifImportTaskError value);
        void Clear();
        bool Contains(McifImportTaskError value);
        int IndexOf(McifImportTaskError value);
        void Insert(int index, McifImportTaskError value);
        void Remove(McifImportTaskError value);
        void RemoveAt(int index);

        bool IsFixedSize { get; }

        bool IsReadOnly { get; }

        McifImportTaskError this[int index] { get; set; }
    }
}

