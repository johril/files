namespace Corillian.Marketing.Domain.Plugin
{
    using System;

    public interface ICampaignContextMapEnumerator
    {
        bool MoveNext();
        void Reset();

        CampaignContextMap Current { get; }
    }
}

