namespace Corillian.Marketing.Domain.Plugin
{
    using System;

    public interface ICriterionDataTypeCollection
    {
        void CopyTo(CriterionDataType[] array, int arrayIndex);
        ICriterionDataTypeEnumerator GetEnumerator();

        int Count { get; }

        bool IsSynchronized { get; }

        object SyncRoot { get; }
    }
}

