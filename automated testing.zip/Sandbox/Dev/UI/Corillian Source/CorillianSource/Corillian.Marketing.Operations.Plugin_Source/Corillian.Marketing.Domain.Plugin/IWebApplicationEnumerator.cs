namespace Corillian.Marketing.Domain.Plugin
{
    using System;

    public interface IWebApplicationEnumerator
    {
        bool MoveNext();
        void Reset();

        WebApplication Current { get; }
    }
}

