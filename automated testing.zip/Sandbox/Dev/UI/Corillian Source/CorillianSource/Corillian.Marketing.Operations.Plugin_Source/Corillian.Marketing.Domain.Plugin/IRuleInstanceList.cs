namespace Corillian.Marketing.Domain.Plugin
{
    using System;
    using System.Reflection;

    public interface IRuleInstanceList : IRuleInstanceCollection
    {
        int Add(RuleInstance value);
        void Clear();
        bool Contains(RuleInstance value);
        int IndexOf(RuleInstance value);
        void Insert(int index, RuleInstance value);
        void Remove(RuleInstance value);
        void RemoveAt(int index);

        bool IsFixedSize { get; }

        bool IsReadOnly { get; }

        RuleInstance this[int index] { get; set; }
    }
}

