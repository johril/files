namespace Corillian.Marketing.Domain.Plugin
{
    using System;
    using System.Reflection;

    public interface IAdContentList : IAdContentCollection
    {
        int Add(AdContent value);
        void Clear();
        bool Contains(AdContent value);
        int IndexOf(AdContent value);
        void Insert(int index, AdContent value);
        void Remove(AdContent value);
        void RemoveAt(int index);

        bool IsFixedSize { get; }

        bool IsReadOnly { get; }

        AdContent this[int index] { get; set; }
    }
}

