namespace Corillian.Marketing.Domain.Plugin
{
    using System;

    public interface ICampaignImportTaskEnumerator
    {
        bool MoveNext();
        void Reset();

        CampaignImportTask Current { get; }
    }
}

