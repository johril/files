namespace Corillian.Marketing.Domain.Plugin
{
    using System;
    using System.Reflection;

    public interface ICampaignImportTaskList : ICampaignImportTaskCollection
    {
        int Add(CampaignImportTask value);
        void Clear();
        bool Contains(CampaignImportTask value);
        int IndexOf(CampaignImportTask value);
        void Insert(int index, CampaignImportTask value);
        void Remove(CampaignImportTask value);
        void RemoveAt(int index);

        bool IsFixedSize { get; }

        bool IsReadOnly { get; }

        CampaignImportTask this[int index] { get; set; }
    }
}

