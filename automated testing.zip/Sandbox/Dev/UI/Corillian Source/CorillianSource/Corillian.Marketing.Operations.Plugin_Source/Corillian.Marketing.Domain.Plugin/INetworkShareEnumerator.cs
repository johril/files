namespace Corillian.Marketing.Domain.Plugin
{
    using System;

    public interface INetworkShareEnumerator
    {
        bool MoveNext();
        void Reset();

        NetworkShare Current { get; }
    }
}

