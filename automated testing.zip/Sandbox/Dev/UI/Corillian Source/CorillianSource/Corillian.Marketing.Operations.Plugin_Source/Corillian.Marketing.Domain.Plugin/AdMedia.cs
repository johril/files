namespace Corillian.Marketing.Domain.Plugin
{
    using Corillian.Voyager.Common;
    using Corillian.Voyager.Common.Attributes;
    using System;
    using System.Xml.Serialization;

    [Serializable, XmlType(Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", TypeName="AdMedia"), XmlRoot(Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", ElementName="AdMedia")]
    public class AdMedia : IFormattable
    {
        private string _admediadescription;
        private string _admediaguid;
        private string _admedianame;
        private int _admediatype;
        private bool _deleted;
        private int _fiid;
        private string _filename;
        private bool _inuse;
        private string _mimetype;
        [Ignore, XmlIgnore]
        public bool AdMediaTypeSpecified;
        [XmlIgnore, Ignore]
        public bool DeletedSpecified;
        [XmlIgnore, Ignore]
        public bool FiidSpecified;
        [XmlIgnore, Ignore]
        public bool InUseSpecified;

        public virtual string ToString(string format)
        {
            return FormattableObject.ToString(this, format, null);
        }

        public virtual string ToString(string format, IFormatProvider formatProvider)
        {
            if (format == null)
            {
                return base.ToString();
            }
            return FormattableObject.ToString(this, format, formatProvider);
        }

        [XmlElement(ElementName="AdMediaDescription", Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", DataType="string")]
        public string AdMediaDescription
        {
            get
            {
                return this._admediadescription;
            }
            set
            {
                this._admediadescription = value;
            }
        }

        [XmlElement(ElementName="AdMediaGuid", Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", DataType="string")]
        public string AdMediaGuid
        {
            get
            {
                return this._admediaguid;
            }
            set
            {
                this._admediaguid = value;
            }
        }

        [XmlElement(ElementName="AdMediaName", Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", DataType="string")]
        public string AdMediaName
        {
            get
            {
                return this._admedianame;
            }
            set
            {
                this._admedianame = value;
            }
        }

        [XmlElement(ElementName="AdMediaType", Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", DataType="int")]
        public int AdMediaType
        {
            get
            {
                return this._admediatype;
            }
            set
            {
                this.AdMediaTypeSpecified = true;
                this._admediatype = value;
            }
        }

        [XmlElement(ElementName="Deleted", Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", DataType="boolean")]
        public bool Deleted
        {
            get
            {
                return this._deleted;
            }
            set
            {
                this.DeletedSpecified = true;
                this._deleted = value;
            }
        }

        [XmlElement(ElementName="Fiid", Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", DataType="int")]
        public int Fiid
        {
            get
            {
                return this._fiid;
            }
            set
            {
                this.FiidSpecified = true;
                this._fiid = value;
            }
        }

        [XmlElement(ElementName="FileName", Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", DataType="string")]
        public string FileName
        {
            get
            {
                return this._filename;
            }
            set
            {
                this._filename = value;
            }
        }

        [XmlElement(ElementName="InUse", Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", DataType="boolean")]
        public bool InUse
        {
            get
            {
                return this._inuse;
            }
            set
            {
                this.InUseSpecified = true;
                this._inuse = value;
            }
        }

        [XmlElement(ElementName="MimeType", Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", DataType="string")]
        public string MimeType
        {
            get
            {
                return this._mimetype;
            }
            set
            {
                this._mimetype = value;
            }
        }
    }
}

