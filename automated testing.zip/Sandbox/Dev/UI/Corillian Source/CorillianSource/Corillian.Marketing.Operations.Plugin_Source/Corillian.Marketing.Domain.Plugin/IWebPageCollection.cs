namespace Corillian.Marketing.Domain.Plugin
{
    using System;

    public interface IWebPageCollection
    {
        void CopyTo(WebPage[] array, int arrayIndex);
        IWebPageEnumerator GetEnumerator();

        int Count { get; }

        bool IsSynchronized { get; }

        object SyncRoot { get; }
    }
}

