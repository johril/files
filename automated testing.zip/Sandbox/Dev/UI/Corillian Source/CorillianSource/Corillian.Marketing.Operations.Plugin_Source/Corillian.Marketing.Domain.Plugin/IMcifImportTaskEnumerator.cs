namespace Corillian.Marketing.Domain.Plugin
{
    using System;

    public interface IMcifImportTaskEnumerator
    {
        bool MoveNext();
        void Reset();

        McifImportTask Current { get; }
    }
}

