namespace Corillian.Marketing.Domain.Plugin
{
    using System;

    public interface IRuleInstanceCollection
    {
        void CopyTo(RuleInstance[] array, int arrayIndex);
        IRuleInstanceEnumerator GetEnumerator();

        int Count { get; }

        bool IsSynchronized { get; }

        object SyncRoot { get; }
    }
}

