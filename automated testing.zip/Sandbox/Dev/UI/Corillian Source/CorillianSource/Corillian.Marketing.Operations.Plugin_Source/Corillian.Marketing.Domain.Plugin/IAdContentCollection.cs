namespace Corillian.Marketing.Domain.Plugin
{
    using System;

    public interface IAdContentCollection
    {
        void CopyTo(AdContent[] array, int arrayIndex);
        IAdContentEnumerator GetEnumerator();

        int Count { get; }

        bool IsSynchronized { get; }

        object SyncRoot { get; }
    }
}

