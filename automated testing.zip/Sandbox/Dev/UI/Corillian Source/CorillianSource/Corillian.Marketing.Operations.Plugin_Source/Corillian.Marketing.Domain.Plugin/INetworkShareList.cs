namespace Corillian.Marketing.Domain.Plugin
{
    using System;
    using System.Reflection;

    public interface INetworkShareList : INetworkShareCollection
    {
        int Add(NetworkShare value);
        void Clear();
        bool Contains(NetworkShare value);
        int IndexOf(NetworkShare value);
        void Insert(int index, NetworkShare value);
        void Remove(NetworkShare value);
        void RemoveAt(int index);

        bool IsFixedSize { get; }

        bool IsReadOnly { get; }

        NetworkShare this[int index] { get; set; }
    }
}

