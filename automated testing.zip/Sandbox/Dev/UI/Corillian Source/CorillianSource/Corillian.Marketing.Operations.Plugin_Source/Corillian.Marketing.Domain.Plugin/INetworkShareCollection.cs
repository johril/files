namespace Corillian.Marketing.Domain.Plugin
{
    using System;

    public interface INetworkShareCollection
    {
        void CopyTo(NetworkShare[] array, int arrayIndex);
        INetworkShareEnumerator GetEnumerator();

        int Count { get; }

        bool IsSynchronized { get; }

        object SyncRoot { get; }
    }
}

