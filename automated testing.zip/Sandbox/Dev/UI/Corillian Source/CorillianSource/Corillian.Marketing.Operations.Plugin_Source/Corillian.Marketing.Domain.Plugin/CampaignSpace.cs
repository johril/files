namespace Corillian.Marketing.Domain.Plugin
{
    using Corillian.Voyager.Common;
    using Corillian.Voyager.Common.Attributes;
    using System;
    using System.Xml.Serialization;

    [Serializable, XmlRoot(Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", ElementName="CampaignSpace"), XmlType(Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", TypeName="CampaignSpace")]
    public class CampaignSpace : IFormattable
    {
        private int _adspaceid;
        private string _adspacename;
        private string _campaigncontext;
        private string _pagename;
        [Ignore, XmlIgnore]
        public bool AdSpaceIdSpecified;

        public virtual string ToString(string format)
        {
            return FormattableObject.ToString(this, format, null);
        }

        public virtual string ToString(string format, IFormatProvider formatProvider)
        {
            if (format == null)
            {
                return base.ToString();
            }
            return FormattableObject.ToString(this, format, formatProvider);
        }

        [XmlElement(ElementName="AdSpaceId", Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", DataType="int")]
        public int AdSpaceId
        {
            get
            {
                return this._adspaceid;
            }
            set
            {
                this.AdSpaceIdSpecified = true;
                this._adspaceid = value;
            }
        }

        [XmlElement(ElementName="AdSpaceName", Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", DataType="string")]
        public string AdSpaceName
        {
            get
            {
                return this._adspacename;
            }
            set
            {
                this._adspacename = value;
            }
        }

        [XmlElement(ElementName="CampaignContext", Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", DataType="string")]
        public string CampaignContext
        {
            get
            {
                return this._campaigncontext;
            }
            set
            {
                this._campaigncontext = value;
            }
        }

        [XmlElement(ElementName="PageName", Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", DataType="string")]
        public string PageName
        {
            get
            {
                return this._pagename;
            }
            set
            {
                this._pagename = value;
            }
        }
    }
}

