namespace Corillian.Marketing.Domain.Plugin
{
    using Corillian.Voyager.Common;
    using Corillian.Voyager.Common.Attributes;
    using System;
    using System.Xml.Serialization;

    [Serializable, XmlType(Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", TypeName="TargetUrlDisplay"), XmlRoot(Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", ElementName="TargetUrlDisplay")]
    public class TargetUrlDisplay : IFormattable
    {
        private long _campaigncompositionid;
        private int _height;
        private string _targeturl;
        private long _targeturldisplayid;
        private int _width;
        private int _windowdisplaybitmask;
        [Ignore, XmlIgnore]
        public bool CampaignCompositionIdSpecified;
        [XmlIgnore, Ignore]
        public bool HeightSpecified;
        [Ignore, XmlIgnore]
        public bool TargetUrlDisplayIdSpecified;
        [Ignore, XmlIgnore]
        public bool WidthSpecified;
        [XmlIgnore, Ignore]
        public bool WindowDisplayBitMaskSpecified;

        public virtual string ToString(string format)
        {
            return FormattableObject.ToString(this, format, null);
        }

        public virtual string ToString(string format, IFormatProvider formatProvider)
        {
            if (format == null)
            {
                return base.ToString();
            }
            return FormattableObject.ToString(this, format, formatProvider);
        }

        [XmlElement(ElementName="CampaignCompositionId", Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", DataType="long")]
        public long CampaignCompositionId
        {
            get
            {
                return this._campaigncompositionid;
            }
            set
            {
                this.CampaignCompositionIdSpecified = true;
                this._campaigncompositionid = value;
            }
        }

        [XmlElement(ElementName="Height", Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", DataType="int")]
        public int Height
        {
            get
            {
                return this._height;
            }
            set
            {
                this.HeightSpecified = true;
                this._height = value;
            }
        }

        [XmlElement(ElementName="TargetUrl", Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", DataType="string")]
        public string TargetUrl
        {
            get
            {
                return this._targeturl;
            }
            set
            {
                this._targeturl = value;
            }
        }

        [XmlElement(ElementName="TargetUrlDisplayId", Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", DataType="long")]
        public long TargetUrlDisplayId
        {
            get
            {
                return this._targeturldisplayid;
            }
            set
            {
                this.TargetUrlDisplayIdSpecified = true;
                this._targeturldisplayid = value;
            }
        }

        [XmlElement(ElementName="Width", Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", DataType="int")]
        public int Width
        {
            get
            {
                return this._width;
            }
            set
            {
                this.WidthSpecified = true;
                this._width = value;
            }
        }

        [XmlElement(ElementName="WindowDisplayBitMask", Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", DataType="int")]
        public int WindowDisplayBitMask
        {
            get
            {
                return this._windowdisplaybitmask;
            }
            set
            {
                this.WindowDisplayBitMaskSpecified = true;
                this._windowdisplaybitmask = value;
            }
        }
    }
}

