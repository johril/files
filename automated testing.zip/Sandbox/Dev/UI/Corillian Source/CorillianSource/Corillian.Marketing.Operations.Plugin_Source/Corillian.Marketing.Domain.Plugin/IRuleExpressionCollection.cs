namespace Corillian.Marketing.Domain.Plugin
{
    using System;

    public interface IRuleExpressionCollection
    {
        void CopyTo(RuleExpression[] array, int arrayIndex);
        IRuleExpressionEnumerator GetEnumerator();

        int Count { get; }

        bool IsSynchronized { get; }

        object SyncRoot { get; }
    }
}

