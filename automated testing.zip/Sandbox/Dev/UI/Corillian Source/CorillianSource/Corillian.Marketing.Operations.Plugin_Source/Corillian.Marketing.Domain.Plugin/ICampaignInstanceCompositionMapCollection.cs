namespace Corillian.Marketing.Domain.Plugin
{
    using System;

    public interface ICampaignInstanceCompositionMapCollection
    {
        void CopyTo(CampaignInstanceCompositionMap[] array, int arrayIndex);
        ICampaignInstanceCompositionMapEnumerator GetEnumerator();

        int Count { get; }

        bool IsSynchronized { get; }

        object SyncRoot { get; }
    }
}

