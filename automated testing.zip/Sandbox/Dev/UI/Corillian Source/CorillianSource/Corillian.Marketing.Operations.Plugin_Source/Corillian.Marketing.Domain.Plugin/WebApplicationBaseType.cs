namespace Corillian.Marketing.Domain.Plugin
{
    using Corillian.Voyager.Common;
    using System;
    using System.Xml.Serialization;

    [Serializable, XmlType(Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", TypeName="WebApplicationBaseType"), XmlRoot(Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", ElementName="WebApplicationBaseType")]
    public class WebApplicationBaseType : IFormattable
    {
        private WebApplicationCollection _webapplications;

        public virtual string ToString(string format)
        {
            return FormattableObject.ToString(this, format, null);
        }

        public virtual string ToString(string format, IFormatProvider formatProvider)
        {
            if (format == null)
            {
                return base.ToString();
            }
            return FormattableObject.ToString(this, format, formatProvider);
        }

        [XmlElement(ElementName="WebApplication", Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05")]
        public WebApplicationCollection WebApplicationList
        {
            get
            {
                return this._webapplications;
            }
            set
            {
                this._webapplications = value;
            }
        }
    }
}

