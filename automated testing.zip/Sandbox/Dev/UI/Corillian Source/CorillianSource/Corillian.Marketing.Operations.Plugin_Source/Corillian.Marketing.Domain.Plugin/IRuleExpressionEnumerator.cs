namespace Corillian.Marketing.Domain.Plugin
{
    using System;

    public interface IRuleExpressionEnumerator
    {
        bool MoveNext();
        void Reset();

        RuleExpression Current { get; }
    }
}

