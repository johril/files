namespace Corillian.Marketing.Domain.Plugin
{
    using System;

    public interface IMcifImportTaskErrorCollection
    {
        void CopyTo(McifImportTaskError[] array, int arrayIndex);
        IMcifImportTaskErrorEnumerator GetEnumerator();

        int Count { get; }

        bool IsSynchronized { get; }

        object SyncRoot { get; }
    }
}

