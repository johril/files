namespace Corillian.Marketing.Domain.Plugin
{
    using Corillian.Voyager.Common;
    using System;
    using System.Xml.Serialization;

    [Serializable, XmlType(Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", TypeName="AdSpaceBaseType"), XmlRoot(Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", ElementName="AdSpaceBaseType")]
    public class AdSpaceBaseType : IFormattable
    {
        private AdSpaceCollection _adspaces;

        public virtual string ToString(string format)
        {
            return FormattableObject.ToString(this, format, null);
        }

        public virtual string ToString(string format, IFormatProvider formatProvider)
        {
            if (format == null)
            {
                return base.ToString();
            }
            return FormattableObject.ToString(this, format, formatProvider);
        }

        [XmlElement(ElementName="AdSpace", Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05")]
        public AdSpaceCollection AdSpaceList
        {
            get
            {
                return this._adspaces;
            }
            set
            {
                this._adspaces = value;
            }
        }
    }
}

