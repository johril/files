namespace Corillian.Marketing.Domain.Plugin
{
    using Corillian.Voyager.Common;
    using Corillian.Voyager.Common.Attributes;
    using System;
    using System.Xml.Serialization;

    [Serializable, XmlType(Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", TypeName="CriterionDataType"), XmlRoot(Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", ElementName="CriterionDataType")]
    public class CriterionDataType : IFormattable
    {
        private string _criteriondatatypedescription;
        private int _criteriondatatypeid;
        private string _criteriondatatypename;
        [XmlIgnore, Ignore]
        public bool CriterionDataTypeIdSpecified;

        public virtual string ToString(string format)
        {
            return FormattableObject.ToString(this, format, null);
        }

        public virtual string ToString(string format, IFormatProvider formatProvider)
        {
            if (format == null)
            {
                return base.ToString();
            }
            return FormattableObject.ToString(this, format, formatProvider);
        }

        [XmlElement(ElementName="CriterionDataTypeDescription", Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", DataType="string")]
        public string CriterionDataTypeDescription
        {
            get
            {
                return this._criteriondatatypedescription;
            }
            set
            {
                this._criteriondatatypedescription = value;
            }
        }

        [XmlElement(ElementName="CriterionDataTypeId", Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", DataType="int")]
        public int CriterionDataTypeId
        {
            get
            {
                return this._criteriondatatypeid;
            }
            set
            {
                this.CriterionDataTypeIdSpecified = true;
                this._criteriondatatypeid = value;
            }
        }

        [XmlElement(ElementName="CriterionDataTypeName", Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", DataType="string")]
        public string CriterionDataTypeName
        {
            get
            {
                return this._criteriondatatypename;
            }
            set
            {
                this._criteriondatatypename = value;
            }
        }
    }
}

