namespace Corillian.Marketing.Domain.Plugin
{
    using Corillian.Voyager.Common;
    using Corillian.Voyager.Common.Attributes;
    using System;
    using System.Xml.Serialization;

    [Serializable, XmlType(Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", TypeName="CampaignType"), XmlRoot(Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", ElementName="CampaignType")]
    public class CampaignType : IFormattable
    {
        private string _campaigntypedescription;
        private int _campaigntypeid;
        private string _campaigntypename;
        [Ignore, XmlIgnore]
        public bool CampaignTypeIdSpecified;

        public virtual string ToString(string format)
        {
            return FormattableObject.ToString(this, format, null);
        }

        public virtual string ToString(string format, IFormatProvider formatProvider)
        {
            if (format == null)
            {
                return base.ToString();
            }
            return FormattableObject.ToString(this, format, formatProvider);
        }

        [XmlElement(ElementName="CampaignTypeDescription", Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", DataType="string")]
        public string CampaignTypeDescription
        {
            get
            {
                return this._campaigntypedescription;
            }
            set
            {
                this._campaigntypedescription = value;
            }
        }

        [XmlElement(ElementName="CampaignTypeId", Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", DataType="int")]
        public int CampaignTypeId
        {
            get
            {
                return this._campaigntypeid;
            }
            set
            {
                this.CampaignTypeIdSpecified = true;
                this._campaigntypeid = value;
            }
        }

        [XmlElement(ElementName="CampaignTypeName", Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", DataType="string")]
        public string CampaignTypeName
        {
            get
            {
                return this._campaigntypename;
            }
            set
            {
                this._campaigntypename = value;
            }
        }
    }
}

