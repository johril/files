namespace Corillian.Marketing.Domain.Plugin
{
    using System;
    using System.Reflection;

    public interface IRuleTokenTypeList : IRuleTokenTypeCollection
    {
        int Add(RuleTokenType value);
        void Clear();
        bool Contains(RuleTokenType value);
        int IndexOf(RuleTokenType value);
        void Insert(int index, RuleTokenType value);
        void Remove(RuleTokenType value);
        void RemoveAt(int index);

        bool IsFixedSize { get; }

        bool IsReadOnly { get; }

        RuleTokenType this[int index] { get; set; }
    }
}

