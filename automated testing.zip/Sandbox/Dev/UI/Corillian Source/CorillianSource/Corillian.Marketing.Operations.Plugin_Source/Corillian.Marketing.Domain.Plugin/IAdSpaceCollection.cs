namespace Corillian.Marketing.Domain.Plugin
{
    using System;

    public interface IAdSpaceCollection
    {
        void CopyTo(AdSpace[] array, int arrayIndex);
        IAdSpaceEnumerator GetEnumerator();

        int Count { get; }

        bool IsSynchronized { get; }

        object SyncRoot { get; }
    }
}

