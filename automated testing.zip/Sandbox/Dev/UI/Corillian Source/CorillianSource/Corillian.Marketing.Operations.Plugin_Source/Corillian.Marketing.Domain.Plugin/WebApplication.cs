namespace Corillian.Marketing.Domain.Plugin
{
    using Corillian.Voyager.Common;
    using Corillian.Voyager.Common.Attributes;
    using System;
    using System.Xml.Serialization;

    [Serializable, XmlRoot(Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", ElementName="WebApplication"), XmlType(Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", TypeName="WebApplication")]
    public class WebApplication : IFormattable
    {
        private bool _active;
        private int _fiid;
        private int _version;
        private string _webapplicationdescription;
        private int _webapplicationid;
        private string _webapplicationname;
        private int _webapplicationnamechecksum;
        [XmlIgnore, Ignore]
        public bool ActiveSpecified;
        [XmlIgnore, Ignore]
        public bool FiidSpecified;
        [XmlIgnore, Ignore]
        public bool VersionSpecified;
        [Ignore, XmlIgnore]
        public bool WebApplicationIdSpecified;
        [Ignore, XmlIgnore]
        public bool WebApplicationNameCheckSumSpecified;

        public virtual string ToString(string format)
        {
            return FormattableObject.ToString(this, format, null);
        }

        public virtual string ToString(string format, IFormatProvider formatProvider)
        {
            if (format == null)
            {
                return base.ToString();
            }
            return FormattableObject.ToString(this, format, formatProvider);
        }

        [XmlElement(ElementName="Active", Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", DataType="boolean")]
        public bool Active
        {
            get
            {
                return this._active;
            }
            set
            {
                this.ActiveSpecified = true;
                this._active = value;
            }
        }

        [XmlElement(ElementName="Fiid", Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", DataType="int")]
        public int Fiid
        {
            get
            {
                return this._fiid;
            }
            set
            {
                this.FiidSpecified = true;
                this._fiid = value;
            }
        }

        [XmlElement(ElementName="Version", Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", DataType="int")]
        public int Version
        {
            get
            {
                return this._version;
            }
            set
            {
                this.VersionSpecified = true;
                this._version = value;
            }
        }

        [XmlElement(ElementName="WebApplicationDescription", Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", DataType="string")]
        public string WebApplicationDescription
        {
            get
            {
                return this._webapplicationdescription;
            }
            set
            {
                this._webapplicationdescription = value;
            }
        }

        [XmlElement(ElementName="WebApplicationId", Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", DataType="int")]
        public int WebApplicationId
        {
            get
            {
                return this._webapplicationid;
            }
            set
            {
                this.WebApplicationIdSpecified = true;
                this._webapplicationid = value;
            }
        }

        [XmlElement(ElementName="WebApplicationName", Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", DataType="string")]
        public string WebApplicationName
        {
            get
            {
                return this._webapplicationname;
            }
            set
            {
                this._webapplicationname = value;
            }
        }

        [XmlElement(ElementName="WebApplicationNameCheckSum", Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", DataType="int")]
        public int WebApplicationNameCheckSum
        {
            get
            {
                return this._webapplicationnamechecksum;
            }
            set
            {
                this.WebApplicationNameCheckSumSpecified = true;
                this._webapplicationnamechecksum = value;
            }
        }
    }
}

