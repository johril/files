namespace Corillian.Marketing.Domain.Plugin
{
    using Corillian.Voyager.Common;
    using System;
    using System.Xml.Serialization;

    [Serializable, XmlRoot(Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", ElementName="WebPageBaseType"), XmlType(Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", TypeName="WebPageBaseType")]
    public class WebPageBaseType : IFormattable
    {
        private WebPageCollection _webpages;

        public virtual string ToString(string format)
        {
            return FormattableObject.ToString(this, format, null);
        }

        public virtual string ToString(string format, IFormatProvider formatProvider)
        {
            if (format == null)
            {
                return base.ToString();
            }
            return FormattableObject.ToString(this, format, formatProvider);
        }

        [XmlElement(ElementName="WebPage", Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05")]
        public WebPageCollection WebPageList
        {
            get
            {
                return this._webpages;
            }
            set
            {
                this._webpages = value;
            }
        }
    }
}

