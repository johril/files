namespace Corillian.Marketing.Domain.Plugin
{
    using System;
    using System.Reflection;

    public interface ICampaignList : ICampaignCollection
    {
        int Add(Campaign value);
        void Clear();
        bool Contains(Campaign value);
        int IndexOf(Campaign value);
        void Insert(int index, Campaign value);
        void Remove(Campaign value);
        void RemoveAt(int index);

        bool IsFixedSize { get; }

        bool IsReadOnly { get; }

        Campaign this[int index] { get; set; }
    }
}

