namespace Corillian.Marketing.Domain.Plugin
{
    using Corillian.Voyager.Common;
    using Corillian.Voyager.Common.Attributes;
    using System;
    using System.Xml.Serialization;

    [Serializable, XmlRoot(Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", ElementName="CriterionMetadata"), XmlType(Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", TypeName="CriterionMetadata")]
    public class CriterionMetadata : IFormattable
    {
        private string _createdby;
        private DateTime _createddate;
        private string _criteriondescription;
        private string _criterionmetadataguid;
        private int _criterionmetadataid;
        private string _criterionname;
        private CriterionDataType _datatype;
        private bool _deleted;
        private int _fiid;
        private bool _intrinsicflag;
        private bool _inuse;
        private string _modifiedby;
        private DateTime _modifydate;
        private bool _newinimport;
        [XmlIgnore, Ignore]
        public bool CreatedDateSpecified;
        [Ignore, XmlIgnore]
        public bool CriterionMetadataIdSpecified;
        [XmlIgnore, Ignore]
        public bool DeletedSpecified;
        [XmlIgnore, Ignore]
        public bool FiidSpecified;
        [Ignore, XmlIgnore]
        public bool IntrinsicFlagSpecified;
        [Ignore, XmlIgnore]
        public bool InUseSpecified;
        [XmlIgnore, Ignore]
        public bool ModifyDateSpecified;
        [XmlIgnore, Ignore]
        public bool NewInImportSpecified;

        public virtual string ToString(string format)
        {
            return FormattableObject.ToString(this, format, null);
        }

        public virtual string ToString(string format, IFormatProvider formatProvider)
        {
            if (format == null)
            {
                return base.ToString();
            }
            return FormattableObject.ToString(this, format, formatProvider);
        }

        [XmlElement(ElementName="CreatedBy", Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", DataType="string")]
        public string CreatedBy
        {
            get
            {
                return this._createdby;
            }
            set
            {
                this._createdby = value;
            }
        }

        [XmlElement(ElementName="CreatedDate", Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", DataType="dateTime")]
        public DateTime CreatedDate
        {
            get
            {
                return this._createddate;
            }
            set
            {
                this.CreatedDateSpecified = true;
                this._createddate = value;
            }
        }

        [XmlElement(ElementName="CriterionDescription", Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", DataType="string")]
        public string CriterionDescription
        {
            get
            {
                return this._criteriondescription;
            }
            set
            {
                this._criteriondescription = value;
            }
        }

        [XmlElement(ElementName="CriterionMetadataGuid", Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", DataType="string")]
        public string CriterionMetadataGuid
        {
            get
            {
                return this._criterionmetadataguid;
            }
            set
            {
                this._criterionmetadataguid = value;
            }
        }

        [XmlElement(ElementName="CriterionMetadataId", Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", DataType="int")]
        public int CriterionMetadataId
        {
            get
            {
                return this._criterionmetadataid;
            }
            set
            {
                this.CriterionMetadataIdSpecified = true;
                this._criterionmetadataid = value;
            }
        }

        [XmlElement(ElementName="CriterionName", Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", DataType="string")]
        public string CriterionName
        {
            get
            {
                return this._criterionname;
            }
            set
            {
                this._criterionname = value;
            }
        }

        [XmlElement(ElementName="DataType", Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05")]
        public CriterionDataType DataType
        {
            get
            {
                return this._datatype;
            }
            set
            {
                this._datatype = value;
            }
        }

        [XmlElement(ElementName="Deleted", Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", DataType="boolean")]
        public bool Deleted
        {
            get
            {
                return this._deleted;
            }
            set
            {
                this.DeletedSpecified = true;
                this._deleted = value;
            }
        }

        [XmlElement(ElementName="Fiid", Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", DataType="int")]
        public int Fiid
        {
            get
            {
                return this._fiid;
            }
            set
            {
                this.FiidSpecified = true;
                this._fiid = value;
            }
        }

        [XmlElement(ElementName="IntrinsicFlag", Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", DataType="boolean")]
        public bool IntrinsicFlag
        {
            get
            {
                return this._intrinsicflag;
            }
            set
            {
                this.IntrinsicFlagSpecified = true;
                this._intrinsicflag = value;
            }
        }

        [XmlElement(ElementName="InUse", Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", DataType="boolean")]
        public bool InUse
        {
            get
            {
                return this._inuse;
            }
            set
            {
                this.InUseSpecified = true;
                this._inuse = value;
            }
        }

        [XmlElement(ElementName="ModifiedBy", Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", DataType="string")]
        public string ModifiedBy
        {
            get
            {
                return this._modifiedby;
            }
            set
            {
                this._modifiedby = value;
            }
        }

        [XmlElement(ElementName="ModifyDate", Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", DataType="dateTime")]
        public DateTime ModifyDate
        {
            get
            {
                return this._modifydate;
            }
            set
            {
                this.ModifyDateSpecified = true;
                this._modifydate = value;
            }
        }

        [XmlElement(ElementName="NewInImport", Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", DataType="boolean")]
        public bool NewInImport
        {
            get
            {
                return this._newinimport;
            }
            set
            {
                this.NewInImportSpecified = true;
                this._newinimport = value;
            }
        }
    }
}

