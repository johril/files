namespace Corillian.Marketing.Domain.Plugin
{
    using Corillian.Voyager.Common;
    using Corillian.Voyager.Common.Attributes;
    using System;
    using System.Xml.Serialization;

    [Serializable, XmlType(Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", TypeName="CustomerCriterion"), XmlRoot(Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", ElementName="CustomerCriterion")]
    public class CustomerCriterion : IFormattable
    {
        private bool _campaignflag;
        private string _criteriondatatype;
        private int _criteriondatatypeid;
        private string _criterionmetadataguid;
        private int _criterionmetadataid;
        private string _criterionname;
        private long _customerid;
        private long _customeridmodulo;
        private DateTime _daterefreshed;
        private long _id;
        private bool _intrinsicflag;
        private string _keyvalue;
        [XmlIgnore, Ignore]
        public bool CampaignFlagSpecified;
        [XmlIgnore, Ignore]
        public bool CriterionDataTypeIdSpecified;
        [Ignore, XmlIgnore]
        public bool CriterionMetaDataIdSpecified;
        [Ignore, XmlIgnore]
        public bool CustomerIDModuloSpecified;
        [XmlIgnore, Ignore]
        public bool CustomerIdSpecified;
        [XmlIgnore, Ignore]
        public bool DateRefreshedSpecified;
        [Ignore, XmlIgnore]
        public bool IdSpecified;
        [XmlIgnore, Ignore]
        public bool IntrinsicFlagSpecified;

        public virtual string ToString(string format)
        {
            return FormattableObject.ToString(this, format, null);
        }

        public virtual string ToString(string format, IFormatProvider formatProvider)
        {
            if (format == null)
            {
                return base.ToString();
            }
            return FormattableObject.ToString(this, format, formatProvider);
        }

        [XmlElement(ElementName="CampaignFlag", Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", DataType="boolean")]
        public bool CampaignFlag
        {
            get
            {
                return this._campaignflag;
            }
            set
            {
                this.CampaignFlagSpecified = true;
                this._campaignflag = value;
            }
        }

        [XmlElement(ElementName="CriterionDataType", Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", DataType="string")]
        public string CriterionDataType
        {
            get
            {
                return this._criteriondatatype;
            }
            set
            {
                this._criteriondatatype = value;
            }
        }

        [XmlElement(ElementName="CriterionDataTypeId", Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", DataType="int")]
        public int CriterionDataTypeId
        {
            get
            {
                return this._criteriondatatypeid;
            }
            set
            {
                this.CriterionDataTypeIdSpecified = true;
                this._criteriondatatypeid = value;
            }
        }

        [XmlElement(ElementName="CriterionMetaDataGuid", Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", DataType="string")]
        public string CriterionMetaDataGuid
        {
            get
            {
                return this._criterionmetadataguid;
            }
            set
            {
                this._criterionmetadataguid = value;
            }
        }

        [XmlElement(ElementName="CriterionMetaDataId", Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", DataType="int")]
        public int CriterionMetaDataId
        {
            get
            {
                return this._criterionmetadataid;
            }
            set
            {
                this.CriterionMetaDataIdSpecified = true;
                this._criterionmetadataid = value;
            }
        }

        [XmlElement(ElementName="CriterionName", Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", DataType="string")]
        public string CriterionName
        {
            get
            {
                return this._criterionname;
            }
            set
            {
                this._criterionname = value;
            }
        }

        [XmlElement(ElementName="CustomerId", Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", DataType="long")]
        public long CustomerId
        {
            get
            {
                return this._customerid;
            }
            set
            {
                this.CustomerIdSpecified = true;
                this._customerid = value;
            }
        }

        [XmlElement(ElementName="CustomerIDModulo", Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", DataType="long")]
        public long CustomerIDModulo
        {
            get
            {
                return this._customeridmodulo;
            }
            set
            {
                this.CustomerIDModuloSpecified = true;
                this._customeridmodulo = value;
            }
        }

        [XmlElement(ElementName="DateRefreshed", Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", DataType="date")]
        public DateTime DateRefreshed
        {
            get
            {
                return this._daterefreshed;
            }
            set
            {
                this.DateRefreshedSpecified = true;
                this._daterefreshed = value;
            }
        }

        [XmlElement(ElementName="Id", Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", DataType="long")]
        public long Id
        {
            get
            {
                return this._id;
            }
            set
            {
                this.IdSpecified = true;
                this._id = value;
            }
        }

        [XmlElement(ElementName="IntrinsicFlag", Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", DataType="boolean")]
        public bool IntrinsicFlag
        {
            get
            {
                return this._intrinsicflag;
            }
            set
            {
                this.IntrinsicFlagSpecified = true;
                this._intrinsicflag = value;
            }
        }

        [XmlElement(ElementName="KeyValue", Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", DataType="string")]
        public string KeyValue
        {
            get
            {
                return this._keyvalue;
            }
            set
            {
                this._keyvalue = value;
            }
        }
    }
}

