namespace Corillian.Marketing.Domain.Plugin
{
    using System;

    public interface ICachedCriterionCollection
    {
        void CopyTo(CachedCriterion[] array, int arrayIndex);
        ICachedCriterionEnumerator GetEnumerator();

        int Count { get; }

        bool IsSynchronized { get; }

        object SyncRoot { get; }
    }
}

