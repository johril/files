namespace Corillian.Marketing.Domain.Plugin
{
    using System;

    public interface IRuleEnumerator
    {
        bool MoveNext();
        void Reset();

        Rule Current { get; }
    }
}

