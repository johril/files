namespace Corillian.Marketing.Domain.Plugin
{
    using System;
    using System.Reflection;

    public interface ICampaignInstanceCompositionMapList : ICampaignInstanceCompositionMapCollection
    {
        int Add(CampaignInstanceCompositionMap value);
        void Clear();
        bool Contains(CampaignInstanceCompositionMap value);
        int IndexOf(CampaignInstanceCompositionMap value);
        void Insert(int index, CampaignInstanceCompositionMap value);
        void Remove(CampaignInstanceCompositionMap value);
        void RemoveAt(int index);

        bool IsFixedSize { get; }

        bool IsReadOnly { get; }

        CampaignInstanceCompositionMap this[int index] { get; set; }
    }
}

