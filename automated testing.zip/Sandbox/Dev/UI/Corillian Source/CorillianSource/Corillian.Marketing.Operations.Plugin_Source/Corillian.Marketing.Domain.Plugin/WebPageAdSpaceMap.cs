namespace Corillian.Marketing.Domain.Plugin
{
    using Corillian.Voyager.Common;
    using Corillian.Voyager.Common.Attributes;
    using System;
    using System.Xml.Serialization;

    [Serializable, XmlType(Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", TypeName="WebPageAdSpaceMap"), XmlRoot(Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", ElementName="WebPageAdSpaceMap")]
    public class WebPageAdSpaceMap : IFormattable
    {
        private int _adspaceid;
        private long _pagespacemapid;
        private int _webpageid;
        [Ignore, XmlIgnore]
        public bool AdSpaceIdSpecified;
        [XmlIgnore, Ignore]
        public bool PageSpaceMapIdSpecified;
        [Ignore, XmlIgnore]
        public bool WebPageIDSpecified;

        public virtual string ToString(string format)
        {
            return FormattableObject.ToString(this, format, null);
        }

        public virtual string ToString(string format, IFormatProvider formatProvider)
        {
            if (format == null)
            {
                return base.ToString();
            }
            return FormattableObject.ToString(this, format, formatProvider);
        }

        [XmlElement(ElementName="AdSpaceId", Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", DataType="int")]
        public int AdSpaceId
        {
            get
            {
                return this._adspaceid;
            }
            set
            {
                this.AdSpaceIdSpecified = true;
                this._adspaceid = value;
            }
        }

        [XmlElement(ElementName="PageSpaceMapId", Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", DataType="long")]
        public long PageSpaceMapId
        {
            get
            {
                return this._pagespacemapid;
            }
            set
            {
                this.PageSpaceMapIdSpecified = true;
                this._pagespacemapid = value;
            }
        }

        [XmlElement(ElementName="WebPageID", Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", DataType="int")]
        public int WebPageID
        {
            get
            {
                return this._webpageid;
            }
            set
            {
                this.WebPageIDSpecified = true;
                this._webpageid = value;
            }
        }
    }
}

