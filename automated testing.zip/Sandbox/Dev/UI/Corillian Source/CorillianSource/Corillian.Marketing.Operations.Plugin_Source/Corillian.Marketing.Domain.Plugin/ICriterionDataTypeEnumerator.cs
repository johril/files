namespace Corillian.Marketing.Domain.Plugin
{
    using System;

    public interface ICriterionDataTypeEnumerator
    {
        bool MoveNext();
        void Reset();

        CriterionDataType Current { get; }
    }
}

