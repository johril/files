namespace Corillian.Marketing.Domain.Plugin
{
    using Corillian.Voyager.Common;
    using System;
    using System.Xml.Serialization;

    [Serializable, XmlType(Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", TypeName="RuleTokenTypeBaseType"), XmlRoot(Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", ElementName="RuleTokenTypeBaseType")]
    public class RuleTokenTypeBaseType : IFormattable
    {
        private RuleTokenTypeCollection _ruletokentypes;

        public virtual string ToString(string format)
        {
            return FormattableObject.ToString(this, format, null);
        }

        public virtual string ToString(string format, IFormatProvider formatProvider)
        {
            if (format == null)
            {
                return base.ToString();
            }
            return FormattableObject.ToString(this, format, formatProvider);
        }

        [XmlElement(ElementName="RuleTokenType", Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05")]
        public RuleTokenTypeCollection RuleTokenTypeList
        {
            get
            {
                return this._ruletokentypes;
            }
            set
            {
                this._ruletokentypes = value;
            }
        }
    }
}

