namespace Corillian.Marketing.Domain.Plugin
{
    using System;
    using System.Reflection;

    public interface IAdSpaceList : IAdSpaceCollection
    {
        int Add(AdSpace value);
        void Clear();
        bool Contains(AdSpace value);
        int IndexOf(AdSpace value);
        void Insert(int index, AdSpace value);
        void Remove(AdSpace value);
        void RemoveAt(int index);

        bool IsFixedSize { get; }

        bool IsReadOnly { get; }

        AdSpace this[int index] { get; set; }
    }
}

