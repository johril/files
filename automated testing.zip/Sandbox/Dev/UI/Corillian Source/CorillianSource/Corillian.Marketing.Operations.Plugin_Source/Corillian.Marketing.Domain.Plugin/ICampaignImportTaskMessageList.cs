namespace Corillian.Marketing.Domain.Plugin
{
    using System;
    using System.Reflection;

    public interface ICampaignImportTaskMessageList : ICampaignImportTaskMessageCollection
    {
        int Add(CampaignImportTaskMessage value);
        void Clear();
        bool Contains(CampaignImportTaskMessage value);
        int IndexOf(CampaignImportTaskMessage value);
        void Insert(int index, CampaignImportTaskMessage value);
        void Remove(CampaignImportTaskMessage value);
        void RemoveAt(int index);

        bool IsFixedSize { get; }

        bool IsReadOnly { get; }

        CampaignImportTaskMessage this[int index] { get; set; }
    }
}

