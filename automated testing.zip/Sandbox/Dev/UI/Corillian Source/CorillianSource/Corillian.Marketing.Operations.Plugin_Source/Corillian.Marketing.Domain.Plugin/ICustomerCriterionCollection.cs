namespace Corillian.Marketing.Domain.Plugin
{
    using System;

    public interface ICustomerCriterionCollection
    {
        void CopyTo(CustomerCriterion[] array, int arrayIndex);
        ICustomerCriterionEnumerator GetEnumerator();

        int Count { get; }

        bool IsSynchronized { get; }

        object SyncRoot { get; }
    }
}

