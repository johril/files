namespace Corillian.Marketing.Domain.Plugin
{
    using System;

    public interface IMcifImportTaskCollection
    {
        void CopyTo(McifImportTask[] array, int arrayIndex);
        IMcifImportTaskEnumerator GetEnumerator();

        int Count { get; }

        bool IsSynchronized { get; }

        object SyncRoot { get; }
    }
}

