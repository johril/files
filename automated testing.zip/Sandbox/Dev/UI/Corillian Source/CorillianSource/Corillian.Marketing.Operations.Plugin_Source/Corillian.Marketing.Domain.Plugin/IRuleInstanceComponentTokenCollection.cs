namespace Corillian.Marketing.Domain.Plugin
{
    using System;

    public interface IRuleInstanceComponentTokenCollection
    {
        void CopyTo(RuleInstanceComponentToken[] array, int arrayIndex);
        IRuleInstanceComponentTokenEnumerator GetEnumerator();

        int Count { get; }

        bool IsSynchronized { get; }

        object SyncRoot { get; }
    }
}

