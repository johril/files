namespace Corillian.Marketing.Domain.Plugin
{
    using Corillian.Voyager.Common;
    using Corillian.Voyager.Common.Attributes;
    using System;
    using System.Xml.Serialization;

    [Serializable, XmlRoot(Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", ElementName="NetworkShare"), XmlType(Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", TypeName="NetworkShare")]
    public class NetworkShare : IFormattable
    {
        private int _fiid;
        private int _shareid;
        private string _sharename;
        private string _sharepath;
        [Ignore, XmlIgnore]
        public bool FiidSpecified;
        [Ignore, XmlIgnore]
        public bool ShareIdSpecified;

        public virtual string ToString(string format)
        {
            return FormattableObject.ToString(this, format, null);
        }

        public virtual string ToString(string format, IFormatProvider formatProvider)
        {
            if (format == null)
            {
                return base.ToString();
            }
            return FormattableObject.ToString(this, format, formatProvider);
        }

        [XmlElement(ElementName="Fiid", Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", DataType="int")]
        public int Fiid
        {
            get
            {
                return this._fiid;
            }
            set
            {
                this.FiidSpecified = true;
                this._fiid = value;
            }
        }

        [XmlElement(ElementName="ShareId", Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", DataType="int")]
        public int ShareId
        {
            get
            {
                return this._shareid;
            }
            set
            {
                this.ShareIdSpecified = true;
                this._shareid = value;
            }
        }

        [XmlElement(ElementName="ShareName", Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", DataType="string")]
        public string ShareName
        {
            get
            {
                return this._sharename;
            }
            set
            {
                this._sharename = value;
            }
        }

        [XmlElement(ElementName="SharePath", Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", DataType="string")]
        public string SharePath
        {
            get
            {
                return this._sharepath;
            }
            set
            {
                this._sharepath = value;
            }
        }
    }
}

