namespace Corillian.Marketing.Domain.Plugin
{
    using Corillian.Voyager.Common;
    using Corillian.Voyager.Common.Attributes;
    using System;
    using System.Xml.Serialization;

    [Serializable, XmlRoot(Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", ElementName="RuleInstanceComponentToken"), XmlType(Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", TypeName="RuleInstanceComponentToken")]
    public class RuleInstanceComponentToken : IFormattable
    {
        private string _componenttokenpointerguid;
        private string _ruleguid;
        private string _ruleinstanceguid;
        private Corillian.Marketing.Domain.Plugin.RuleTokenType _ruletokentype;
        private short _sequenceid;
        private string _token;
        private int _tokenchecksum;
        [Ignore, XmlIgnore]
        public bool SequenceIdSpecified;
        [XmlIgnore, Ignore]
        public bool TokenCheckSumSpecified;

        public virtual string ToString(string format)
        {
            return FormattableObject.ToString(this, format, null);
        }

        public virtual string ToString(string format, IFormatProvider formatProvider)
        {
            if (format == null)
            {
                return base.ToString();
            }
            return FormattableObject.ToString(this, format, formatProvider);
        }

        [XmlElement(ElementName="ComponentTokenPointerGuid", Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", DataType="string")]
        public string ComponentTokenPointerGuid
        {
            get
            {
                return this._componenttokenpointerguid;
            }
            set
            {
                this._componenttokenpointerguid = value;
            }
        }

        [XmlElement(ElementName="RuleGuid", Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", DataType="string")]
        public string RuleGuid
        {
            get
            {
                return this._ruleguid;
            }
            set
            {
                this._ruleguid = value;
            }
        }

        [XmlElement(ElementName="RuleInstanceGuid", Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", DataType="string")]
        public string RuleInstanceGuid
        {
            get
            {
                return this._ruleinstanceguid;
            }
            set
            {
                this._ruleinstanceguid = value;
            }
        }

        [XmlElement(ElementName="RuleTokenType", Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05")]
        public Corillian.Marketing.Domain.Plugin.RuleTokenType RuleTokenType
        {
            get
            {
                return this._ruletokentype;
            }
            set
            {
                this._ruletokentype = value;
            }
        }

        [XmlElement(ElementName="SequenceId", Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", DataType="short")]
        public short SequenceId
        {
            get
            {
                return this._sequenceid;
            }
            set
            {
                this.SequenceIdSpecified = true;
                this._sequenceid = value;
            }
        }

        [XmlElement(ElementName="Token", Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", DataType="string")]
        public string Token
        {
            get
            {
                return this._token;
            }
            set
            {
                this._token = value;
            }
        }

        [XmlElement(ElementName="TokenCheckSum", Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", DataType="int")]
        public int TokenCheckSum
        {
            get
            {
                return this._tokenchecksum;
            }
            set
            {
                this.TokenCheckSumSpecified = true;
                this._tokenchecksum = value;
            }
        }
    }
}

