namespace Corillian.Marketing.Domain.Plugin
{
    using Corillian.Voyager.Common;
    using System;
    using System.Xml.Serialization;

    [Serializable, XmlType(Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", TypeName="WebPageContextMap"), XmlRoot(Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", ElementName="WebPageContextMap")]
    public class WebPageContextMap : IFormattable
    {
        private Corillian.Marketing.Domain.Plugin.BaseContext _basecontext;
        private Corillian.Marketing.Domain.Plugin.WebPage _webpage;

        public virtual string ToString(string format)
        {
            return FormattableObject.ToString(this, format, null);
        }

        public virtual string ToString(string format, IFormatProvider formatProvider)
        {
            if (format == null)
            {
                return base.ToString();
            }
            return FormattableObject.ToString(this, format, formatProvider);
        }

        [XmlElement(ElementName="BaseContext", Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05")]
        public Corillian.Marketing.Domain.Plugin.BaseContext BaseContext
        {
            get
            {
                return this._basecontext;
            }
            set
            {
                this._basecontext = value;
            }
        }

        [XmlElement(ElementName="WebPage", Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05")]
        public Corillian.Marketing.Domain.Plugin.WebPage WebPage
        {
            get
            {
                return this._webpage;
            }
            set
            {
                this._webpage = value;
            }
        }
    }
}

