namespace Corillian.Marketing.Domain.Plugin
{
    using System;
    using System.Reflection;

    public interface IBaseContextList : IBaseContextCollection
    {
        int Add(BaseContext value);
        void Clear();
        bool Contains(BaseContext value);
        int IndexOf(BaseContext value);
        void Insert(int index, BaseContext value);
        void Remove(BaseContext value);
        void RemoveAt(int index);

        bool IsFixedSize { get; }

        bool IsReadOnly { get; }

        BaseContext this[int index] { get; set; }
    }
}

