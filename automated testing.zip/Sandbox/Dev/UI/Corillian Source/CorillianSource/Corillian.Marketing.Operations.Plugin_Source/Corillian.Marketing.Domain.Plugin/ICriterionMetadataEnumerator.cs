namespace Corillian.Marketing.Domain.Plugin
{
    using System;

    public interface ICriterionMetadataEnumerator
    {
        bool MoveNext();
        void Reset();

        CriterionMetadata Current { get; }
    }
}

