namespace Corillian.Marketing.Domain.Plugin
{
    using System;

    public interface IWebPageEnumerator
    {
        bool MoveNext();
        void Reset();

        WebPage Current { get; }
    }
}

