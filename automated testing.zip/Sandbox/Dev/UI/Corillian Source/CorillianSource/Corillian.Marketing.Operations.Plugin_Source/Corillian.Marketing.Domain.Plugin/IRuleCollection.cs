namespace Corillian.Marketing.Domain.Plugin
{
    using System;

    public interface IRuleCollection
    {
        void CopyTo(Rule[] array, int arrayIndex);
        IRuleEnumerator GetEnumerator();

        int Count { get; }

        bool IsSynchronized { get; }

        object SyncRoot { get; }
    }
}

