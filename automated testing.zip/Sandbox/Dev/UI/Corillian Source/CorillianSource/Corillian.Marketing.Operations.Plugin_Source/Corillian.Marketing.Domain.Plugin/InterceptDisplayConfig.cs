namespace Corillian.Marketing.Domain.Plugin
{
    using Corillian.Voyager.Common;
    using System;
    using System.Xml.Serialization;

    [Serializable, XmlRoot(Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", ElementName="InterceptDisplayConfig"), XmlType(Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", TypeName="InterceptDisplayConfig")]
    public class InterceptDisplayConfig : IFormattable
    {
        private string _applytext;
        private Corillian.Marketing.Domain.Plugin.InterceptDisplay _interceptdisplay;
        private string _remaindtext;
        private string _supresstext;

        public virtual string ToString(string format)
        {
            return FormattableObject.ToString(this, format, null);
        }

        public virtual string ToString(string format, IFormatProvider formatProvider)
        {
            if (format == null)
            {
                return base.ToString();
            }
            return FormattableObject.ToString(this, format, formatProvider);
        }

        [XmlElement(ElementName="ApplyText", Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", DataType="string")]
        public string ApplyText
        {
            get
            {
                return this._applytext;
            }
            set
            {
                this._applytext = value;
            }
        }

        [XmlElement(ElementName="InterceptDisplay", Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05")]
        public Corillian.Marketing.Domain.Plugin.InterceptDisplay InterceptDisplay
        {
            get
            {
                return this._interceptdisplay;
            }
            set
            {
                this._interceptdisplay = value;
            }
        }

        [XmlElement(ElementName="RemaindText", Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", DataType="string")]
        public string RemaindText
        {
            get
            {
                return this._remaindtext;
            }
            set
            {
                this._remaindtext = value;
            }
        }

        [XmlElement(ElementName="SupressText", Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", DataType="string")]
        public string SupressText
        {
            get
            {
                return this._supresstext;
            }
            set
            {
                this._supresstext = value;
            }
        }
    }
}

