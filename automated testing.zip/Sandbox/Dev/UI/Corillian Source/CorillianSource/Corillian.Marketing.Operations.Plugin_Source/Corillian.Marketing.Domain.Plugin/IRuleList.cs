namespace Corillian.Marketing.Domain.Plugin
{
    using System;
    using System.Reflection;

    public interface IRuleList : IRuleCollection
    {
        int Add(Rule value);
        void Clear();
        bool Contains(Rule value);
        int IndexOf(Rule value);
        void Insert(int index, Rule value);
        void Remove(Rule value);
        void RemoveAt(int index);

        bool IsFixedSize { get; }

        bool IsReadOnly { get; }

        Rule this[int index] { get; set; }
    }
}

