namespace Corillian.Marketing.Domain.Plugin
{
    using System;

    public interface IAdContentEnumerator
    {
        bool MoveNext();
        void Reset();

        AdContent Current { get; }
    }
}

