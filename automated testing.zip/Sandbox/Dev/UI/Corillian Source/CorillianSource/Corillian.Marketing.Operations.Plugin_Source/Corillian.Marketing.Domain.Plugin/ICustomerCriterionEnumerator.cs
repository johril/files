namespace Corillian.Marketing.Domain.Plugin
{
    using System;

    public interface ICustomerCriterionEnumerator
    {
        bool MoveNext();
        void Reset();

        CustomerCriterion Current { get; }
    }
}

