namespace Corillian.Marketing.Domain.Plugin
{
    using System;

    public interface IBaseContextCollection
    {
        void CopyTo(BaseContext[] array, int arrayIndex);
        IBaseContextEnumerator GetEnumerator();

        int Count { get; }

        bool IsSynchronized { get; }

        object SyncRoot { get; }
    }
}

