namespace Corillian.Marketing.Domain.Plugin
{
    using Corillian.Voyager.Common;
    using Corillian.Voyager.Common.Attributes;
    using System;
    using System.Xml.Serialization;

    [Serializable, XmlRoot(Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", ElementName="McifImportTask"), XmlType(Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", TypeName="McifImportTask")]
    public class McifImportTask : IFormattable
    {
        private int _errorcount;
        private int _fiid;
        private string _filename;
        private DateTime _importeddate;
        private int _importstatus;
        private int _importtaskid;
        private int _insertedcount;
        private int _processedcount;
        private string _statusdescription;
        private int _updatedcount;
        [Ignore, XmlIgnore]
        public bool ErrorCountSpecified;
        [Ignore, XmlIgnore]
        public bool FiidSpecified;
        [XmlIgnore, Ignore]
        public bool ImportedDateSpecified;
        [Ignore, XmlIgnore]
        public bool ImportStatusSpecified;
        [Ignore, XmlIgnore]
        public bool ImportTaskIdSpecified;
        [XmlIgnore, Ignore]
        public bool InsertedCountSpecified;
        [Ignore, XmlIgnore]
        public bool ProcessedCountSpecified;
        [XmlIgnore, Ignore]
        public bool UpdatedCountSpecified;

        public virtual string ToString(string format)
        {
            return FormattableObject.ToString(this, format, null);
        }

        public virtual string ToString(string format, IFormatProvider formatProvider)
        {
            if (format == null)
            {
                return base.ToString();
            }
            return FormattableObject.ToString(this, format, formatProvider);
        }

        [XmlElement(ElementName="ErrorCount", Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", DataType="int")]
        public int ErrorCount
        {
            get
            {
                return this._errorcount;
            }
            set
            {
                this.ErrorCountSpecified = true;
                this._errorcount = value;
            }
        }

        [XmlElement(ElementName="Fiid", Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", DataType="int")]
        public int Fiid
        {
            get
            {
                return this._fiid;
            }
            set
            {
                this.FiidSpecified = true;
                this._fiid = value;
            }
        }

        [XmlElement(ElementName="FileName", Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", DataType="string")]
        public string FileName
        {
            get
            {
                return this._filename;
            }
            set
            {
                this._filename = value;
            }
        }

        [XmlElement(ElementName="ImportedDate", Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", DataType="date")]
        public DateTime ImportedDate
        {
            get
            {
                return this._importeddate;
            }
            set
            {
                this.ImportedDateSpecified = true;
                this._importeddate = value;
            }
        }

        [XmlElement(ElementName="ImportStatus", Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", DataType="int")]
        public int ImportStatus
        {
            get
            {
                return this._importstatus;
            }
            set
            {
                this.ImportStatusSpecified = true;
                this._importstatus = value;
            }
        }

        [XmlElement(ElementName="ImportTaskId", Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", DataType="int")]
        public int ImportTaskId
        {
            get
            {
                return this._importtaskid;
            }
            set
            {
                this.ImportTaskIdSpecified = true;
                this._importtaskid = value;
            }
        }

        [XmlElement(ElementName="InsertedCount", Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", DataType="int")]
        public int InsertedCount
        {
            get
            {
                return this._insertedcount;
            }
            set
            {
                this.InsertedCountSpecified = true;
                this._insertedcount = value;
            }
        }

        [XmlElement(ElementName="ProcessedCount", Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", DataType="int")]
        public int ProcessedCount
        {
            get
            {
                return this._processedcount;
            }
            set
            {
                this.ProcessedCountSpecified = true;
                this._processedcount = value;
            }
        }

        [XmlElement(ElementName="StatusDescription", Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", DataType="string")]
        public string StatusDescription
        {
            get
            {
                return this._statusdescription;
            }
            set
            {
                this._statusdescription = value;
            }
        }

        [XmlElement(ElementName="UpdatedCount", Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", DataType="int")]
        public int UpdatedCount
        {
            get
            {
                return this._updatedcount;
            }
            set
            {
                this.UpdatedCountSpecified = true;
                this._updatedcount = value;
            }
        }
    }
}

