namespace Corillian.Marketing.Domain
{
    using Corillian.Voyager.Common;
    using System;
    using System.Xml.Serialization;

    [Serializable, XmlRoot(Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", ElementName="CampaignSpaceBaseType"), XmlType(Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", TypeName="CampaignSpaceBaseType")]
    public class CampaignSpaceBaseType : IFormattable
    {
        private CampaignSpaceCollection _campaignspaces;

        public static CampaignSpaceBaseType Deserialize(string response)
        {
            return (CampaignSpaceBaseType) ObjectFactory.DeserializeResponse(response, typeof(CampaignSpaceBaseType), true);
        }

        public virtual string ToString(string format)
        {
            return FormattableObject.ToString(this, format, null);
        }

        public virtual string ToString(string format, IFormatProvider formatProvider)
        {
            if (format == null)
            {
                return base.ToString();
            }
            return FormattableObject.ToString(this, format, formatProvider);
        }

        [XmlElement(ElementName="CampaignSpace", Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05")]
        public CampaignSpaceCollection CampaignSpaceList
        {
            get
            {
                return this._campaignspaces;
            }
            set
            {
                this._campaignspaces = value;
            }
        }
    }
}

