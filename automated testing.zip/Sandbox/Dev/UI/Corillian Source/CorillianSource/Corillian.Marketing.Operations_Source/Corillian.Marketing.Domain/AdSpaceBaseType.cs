namespace Corillian.Marketing.Domain
{
    using Corillian.Voyager.Common;
    using System;
    using System.Xml.Serialization;

    [Serializable, XmlRoot(Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", ElementName="AdSpaceBaseType"), XmlType(Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", TypeName="AdSpaceBaseType")]
    public class AdSpaceBaseType : IFormattable
    {
        private AdSpaceCollection _adspaces;

        public static AdSpaceBaseType Deserialize(string response)
        {
            return (AdSpaceBaseType) ObjectFactory.DeserializeResponse(response, typeof(AdSpaceBaseType), true);
        }

        public virtual string ToString(string format)
        {
            return FormattableObject.ToString(this, format, null);
        }

        public virtual string ToString(string format, IFormatProvider formatProvider)
        {
            if (format == null)
            {
                return base.ToString();
            }
            return FormattableObject.ToString(this, format, formatProvider);
        }

        [XmlElement(ElementName="AdSpace", Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05")]
        public AdSpaceCollection AdSpaceList
        {
            get
            {
                return this._adspaces;
            }
            set
            {
                this._adspaces = value;
            }
        }
    }
}

