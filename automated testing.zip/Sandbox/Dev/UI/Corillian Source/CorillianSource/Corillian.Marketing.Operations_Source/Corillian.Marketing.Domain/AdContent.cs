namespace Corillian.Marketing.Domain
{
    using Corillian.Voyager.Common;
    using Corillian.Voyager.Common.Attributes;
    using System;
    using System.Xml.Serialization;

    [Serializable, XmlRoot(Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", ElementName="AdContent"), XmlType(Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", TypeName="AdContent")]
    public class AdContent : IFormattable
    {
        private Corillian.Marketing.Domain.AdMedia _admedia;
        private byte[] _content;
        private bool _newinimport;
        [XmlIgnore, Ignore]
        public bool NewInImportSpecified;

        public static AdContent Deserialize(string response)
        {
            return (AdContent) ObjectFactory.DeserializeResponse(response, typeof(AdContent), true);
        }

        public virtual string ToString(string format)
        {
            return FormattableObject.ToString(this, format, null);
        }

        public virtual string ToString(string format, IFormatProvider formatProvider)
        {
            if (format == null)
            {
                return base.ToString();
            }
            return FormattableObject.ToString(this, format, formatProvider);
        }

        [XmlElement(ElementName="AdMedia", Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05")]
        public Corillian.Marketing.Domain.AdMedia AdMedia
        {
            get
            {
                return this._admedia;
            }
            set
            {
                this._admedia = value;
            }
        }

        [XmlElement(ElementName="Content", Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", DataType="base64Binary")]
        public byte[] Content
        {
            get
            {
                return this._content;
            }
            set
            {
                this._content = value;
            }
        }

        [XmlElement(ElementName="NewInImport", Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", DataType="boolean")]
        public bool NewInImport
        {
            get
            {
                return this._newinimport;
            }
            set
            {
                this.NewInImportSpecified = true;
                this._newinimport = value;
            }
        }
    }
}

