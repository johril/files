namespace Corillian.Marketing.Domain
{
    using Corillian.Voyager.Common;
    using Corillian.Voyager.Common.Attributes;
    using System;
    using System.Xml.Serialization;

    [Serializable, XmlType(Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", TypeName="CampaignImportTask"), XmlRoot(Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", ElementName="CampaignImportTask")]
    public class CampaignImportTask : IFormattable
    {
        private short _fiid;
        private byte[] _filecontent;
        private string _filename;
        private string _filepath;
        private string _importedby;
        private DateTime _importeddate;
        private string _importedthrough;
        private int _importstatus;
        private int _importtaskid;
        private bool _iserrors;
        private bool _issugestions;
        private string _statusdescription;
        [Ignore, XmlIgnore]
        public bool FiidSpecified;
        [Ignore, XmlIgnore]
        public bool ImportedDateSpecified;
        [XmlIgnore, Ignore]
        public bool ImportStatusSpecified;
        [Ignore, XmlIgnore]
        public bool ImportTaskIdSpecified;
        [Ignore, XmlIgnore]
        public bool IsErrorsSpecified;
        [Ignore, XmlIgnore]
        public bool IsSugestionsSpecified;

        public static CampaignImportTask Deserialize(string response)
        {
            return (CampaignImportTask) ObjectFactory.DeserializeResponse(response, typeof(CampaignImportTask), true);
        }

        public virtual string ToString(string format)
        {
            return FormattableObject.ToString(this, format, null);
        }

        public virtual string ToString(string format, IFormatProvider formatProvider)
        {
            if (format == null)
            {
                return base.ToString();
            }
            return FormattableObject.ToString(this, format, formatProvider);
        }

        [XmlElement(ElementName="Fiid", Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", DataType="short")]
        public short Fiid
        {
            get
            {
                return this._fiid;
            }
            set
            {
                this.FiidSpecified = true;
                this._fiid = value;
            }
        }

        [XmlElement(ElementName="FileContent", Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", DataType="base64Binary")]
        public byte[] FileContent
        {
            get
            {
                return this._filecontent;
            }
            set
            {
                this._filecontent = value;
            }
        }

        [XmlElement(ElementName="FileName", Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", DataType="string")]
        public string FileName
        {
            get
            {
                return this._filename;
            }
            set
            {
                this._filename = value;
            }
        }

        [XmlElement(ElementName="FilePath", Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", DataType="string")]
        public string FilePath
        {
            get
            {
                return this._filepath;
            }
            set
            {
                this._filepath = value;
            }
        }

        [XmlElement(ElementName="ImportedBy", Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", DataType="string")]
        public string ImportedBy
        {
            get
            {
                return this._importedby;
            }
            set
            {
                this._importedby = value;
            }
        }

        [XmlElement(ElementName="ImportedDate", Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", DataType="date")]
        public DateTime ImportedDate
        {
            get
            {
                return this._importeddate;
            }
            set
            {
                this.ImportedDateSpecified = true;
                this._importeddate = value;
            }
        }

        [XmlElement(ElementName="ImportedThrough", Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", DataType="string")]
        public string ImportedThrough
        {
            get
            {
                return this._importedthrough;
            }
            set
            {
                this._importedthrough = value;
            }
        }

        [XmlElement(ElementName="ImportStatus", Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", DataType="int")]
        public int ImportStatus
        {
            get
            {
                return this._importstatus;
            }
            set
            {
                this.ImportStatusSpecified = true;
                this._importstatus = value;
            }
        }

        [XmlElement(ElementName="ImportTaskId", Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", DataType="int")]
        public int ImportTaskId
        {
            get
            {
                return this._importtaskid;
            }
            set
            {
                this.ImportTaskIdSpecified = true;
                this._importtaskid = value;
            }
        }

        [XmlElement(ElementName="IsErrors", Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", DataType="boolean")]
        public bool IsErrors
        {
            get
            {
                return this._iserrors;
            }
            set
            {
                this.IsErrorsSpecified = true;
                this._iserrors = value;
            }
        }

        [XmlElement(ElementName="IsSugestions", Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", DataType="boolean")]
        public bool IsSugestions
        {
            get
            {
                return this._issugestions;
            }
            set
            {
                this.IsSugestionsSpecified = true;
                this._issugestions = value;
            }
        }

        [XmlElement(ElementName="StatusDescription", Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", DataType="string")]
        public string StatusDescription
        {
            get
            {
                return this._statusdescription;
            }
            set
            {
                this._statusdescription = value;
            }
        }
    }
}

