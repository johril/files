namespace Corillian.Marketing.Domain
{
    using Corillian.Voyager.Common;
    using Corillian.Voyager.Common.Attributes;
    using System;
    using System.Xml.Serialization;

    [Serializable, XmlType(Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", TypeName="CampaignInstance"), XmlRoot(Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", ElementName="CampaignInstance")]
    public class CampaignInstance : IFormattable
    {
        private int _adspaceid;
        private string _campaignguid;
        private int _campaigninstanceaggchecksum;
        private string _campaigninstanceguid;
        private int _campaignversion;
        private DateTime _createdate;
        private string _createdby;
        private bool _currentinstance;
        private bool _deleted;
        private int _hierarchyvalue;
        private bool _makedefaultforadspace;
        private string _ruleinstanceguid;
        private TargetUrlDisplay _targeturldisplay;
        [Ignore, XmlIgnore]
        public bool AdSpaceIdSpecified;
        [XmlIgnore, Ignore]
        public bool CampaignInstanceAggChecksumSpecified;
        [XmlIgnore, Ignore]
        public bool CampaignVersionSpecified;
        [Ignore, XmlIgnore]
        public bool CreateDateSpecified;
        [Ignore, XmlIgnore]
        public bool CurrentInstanceSpecified;
        [Ignore, XmlIgnore]
        public bool DeletedSpecified;
        [Ignore, XmlIgnore]
        public bool HierarchyValueSpecified;
        [Ignore, XmlIgnore]
        public bool MakeDefaultForAdSpaceSpecified;

        public static CampaignInstance Deserialize(string response)
        {
            return (CampaignInstance) ObjectFactory.DeserializeResponse(response, typeof(CampaignInstance), true);
        }

        public virtual string ToString(string format)
        {
            return FormattableObject.ToString(this, format, null);
        }

        public virtual string ToString(string format, IFormatProvider formatProvider)
        {
            if (format == null)
            {
                return base.ToString();
            }
            return FormattableObject.ToString(this, format, formatProvider);
        }

        [XmlElement(ElementName="AdSpaceId", Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", DataType="int")]
        public int AdSpaceId
        {
            get
            {
                return this._adspaceid;
            }
            set
            {
                this.AdSpaceIdSpecified = true;
                this._adspaceid = value;
            }
        }

        [XmlElement(ElementName="CampaignGuid", Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", DataType="string")]
        public string CampaignGuid
        {
            get
            {
                return this._campaignguid;
            }
            set
            {
                this._campaignguid = value;
            }
        }

        [XmlElement(ElementName="CampaignInstanceAggChecksum", Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", DataType="int")]
        public int CampaignInstanceAggChecksum
        {
            get
            {
                return this._campaigninstanceaggchecksum;
            }
            set
            {
                this.CampaignInstanceAggChecksumSpecified = true;
                this._campaigninstanceaggchecksum = value;
            }
        }

        [XmlElement(ElementName="CampaignInstanceGuid", Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", DataType="string")]
        public string CampaignInstanceGuid
        {
            get
            {
                return this._campaigninstanceguid;
            }
            set
            {
                this._campaigninstanceguid = value;
            }
        }

        [XmlElement(ElementName="CampaignVersion", Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", DataType="int")]
        public int CampaignVersion
        {
            get
            {
                return this._campaignversion;
            }
            set
            {
                this.CampaignVersionSpecified = true;
                this._campaignversion = value;
            }
        }

        [XmlElement(ElementName="CreateDate", Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", DataType="dateTime")]
        public DateTime CreateDate
        {
            get
            {
                return this._createdate;
            }
            set
            {
                this.CreateDateSpecified = true;
                this._createdate = value;
            }
        }

        [XmlElement(ElementName="CreatedBy", Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", DataType="string")]
        public string CreatedBy
        {
            get
            {
                return this._createdby;
            }
            set
            {
                this._createdby = value;
            }
        }

        [XmlElement(ElementName="CurrentInstance", Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", DataType="boolean")]
        public bool CurrentInstance
        {
            get
            {
                return this._currentinstance;
            }
            set
            {
                this.CurrentInstanceSpecified = true;
                this._currentinstance = value;
            }
        }

        [XmlElement(ElementName="Deleted", Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", DataType="boolean")]
        public bool Deleted
        {
            get
            {
                return this._deleted;
            }
            set
            {
                this.DeletedSpecified = true;
                this._deleted = value;
            }
        }

        [XmlElement(ElementName="HierarchyValue", Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", DataType="int")]
        public int HierarchyValue
        {
            get
            {
                return this._hierarchyvalue;
            }
            set
            {
                this.HierarchyValueSpecified = true;
                this._hierarchyvalue = value;
            }
        }

        [XmlElement(ElementName="MakeDefaultForAdSpace", Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", DataType="boolean")]
        public bool MakeDefaultForAdSpace
        {
            get
            {
                return this._makedefaultforadspace;
            }
            set
            {
                this.MakeDefaultForAdSpaceSpecified = true;
                this._makedefaultforadspace = value;
            }
        }

        [XmlElement(ElementName="RuleInstanceGuid", Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", DataType="string")]
        public string RuleInstanceGuid
        {
            get
            {
                return this._ruleinstanceguid;
            }
            set
            {
                this._ruleinstanceguid = value;
            }
        }

        [XmlElement(ElementName="TargetURLDisplay", Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05")]
        public TargetUrlDisplay TargetURLDisplay
        {
            get
            {
                return this._targeturldisplay;
            }
            set
            {
                this._targeturldisplay = value;
            }
        }
    }
}

