namespace Corillian.Marketing.Domain
{
    using Corillian.Voyager.Common;
    using Corillian.Voyager.Common.Attributes;
    using System;
    using System.Xml.Serialization;

    [Serializable, XmlRoot(Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", ElementName="CachedCriterionsBaseType"), XmlType(Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", TypeName="CachedCriterionsBaseType")]
    public class CachedCriterionsBaseType : IFormattable
    {
        private CachedCriterionCollection _cachedcriterions;

        public static CachedCriterionsBaseType Deserialize(string response)
        {
            return (CachedCriterionsBaseType) ObjectFactory.DeserializeResponse(response, typeof(CachedCriterionsBaseType), true);
        }

        public virtual string ToString(string format)
        {
            return FormattableObject.ToString(this, format, null);
        }

        public virtual string ToString(string format, IFormatProvider formatProvider)
        {
            if (format == null)
            {
                return base.ToString();
            }
            return FormattableObject.ToString(this, format, formatProvider);
        }

        [Repository(RepositoryType.Secure), TagName("CMCriterion."), XmlElement(ElementName="CachedCriterion", Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05")]
        public CachedCriterionCollection CachedCriterionList
        {
            get
            {
                return this._cachedcriterions;
            }
            set
            {
                this._cachedcriterions = value;
            }
        }
    }
}

