namespace Corillian.Marketing.Domain
{
    using Corillian.Voyager.Common;
    using Corillian.Voyager.Common.Attributes;
    using System;
    using System.Xml.Serialization;

    [Serializable, XmlRoot(Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", ElementName="CampaignImportTaskMessage"), XmlType(Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", TypeName="CampaignImportTaskMessage")]
    public class CampaignImportTaskMessage : IFormattable
    {
        private int _importtaskid;
        private int _importtaskmessageid;
        private string _message;
        private int _messagetype;
        [XmlIgnore, Ignore]
        public bool ImportTaskIdSpecified;
        [Ignore, XmlIgnore]
        public bool ImportTaskMessageIdSpecified;
        [Ignore, XmlIgnore]
        public bool MessageTypeSpecified;

        public static CampaignImportTaskMessage Deserialize(string response)
        {
            return (CampaignImportTaskMessage) ObjectFactory.DeserializeResponse(response, typeof(CampaignImportTaskMessage), true);
        }

        public virtual string ToString(string format)
        {
            return FormattableObject.ToString(this, format, null);
        }

        public virtual string ToString(string format, IFormatProvider formatProvider)
        {
            if (format == null)
            {
                return base.ToString();
            }
            return FormattableObject.ToString(this, format, formatProvider);
        }

        [XmlElement(ElementName="ImportTaskId", Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", DataType="int")]
        public int ImportTaskId
        {
            get
            {
                return this._importtaskid;
            }
            set
            {
                this.ImportTaskIdSpecified = true;
                this._importtaskid = value;
            }
        }

        [XmlElement(ElementName="ImportTaskMessageId", Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", DataType="int")]
        public int ImportTaskMessageId
        {
            get
            {
                return this._importtaskmessageid;
            }
            set
            {
                this.ImportTaskMessageIdSpecified = true;
                this._importtaskmessageid = value;
            }
        }

        [XmlElement(ElementName="Message", Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", DataType="string")]
        public string Message
        {
            get
            {
                return this._message;
            }
            set
            {
                this._message = value;
            }
        }

        [XmlElement(ElementName="MessageType", Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", DataType="int")]
        public int MessageType
        {
            get
            {
                return this._messagetype;
            }
            set
            {
                this.MessageTypeSpecified = true;
                this._messagetype = value;
            }
        }
    }
}

