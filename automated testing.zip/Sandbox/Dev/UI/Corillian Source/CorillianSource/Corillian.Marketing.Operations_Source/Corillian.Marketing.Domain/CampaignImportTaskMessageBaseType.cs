namespace Corillian.Marketing.Domain
{
    using Corillian.Voyager.Common;
    using System;
    using System.Xml.Serialization;

    [Serializable, XmlRoot(Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", ElementName="CampaignImportTaskMessageBaseType"), XmlType(Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", TypeName="CampaignImportTaskMessageBaseType")]
    public class CampaignImportTaskMessageBaseType : IFormattable
    {
        private CampaignImportTaskMessageCollection _campaignimporttaskmessages;

        public static CampaignImportTaskMessageBaseType Deserialize(string response)
        {
            return (CampaignImportTaskMessageBaseType) ObjectFactory.DeserializeResponse(response, typeof(CampaignImportTaskMessageBaseType), true);
        }

        public virtual string ToString(string format)
        {
            return FormattableObject.ToString(this, format, null);
        }

        public virtual string ToString(string format, IFormatProvider formatProvider)
        {
            if (format == null)
            {
                return base.ToString();
            }
            return FormattableObject.ToString(this, format, formatProvider);
        }

        [XmlElement(ElementName="CampaignImportTaskMessage", Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05")]
        public CampaignImportTaskMessageCollection CampaignImportTaskMessageList
        {
            get
            {
                return this._campaignimporttaskmessages;
            }
            set
            {
                this._campaignimporttaskmessages = value;
            }
        }
    }
}

