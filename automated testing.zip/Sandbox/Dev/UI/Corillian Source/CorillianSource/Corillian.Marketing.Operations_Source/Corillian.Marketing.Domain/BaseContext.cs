namespace Corillian.Marketing.Domain
{
    using Corillian.Voyager.Common;
    using Corillian.Voyager.Common.Attributes;
    using System;
    using System.Xml.Serialization;

    [Serializable, XmlRoot(Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", ElementName="BaseContext"), XmlType(Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", TypeName="BaseContext")]
    public class BaseContext : IFormattable
    {
        private int _basecontextid;
        private string _basecontexttype;
        private string _basecontexttypedescription;
        [Ignore, XmlIgnore]
        public bool BaseContextIdSpecified;

        public static BaseContext Deserialize(string response)
        {
            return (BaseContext) ObjectFactory.DeserializeResponse(response, typeof(BaseContext), true);
        }

        public virtual string ToString(string format)
        {
            return FormattableObject.ToString(this, format, null);
        }

        public virtual string ToString(string format, IFormatProvider formatProvider)
        {
            if (format == null)
            {
                return base.ToString();
            }
            return FormattableObject.ToString(this, format, formatProvider);
        }

        [XmlElement(ElementName="BaseContextId", Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", DataType="int")]
        public int BaseContextId
        {
            get
            {
                return this._basecontextid;
            }
            set
            {
                this.BaseContextIdSpecified = true;
                this._basecontextid = value;
            }
        }

        [XmlElement(ElementName="BaseContextType", Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", DataType="string")]
        public string BaseContextType
        {
            get
            {
                return this._basecontexttype;
            }
            set
            {
                this._basecontexttype = value;
            }
        }

        [XmlElement(ElementName="BaseContextTypeDescription", Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", DataType="string")]
        public string BaseContextTypeDescription
        {
            get
            {
                return this._basecontexttypedescription;
            }
            set
            {
                this._basecontexttypedescription = value;
            }
        }
    }
}

