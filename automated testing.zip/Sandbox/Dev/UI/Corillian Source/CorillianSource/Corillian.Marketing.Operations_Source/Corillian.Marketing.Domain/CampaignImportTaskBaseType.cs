namespace Corillian.Marketing.Domain
{
    using Corillian.Voyager.Common;
    using System;
    using System.Xml.Serialization;

    [Serializable, XmlRoot(Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", ElementName="CampaignImportTaskBaseType"), XmlType(Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", TypeName="CampaignImportTaskBaseType")]
    public class CampaignImportTaskBaseType : IFormattable
    {
        private CampaignImportTaskCollection _campaignimporttasks;

        public static CampaignImportTaskBaseType Deserialize(string response)
        {
            return (CampaignImportTaskBaseType) ObjectFactory.DeserializeResponse(response, typeof(CampaignImportTaskBaseType), true);
        }

        public virtual string ToString(string format)
        {
            return FormattableObject.ToString(this, format, null);
        }

        public virtual string ToString(string format, IFormatProvider formatProvider)
        {
            if (format == null)
            {
                return base.ToString();
            }
            return FormattableObject.ToString(this, format, formatProvider);
        }

        [XmlElement(ElementName="CampaignImportTask", Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05")]
        public CampaignImportTaskCollection CampaignImportTaskList
        {
            get
            {
                return this._campaignimporttasks;
            }
            set
            {
                this._campaignimporttasks = value;
            }
        }
    }
}

