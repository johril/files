namespace Corillian.Marketing.Domain
{
    using Corillian.Voyager.Common;
    using System;
    using System.Xml.Serialization;

    [Serializable, XmlType(Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", TypeName="AdMediaBaseType"), XmlRoot(Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", ElementName="AdMediaBaseType")]
    public class AdMediaBaseType : IFormattable
    {
        private AdMediaCollection _admedias;

        public static AdMediaBaseType Deserialize(string response)
        {
            return (AdMediaBaseType) ObjectFactory.DeserializeResponse(response, typeof(AdMediaBaseType), true);
        }

        public virtual string ToString(string format)
        {
            return FormattableObject.ToString(this, format, null);
        }

        public virtual string ToString(string format, IFormatProvider formatProvider)
        {
            if (format == null)
            {
                return base.ToString();
            }
            return FormattableObject.ToString(this, format, formatProvider);
        }

        [XmlElement(ElementName="AdMedia", Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05")]
        public AdMediaCollection AdMediaList
        {
            get
            {
                return this._admedias;
            }
            set
            {
                this._admedias = value;
            }
        }
    }
}

