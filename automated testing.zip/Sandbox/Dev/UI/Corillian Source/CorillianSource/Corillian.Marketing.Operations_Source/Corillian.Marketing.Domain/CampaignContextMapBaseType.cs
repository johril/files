namespace Corillian.Marketing.Domain
{
    using Corillian.Voyager.Common;
    using System;
    using System.Xml.Serialization;

    [Serializable, XmlType(Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", TypeName="CampaignContextMapBaseType"), XmlRoot(Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", ElementName="CampaignContextMapBaseType")]
    public class CampaignContextMapBaseType : IFormattable
    {
        private CampaignContextMapCollection _campaigncontextmaps;

        public static CampaignContextMapBaseType Deserialize(string response)
        {
            return (CampaignContextMapBaseType) ObjectFactory.DeserializeResponse(response, typeof(CampaignContextMapBaseType), true);
        }

        public virtual string ToString(string format)
        {
            return FormattableObject.ToString(this, format, null);
        }

        public virtual string ToString(string format, IFormatProvider formatProvider)
        {
            if (format == null)
            {
                return base.ToString();
            }
            return FormattableObject.ToString(this, format, formatProvider);
        }

        [XmlElement(ElementName="CampaignContextMap", Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05")]
        public CampaignContextMapCollection CampaignContextMapList
        {
            get
            {
                return this._campaigncontextmaps;
            }
            set
            {
                this._campaigncontextmaps = value;
            }
        }
    }
}

