namespace Corillian.Marketing.Domain
{
    using Corillian.Voyager.Common;
    using System;
    using System.Xml.Serialization;

    [Serializable, XmlType(Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", TypeName="CampaignBaseType"), XmlRoot(Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", ElementName="CampaignBaseType")]
    public class CampaignBaseType : IFormattable
    {
        private CampaignCollection _campaigns;

        public static CampaignBaseType Deserialize(string response)
        {
            return (CampaignBaseType) ObjectFactory.DeserializeResponse(response, typeof(CampaignBaseType), true);
        }

        public virtual string ToString(string format)
        {
            return FormattableObject.ToString(this, format, null);
        }

        public virtual string ToString(string format, IFormatProvider formatProvider)
        {
            if (format == null)
            {
                return base.ToString();
            }
            return FormattableObject.ToString(this, format, formatProvider);
        }

        [XmlElement(ElementName="Campaign", Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05")]
        public CampaignCollection CampaignList
        {
            get
            {
                return this._campaigns;
            }
            set
            {
                this._campaigns = value;
            }
        }
    }
}

