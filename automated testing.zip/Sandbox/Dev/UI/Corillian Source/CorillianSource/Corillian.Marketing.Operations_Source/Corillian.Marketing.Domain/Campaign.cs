namespace Corillian.Marketing.Domain
{
    using Corillian.Voyager.Common;
    using Corillian.Voyager.Common.Attributes;
    using System;
    using System.Xml.Serialization;

    [Serializable, XmlType(Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", TypeName="Campaign"), XmlRoot(Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", ElementName="Campaign")]
    public class Campaign : IFormattable
    {
        private string _campaigndescription;
        private int _campaigndisplaypriority;
        private string _campaignguid;
        private string _campaignname;
        private Corillian.Marketing.Domain.CampaignType _campaigntype;
        private DateTime _createdate;
        private string _createdby;
        private CampaignInstance _currentcampaigninstance;
        private bool _deleted;
        private AdSpace _displayingadspace;
        private string _displayingcampaigncontext;
        private CampaignInstanceCompositionMap _displayingcomposition;
        private DateTime _effectivedate;
        private int _fiid;
        private bool _isexported;
        private bool _isimported;
        private bool _newinimport;
        private string _ruleguid;
        private int _state;
        private DateTime _statechangedate;
        private int _statestatus;
        private DateTime _terminationdate;
        private int _webpageid;
        [Ignore, XmlIgnore]
        public bool CampaignDisplayPrioritySpecified;
        [XmlIgnore, Ignore]
        public bool CreateDateSpecified;
        [Ignore, XmlIgnore]
        public bool DeletedSpecified;
        [XmlIgnore, Ignore]
        public bool EffectiveDateSpecified;
        [Ignore, XmlIgnore]
        public bool FiidSpecified;
        [Ignore, XmlIgnore]
        public bool IsExportedSpecified;
        [XmlIgnore, Ignore]
        public bool IsImportedSpecified;
        [Ignore, XmlIgnore]
        public bool NewInImportSpecified;
        [XmlIgnore, Ignore]
        public bool StateChangeDateSpecified;
        [XmlIgnore, Ignore]
        public bool StateSpecified;
        [Ignore, XmlIgnore]
        public bool StateStatusSpecified;
        [Ignore, XmlIgnore]
        public bool TerminationDateSpecified;
        [Ignore, XmlIgnore]
        public bool WebPageIdSpecified;

        public static Campaign Deserialize(string response)
        {
            return (Campaign) ObjectFactory.DeserializeResponse(response, typeof(Campaign), true);
        }

        public virtual string ToString(string format)
        {
            return FormattableObject.ToString(this, format, null);
        }

        public virtual string ToString(string format, IFormatProvider formatProvider)
        {
            if (format == null)
            {
                return base.ToString();
            }
            return FormattableObject.ToString(this, format, formatProvider);
        }

        [XmlElement(ElementName="CampaignDescription", Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", DataType="string")]
        public string CampaignDescription
        {
            get
            {
                return this._campaigndescription;
            }
            set
            {
                this._campaigndescription = value;
            }
        }

        [XmlElement(ElementName="CampaignDisplayPriority", Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", DataType="int")]
        public int CampaignDisplayPriority
        {
            get
            {
                return this._campaigndisplaypriority;
            }
            set
            {
                this.CampaignDisplayPrioritySpecified = true;
                this._campaigndisplaypriority = value;
            }
        }

        [XmlElement(ElementName="CampaignGuid", Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", DataType="string")]
        public string CampaignGuid
        {
            get
            {
                return this._campaignguid;
            }
            set
            {
                this._campaignguid = value;
            }
        }

        [XmlElement(ElementName="CampaignName", Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", DataType="string")]
        public string CampaignName
        {
            get
            {
                return this._campaignname;
            }
            set
            {
                this._campaignname = value;
            }
        }

        [XmlElement(ElementName="CampaignType", Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05")]
        public Corillian.Marketing.Domain.CampaignType CampaignType
        {
            get
            {
                return this._campaigntype;
            }
            set
            {
                this._campaigntype = value;
            }
        }

        [XmlElement(ElementName="CreateDate", Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", DataType="dateTime")]
        public DateTime CreateDate
        {
            get
            {
                return this._createdate;
            }
            set
            {
                this.CreateDateSpecified = true;
                this._createdate = value;
            }
        }

        [XmlElement(ElementName="CreatedBy", Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", DataType="string")]
        public string CreatedBy
        {
            get
            {
                return this._createdby;
            }
            set
            {
                this._createdby = value;
            }
        }

        [XmlElement(ElementName="CurrentCampaignInstance", Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05")]
        public CampaignInstance CurrentCampaignInstance
        {
            get
            {
                return this._currentcampaigninstance;
            }
            set
            {
                this._currentcampaigninstance = value;
            }
        }

        [XmlElement(ElementName="Deleted", Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", DataType="boolean")]
        public bool Deleted
        {
            get
            {
                return this._deleted;
            }
            set
            {
                this.DeletedSpecified = true;
                this._deleted = value;
            }
        }

        [XmlElement(ElementName="DisplayingAdSpace", Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05")]
        public AdSpace DisplayingAdSpace
        {
            get
            {
                return this._displayingadspace;
            }
            set
            {
                this._displayingadspace = value;
            }
        }

        [XmlElement(ElementName="DisplayingCampaignContext", Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", DataType="string")]
        public string DisplayingCampaignContext
        {
            get
            {
                return this._displayingcampaigncontext;
            }
            set
            {
                this._displayingcampaigncontext = value;
            }
        }

        [XmlElement(ElementName="DisplayingComposition", Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05")]
        public CampaignInstanceCompositionMap DisplayingComposition
        {
            get
            {
                return this._displayingcomposition;
            }
            set
            {
                this._displayingcomposition = value;
            }
        }

        [XmlElement(ElementName="EffectiveDate", Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", DataType="dateTime")]
        public DateTime EffectiveDate
        {
            get
            {
                return this._effectivedate;
            }
            set
            {
                this.EffectiveDateSpecified = true;
                this._effectivedate = value;
            }
        }

        [XmlElement(ElementName="Fiid", Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", DataType="int")]
        public int Fiid
        {
            get
            {
                return this._fiid;
            }
            set
            {
                this.FiidSpecified = true;
                this._fiid = value;
            }
        }

        [XmlElement(ElementName="IsExported", Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", DataType="boolean")]
        public bool IsExported
        {
            get
            {
                return this._isexported;
            }
            set
            {
                this.IsExportedSpecified = true;
                this._isexported = value;
            }
        }

        [XmlElement(ElementName="IsImported", Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", DataType="boolean")]
        public bool IsImported
        {
            get
            {
                return this._isimported;
            }
            set
            {
                this.IsImportedSpecified = true;
                this._isimported = value;
            }
        }

        [XmlElement(ElementName="NewInImport", Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", DataType="boolean")]
        public bool NewInImport
        {
            get
            {
                return this._newinimport;
            }
            set
            {
                this.NewInImportSpecified = true;
                this._newinimport = value;
            }
        }

        [XmlElement(ElementName="RuleGuid", Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", DataType="string")]
        public string RuleGuid
        {
            get
            {
                return this._ruleguid;
            }
            set
            {
                this._ruleguid = value;
            }
        }

        [XmlElement(ElementName="State", Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", DataType="int")]
        public int State
        {
            get
            {
                return this._state;
            }
            set
            {
                this.StateSpecified = true;
                this._state = value;
            }
        }

        [XmlElement(ElementName="StateChangeDate", Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", DataType="dateTime")]
        public DateTime StateChangeDate
        {
            get
            {
                return this._statechangedate;
            }
            set
            {
                this.StateChangeDateSpecified = true;
                this._statechangedate = value;
            }
        }

        [XmlElement(ElementName="StateStatus", Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", DataType="int")]
        public int StateStatus
        {
            get
            {
                return this._statestatus;
            }
            set
            {
                this.StateStatusSpecified = true;
                this._statestatus = value;
            }
        }

        [XmlElement(ElementName="TerminationDate", Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", DataType="dateTime")]
        public DateTime TerminationDate
        {
            get
            {
                return this._terminationdate;
            }
            set
            {
                this.TerminationDateSpecified = true;
                this._terminationdate = value;
            }
        }

        [XmlElement(ElementName="WebPageId", Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", DataType="int")]
        public int WebPageId
        {
            get
            {
                return this._webpageid;
            }
            set
            {
                this.WebPageIdSpecified = true;
                this._webpageid = value;
            }
        }
    }
}

