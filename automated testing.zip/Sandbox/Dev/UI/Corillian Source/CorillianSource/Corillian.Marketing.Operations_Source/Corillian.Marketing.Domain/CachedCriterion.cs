namespace Corillian.Marketing.Domain
{
    using Corillian.Voyager.Common;
    using Corillian.Voyager.Common.Attributes;
    using System;
    using System.Xml.Serialization;

    [Serializable, XmlRoot(Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", ElementName="CachedCriterion"), XmlType(Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", TypeName="CachedCriterion")]
    public class CachedCriterion : IFormattable
    {
        private string _name;
        private string _type;
        private string _value;

        public static CachedCriterion Deserialize(string response)
        {
            return (CachedCriterion) ObjectFactory.DeserializeResponse(response, typeof(CachedCriterion), true);
        }

        public virtual string ToString(string format)
        {
            return FormattableObject.ToString(this, format, null);
        }

        public virtual string ToString(string format, IFormatProvider formatProvider)
        {
            if (format == null)
            {
                return base.ToString();
            }
            return FormattableObject.ToString(this, format, formatProvider);
        }

        [XmlElement(ElementName="Name", Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", DataType="string")]
        public string Name
        {
            get
            {
                return this._name;
            }
            set
            {
                this._name = value;
            }
        }

        [XmlElement(ElementName="Type", Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", DataType="string")]
        public string Type
        {
            get
            {
                return this._type;
            }
            set
            {
                this._type = value;
            }
        }

        [IgnoreWhenEmpty, XmlElement(ElementName="Value", Namespace="http://www.corillian.com/corillian/marketing/domain/2007/05", DataType="string")]
        public string Value
        {
            get
            {
                return this._value;
            }
            set
            {
                this._value = value;
            }
        }
    }
}

