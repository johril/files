namespace Corillian.Marketing.CampaignManager.WebControls
{
    using Corillian.Marketing.CampaignManager.Common;
    using Corillian.Marketing.Domain;
    using Corillian.Voyager.Common;
    using Corillian.Voyager.Web.Security;
    using System;
    using System.Threading;
    using System.Web;
    using System.Web.UI;
    using System.Web.UI.HtmlControls;
    using System.Web.UI.WebControls;

    [ToolboxData("<{0}:LogoutInterceptCampaignControl runat=\"server\" AdSpaceId=\"\" DestinationPage=\"\"></{0}:LogoutInterceptCampaignControl>")]
    public class LogoutInterceptCampaignControl : CampaignControlBase
    {
        private const string POPUP_JS_FUNCTION = "<script type='text/javascript' language='javascript'>\r\nfunction showCampaignTargetUrl(url, title, properties, navurl)\r\n{\r\n\tvar newwindow = window.open(url,title,properties);\r\n\tif (window.focus) \r\n\t{\r\n\t\tnewwindow.focus();\r\n\t}\r\n\tdocument.location.href = navurl;\r\n\treturn false;\r\n}\r\n</script>";

        static LogoutInterceptCampaignControl()
        {
            CampaignControlBase.logSvc = LoggingServiceFactory.GetService(typeof(LogoutInterceptCampaignControl));
        }

        private string GetButtonClickJS(Enumeration.CampaignInteraction campaignInteraction)
        {
            return string.Format("document.location.href = '{0}'; return false;", Common.GetClickTrackerUrl(this.GetClickTrackProperties(campaignInteraction)));
        }

        private string GetClickTrackProperties()
        {
            return this.GetClickTrackProperties(Enumeration.CampaignInteraction.ACCEPT);
        }

        private string GetClickTrackProperties(Enumeration.CampaignInteraction campaignInteraction)
        {
            string str = (campaignInteraction == Enumeration.CampaignInteraction.ACCEPT) ? base._cicMap.LinkId : this.DestinationPage;
            string format = "CampaignGuid={0}&Page={1}&cicId={2}&RuleGuid={3}&RuleInstanceGuid={4}&AdMediaGuid={5}&CampaignInstanceGuid={6}&AdUrl={7}&WebPageId={8}&InterceptResponse={9}&Id={10}&LogoutUrl={11}";
            return HttpUtility.UrlEncode(Common.Encrypt(string.Format(format, new object[] { base._campaign.CampaignGuid, Common.ResolvePageName(this.GetPageName, this.Page), base._cicMap.CampaignCompositionId, base._campaign.RuleGuid, base._campaign.CurrentCampaignInstance.RuleInstanceGuid, base._cicMap.AdMedia.AdMediaGuid, base._campaign.CurrentCampaignInstance.CampaignInstanceGuid, HttpUtility.UrlEncode(str), base._campaign.WebPageId, (int) campaignInteraction, this.CMCustomerId.ToString(), HttpUtility.UrlEncode(this.DestinationPage) }), Common.EncryptKey));
        }

        private string GetPopupCallJs(Corillian.Marketing.CampaignManager.WebControls.WindowProperties winProps, string clickTrackerUrl)
        {
            string str = string.Format("height={0},width={1},menubar={2},resizable={3},scrollbars={4},status={5},toolbar={6},location={7}", new object[] { winProps.Height, winProps.Width, this.GetYesNo(winProps.ShowMenuBar), this.GetYesNo(winProps.AllowWindowResize), this.GetYesNo(winProps.ShowScrollBar), this.GetYesNo(winProps.ShowStatusBar), this.GetYesNo(winProps.ShowToolbar), this.GetYesNo(winProps.ShowAddressBar) });
            return string.Format("javascript:showCampaignTargetUrl('{0}', '{1}', '{2}', '{3}');", new object[] { clickTrackerUrl, "_blank", str, this.DestinationPage });
        }

        private string GetYesNo(bool val)
        {
            if (!val)
            {
                return "no";
            }
            return "yes";
        }

        protected override void OnLoad(EventArgs e)
        {
            base.OnLoad(e);
            if ((this.Enabled && (HttpContext.Current != null)) && SiteSecurity.IsLoggedIn())
            {
                this.PopulateCampaign();
                this.RenderCampaign();
            }
        }

        protected override void OnPreRender(EventArgs e)
        {
            base.OnPreRender(e);
        }

        private void RegisterShowCampaignTargetUrlInPopupScriptBlock()
        {
            if (!this.Page.ClientScript.IsClientScriptBlockRegistered("ShowCampaignTargetUrlInPopup"))
            {
                this.Page.ClientScript.RegisterClientScriptBlock(base.GetType(), "ShowCampaignTargetUrlInPopup", "<script type='text/javascript' language='javascript'>\r\nfunction showCampaignTargetUrl(url, title, properties, navurl)\r\n{\r\n\tvar newwindow = window.open(url,title,properties);\r\n\tif (window.focus) \r\n\t{\r\n\t\tnewwindow.focus();\r\n\t}\r\n\tdocument.location.href = navurl;\r\n\treturn false;\r\n}\r\n</script>");
            }
        }

        protected internal virtual void RenderCampaign()
        {
            try
            {
                if (((base._campaign == null) || (base._cicMap == null)) || ((base._cicMap.AdMedia == null) || (base._cicMap.AdMedia.AdMediaGuid == null)))
                {
                    if (((this.DestinationPage != null) && (this.DestinationPage != string.Empty)) && this.RedirectEnabled)
                    {
                        this.Context.Response.Redirect(this.DestinationPage);
                    }
                }
                else
                {
                    this.RenderInterceptCampaignControl();
                }
            }
            catch (ThreadAbortException)
            {
            }
            catch (Exception exception)
            {
                CampaignControlBase.logSvc.Error("Error while rendering campaign", exception);
            }
        }

        private Table RenderInterceptButtons()
        {
            Table table = null;
            if ((base._cicMap != null) && (base._cicMap.InterceptDisplayConfig != null))
            {
                InterceptDisplayConfig interceptDisplayConfig = base._cicMap.InterceptDisplayConfig;
                table = new Table();
                table.CssClass = this.InterceptButtonsContainerCss;
                table.ID = "tblInterceptActions";
                TableRow row = new TableRow();
                if ((interceptDisplayConfig.RemaindText != null) && (interceptDisplayConfig.RemaindText != string.Empty))
                {
                    TableCell cell = new TableCell();
                    Button child = new Button();
                    child.ID = "btnRemindMeLater";
                    child.CssClass = this.InterceptButtonCss;
                    child.Text = HttpUtility.HtmlDecode(interceptDisplayConfig.RemaindText);
                    child.CommandName = "RemindMeLater";
                    child.Attributes.Add("onclick", this.GetButtonClickJS(Enumeration.CampaignInteraction.REMIND));
                    cell.Controls.Add(child);
                    row.Cells.Add(cell);
                }
                if ((interceptDisplayConfig.SupressText != null) && (interceptDisplayConfig.SupressText != string.Empty))
                {
                    TableCell cell2 = new TableCell();
                    Button button2 = new Button();
                    button2.ID = "btnSuppress";
                    button2.CssClass = this.InterceptButtonCss;
                    button2.Text = HttpUtility.HtmlDecode(interceptDisplayConfig.SupressText);
                    button2.Attributes.Add("onclick", this.GetButtonClickJS(Enumeration.CampaignInteraction.DECLINE));
                    button2.CommandName = "SuppressCampaign";
                    cell2.Controls.Add(button2);
                    row.Cells.Add(cell2);
                }
                if ((interceptDisplayConfig.ApplyText != null) && (interceptDisplayConfig.ApplyText != string.Empty))
                {
                    TableCell cell3 = new TableCell();
                    Button button3 = new Button();
                    button3.ID = "btnApply";
                    button3.CssClass = this.InterceptButtonCss;
                    button3.Text = HttpUtility.HtmlDecode(interceptDisplayConfig.ApplyText);
                    button3.CommandName = button3.CommandName + "ApplyForCampaign";
                    button3.CommandArgument = this.GetClickTrackProperties();
                    button3.Attributes.Add("onclick", this.GetButtonClickJS(Enumeration.CampaignInteraction.ACCEPT));
                    if ((((base._campaign != null) && (base._cicMap != null)) && (!Strings.IsNullOrEmpty(base._cicMap.LinkId) && (base._campaign.CurrentCampaignInstance != null))) && (base._campaign.CurrentCampaignInstance.TargetURLDisplay != null))
                    {
                        TargetUrlDisplay targetURLDisplay = base._campaign.CurrentCampaignInstance.TargetURLDisplay;
                        Corillian.Marketing.CampaignManager.WebControls.WindowProperties winProps = new Corillian.Marketing.CampaignManager.WebControls.WindowProperties(targetURLDisplay.Height, targetURLDisplay.Width, targetURLDisplay.WindowDisplayBitMask);
                        if (winProps.OpenInNewWindow)
                        {
                            this.RegisterShowCampaignTargetUrlInPopupScriptBlock();
                            string clickTrackerUrl = Common.GetClickTrackerUrl(this.GetClickTrackProperties());
                            button3.Attributes.Add("onclick", this.GetPopupCallJs(winProps, clickTrackerUrl) + " return false;");
                        }
                    }
                    cell3.Controls.Add(button3);
                    row.Cells.Add(cell3);
                }
                table.Rows.Add(row);
            }
            return table;
        }

        protected void RenderInterceptCampaignControl()
        {
            Panel child = new Panel();
            child.CssClass = this.CampaignContainerCss;
            child.ID = "pnlCamapaignContainer";
            Panel panel2 = new Panel();
            panel2.CssClass = this.InterceptAdMediaContainerCss;
            panel2.ID = "pnlAdMediaContainer";
            Label label = this.RenderTitle();
            if ((label != null) && (label.Text != string.Empty))
            {
                Panel panel3 = new Panel();
                panel3.CssClass = this.InterceptCampaignTitleCss;
                panel3.ID = "pnlInterceptCampaignTitle";
                panel3.Controls.Add(label);
                child.Controls.Add(panel3);
            }
            HtmlAnchor anchor = this.RenderTargetLink();
            Control control = base.RenderAdMedia();
            if (anchor == null)
            {
                panel2.Controls.Add(control);
            }
            else
            {
                anchor.Controls.Add(control);
                panel2.Controls.Add(anchor);
            }
            child.Controls.Add(panel2);
            Table table = this.RenderInterceptButtons();
            child.Controls.Add(table);
            this.Controls.Add(child);
        }

        private HtmlAnchor RenderTargetLink()
        {
            HtmlAnchor anchor = null;
            if (((base._campaign != null) && (base._cicMap != null)) && !Strings.IsNullOrEmpty(base._cicMap.LinkId))
            {
                string clickTrackerUrl = Common.GetClickTrackerUrl(this.GetClickTrackProperties());
                anchor = new HtmlAnchor();
                anchor.ID = "lnkTarget";
                anchor.HRef = clickTrackerUrl;
                if ((base._campaign.CurrentCampaignInstance != null) && (base._campaign.CurrentCampaignInstance.TargetURLDisplay != null))
                {
                    TargetUrlDisplay targetURLDisplay = base._campaign.CurrentCampaignInstance.TargetURLDisplay;
                    Corillian.Marketing.CampaignManager.WebControls.WindowProperties winProps = new Corillian.Marketing.CampaignManager.WebControls.WindowProperties(targetURLDisplay.Height, targetURLDisplay.Width, targetURLDisplay.WindowDisplayBitMask);
                    if (winProps.OpenInNewWindow)
                    {
                        this.RegisterShowCampaignTargetUrlInPopupScriptBlock();
                        anchor.HRef = this.GetPopupCallJs(winProps, clickTrackerUrl);
                    }
                }
            }
            return anchor;
        }

        private Label RenderTitle()
        {
            Label label = null;
            if (((base._cicMap != null) && (base._cicMap.InterceptDisplayConfig != null)) && (base._cicMap.InterceptDisplayConfig.InterceptDisplay != null))
            {
                Label label2 = new Label();
                label2.Text = base._cicMap.InterceptDisplayConfig.InterceptDisplay.Title;
                label = label2;
            }
            return label;
        }

        public virtual string DestinationPage
        {
            get
            {
                return (this.ViewState["DestinationPage"] as string);
            }
            set
            {
                this.ViewState["DestinationPage"] = value;
            }
        }

        public virtual string InterceptAdMediaContainerCss
        {
            get
            {
                if (this.ViewState["InterceptAdMediaContainerCss"] == null)
                {
                    return string.Empty;
                }
                return (this.ViewState["InterceptAdMediaContainerCss"] as string);
            }
            set
            {
                this.ViewState["InterceptAdMediaContainerCss"] = value;
            }
        }

        public virtual string InterceptButtonCss
        {
            get
            {
                if (this.ViewState["InterceptButtonCss"] == null)
                {
                    return string.Empty;
                }
                return (this.ViewState["InterceptButtonCss"] as string);
            }
            set
            {
                this.ViewState["InterceptButtonCss"] = value;
            }
        }

        public virtual string InterceptButtonsContainerCss
        {
            get
            {
                if (this.ViewState["InterceptButtonsContainerCss"] == null)
                {
                    return string.Empty;
                }
                return (this.ViewState["InterceptButtonsContainerCss"] as string);
            }
            set
            {
                this.ViewState["InterceptButtonsContainerCss"] = value;
            }
        }

        public virtual string InterceptCampaignTitleCss
        {
            get
            {
                if (this.ViewState["InterceptCampaignTitleCss"] == null)
                {
                    return string.Empty;
                }
                return (this.ViewState["InterceptCampaignTitleCss"] as string);
            }
            set
            {
                this.ViewState["InterceptCampaignTitleCss"] = value;
            }
        }

        public virtual bool RedirectEnabled
        {
            get
            {
                return Convert.ToBoolean(this.ViewState["RedirectEnabled"]);
            }
            set
            {
                this.ViewState["RedirectEnabled"] = value;
            }
        }
    }
}

