namespace Corillian.Marketing.CampaignManager.WebControls
{
    using Corillian.Marketing.Domain;
    using Corillian.Marketing.Messages;
    using Corillian.Marketing.Operations;
    using Corillian.Voyager.Common;
    using System;
    using System.Collections;
    using System.ComponentModel;
    using System.Web.UI;
    using System.Web.UI.WebControls;

    [ParseChildren(true), ToolboxData("<{0}:CampaignControlManager runat=\"server\"></{0}:CampaignControlManager>"), PersistChildren(false)]
    public class CampaignControlManager : WebControl, INamingContainer
    {
        private ControlConnectionCollection _controlConnections;
        private PageLookup _getPageName;
        private static ILoggingService _logSvc;

        static CampaignControlManager()
        {
            if (_logSvc == null)
            {
                _logSvc = LoggingServiceFactory.GetService(typeof(CampaignControlManager));
            }
        }

        public CampaignControlManager()
        {
            this._controlConnections = new ControlConnectionCollection();
        }

        public CampaignControlManager(ILoggingService logSvc)
        {
            this._controlConnections = new ControlConnectionCollection();
            _logSvc = logSvc;
        }

        private void FillControls(ArrayList controlCollection, CampaignCollection cColl)
        {
            if ((cColl == null) || (cColl.Count == 0))
            {
                _logSvc.Debug("No Ads are returned.");
            }
            else if ((controlCollection != null) && (controlCollection.Count > 0))
            {
                for (int i = 0; i < controlCollection.Count; i++)
                {
                    CampaignControl control = controlCollection[i] as CampaignControl;
                    if (control != null)
                    {
                        Campaign campaign;
                        if (control.AdSpaceId.Trim().Length > 0)
                        {
                            campaign = this.FindCampaignBasedOnDisplayingAdSpaceAndContext(cColl, Convert.ToInt32(control.AdSpaceId), control.CampaignContext);
                        }
                        else
                        {
                            campaign = this.FindCampaignBasedOnDisplayingAdSpaceAndContext(cColl, control.AdSpaceName, control.CampaignContext);
                        }
                        control.PopulateCampaign(campaign);
                    }
                }
            }
        }

        private Campaign FindCampaignBasedOnDisplayingAdSpaceAndContext(CampaignCollection cColl, int adSpaceId, string campaignContext)
        {
            if ((cColl != null) && (cColl.Count > 0))
            {
                foreach (Campaign campaign2 in cColl)
                {
                    if ((campaign2.DisplayingAdSpace.AdSpaceId == adSpaceId) && (campaign2.DisplayingCampaignContext == campaignContext))
                    {
                        return campaign2;
                    }
                }
            }
            return null;
        }

        private Campaign FindCampaignBasedOnDisplayingAdSpaceAndContext(CampaignCollection cColl, string adSpaceName, string campaignContext)
        {
            if ((cColl != null) && (cColl.Count > 0))
            {
                foreach (Campaign campaign2 in cColl)
                {
                    if ((campaign2.DisplayingAdSpace.AdSpaceName == adSpaceName) && (campaign2.DisplayingCampaignContext == campaignContext))
                    {
                        return campaign2;
                    }
                }
            }
            return null;
        }

        private CampaignControl FindCampaignControl(string id)
        {
            Control control = null;
            CampaignControl control2 = null;
            control = this.FindControlRecursively(this.Parent, id);
            if (control == null)
            {
                control = this.FindControlRecursively(this.Page, id);
            }
            if (control != null)
            {
                control2 = control as CampaignControl;
            }
            return control2;
        }

        private Control FindControlRecursively(Control root, string id)
        {
            Control control = root;
            if (control.ID == id)
            {
                return control;
            }
            foreach (Control control2 in control.Controls)
            {
                Control control3 = this.FindControlRecursively(control2, id);
                if (control3 != null)
                {
                    return control3;
                }
            }
            return null;
        }

        public void LoadCampaigns()
        {
            try
            {
                if (this.ControlConnections.Count == 0)
                {
                    _logSvc.Debug("ControlConnections is empty.");
                }
                else
                {
                    ArrayList controlCollection = new ArrayList();
                    foreach (ControlConnection connection in this.ControlConnections)
                    {
                        CampaignControl control = null;
                        string id = string.Empty;
                        id = connection.ControlId;
                        switch (id)
                        {
                            case null:
                            case "":
                                _logSvc.Error("ControlId needs to be specified in the ControlConnections");
                                throw new InvalidOperationException("In the ControlConnections controlId cannot be empty.");
                        }
                        control = this.FindCampaignControl(id);
                        if (control == null)
                        {
                            _logSvc.Error(string.Format("Campaign Control with the ControlId {0} could not be found", id));
                            throw new InvalidOperationException("In the ControlConnections please specify a controlId that is valid.");
                        }
                        if (!control.Enabled)
                        {
                            _logSvc.Debug(string.Format("Campaign Control with the ControlId {0} is disabled", id));
                            continue;
                        }
                        if (((control.AdSpaceId.Trim().Length == 0) || (Convert.ToInt32(control.AdSpaceId.Trim()) < 0)) && ((control.AdSpaceName == null) || (control.AdSpaceName.Trim().Length == 0)))
                        {
                            throw new InvalidOperationException(string.Format("The AdSpaceId or AdSpaceName property for the control {0} must be valid.  Please set either one of the property.", control.ID));
                        }
                        controlCollection.Add(control);
                    }
                    if (controlCollection.Count == 0)
                    {
                        _logSvc.Debug("No Campaign controls found.");
                    }
                    else
                    {
                        CampaignSpaceCollection spaces = new CampaignSpaceCollection();
                        for (int i = 0; i < controlCollection.Count; i++)
                        {
                            CampaignControl control2 = controlCollection[i] as CampaignControl;
                            if (control2 != null)
                            {
                                CampaignSpace space = new CampaignSpace();
                                if ((control2.AdSpaceId.Trim().Length > 0) && (Convert.ToInt32(control2.AdSpaceId.Trim()) > -1))
                                {
                                    space.AdSpaceId = Convert.ToInt32(control2.AdSpaceId);
                                    space.AdSpaceName = string.Empty;
                                }
                                else
                                {
                                    space.AdSpaceName = control2.AdSpaceName;
                                    space.AdSpaceId = -1;
                                }
                                space.CampaignContext = control2.CampaignContext;
                                space.PageName = Common.ResolvePageName(this.GetPageName, this.Page);
                                spaces.Add(space);
                            }
                        }
                        MarketingServiceProxy proxy = new MarketingServiceProxy();
                        GetMultipleCampaignsForDisplayRequest req = new GetMultipleCampaignsForDisplayRequest();
                        req.CampaignSpaceList = spaces;
                        GetMultipleCampaignsForDisplayResponse multipleCampaignsForDisplay = proxy.GetMultipleCampaignsForDisplay(req);
                        if (!multipleCampaignsForDisplay.Header.Success)
                        {
                            _logSvc.Error(multipleCampaignsForDisplay.Header.ResultMessage);
                            throw new Exception(multipleCampaignsForDisplay.Header.ResultMessage);
                        }
                        this.FillControls(controlCollection, multipleCampaignsForDisplay.CampaignList);
                    }
                }
            }
            catch (Exception exception)
            {
                _logSvc.Error("Error while displaying campaigns through campaign control manager", exception);
            }
        }

        [PersistenceMode(PersistenceMode.InnerProperty), DesignerSerializationVisibility(DesignerSerializationVisibility.Visible)]
        public ControlConnectionCollection ControlConnections
        {
            get
            {
                return this._controlConnections;
            }
            set
            {
                this._controlConnections = value;
            }
        }

        public virtual PageLookup GetPageName
        {
            get
            {
                return this._getPageName;
            }
            set
            {
                this._getPageName = value;
            }
        }
    }
}

