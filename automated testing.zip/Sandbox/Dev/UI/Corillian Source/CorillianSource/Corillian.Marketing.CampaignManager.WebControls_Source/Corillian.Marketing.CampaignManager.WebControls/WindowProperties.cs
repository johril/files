namespace Corillian.Marketing.CampaignManager.WebControls
{
    using System;

    public class WindowProperties
    {
        private WindowFlags _flags;
        private int _height;
        private int _width;

        public WindowProperties(int height, int width, int flags)
        {
            this._height = height;
            this._width = width;
            this._flags = (WindowFlags) flags;
        }

        public WindowProperties(int height, int width, bool openInNewWindow, bool allowResize, bool showMenuBar, bool showAddressBar, bool showToolBar, bool showStatusBar, bool showScrollBar)
        {
            this._height = height;
            this._width = width;
            this.OpenInNewWindow = openInNewWindow;
            this.AllowWindowResize = allowResize;
            this.ShowMenuBar = showMenuBar;
            this.ShowAddressBar = showAddressBar;
            this.ShowToolbar = showToolBar;
            this.ShowStatusBar = showStatusBar;
            this.ShowScrollBar = showScrollBar;
        }

        public bool AllowWindowResize
        {
            get
            {
                return Convert.ToBoolean(this._flags & WindowFlags.AllowWindowResize);
            }
            set
            {
                if (value)
                {
                    this._flags |= WindowFlags.AllowWindowResize;
                }
                else
                {
                    this._flags &= ~WindowFlags.AllowWindowResize;
                }
            }
        }

        public int Height
        {
            get
            {
                return this._height;
            }
            set
            {
                this._height = value;
            }
        }

        public bool OpenInNewWindow
        {
            get
            {
                return Convert.ToBoolean(this._flags & WindowFlags.ShowInNewWindow);
            }
            set
            {
                if (value)
                {
                    this._flags |= WindowFlags.ShowInNewWindow;
                }
                else
                {
                    this._flags &= ~WindowFlags.ShowInNewWindow;
                }
            }
        }

        public bool ShowAddressBar
        {
            get
            {
                return Convert.ToBoolean(this._flags & WindowFlags.ShowAddressBar);
            }
            set
            {
                if (value)
                {
                    this._flags |= WindowFlags.ShowAddressBar;
                }
                else
                {
                    this._flags &= ~WindowFlags.ShowAddressBar;
                }
            }
        }

        public bool ShowMenuBar
        {
            get
            {
                return Convert.ToBoolean(this._flags & WindowFlags.ShowMenuBar);
            }
            set
            {
                if (value)
                {
                    this._flags |= WindowFlags.ShowMenuBar;
                }
                else
                {
                    this._flags &= ~WindowFlags.ShowMenuBar;
                }
            }
        }

        public bool ShowScrollBar
        {
            get
            {
                return Convert.ToBoolean(this._flags & WindowFlags.ShowScrollBar);
            }
            set
            {
                if (value)
                {
                    this._flags |= WindowFlags.ShowScrollBar;
                }
                else
                {
                    this._flags &= ~WindowFlags.ShowScrollBar;
                }
            }
        }

        public bool ShowStatusBar
        {
            get
            {
                return Convert.ToBoolean(this._flags & WindowFlags.ShowStatusBar);
            }
            set
            {
                if (value)
                {
                    this._flags |= WindowFlags.ShowStatusBar;
                }
                else
                {
                    this._flags &= ~WindowFlags.ShowStatusBar;
                }
            }
        }

        public bool ShowToolbar
        {
            get
            {
                return Convert.ToBoolean(this._flags & WindowFlags.ShowToolbar);
            }
            set
            {
                if (value)
                {
                    this._flags |= WindowFlags.ShowToolbar;
                }
                else
                {
                    this._flags &= ~WindowFlags.ShowToolbar;
                }
            }
        }

        public int Value
        {
            get
            {
                return (int) this._flags;
            }
            set
            {
                this._flags = (WindowFlags) value;
            }
        }

        public int Width
        {
            get
            {
                return this._width;
            }
            set
            {
                this._width = value;
            }
        }
    }
}

