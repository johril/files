namespace Corillian.Marketing.CampaignManager.WebControls
{
    using System;
    using System.ComponentModel;
    using System.Web.UI;

    [ToolboxData("<{0}:ControlConnection runat=server></{0}:ControlConnection>")]
    public class ControlConnection
    {
        private string _controlId = string.Empty;

        [Browsable(true), Description("The ControlId of the CampaignManagerAd control."), NotifyParentProperty(true)]
        public string ControlId
        {
            get
            {
                return this._controlId;
            }
            set
            {
                this._controlId = value;
            }
        }
    }
}

