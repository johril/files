namespace Corillian.Marketing.CampaignManager.WebControls
{
    using Corillian.Marketing.Domain;
    using Corillian.Voyager.Common;
    using Corillian.Voyager.Web.Security;
    using System;
    using System.Threading;
    using System.Web;
    using System.Web.UI;
    using System.Web.UI.HtmlControls;
    using System.Web.UI.WebControls;

    [ToolboxData("<{0}:CampaignControl runat=\"server\" AdSpaceId=\"\"></{0}:CampaignControl>")]
    public class CampaignControl : CampaignControlBase
    {
        static CampaignControl()
        {
            CampaignControlBase.logSvc = LoggingServiceFactory.GetService(typeof(CampaignControl));
        }

        protected override void OnLoad(EventArgs e)
        {
            base.OnLoad(e);
            if ((this.Enabled && !this.HasManager) && ((HttpContext.Current != null) && SiteSecurity.IsLoggedIn()))
            {
                if (this.Page.IsPostBack)
                {
                    base._campaign = (Campaign) this.ViewState["Campaign"];
                }
                if (base._campaign == null)
                {
                    this.PopulateCampaign();
                    this.RenderCampaign();
                }
                else
                {
                    this.PopulateCampaign(base._campaign);
                }
            }
        }

        protected override void OnPreRender(EventArgs e)
        {
            base.OnPreRender(e);
            if (base._campaign != null)
            {
                this.ViewState["Campaign"] = base._campaign;
            }
        }

        protected internal virtual void PopulateCampaign(Campaign campaign)
        {
            if (campaign != null)
            {
                base._campaign = campaign;
                base._cicMap = campaign.DisplayingComposition;
                base._adSpace = campaign.DisplayingAdSpace;
                this.RenderCampaign();
            }
        }

        protected internal virtual void RenderCampaign()
        {
            try
            {
                if (((base._campaign != null) && (base._cicMap != null)) && ((base._cicMap.AdMedia != null) && (base._cicMap.AdMedia.AdMediaGuid != null)))
                {
                    this.RenderControls();
                }
            }
            catch (ThreadAbortException)
            {
            }
            catch (Exception exception)
            {
                CampaignControlBase.logSvc.Error("Error while rendering campaign", exception);
            }
        }

        private void RenderControls()
        {
            Panel child = new Panel();
            child.CssClass = this.CampaignContainerCss;
            child.ID = "pnlCamapaignContainer";
            child.Width = Unit.Pixel(base._adSpace.Width);
            child.Height = Unit.Pixel(base._adSpace.Height);
            HtmlAnchor anchor = base.RenderTargetLink();
            Control control = base.RenderAdMedia();
            if (anchor == null)
            {
                child.Controls.Add(control);
            }
            else
            {
                anchor.Controls.Add(control);
                child.Controls.Add(anchor);
            }
            this.Controls.Add(child);
        }
    }
}

