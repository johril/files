namespace Corillian.Marketing.CampaignManager.WebControls
{
    using System;
    using System.Runtime.CompilerServices;
    using System.Web.UI.WebControls;

    public delegate void InterceptActionEventHandler(object sender, CommandEventArgs e);
}

