namespace Corillian.Marketing.CampaignManager.WebControls
{
    using System;
    using System.Reflection;

    public interface IControlConnectionList : IControlConnectionCollection
    {
        int Add(ControlConnection value);
        void Clear();
        bool Contains(ControlConnection value);
        int IndexOf(ControlConnection value);
        void Insert(int index, ControlConnection value);
        void Remove(ControlConnection value);
        void RemoveAt(int index);

        bool IsFixedSize { get; }

        bool IsReadOnly { get; }

        ControlConnection this[int index] { get; set; }
    }
}

