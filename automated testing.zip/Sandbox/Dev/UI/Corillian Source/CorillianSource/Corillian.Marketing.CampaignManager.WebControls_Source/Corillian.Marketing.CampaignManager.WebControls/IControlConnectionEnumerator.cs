namespace Corillian.Marketing.CampaignManager.WebControls
{
    using System;

    public interface IControlConnectionEnumerator
    {
        bool MoveNext();
        void Reset();

        ControlConnection Current { get; }
    }
}

