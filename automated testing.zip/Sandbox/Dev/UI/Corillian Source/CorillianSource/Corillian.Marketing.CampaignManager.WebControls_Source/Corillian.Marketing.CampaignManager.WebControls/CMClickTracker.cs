namespace Corillian.Marketing.CampaignManager.WebControls
{
    using Corillian.Marketing.Domain;
    using Corillian.Marketing.Messages;
    using Corillian.Marketing.Operations;
    using Corillian.Voyager.Common;
    using Corillian.Voyager.ExecutionServices.Client;
    using Corillian.Voyager.ExecutionServices.Client.Configuration;
    using System;
    using System.Collections.Specialized;
    using System.Threading;
    using System.Web;

    public class CMClickTracker : IHttpHandler
    {
        public const string DefaultEndpointUrl = "CMClickTracker.ashx";
        private static ILoggingService logSvc = LoggingServiceFactory.GetService(typeof(CMClickTracker));

        public virtual void ProcessRequest(HttpContext context)
        {
            try
            {
                string textToDecrypt = context.Request.QueryString["token"];
                string[] strArray = Common.Decrypt(textToDecrypt, Common.EncryptKey).Split(new char[] { '&' });
                NameValueCollection values = new NameValueCollection(13);
                foreach (string str3 in strArray)
                {
                    string[] strArray2 = str3.Split(new char[] { '=' });
                    values[strArray2[0]] = strArray2[1];
                }
                string s = values["CampaignGuid"];
                string str5 = values["Page"];
                string str6 = HttpUtility.UrlDecode(values["AdUrl"]);
                long num = long.Parse(values["cicId"]);
                string str7 = values["CampaignInstanceGuid"];
                string str8 = values["RuleGuid"];
                string str9 = values["RuleInstanceGuid"];
                string str10 = values["AdMediaGuid"];
                string str11 = values["InterceptResponse"];
                string str12 = values["Id"];
                int num2 = Convert.ToInt32(values["webPageId"]);
                string str13 = HttpUtility.UrlDecode(values["LogoutUrl"]);
                if (Strings.IsNullOrEmpty(s))
                {
                    logSvc.Error("CMClickTracker.ProcessRequest() - campaign guid must not be blank.");
                }
                else
                {
                    MarketingServiceProxy proxy = new MarketingServiceProxy();
                    if (Strings.IsNullOrEmpty(str11))
                    {
                        LogCampaignCustomerInteractionRequest req = new LogCampaignCustomerInteractionRequest();
                        req.CampaignCompositionId = num;
                        req.CampaignInstanceGuid = str7;
                        req.RuleGuid = str8;
                        req.RuleInstanceGuid = str9;
                        req.AdMediaGuid = str10;
                        req.WebPageName = str5;
                        req.WebPageId = num2;
                        proxy.LogCampaignCustomerInteraction(req);
                    }
                    else
                    {
                        VoyagerService voyagerService = VoyagerService.GetVoyagerService("MarketingServiceProxy");
                        string sessionID = voyagerService.CreateSession(Guid.NewGuid().ToString(), SiteConfig.GetSiteConfig().FI);
                        try
                        {
                            if (Convert.ToInt16(str11) == 1)
                            {
                                LogCampaignCustomerInteractionHostDirectRequest request2 = new LogCampaignCustomerInteractionHostDirectRequest();
                                request2.CampaignCompositionId = num;
                                request2.CampaignInstanceGuid = str7;
                                request2.RuleGuid = str8;
                                request2.RuleInstanceGuid = str9;
                                request2.AdMediaGuid = str10;
                                request2.WebPageName = str5;
                                request2.WebPageId = num2;
                                request2.CMCustomerId = Convert.ToInt64(str12);
                                request2.SubTrx = "CMLogCampaignCustomerInteraction";
                                proxy.LogCampaignCustomerInteractionHostDirect(request2, sessionID, SiteConfig.GetSiteConfig().FI);
                            }
                            LogInterceptCampaignCustomerInteractionHostDirectRequest request3 = new LogInterceptCampaignCustomerInteractionHostDirectRequest();
                            request3.CampaignGuid = s;
                            request3.InterceptActionType = Convert.ToInt16(str11);
                            request3.SubTrx = "CMLogInterceptCampaignCustomerInteraction";
                            request3.CMCustomerId = Convert.ToInt64(str12);
                            Campaign campaign = new Campaign();
                            campaign.CurrentCampaignInstance = new CampaignInstance();
                            campaign.CurrentCampaignInstance.CampaignInstanceGuid = str7;
                            campaign.CurrentCampaignInstance.RuleInstanceGuid = str9;
                            campaign.DisplayingComposition = new CampaignInstanceCompositionMap();
                            campaign.DisplayingComposition.CampaignCompositionId = num;
                            campaign.DisplayingComposition.AdMedia = new AdMedia();
                            campaign.DisplayingComposition.AdMedia.AdMediaGuid = str10;
                            campaign.RuleGuid = str8;
                            request3.Campaign = campaign;
                            proxy.LogInterceptCampaignCustomerInteractionHostDirect(request3, sessionID, SiteConfig.GetSiteConfig().FI);
                        }
                        finally
                        {
                            if (!Strings.IsNullOrEmpty(sessionID))
                            {
                                voyagerService.DeleteSession(sessionID, SiteConfig.GetSiteConfig().FI);
                            }
                        }
                    }
                }
                string str15 = Strings.IsNullOrEmpty(str6) ? str13 : str6;
                context.Response.Redirect(HttpUtility.HtmlDecode(str15));
            }
            catch (ThreadAbortException)
            {
            }
            catch (Exception exception)
            {
                logSvc.Error("Error while handling click through", exception);
            }
        }

        public virtual bool IsReusable
        {
            get
            {
                return false;
            }
        }
    }
}

