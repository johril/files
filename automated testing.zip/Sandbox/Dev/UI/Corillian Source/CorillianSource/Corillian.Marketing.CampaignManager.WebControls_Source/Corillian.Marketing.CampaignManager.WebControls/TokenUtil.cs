namespace Corillian.Marketing.CampaignManager.WebControls
{
    using System;
    using System.IO;
    using System.Security.Cryptography;
    using System.Text;

    public class TokenUtil
    {
        private byte[] key = new byte[0x10];

        public TokenUtil(string encryptionKey)
        {
            this.key = Convert.FromBase64String(encryptionKey);
        }

        public string AesDecrypt(string value)
        {
            new ASCIIEncoding();
            RijndaelManaged managed = new RijndaelManaged();
            byte[] destinationArray = new byte[0x10];
            byte[] sourceArray = Convert.FromBase64String(value);
            Array.Copy(sourceArray, sourceArray.Length - 0x10, destinationArray, 0, 0x10);
            ICryptoTransform transform = managed.CreateDecryptor(this.key, destinationArray);
            MemoryStream stream = new MemoryStream(sourceArray, 0, sourceArray.Length - 0x10);
            CryptoStream stream2 = new CryptoStream(stream, transform, CryptoStreamMode.Read);
            string str = new StreamReader(stream2).ReadToEnd();
            stream2.Close();
            return str;
        }

        public string AesEncrypt(string value)
        {
            ASCIIEncoding encoding = new ASCIIEncoding();
            RijndaelManaged managed = new RijndaelManaged();
            managed.GenerateIV();
            byte[] iV = managed.IV;
            ICryptoTransform transform = managed.CreateEncryptor(this.key, iV);
            MemoryStream stream = new MemoryStream();
            CryptoStream stream2 = new CryptoStream(stream, transform, CryptoStreamMode.Write);
            byte[] bytes = encoding.GetBytes(value);
            stream2.Write(bytes, 0, bytes.Length);
            stream2.FlushFinalBlock();
            stream.Write(iV, 0, 0x10);
            byte[] inArray = stream.ToArray();
            return Convert.ToBase64String(inArray, 0, inArray.Length);
        }

        public byte[] EncryptionKey
        {
            get
            {
                return this.key;
            }
            set
            {
                this.key = value;
            }
        }
    }
}

