namespace Corillian.Marketing.CampaignManager.WebControls
{
    using Corillian.Marketing.Domain;
    using Corillian.Marketing.Messages;
    using Corillian.Marketing.Operations;
    using Corillian.Voyager.Common;
    using System;
    using System.Runtime.CompilerServices;
    using System.Text;
    using System.Web;
    using System.Web.UI;
    using System.Web.UI.HtmlControls;
    using System.Web.UI.WebControls;

    public abstract class CampaignControlBase : WebControl, INamingContainer
    {
        internal AdSpace _adSpace;
        internal Campaign _campaign;
        internal CampaignInstanceCompositionMap _cicMap;
        private PageLookup _getPageName;
        [CompilerGenerated]
        //private long <CMCustomerId>k__BackingField;
        internal static ILoggingService logSvc;
        private const string POPUP_JS_FUNCTION = "<script type='text/javascript' language='javascript'>\r\nfunction showCampaignTargetUrl(url, title, properties)\r\n{\r\n\tvar newwindow = window.open(url,title,properties);\r\n\tif (window.focus) \r\n\t{\r\n\t\tnewwindow.focus();\r\n\t}\r\n\t//return true;\r\n}\r\n</script>";
        private const string SWF_MIMETYPE = "application/x-shockwave-flash";

        protected CampaignControlBase()
        {
        }

        internal string GetClickTrackProperties()
        {
            string format = "CampaignGuid={0}&Page={1}&cicId={2}&RuleGuid={3}&RuleInstanceGuid={4}&AdMediaGuid={5}&CampaignInstanceGuid={6}&AdUrl={7}&WebPageId={8}";
            return HttpUtility.UrlEncode(Common.Encrypt(string.Format(format, new object[] { this._campaign.CampaignGuid, Common.ResolvePageName(this.GetPageName, this.Page), this._cicMap.CampaignCompositionId, this._campaign.RuleGuid, this._campaign.CurrentCampaignInstance.RuleInstanceGuid, this._cicMap.AdMedia.AdMediaGuid, this._campaign.CurrentCampaignInstance.CampaignInstanceGuid, HttpUtility.UrlEncode(this._cicMap.LinkId), this._campaign.WebPageId }), Common.EncryptKey));
        }

        internal string GetPopupCallJs(WindowProperties winProps, string clickTrackerUrl)
        {
            string str = string.Format("height={0},width={1},menubar={2},resizable={3},scrollbars={4},status={5},toolbar={6},location={7}", new object[] { winProps.Height, winProps.Width, this.GetYesNo(winProps.ShowMenuBar), this.GetYesNo(winProps.AllowWindowResize), this.GetYesNo(winProps.ShowScrollBar), this.GetYesNo(winProps.ShowStatusBar), this.GetYesNo(winProps.ShowToolbar), this.GetYesNo(winProps.ShowAddressBar) });
            return string.Format("javascript:showCampaignTargetUrl('{0}', '{1}', '{2}');", clickTrackerUrl, "_blank", str);
        }

        private string GetSwfMarkup(string id, string width, string height, string mediaName)
        {
            return string.Format("<object classid='clsid:D27CDB6E-AE6D-11cf-96B8-444553540000' codebase='https://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=6,0,40,0'\r\n\t\t\t\t\t\t\t\t\twidth='{1}' height='{2}' id='swfCtrl{0}' mediaName='{3}' viewastext>\r\n\t\t\t\t\t\t\t\t\t<param name=movie value='ImageHandler.ashx?id={0}'>\r\n\t\t\t\t\t\t\t\t\t<param name=quality value=high>\r\n\t\t\t\t\t\t\t\t\t<embed src='ImageHandler.ashx?id={0}' quality=high width='{1}' height='{2}'\r\n\t\t\t\t\t\t\t\t\tname='swfCtrl{0}' align='' type='application/x-shockwave-flash'\r\n\t\t\t\t\t\t\t\t\tpluginspage='https://www.macromedia.com/go/getflashplayer'>\r\n\t\t\t\t\t\t\t\t\t</embed>\r\n\t\t\t\t\t\t\t\t\t</object>", new object[] { id, width, height, mediaName });
        }

        private string GetTextAdMediaContent(string adMediaGuid)
        {
            string str = string.Empty;
            try
            {
                MarketingServiceProxy proxy = new MarketingServiceProxy();
                GetAdMediaContentRequest req = new GetAdMediaContentRequest();
                req.AdMediaGuid = adMediaGuid;
                GetAdMediaContentResponse adMediaContent = proxy.GetAdMediaContent(req);
                if (!adMediaContent.Header.Success)
                {
                    logSvc.Error("Error while fetching text ad media content, Error:" + adMediaContent.Header.Error);
                    return str;
                }
                str = new UnicodeEncoding().GetString(adMediaContent.AdContent.Content);
            }
            catch (Exception exception)
            {
                logSvc.Error("Error while fetching text ad media content", exception);
            }
            return str;
        }

        private string GetYesNo(bool val)
        {
            if (!val)
            {
                return "no";
            }
            return "yes";
        }

        protected virtual void PopulateCampaign()
        {
            int num = 0;
            if ((this.AdSpaceId == null) || (this.AdSpaceId.Trim().Length == 0))
            {
                if ((this.AdSpaceName == null) || (this.AdSpaceName.Trim().Length == 0))
                {
                    throw new InvalidOperationException("The AdSpaceId or AdSpaceName property is required.  Please set either one of the property.");
                }
            }
            else
            {
                num = 1;
            }
            try
            {
                MarketingServiceProxy proxy = new MarketingServiceProxy();
                GetSingleCampaignForDisplayRequest req = new GetSingleCampaignForDisplayRequest();
                if (num == 1)
                {
                    req.AdSpaceId = Convert.ToInt32(this.AdSpaceId);
                    req.AdSpaceName = string.Empty;
                }
                else
                {
                    req.AdSpaceName = this.AdSpaceName;
                    req.AdSpaceId = -1;
                }
                req.PageName = Common.ResolvePageName(this.GetPageName, this.Page);
                req.CampaignContext = this.CampaignContext;
                GetSingleCampaignForDisplayResponse singleCampaignForDisplay = proxy.GetSingleCampaignForDisplay(req);
                if (!singleCampaignForDisplay.Header.Success)
                {
                    logSvc.Error(singleCampaignForDisplay.Header.ResultMessage);
                }
                else if ((singleCampaignForDisplay.Campaign != null) && !Strings.IsNullOrEmpty(singleCampaignForDisplay.Campaign.CampaignName))
                {
                    this._campaign = singleCampaignForDisplay.Campaign;
                    this._adSpace = singleCampaignForDisplay.Campaign.DisplayingAdSpace;
                    this.CMCustomerId = singleCampaignForDisplay.CustomerId;
                    if (singleCampaignForDisplay.Campaign.DisplayingComposition != null)
                    {
                        this._cicMap = singleCampaignForDisplay.Campaign.DisplayingComposition;
                    }
                }
            }
            catch (Exception exception)
            {
                logSvc.Error("Error while fetching campaign for display.", exception);
            }
        }

        internal void RegisterShowCampaignTargetUrlInPopupScriptBlock()
        {
            if (!this.Page.ClientScript.IsClientScriptBlockRegistered("ShowCampaignTargetUrlInPopup"))
            {
                this.Page.ClientScript.RegisterClientScriptBlock(base.GetType(), "ShowCampaignTargetUrlInPopup", "<script type='text/javascript' language='javascript'>\r\nfunction showCampaignTargetUrl(url, title, properties)\r\n{\r\n\tvar newwindow = window.open(url,title,properties);\r\n\tif (window.focus) \r\n\t{\r\n\t\tnewwindow.focus();\r\n\t}\r\n\t//return true;\r\n}\r\n</script>");
            }
        }

        internal Control RenderAdMedia()
        {
            Control control = null;
            if (((this._cicMap != null) && (this._cicMap.AdMedia != null)) && (this._adSpace != null))
            {
                if (this._cicMap.AdMedia.AdMediaType == 3)
                {
                    HtmlGenericControl control2 = new HtmlGenericControl("div");
                    control2.InnerHtml = this.GetTextAdMediaContent(this._cicMap.AdMedia.AdMediaGuid);
                    control2.ID = "divTextAdMedia";
                    return control2;
                }
                if (this._cicMap.AdMedia.AdMediaType == 2)
                {
                    LiteralControl control3 = new LiteralControl(this.GetSwfMarkup(this._cicMap.AdMedia.AdMediaGuid, this._adSpace.Width.ToString(), this._adSpace.Height.ToString(), this._cicMap.AdMedia.AdMediaName));
                    control3.ID = "ltrlFlashAdMedia";
                    return control3;
                }
                if (this._cicMap.AdMedia.AdMediaType == 1)
                {
                    Image image = new Image();
                    image.Width = Unit.Pixel(this._adSpace.Width);
                    image.Height = Unit.Pixel(this._adSpace.Height);
                    image.ImageUrl = string.Format("ImageHandler.ashx?Id={0}", this._cicMap.AdMedia.AdMediaGuid);
                    image.AlternateText = HttpUtility.HtmlDecode(this._campaign.CampaignName);
                    image.ID = "imgAdMedia";
                    image.Attributes.Add("mediaName", this._cicMap.AdMedia.AdMediaName);
                    control = image;
                }
            }
            return control;
        }

        internal HtmlAnchor RenderTargetLink()
        {
            HtmlAnchor anchor = null;
            if (((this._campaign != null) && (this._cicMap != null)) && !Strings.IsNullOrEmpty(this._cicMap.LinkId))
            {
                string clickTrackerUrl = Common.GetClickTrackerUrl(this.GetClickTrackProperties());
                anchor = new HtmlAnchor();
                anchor.ID = "lnkTarget";
                anchor.HRef = clickTrackerUrl;
                if ((this._campaign.CurrentCampaignInstance != null) && (this._campaign.CurrentCampaignInstance.TargetURLDisplay != null))
                {
                    TargetUrlDisplay targetURLDisplay = this._campaign.CurrentCampaignInstance.TargetURLDisplay;
                    WindowProperties winProps = new WindowProperties(targetURLDisplay.Height, targetURLDisplay.Width, targetURLDisplay.WindowDisplayBitMask);
                    if (winProps.OpenInNewWindow)
                    {
                        this.RegisterShowCampaignTargetUrlInPopupScriptBlock();
                        anchor.HRef = this.GetPopupCallJs(winProps, clickTrackerUrl);
                    }
                }
            }
            return anchor;
        }

        public virtual string AdSpaceId
        {
            get
            {
                if (this.ViewState["AdSpaceId"] == null)
                {
                    return string.Empty;
                }
                return (this.ViewState["AdSpaceId"] as string);
            }
            set
            {
                this.ViewState["AdSpaceId"] = value;
            }
        }

        public virtual string AdSpaceName
        {
            get
            {
                if (this.ViewState["AdSpaceName"] == null)
                {
                    return string.Empty;
                }
                return (this.ViewState["AdSpaceName"] as string);
            }
            set
            {
                this.ViewState["AdSpaceName"] = value;
            }
        }

        public virtual string CampaignContainerCss
        {
            get
            {
                if (this.ViewState["CampaignContainerCss"] == null)
                {
                    return string.Empty;
                }
                return (this.ViewState["CampaignContainerCss"] as string);
            }
            set
            {
                this.ViewState["CampaignContainerCss"] = value;
            }
        }

        public virtual string CampaignContext
        {
            get
            {
                return (this.ViewState["CampaignContext"] as string);
            }
            set
            {
                this.ViewState["CampaignContext"] = value;
            }
        }

        public virtual long CMCustomerId { get; set; }
        //{
        //    [CompilerGenerated]
        //    get
        //    {
        //        return this.<CMCustomerId>k__BackingField;
        //    }
        //    [CompilerGenerated]
        //    set
        //    {
        //        this.<CMCustomerId>k__BackingField = value;
        //    }
        //}

        public override bool Enabled
        {
            get
            {
                return ((this.ViewState["Enabled"] == null) || Convert.ToBoolean(this.ViewState["Enabled"]));
            }
            set
            {
                this.ViewState["Enabled"] = value;
            }
        }

        public virtual PageLookup GetPageName
        {
            get
            {
                return this._getPageName;
            }
            set
            {
                this._getPageName = value;
            }
        }

        public virtual bool HasManager
        {
            get
            {
                return Convert.ToBoolean(this.ViewState["HasManager"]);
            }
            set
            {
                this.ViewState["HasManager"] = value;
            }
        }
    }
}

