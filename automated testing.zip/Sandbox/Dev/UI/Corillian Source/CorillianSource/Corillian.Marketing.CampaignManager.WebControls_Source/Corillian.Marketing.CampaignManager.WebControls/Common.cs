namespace Corillian.Marketing.CampaignManager.WebControls
{
    using System;
    using System.Web.UI;

    public class Common
    {
        public static string Base64URLSafeDecode(string szBase64)
        {
            szBase64 = szBase64.Replace('-', '+');
            szBase64 = szBase64.Replace('_', '/');
            szBase64 = szBase64.Replace('.', '=');
            return szBase64;
        }

        public static string Base64URLSafeEncode(string szBase64)
        {
            szBase64 = szBase64.Replace('+', '-');
            szBase64 = szBase64.Replace('/', '_');
            szBase64 = szBase64.Replace('=', '.');
            return szBase64;
        }

        public static string Decrypt(string textToDecrypt, string key)
        {
            TokenUtil util = new TokenUtil(key);
            return util.AesDecrypt(Base64URLSafeDecode(textToDecrypt));
        }

        public static string Encrypt(string textToEncrypt, string key)
        {
            TokenUtil util = new TokenUtil(key);
            return Base64URLSafeEncode(util.AesEncrypt(textToEncrypt));
        }

        public static string GetClickTrackerUrl(string clickTrackProps)
        {
            return ("CMClickTracker.ashx?token=" + clickTrackProps);
        }

        public static string ResolvePageName(PageLookup pageLookupDel, Page page)
        {
            if (pageLookupDel != null)
            {
                return pageLookupDel();
            }
            return page.GetType().FullName.ToString().Trim(new char[] { '_' }).Replace("_aspx", string.Empty).Replace("ASP.", string.Empty);
        }

        public static string EncryptKey
        {
            get
            {
                return "3E569F98E248472292C0B7670955CA50";
            }
        }
    }
}

