namespace Corillian.Marketing.CampaignManager.WebControls
{
    using Corillian.Marketing.Domain;
    using Corillian.Marketing.Messages;
    using Corillian.Marketing.Operations;
    using Corillian.Voyager.Common;
    using Corillian.Voyager.Web.Security;
    using System;
    using System.Threading;
    using System.Web;
    using System.Web.UI;
    using System.Web.UI.HtmlControls;
    using System.Web.UI.WebControls;

    [ToolboxData("<{0}:InterceptCampaignControl runat=\"server\" AdSpaceId=\"\" DestinationPage=\"\"></{0}:InterceptCampaignControl>")]
    public class InterceptCampaignControl : CampaignControlBase
    {
        private InterceptActionEventHandler _ApplyCampaignAction;
        private InterceptActionEventHandler _RemindCampaignLaterAction;
        private InterceptActionEventHandler _SuppressCampaignAction;

        public event InterceptActionEventHandler ApplyCampaignAction
        {
            add
            {
                InterceptActionEventHandler handler2;
                InterceptActionEventHandler applyCampaignAction = this._ApplyCampaignAction;
                do
                {
                    handler2 = applyCampaignAction;
                    InterceptActionEventHandler handler3 = (InterceptActionEventHandler) Delegate.Combine(handler2, value);
                    applyCampaignAction = Interlocked.CompareExchange<InterceptActionEventHandler>(ref this._ApplyCampaignAction, handler3, handler2);
                }
                while (applyCampaignAction != handler2);
            }
            remove
            {
                InterceptActionEventHandler handler2;
                InterceptActionEventHandler applyCampaignAction = this._ApplyCampaignAction;
                do
                {
                    handler2 = applyCampaignAction;
                    InterceptActionEventHandler handler3 = (InterceptActionEventHandler) Delegate.Remove(handler2, value);
                    applyCampaignAction = Interlocked.CompareExchange<InterceptActionEventHandler>(ref this._ApplyCampaignAction, handler3, handler2);
                }
                while (applyCampaignAction != handler2);
            }
        }

        public event InterceptActionEventHandler RemindCampaignLaterAction
        {
            add
            {
                InterceptActionEventHandler handler2;
                InterceptActionEventHandler remindCampaignLaterAction = this._RemindCampaignLaterAction;
                do
                {
                    handler2 = remindCampaignLaterAction;
                    InterceptActionEventHandler handler3 = (InterceptActionEventHandler) Delegate.Combine(handler2, value);
                    remindCampaignLaterAction = Interlocked.CompareExchange<InterceptActionEventHandler>(ref this._RemindCampaignLaterAction, handler3, handler2);
                }
                while (remindCampaignLaterAction != handler2);
            }
            remove
            {
                InterceptActionEventHandler handler2;
                InterceptActionEventHandler remindCampaignLaterAction = this._RemindCampaignLaterAction;
                do
                {
                    handler2 = remindCampaignLaterAction;
                    InterceptActionEventHandler handler3 = (InterceptActionEventHandler) Delegate.Remove(handler2, value);
                    remindCampaignLaterAction = Interlocked.CompareExchange<InterceptActionEventHandler>(ref this._RemindCampaignLaterAction, handler3, handler2);
                }
                while (remindCampaignLaterAction != handler2);
            }
        }

        public event InterceptActionEventHandler SuppressCampaignAction
        {
            add
            {
                InterceptActionEventHandler handler2;
                InterceptActionEventHandler suppressCampaignAction = this._SuppressCampaignAction;
                do
                {
                    handler2 = suppressCampaignAction;
                    InterceptActionEventHandler handler3 = (InterceptActionEventHandler) Delegate.Combine(handler2, value);
                    suppressCampaignAction = Interlocked.CompareExchange<InterceptActionEventHandler>(ref this._SuppressCampaignAction, handler3, handler2);
                }
                while (suppressCampaignAction != handler2);
            }
            remove
            {
                InterceptActionEventHandler handler2;
                InterceptActionEventHandler suppressCampaignAction = this._SuppressCampaignAction;
                do
                {
                    handler2 = suppressCampaignAction;
                    InterceptActionEventHandler handler3 = (InterceptActionEventHandler) Delegate.Remove(handler2, value);
                    suppressCampaignAction = Interlocked.CompareExchange<InterceptActionEventHandler>(ref this._SuppressCampaignAction, handler3, handler2);
                }
                while (suppressCampaignAction != handler2);
            }
        }

        static InterceptCampaignControl()
        {
            CampaignControlBase.logSvc = LoggingServiceFactory.GetService(typeof(InterceptCampaignControl));
        }

        private void btnApply_Command(object sender, CommandEventArgs e)
        {
            this.LogInterceptInteraction(1, e.CommandArgument.ToString());
            if ((((base._campaign != null) && (base._cicMap != null)) && (!Strings.IsNullOrEmpty(base._cicMap.LinkId) && (base._campaign.CurrentCampaignInstance != null))) && (base._campaign.CurrentCampaignInstance.TargetURLDisplay != null))
            {
                TargetUrlDisplay targetURLDisplay = base._campaign.CurrentCampaignInstance.TargetURLDisplay;
                WindowProperties properties = new WindowProperties(targetURLDisplay.Height, targetURLDisplay.Width, targetURLDisplay.WindowDisplayBitMask);
                if (!properties.OpenInNewWindow && !Strings.IsNullOrEmpty(base._cicMap.LinkId))
                {
                    try
                    {
                        this.Context.Response.Redirect(base._cicMap.LinkId);
                    }
                    catch (ThreadAbortException)
                    {
                    }
                    return;
                }
            }
            this.OnApplyCampaignAction(sender, e);
        }

        private void btnRemindLater_Command(object sender, CommandEventArgs e)
        {
            this.LogInterceptInteraction(2, e.CommandArgument.ToString());
            this.OnRemindCampaignLaterAction(sender, e);
        }

        private void btnSuppress_Command(object sender, CommandEventArgs e)
        {
            this.LogInterceptInteraction(3, e.CommandArgument.ToString());
            this.OnSuppressCampaignAction(sender, e);
        }

        private string GetPropertyValue(string key, string clickTrackProperties)
        {
            string str = Common.Decrypt(clickTrackProperties, Common.EncryptKey);
            string str2 = null;
            if ((str != null) && (str.Length > 0))
            {
                string[] strArray = str.Split(new char[] { '&' });
                if ((strArray == null) || (strArray.Length <= 0))
                {
                    return str2;
                }
                for (int i = 0; i < strArray.Length; i++)
                {
                    string[] strArray2 = strArray[i].Split(new char[] { '=' });
                    if (((strArray2 != null) && (strArray2.Length == 2)) && (strArray2[0] == key))
                    {
                        return strArray2[1];
                    }
                }
            }
            return str2;
        }

        private void LogInterceptInteraction(int actionType, string clickTrackProperties)
        {
            try
            {
                string propertyValue = this.GetPropertyValue("CampaignGuid", clickTrackProperties);
                if (propertyValue != null)
                {
                    MarketingServiceProxy proxy = new MarketingServiceProxy();
                    LogInterceptCampaignCustomerInteractionRequest req = new LogInterceptCampaignCustomerInteractionRequest();
                    req.CampaignGuid = propertyValue;
                    req.InterceptActionType = actionType;
                    req.Campaign = base._campaign;
                    proxy.LogInterceptCampaignCustomerInteraction(req);
                }
            }
            catch (Exception exception)
            {
                CampaignControlBase.logSvc.Error("Error while logging intercept action", exception);
            }
        }

        private void OnApplyCampaignAction(object sender, CommandEventArgs e)
        {
            if (this._ApplyCampaignAction != null)
            {
                this._ApplyCampaignAction(sender, e);
            }
            else
            {
                try
                {
                    this.Context.Response.Redirect(this.DestinationPage);
                }
                catch (ThreadAbortException)
                {
                }
            }
        }

        protected override void OnLoad(EventArgs e)
        {
            base.OnLoad(e);
            if ((this.Enabled && !this.HasManager) && ((HttpContext.Current != null) && SiteSecurity.IsLoggedIn()))
            {
                if (this.Page.IsPostBack)
                {
                    base._campaign = (Campaign) this.ViewState["Campaign"];
                }
                if (base._campaign == null)
                {
                    this.PopulateCampaign();
                    this.RenderCampaign();
                }
                else
                {
                    this.PopulateCampaign(base._campaign);
                }
            }
        }

        protected override void OnPreRender(EventArgs e)
        {
            base.OnPreRender(e);
            if (base._campaign != null)
            {
                this.ViewState["Campaign"] = base._campaign;
            }
        }

        private void OnRemindCampaignLaterAction(object sender, CommandEventArgs e)
        {
            if (this._RemindCampaignLaterAction != null)
            {
                this._RemindCampaignLaterAction(sender, e);
            }
            else
            {
                try
                {
                    this.Context.Response.Redirect(this.DestinationPage);
                }
                catch (ThreadAbortException)
                {
                }
            }
        }

        private void OnSuppressCampaignAction(object sender, CommandEventArgs e)
        {
            if (this._SuppressCampaignAction != null)
            {
                this._SuppressCampaignAction(sender, e);
            }
            else
            {
                try
                {
                    this.Context.Response.Redirect(this.DestinationPage);
                }
                catch (ThreadAbortException)
                {
                }
            }
        }

        protected internal virtual void PopulateCampaign(Campaign campaign)
        {
            if (campaign != null)
            {
                base._campaign = campaign;
                base._cicMap = campaign.DisplayingComposition;
                base._adSpace = campaign.DisplayingAdSpace;
                this.RenderCampaign();
            }
        }

        protected internal virtual void RenderCampaign()
        {
            try
            {
                if (((base._campaign == null) || (base._cicMap == null)) || ((base._cicMap.AdMedia == null) || (base._cicMap.AdMedia.AdMediaGuid == null)))
                {
                    if ((this.DestinationPage != null) && (this.DestinationPage != string.Empty))
                    {
                        this.Context.Response.Redirect(this.DestinationPage);
                    }
                }
                else
                {
                    this.RenderControls();
                }
            }
            catch (ThreadAbortException)
            {
            }
            catch (Exception exception)
            {
                CampaignControlBase.logSvc.Error("Error while rendering campaign", exception);
            }
        }

        protected void RenderControls()
        {
            Panel child = new Panel();
            child.CssClass = this.CampaignContainerCss;
            child.ID = "pnlCamapaignContainer";
            Panel panel2 = new Panel();
            panel2.CssClass = this.InterceptAdMediaContainerCss;
            panel2.ID = "pnlAdMediaContainer";
            Label label = this.RenderTitle();
            if ((label != null) && (label.Text != string.Empty))
            {
                Panel panel3 = new Panel();
                panel3.CssClass = this.InterceptCampaignTitleCss;
                panel3.ID = "pnlInterceptCampaignTitle";
                panel3.Controls.Add(label);
                child.Controls.Add(panel3);
            }
            HtmlAnchor anchor = base.RenderTargetLink();
            Control control = base.RenderAdMedia();
            if (anchor == null)
            {
                panel2.Controls.Add(control);
            }
            else
            {
                anchor.Controls.Add(control);
                panel2.Controls.Add(anchor);
            }
            child.Controls.Add(panel2);
            Table table = this.RenderInterceptButtons();
            child.Controls.Add(table);
            this.Controls.Add(child);
        }

        private Table RenderInterceptButtons()
        {
            Table table = null;
            if ((base._cicMap != null) && (base._cicMap.InterceptDisplayConfig != null))
            {
                InterceptDisplayConfig interceptDisplayConfig = base._cicMap.InterceptDisplayConfig;
                table = new Table();
                table.CssClass = this.InterceptButtonsContainerCss;
                table.ID = "tblInterceptActions";
                TableRow row = new TableRow();
                if ((interceptDisplayConfig.RemaindText != null) && (interceptDisplayConfig.RemaindText != string.Empty))
                {
                    TableCell cell = new TableCell();
                    Button child = new Button();
                    child.ID = "btnRemindMeLater";
                    child.CssClass = this.InterceptButtonCss;
                    child.Text = HttpUtility.HtmlDecode(interceptDisplayConfig.RemaindText);
                    child.Command += new CommandEventHandler(this.btnRemindLater_Command);
                    child.CommandName = "RemindMeLater";
                    child.CommandArgument = base.GetClickTrackProperties();
                    cell.Controls.Add(child);
                    row.Cells.Add(cell);
                }
                if ((interceptDisplayConfig.SupressText != null) && (interceptDisplayConfig.SupressText != string.Empty))
                {
                    TableCell cell2 = new TableCell();
                    Button button2 = new Button();
                    button2.ID = "btnSuppress";
                    button2.CssClass = this.InterceptButtonCss;
                    button2.Text = HttpUtility.HtmlDecode(interceptDisplayConfig.SupressText);
                    button2.Command += new CommandEventHandler(this.btnSuppress_Command);
                    button2.CommandName = "SuppressCampaign";
                    button2.CommandArgument = base.GetClickTrackProperties();
                    cell2.Controls.Add(button2);
                    row.Cells.Add(cell2);
                }
                if ((interceptDisplayConfig.ApplyText != null) && (interceptDisplayConfig.ApplyText != string.Empty))
                {
                    TableCell cell3 = new TableCell();
                    Button button3 = new Button();
                    button3.ID = "btnApply";
                    button3.CssClass = this.InterceptButtonCss;
                    button3.Text = HttpUtility.HtmlDecode(interceptDisplayConfig.ApplyText);
                    button3.Command += new CommandEventHandler(this.btnApply_Command);
                    button3.CommandName = button3.CommandName + "ApplyForCampaign";
                    button3.CommandArgument = base.GetClickTrackProperties();
                    if ((((base._campaign != null) && (base._cicMap != null)) && (!Strings.IsNullOrEmpty(base._cicMap.LinkId) && (base._campaign.CurrentCampaignInstance != null))) && (base._campaign.CurrentCampaignInstance.TargetURLDisplay != null))
                    {
                        TargetUrlDisplay targetURLDisplay = base._campaign.CurrentCampaignInstance.TargetURLDisplay;
                        WindowProperties winProps = new WindowProperties(targetURLDisplay.Height, targetURLDisplay.Width, targetURLDisplay.WindowDisplayBitMask);
                        if (winProps.OpenInNewWindow)
                        {
                            base.RegisterShowCampaignTargetUrlInPopupScriptBlock();
                            string clickTrackerUrl = Common.GetClickTrackerUrl(base.GetClickTrackProperties());
                            button3.Attributes.Add("onclick", base.GetPopupCallJs(winProps, clickTrackerUrl));
                        }
                    }
                    cell3.Controls.Add(button3);
                    row.Cells.Add(cell3);
                }
                table.Rows.Add(row);
            }
            return table;
        }

        private Label RenderTitle()
        {
            Label label = null;
            if (((base._cicMap != null) && (base._cicMap.InterceptDisplayConfig != null)) && (base._cicMap.InterceptDisplayConfig.InterceptDisplay != null))
            {
                Label label2 = new Label();
                label2.Text = base._cicMap.InterceptDisplayConfig.InterceptDisplay.Title;
                label = label2;
            }
            return label;
        }

        public virtual string DestinationPage
        {
            get
            {
                return (this.ViewState["DestinationPage"] as string);
            }
            set
            {
                this.ViewState["DestinationPage"] = value;
            }
        }

        public virtual string InterceptAdMediaContainerCss
        {
            get
            {
                if (this.ViewState["InterceptAdMediaContainerCss"] == null)
                {
                    return string.Empty;
                }
                return (this.ViewState["InterceptAdMediaContainerCss"] as string);
            }
            set
            {
                this.ViewState["InterceptAdMediaContainerCss"] = value;
            }
        }

        public virtual string InterceptButtonCss
        {
            get
            {
                if (this.ViewState["InterceptButtonCss"] == null)
                {
                    return string.Empty;
                }
                return (this.ViewState["InterceptButtonCss"] as string);
            }
            set
            {
                this.ViewState["InterceptButtonCss"] = value;
            }
        }

        public virtual string InterceptButtonsContainerCss
        {
            get
            {
                if (this.ViewState["InterceptButtonsContainerCss"] == null)
                {
                    return string.Empty;
                }
                return (this.ViewState["InterceptButtonsContainerCss"] as string);
            }
            set
            {
                this.ViewState["InterceptButtonsContainerCss"] = value;
            }
        }

        public virtual string InterceptCampaignTitleCss
        {
            get
            {
                if (this.ViewState["InterceptCampaignTitleCss"] == null)
                {
                    return string.Empty;
                }
                return (this.ViewState["InterceptCampaignTitleCss"] as string);
            }
            set
            {
                this.ViewState["InterceptCampaignTitleCss"] = value;
            }
        }
    }
}

