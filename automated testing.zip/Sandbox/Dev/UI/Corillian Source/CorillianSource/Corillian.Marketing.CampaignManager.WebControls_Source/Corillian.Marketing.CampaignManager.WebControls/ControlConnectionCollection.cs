namespace Corillian.Marketing.CampaignManager.WebControls
{
    using System;
    using System.Collections;
    using System.Reflection;

    [Serializable]
    public class ControlConnectionCollection : IControlConnectionList, IControlConnectionCollection, IList, ICollection, IEnumerable, ICloneable
    {
        private ControlConnection[] _array;
        private int _count;
        private const int _defaultCapacity = 0x10;
        [NonSerialized]
        private int _version;

        public ControlConnectionCollection()
        {
            this._array = new ControlConnection[0x10];
        }

        public ControlConnectionCollection(ControlConnectionCollection collection)
        {
            if (collection == null)
            {
                throw new ArgumentNullException("collection");
            }
            this._array = new ControlConnection[collection.Count];
            this.AddRange(collection);
        }

        private ControlConnectionCollection(Tag tag)
        {
        }

        public ControlConnectionCollection(int capacity)
        {
            if (capacity < 0)
            {
                throw new ArgumentOutOfRangeException("capacity", capacity, "Argument cannot be negative.");
            }
            this._array = new ControlConnection[capacity];
        }

        public ControlConnectionCollection(ControlConnection[] array)
        {
            if (array == null)
            {
                throw new ArgumentNullException("array");
            }
            this._array = new ControlConnection[array.Length];
            this.AddRange(array);
        }

        public virtual int Add(ControlConnection value)
        {
            if (this._count == this._array.Length)
            {
                this.EnsureCapacity(this._count + 1);
            }
            this._version++;
            this._array[this._count] = value;
            return this._count++;
        }

        public virtual void AddRange(ControlConnectionCollection collection)
        {
            if (collection == null)
            {
                throw new ArgumentNullException("collection");
            }
            if (collection.Count != 0)
            {
                if ((this._count + collection.Count) > this._array.Length)
                {
                    this.EnsureCapacity(this._count + collection.Count);
                }
                this._version++;
                Array.Copy(collection.InnerArray, 0, this._array, this._count, collection.Count);
                this._count += collection.Count;
            }
        }

        public virtual void AddRange(ControlConnection[] array)
        {
            if (array == null)
            {
                throw new ArgumentNullException("array");
            }
            if (array.Length != 0)
            {
                if ((this._count + array.Length) > this._array.Length)
                {
                    this.EnsureCapacity(this._count + array.Length);
                }
                this._version++;
                Array.Copy(array, 0, this._array, this._count, array.Length);
                this._count += array.Length;
            }
        }

        public virtual int BinarySearch(ControlConnection value)
        {
            return Array.BinarySearch<ControlConnection>(this._array, 0, this._count, value);
        }

        private void CheckEnumIndex(int index)
        {
            if ((index < 0) || (index >= this._count))
            {
                throw new InvalidOperationException("Enumerator is not on a collection element.");
            }
        }

        private void CheckEnumVersion(int version)
        {
            if (version != this._version)
            {
                throw new InvalidOperationException("Enumerator invalidated by modification to collection.");
            }
        }

        private void CheckTargetArray(Array array, int arrayIndex)
        {
            if (array == null)
            {
                throw new ArgumentNullException("array");
            }
            if (array.Rank > 1)
            {
                throw new ArgumentException("Argument cannot be multidimensional.", "array");
            }
            if (arrayIndex < 0)
            {
                throw new ArgumentOutOfRangeException("arrayIndex", arrayIndex, "Argument cannot be negative.");
            }
            if (arrayIndex >= array.Length)
            {
                throw new ArgumentException("Argument must be less than array length.", "arrayIndex");
            }
            if (this._count > (array.Length - arrayIndex))
            {
                throw new ArgumentException("Argument section must be large enough for collection.", "array");
            }
        }

        public virtual void Clear()
        {
            if (this._count != 0)
            {
                this._version++;
                Array.Clear(this._array, 0, this._count);
                this._count = 0;
            }
        }

        public virtual object Clone()
        {
            ControlConnectionCollection connections = new ControlConnectionCollection(this._count);
            Array.Copy(this._array, 0, connections._array, 0, this._count);
            connections._count = this._count;
            connections._version = this._version;
            return connections;
        }

        public bool Contains(ControlConnection value)
        {
            return (this.IndexOf(value) >= 0);
        }

        public virtual void CopyTo(ControlConnection[] array)
        {
            this.CheckTargetArray(array, 0);
            Array.Copy(this._array, array, this._count);
        }

        public virtual void CopyTo(ControlConnection[] array, int arrayIndex)
        {
            this.CheckTargetArray(array, arrayIndex);
            Array.Copy(this._array, 0, array, arrayIndex, this._count);
        }

        private void EnsureCapacity(int minimum)
        {
            int num = (this._array.Length == 0) ? 0x10 : (this._array.Length * 2);
            if (num < minimum)
            {
                num = minimum;
            }
            this.Capacity = num;
        }

        public virtual IControlConnectionEnumerator GetEnumerator()
        {
            return new Enumerator(this);
        }

        public virtual int IndexOf(ControlConnection value)
        {
            return Array.IndexOf<ControlConnection>(this._array, value, 0, this._count);
        }

        public virtual void Insert(int index, ControlConnection value)
        {
            if (index < 0)
            {
                throw new ArgumentOutOfRangeException("index", index, "Argument cannot be negative.");
            }
            if (index > this._count)
            {
                throw new ArgumentOutOfRangeException("index", index, "Argument cannot exceed Count.");
            }
            if (this._count == this._array.Length)
            {
                this.EnsureCapacity(this._count + 1);
            }
            this._version++;
            if (index < this._count)
            {
                Array.Copy(this._array, index, this._array, index + 1, this._count - index);
            }
            this._array[index] = value;
            this._count++;
        }

        public static ControlConnectionCollection ReadOnly(ControlConnectionCollection collection)
        {
            if (collection == null)
            {
                throw new ArgumentNullException("collection");
            }
            return new ReadOnlyList(collection);
        }

        public virtual void Remove(ControlConnection value)
        {
            int index = this.IndexOf(value);
            if (index >= 0)
            {
                this.RemoveAt(index);
            }
        }

        public virtual void RemoveAt(int index)
        {
            this.ValidateIndex(index);
            this._version++;
            if (index < --this._count)
            {
                Array.Copy(this._array, index + 1, this._array, index, this._count - index);
            }
            this._array[this._count] = null;
        }

        public virtual void RemoveRange(int index, int count)
        {
            if (index < 0)
            {
                throw new ArgumentOutOfRangeException("index", index, "Argument cannot be negative.");
            }
            if (count < 0)
            {
                throw new ArgumentOutOfRangeException("count", count, "Argument cannot be negative.");
            }
            if ((index + count) > this._count)
            {
                throw new ArgumentException("Arguments denote invalid range of elements.");
            }
            if (count != 0)
            {
                this._version++;
                this._count -= count;
                if (index < this._count)
                {
                    Array.Copy(this._array, index + count, this._array, index, this._count - index);
                }
                Array.Clear(this._array, this._count, count);
            }
        }

        public virtual void Reverse()
        {
            if (this._count > 1)
            {
                this._version++;
                Array.Reverse(this._array, 0, this._count);
            }
        }

        public virtual void Reverse(int index, int count)
        {
            if (index < 0)
            {
                throw new ArgumentOutOfRangeException("index", index, "Argument cannot be negative.");
            }
            if (count < 0)
            {
                throw new ArgumentOutOfRangeException("count", count, "Argument cannot be negative.");
            }
            if ((index + count) > this._count)
            {
                throw new ArgumentException("Arguments denote invalid range of elements.");
            }
            if ((count > 1) && (this._count > 1))
            {
                this._version++;
                Array.Reverse(this._array, index, count);
            }
        }

        public virtual void Sort()
        {
            if (this._count > 1)
            {
                this._version++;
                Array.Sort<ControlConnection>(this._array, 0, this._count);
            }
        }

        public virtual void Sort(IComparer comparer)
        {
            if (this._count > 1)
            {
                this._version++;
                Array.Sort(this._array, 0, this._count, comparer);
            }
        }

        public virtual void Sort(int index, int count, IComparer comparer)
        {
            if (index < 0)
            {
                throw new ArgumentOutOfRangeException("index", index, "Argument cannot be negative.");
            }
            if (count < 0)
            {
                throw new ArgumentOutOfRangeException("count", count, "Argument cannot be negative.");
            }
            if ((index + count) > this._count)
            {
                throw new ArgumentException("Arguments denote invalid range of elements.");
            }
            if ((count > 1) && (this._count > 1))
            {
                this._version++;
                Array.Sort(this._array, index, count, comparer);
            }
        }

        public static ControlConnectionCollection Synchronized(ControlConnectionCollection collection)
        {
            if (collection == null)
            {
                throw new ArgumentNullException("collection");
            }
            return new SyncList(collection);
        }

        void ICollection.CopyTo(Array array, int arrayIndex)
        {
            this.CheckTargetArray(array, arrayIndex);
            this.CopyTo((ControlConnection[]) array, arrayIndex);
        }

        IEnumerator IEnumerable.GetEnumerator()
        {
            return (IEnumerator) this.GetEnumerator();
        }

        int IList.Add(object value)
        {
            return this.Add((ControlConnection) value);
        }

        bool IList.Contains(object value)
        {
            return this.Contains((ControlConnection) value);
        }

        int IList.IndexOf(object value)
        {
            return this.IndexOf((ControlConnection) value);
        }

        void IList.Insert(int index, object value)
        {
            this.Insert(index, (ControlConnection) value);
        }

        void IList.Remove(object value)
        {
            this.Remove((ControlConnection) value);
        }

        public virtual ControlConnection[] ToArray()
        {
            ControlConnection[] destinationArray = new ControlConnection[this._count];
            Array.Copy(this._array, destinationArray, this._count);
            return destinationArray;
        }

        public virtual void TrimToSize()
        {
            this.Capacity = this._count;
        }

        public static ControlConnectionCollection Unique(ControlConnectionCollection collection)
        {
            if (collection == null)
            {
                throw new ArgumentNullException("collection");
            }
            for (int i = collection.Count - 1; i > 0; i--)
            {
                if (collection.IndexOf(collection[i]) < i)
                {
                    throw new ArgumentException("collection", "Argument cannot contain duplicate elements.");
                }
            }
            return new UniqueList(collection);
        }

        private void ValidateIndex(int index)
        {
            if (index < 0)
            {
                throw new ArgumentOutOfRangeException("index", index, "Argument cannot be negative.");
            }
            if (index >= this._count)
            {
                throw new ArgumentOutOfRangeException("index", index, "Argument must be less than Count.");
            }
        }

        public virtual int Capacity
        {
            get
            {
                return this._array.Length;
            }
            set
            {
                if (value != this._array.Length)
                {
                    if (value < this._count)
                    {
                        throw new ArgumentOutOfRangeException("Capacity", value, "Value cannot be less than Count.");
                    }
                    if (value == 0)
                    {
                        this._array = new ControlConnection[0x10];
                    }
                    else
                    {
                        ControlConnection[] destinationArray = new ControlConnection[value];
                        Array.Copy(this._array, destinationArray, this._count);
                        this._array = destinationArray;
                    }
                }
            }
        }

        public virtual int Count
        {
            get
            {
                return this._count;
            }
        }

        protected virtual ControlConnection[] InnerArray
        {
            get
            {
                return this._array;
            }
        }

        public virtual bool IsFixedSize
        {
            get
            {
                return false;
            }
        }

        public virtual bool IsReadOnly
        {
            get
            {
                return false;
            }
        }

        public virtual bool IsSynchronized
        {
            get
            {
                return false;
            }
        }

        public virtual bool IsUnique
        {
            get
            {
                return false;
            }
        }

        public virtual ControlConnection this[int index]
        {
            get
            {
                this.ValidateIndex(index);
                return this._array[index];
            }
            set
            {
                this.ValidateIndex(index);
                this._version++;
                this._array[index] = value;
            }
        }

        public virtual object SyncRoot
        {
            get
            {
                return this;
            }
        }

        object IList.this[int index]
        {
            get
            {
                return this[index];
            }
            set
            {
                this[index] = (ControlConnection) value;
            }
        }

        [Serializable]
        private sealed class Enumerator : IControlConnectionEnumerator, IEnumerator
        {
            private readonly ControlConnectionCollection _collection;
            private int _index;
            private readonly int _version;

            internal Enumerator(ControlConnectionCollection collection)
            {
                this._collection = collection;
                this._version = collection._version;
                this._index = -1;
            }

            public bool MoveNext()
            {
                this._collection.CheckEnumVersion(this._version);
                return (++this._index < this._collection.Count);
            }

            public void Reset()
            {
                this._collection.CheckEnumVersion(this._version);
                this._index = -1;
            }

            public ControlConnection Current
            {
                get
                {
                    this._collection.CheckEnumIndex(this._index);
                    this._collection.CheckEnumVersion(this._version);
                    return this._collection[this._index];
                }
            }

            object IEnumerator.Current
            {
                get
                {
                    return this.Current;
                }
            }
        }

        [Serializable, CoverageExclude("Unsused code")]
        private sealed class ReadOnlyList : ControlConnectionCollection
        {
            private ControlConnectionCollection _collection;

            internal ReadOnlyList(ControlConnectionCollection collection) : base(ControlConnectionCollection.Tag.Default)
            {
                this._collection = collection;
            }

            public override int Add(ControlConnection value)
            {
                throw new NotSupportedException("Read-only collections cannot be modified.");
            }

            public override void AddRange(ControlConnectionCollection collection)
            {
                throw new NotSupportedException("Read-only collections cannot be modified.");
            }

            public override void AddRange(ControlConnection[] array)
            {
                throw new NotSupportedException("Read-only collections cannot be modified.");
            }

            public override int BinarySearch(ControlConnection value)
            {
                return this._collection.BinarySearch(value);
            }

            public override void Clear()
            {
                throw new NotSupportedException("Read-only collections cannot be modified.");
            }

            public override object Clone()
            {
                return new ControlConnectionCollection.ReadOnlyList((ControlConnectionCollection) this._collection.Clone());
            }

            public override void CopyTo(ControlConnection[] array)
            {
                this._collection.CopyTo(array);
            }

            public override void CopyTo(ControlConnection[] array, int arrayIndex)
            {
                this._collection.CopyTo(array, arrayIndex);
            }

            public override IControlConnectionEnumerator GetEnumerator()
            {
                return this._collection.GetEnumerator();
            }

            public override int IndexOf(ControlConnection value)
            {
                return this._collection.IndexOf(value);
            }

            public override void Insert(int index, ControlConnection value)
            {
                throw new NotSupportedException("Read-only collections cannot be modified.");
            }

            public override void Remove(ControlConnection value)
            {
                throw new NotSupportedException("Read-only collections cannot be modified.");
            }

            public override void RemoveAt(int index)
            {
                throw new NotSupportedException("Read-only collections cannot be modified.");
            }

            public override void RemoveRange(int index, int count)
            {
                throw new NotSupportedException("Read-only collections cannot be modified.");
            }

            public override void Reverse()
            {
                throw new NotSupportedException("Read-only collections cannot be modified.");
            }

            public override void Reverse(int index, int count)
            {
                throw new NotSupportedException("Read-only collections cannot be modified.");
            }

            public override void Sort()
            {
                throw new NotSupportedException("Read-only collections cannot be modified.");
            }

            public override void Sort(IComparer comparer)
            {
                throw new NotSupportedException("Read-only collections cannot be modified.");
            }

            public override void Sort(int index, int count, IComparer comparer)
            {
                throw new NotSupportedException("Read-only collections cannot be modified.");
            }

            public override ControlConnection[] ToArray()
            {
                return this._collection.ToArray();
            }

            public override void TrimToSize()
            {
                throw new NotSupportedException("Read-only collections cannot be modified.");
            }

            public override int Capacity
            {
                get
                {
                    return this._collection.Capacity;
                }
                set
                {
                    throw new NotSupportedException("Read-only collections cannot be modified.");
                }
            }

            public override int Count
            {
                get
                {
                    return this._collection.Count;
                }
            }

            protected override ControlConnection[] InnerArray
            {
                get
                {
                    return this._collection.InnerArray;
                }
            }

            public override bool IsFixedSize
            {
                get
                {
                    return true;
                }
            }

            public override bool IsReadOnly
            {
                get
                {
                    return true;
                }
            }

            public override bool IsSynchronized
            {
                get
                {
                    return this._collection.IsSynchronized;
                }
            }

            public override bool IsUnique
            {
                get
                {
                    return this._collection.IsUnique;
                }
            }

            public override ControlConnection this[int index]
            {
                get
                {
                    return this._collection[index];
                }
                set
                {
                    throw new NotSupportedException("Read-only collections cannot be modified.");
                }
            }

            public override object SyncRoot
            {
                get
                {
                    return this._collection.SyncRoot;
                }
            }
        }

        [Serializable, CoverageExclude("unused code")]
        private sealed class SyncList : ControlConnectionCollection
        {
            private ControlConnectionCollection _collection;
            private object _root;

            internal SyncList(ControlConnectionCollection collection) : base(ControlConnectionCollection.Tag.Default)
            {
                this._root = collection.SyncRoot;
                this._collection = collection;
            }

            public override int Add(ControlConnection value)
            {
                lock (this._root)
                {
                    return this._collection.Add(value);
                }
            }

            public override void AddRange(ControlConnectionCollection collection)
            {
                lock (this._root)
                {
                    this._collection.AddRange(collection);
                }
            }

            public override void AddRange(ControlConnection[] array)
            {
                lock (this._root)
                {
                    this._collection.AddRange(array);
                }
            }

            public override int BinarySearch(ControlConnection value)
            {
                lock (this._root)
                {
                    return this._collection.BinarySearch(value);
                }
            }

            public override void Clear()
            {
                lock (this._root)
                {
                    this._collection.Clear();
                }
            }

            public override object Clone()
            {
                lock (this._root)
                {
                    return new ControlConnectionCollection.SyncList((ControlConnectionCollection) this._collection.Clone());
                }
            }

            public override void CopyTo(ControlConnection[] array)
            {
                lock (this._root)
                {
                    this._collection.CopyTo(array);
                }
            }

            public override void CopyTo(ControlConnection[] array, int arrayIndex)
            {
                lock (this._root)
                {
                    this._collection.CopyTo(array, arrayIndex);
                }
            }

            public override IControlConnectionEnumerator GetEnumerator()
            {
                lock (this._root)
                {
                    return this._collection.GetEnumerator();
                }
            }

            public override int IndexOf(ControlConnection value)
            {
                lock (this._root)
                {
                    return this._collection.IndexOf(value);
                }
            }

            public override void Insert(int index, ControlConnection value)
            {
                lock (this._root)
                {
                    this._collection.Insert(index, value);
                }
            }

            public override void Remove(ControlConnection value)
            {
                lock (this._root)
                {
                    this._collection.Remove(value);
                }
            }

            public override void RemoveAt(int index)
            {
                lock (this._root)
                {
                    this._collection.RemoveAt(index);
                }
            }

            public override void RemoveRange(int index, int count)
            {
                lock (this._root)
                {
                    this._collection.RemoveRange(index, count);
                }
            }

            public override void Reverse()
            {
                lock (this._root)
                {
                    this._collection.Reverse();
                }
            }

            public override void Reverse(int index, int count)
            {
                lock (this._root)
                {
                    this._collection.Reverse(index, count);
                }
            }

            public override void Sort()
            {
                lock (this._root)
                {
                    this._collection.Sort();
                }
            }

            public override void Sort(IComparer comparer)
            {
                lock (this._root)
                {
                    this._collection.Sort(comparer);
                }
            }

            public override void Sort(int index, int count, IComparer comparer)
            {
                lock (this._root)
                {
                    this._collection.Sort(index, count, comparer);
                }
            }

            public override ControlConnection[] ToArray()
            {
                lock (this._root)
                {
                    return this._collection.ToArray();
                }
            }

            public override void TrimToSize()
            {
                lock (this._root)
                {
                    this._collection.TrimToSize();
                }
            }

            public override int Capacity
            {
                get
                {
                    lock (this._root)
                    {
                        return this._collection.Capacity;
                    }
                }
                set
                {
                    lock (this._root)
                    {
                        this._collection.Capacity = value;
                    }
                }
            }

            public override int Count
            {
                get
                {
                    lock (this._root)
                    {
                        return this._collection.Count;
                    }
                }
            }

            protected override ControlConnection[] InnerArray
            {
                get
                {
                    lock (this._root)
                    {
                        return this._collection.InnerArray;
                    }
                }
            }

            public override bool IsFixedSize
            {
                get
                {
                    return this._collection.IsFixedSize;
                }
            }

            public override bool IsReadOnly
            {
                get
                {
                    return this._collection.IsReadOnly;
                }
            }

            public override bool IsSynchronized
            {
                get
                {
                    return true;
                }
            }

            public override bool IsUnique
            {
                get
                {
                    return this._collection.IsUnique;
                }
            }

            public override ControlConnection this[int index]
            {
                get
                {
                    lock (this._root)
                    {
                        return this._collection[index];
                    }
                }
                set
                {
                    lock (this._root)
                    {
                        this._collection[index] = value;
                    }
                }
            }

            public override object SyncRoot
            {
                get
                {
                    return this._root;
                }
            }
        }

        private enum Tag
        {
            Default
        }

        [Serializable, CoverageExclude("unused code")]
        private sealed class UniqueList : ControlConnectionCollection
        {
            private ControlConnectionCollection _collection;

            internal UniqueList(ControlConnectionCollection collection) : base(ControlConnectionCollection.Tag.Default)
            {
                this._collection = collection;
            }

            public override int Add(ControlConnection value)
            {
                this.CheckUnique(value);
                return this._collection.Add(value);
            }

            public override void AddRange(ControlConnectionCollection collection)
            {
                foreach (ControlConnection connection in collection)
                {
                    this.CheckUnique(connection);
                }
                this._collection.AddRange(collection);
            }

            public override void AddRange(ControlConnection[] array)
            {
                foreach (ControlConnection connection in array)
                {
                    this.CheckUnique(connection);
                }
                this._collection.AddRange(array);
            }

            public override int BinarySearch(ControlConnection value)
            {
                return this._collection.BinarySearch(value);
            }

            private void CheckUnique(ControlConnection value)
            {
                if (this.IndexOf(value) >= 0)
                {
                    throw new NotSupportedException("Unique collections cannot contain duplicate elements.");
                }
            }

            private void CheckUnique(int index, ControlConnection value)
            {
                int num = this.IndexOf(value);
                if ((num >= 0) && (num != index))
                {
                    throw new NotSupportedException("Unique collections cannot contain duplicate elements.");
                }
            }

            public override void Clear()
            {
                this._collection.Clear();
            }

            public override object Clone()
            {
                return new ControlConnectionCollection.UniqueList((ControlConnectionCollection) this._collection.Clone());
            }

            public override void CopyTo(ControlConnection[] array)
            {
                this._collection.CopyTo(array);
            }

            public override void CopyTo(ControlConnection[] array, int arrayIndex)
            {
                this._collection.CopyTo(array, arrayIndex);
            }

            public override IControlConnectionEnumerator GetEnumerator()
            {
                return this._collection.GetEnumerator();
            }

            public override int IndexOf(ControlConnection value)
            {
                return this._collection.IndexOf(value);
            }

            public override void Insert(int index, ControlConnection value)
            {
                this.CheckUnique(value);
                this._collection.Insert(index, value);
            }

            public override void Remove(ControlConnection value)
            {
                this._collection.Remove(value);
            }

            public override void RemoveAt(int index)
            {
                this._collection.RemoveAt(index);
            }

            public override void RemoveRange(int index, int count)
            {
                this._collection.RemoveRange(index, count);
            }

            public override void Reverse()
            {
                this._collection.Reverse();
            }

            public override void Reverse(int index, int count)
            {
                this._collection.Reverse(index, count);
            }

            public override void Sort()
            {
                this._collection.Sort();
            }

            public override void Sort(IComparer comparer)
            {
                this._collection.Sort(comparer);
            }

            public override void Sort(int index, int count, IComparer comparer)
            {
                this._collection.Sort(index, count, comparer);
            }

            public override ControlConnection[] ToArray()
            {
                return this._collection.ToArray();
            }

            public override void TrimToSize()
            {
                this._collection.TrimToSize();
            }

            public override int Capacity
            {
                get
                {
                    return this._collection.Capacity;
                }
                set
                {
                    this._collection.Capacity = value;
                }
            }

            public override int Count
            {
                get
                {
                    return this._collection.Count;
                }
            }

            protected override ControlConnection[] InnerArray
            {
                get
                {
                    return this._collection.InnerArray;
                }
            }

            public override bool IsFixedSize
            {
                get
                {
                    return this._collection.IsFixedSize;
                }
            }

            public override bool IsReadOnly
            {
                get
                {
                    return this._collection.IsReadOnly;
                }
            }

            public override bool IsSynchronized
            {
                get
                {
                    return this._collection.IsSynchronized;
                }
            }

            public override bool IsUnique
            {
                get
                {
                    return true;
                }
            }

            public override ControlConnection this[int index]
            {
                get
                {
                    return this._collection[index];
                }
                set
                {
                    this.CheckUnique(index, value);
                    this._collection[index] = value;
                }
            }

            public override object SyncRoot
            {
                get
                {
                    return this._collection.SyncRoot;
                }
            }
        }
    }
}

