namespace Corillian.Marketing.CampaignManager.WebControls
{
    using System;
    using System.Runtime.CompilerServices;

    public delegate string PageLookup();
}

