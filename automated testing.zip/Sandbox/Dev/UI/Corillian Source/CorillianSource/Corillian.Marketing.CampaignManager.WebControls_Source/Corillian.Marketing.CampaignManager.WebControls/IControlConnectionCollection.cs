namespace Corillian.Marketing.CampaignManager.WebControls
{
    using System;

    public interface IControlConnectionCollection
    {
        void CopyTo(ControlConnection[] array, int arrayIndex);
        IControlConnectionEnumerator GetEnumerator();

        int Count { get; }

        bool IsSynchronized { get; }

        object SyncRoot { get; }
    }
}

