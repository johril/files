using System.Runtime.InteropServices;
// Assembly Corillian.Marketing.CampaignManager.WebControls, Version 4.0.0.0

[assembly: System.Reflection.AssemblyVersion("4.0.0.0")]
[assembly: System.Runtime.CompilerServices.CompilationRelaxations(8)]
//[assembly: System.Diagnostics.Debuggable(System.Diagnostics.DebuggableAttribute.DebuggingModes.IgnoreSymbolStoreSequencePoints | System.Diagnostics.DebuggableAttribute.DebuggingModes.Default)]
[assembly: System.Reflection.AssemblyDescription("")]
[assembly: System.Reflection.AssemblyTitle("Corillian.Marketing.CampaignManager.DataAccess")]
[assembly: System.Runtime.CompilerServices.RuntimeCompatibility(WrapNonExceptionThrows=true)]
[assembly: System.Reflection.AssemblyCompany("Corillian Corporation")]
[assembly: System.Reflection.AssemblyConfiguration("http://subversion/svn/vpsd/suite/release/4.0/dev/CampaignManager -r45842")]
[assembly: System.Reflection.AssemblyCopyright("\x00a9 2004 - 2010 Corillian Corporation")]
[assembly: System.Reflection.AssemblyFileVersion("4.0.0.45841")]

[assembly: ComVisibleAttribute(false)]
