using System;

public enum ExitCodes
{
    ArchiveFailed = 4,
    Duplicate = 3,
    EmptyFile = 2,
    Failed = -1,
    ImportFailure = 6,
    InvalidFileFormat = 8,
    NoFile = 1,
    StartUpFailure = 7,
    StatusFailure = 5,
    Success = 0
}

