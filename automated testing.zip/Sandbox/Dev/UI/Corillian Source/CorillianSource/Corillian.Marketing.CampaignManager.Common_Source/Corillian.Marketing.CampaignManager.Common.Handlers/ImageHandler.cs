namespace Corillian.Marketing.CampaignManager.Common.Handlers
{
    using Corillian.Marketing.Domain;
    using Corillian.Marketing.Messages;
    using Corillian.Marketing.Operations;
    using Corillian.Voyager.Common;
    using Corillian.Voyager.ExecutionServices.Client;
    using Corillian.Voyager.ExecutionServices.Client.Configuration;
    using Corillian.Voyager.Web.Security;
    using System;
    using System.Web;

    public class ImageHandler : IHttpHandler
    {
        private ILoggingService logSvc;

        public ImageHandler()
        {
            this.logSvc = LoggingServiceFactory.GetService(base.GetType());
        }

        private AdContent GetImage(string adMediaGuid)
        {
            GetAdMediaContentResponse adMediaContent = null;
            MarketingServiceProxy proxy = new MarketingServiceProxy();
            if (SiteSecurity.IsLoggedIn())
            {
                GetAdMediaContentRequest req = new GetAdMediaContentRequest();
                req.AdMediaGuid = adMediaGuid;
                adMediaContent = proxy.GetAdMediaContent(req);
            }
            else
            {
                VoyagerService voyagerService = VoyagerService.GetVoyagerService("MarketingServiceProxy");
                string sessionID = voyagerService.CreateSession(Guid.NewGuid().ToString(), SiteConfig.GetSiteConfig().FI);
                try
                {
                    GetAdMediaContentHostDirectRequest request2 = new GetAdMediaContentHostDirectRequest();
                    request2.AdMediaGuid = adMediaGuid;
                    request2.SubTrx = "CMGetAdMediaContent";
                    adMediaContent = proxy.GetAdMediaContentHostDirect(request2, sessionID, SiteConfig.GetSiteConfig().FI);
                }
                finally
                {
                    if (!Strings.IsNullOrEmpty(sessionID))
                    {
                        voyagerService.DeleteSession(sessionID, SiteConfig.GetSiteConfig().FI);
                    }
                }
            }
            return adMediaContent.AdContent;
        }

        public void ProcessRequest(HttpContext context)
        {
            AdContent image = null;
            this.logSvc.Info("ImageHander - Entering ProcessRequest method.");
            string str = context.Request.QueryString["Id"];
            this.logSvc.Info(string.Format("Image Id being requested = {0}", str));
            string key = "IMAGEID-" + str;
            this.logSvc.Info("Checking Cache for image");
            image = (AdContent) context.Cache[key];
            if (image == null)
            {
                this.logSvc.Info("Image not in Cache.  Getting it from DB");
                image = this.GetImage(str);
                if (image == null)
                {
                    this.logSvc.Error("Error while retrieving ad content.");
                    return;
                }
                this.logSvc.Info("Got image from DB, adding it to Cache.");
                context.Cache.Insert(key, image, null, DateTime.MaxValue, TimeSpan.FromHours(4.0));
            }
            else
            {
                this.logSvc.Info("Found Image in Cache.");
            }
            context.Response.ContentType = image.AdMedia.MimeType;
            context.Response.BinaryWrite(image.Content);
        }

        public bool IsReusable
        {
            get
            {
                return true;
            }
        }
    }
}

