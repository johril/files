namespace Corillian.Marketing.CampaignManager.Common
{
    using System;

    public class RandomGenerator
    {
        private static Random _rand = new Random();

        public static int GetRandomNumber()
        {
            return _rand.Next();
        }

        public static int GetRandomNumber(int maxValue)
        {
            return _rand.Next(maxValue);
        }

        public static int GetRandomNumber(int minValue, int maxValue)
        {
            return _rand.Next(minValue, maxValue);
        }
    }
}

