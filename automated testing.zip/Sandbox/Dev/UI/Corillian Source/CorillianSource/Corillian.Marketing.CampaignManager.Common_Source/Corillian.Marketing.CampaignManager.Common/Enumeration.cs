namespace Corillian.Marketing.CampaignManager.Common
{
    using System;

    public class Enumeration
    {
        public static string GetCampaignDisplayPriorityName(string priorityCode)
        {
            switch (priorityCode)
            {
                case "1":
                    return "Low";

                case "2":
                    return "Medium";

                case "3":
                    return "High";

                case "4":
                    return "Override";
            }
            return string.Empty;
        }

        public static string GetCampaignImportMessageStatusName(int state)
        {
            return Enum.GetName(typeof(CampaignImportMessageStatus), state);
        }

        public static string GetCampaignImportStatusName(int state)
        {
            return Enum.GetName(typeof(CampaignImportStatus), state);
        }

        public static string GetCampaignStateName(int state)
        {
            return Enum.GetName(typeof(CampaignState), state);
        }

        public static string GetImportStatusDescription(McifImportStatus status)
        {
            switch (status)
            {
                case McifImportStatus.IMPORTSTARTING:
                    return "Import started.";

                case McifImportStatus.IMPORTING:
                    return "Importing.";

                case McifImportStatus.IMPORTSUCCESSFUL:
                    return "Import successful.";

                case McifImportStatus.IMPORTSUCCESSFULWITHERRORS:
                    return "Import successful with errors.";

                case McifImportStatus.IMPORTFAILED:
                    return "Import failed.";

                case McifImportStatus.EXCEEDEDERRORTHRESHOLD:
                    return "Exceeded error threshold.";

                case McifImportStatus.TIMEDOUT:
                    return "Import timed out.";
            }
            return "Import in un-known status.";
        }

        public enum AdMediaType
        {
            Flash = 2,
            Image = 1,
            Text = 3
        }

        public enum CampaignDisplayPriority
        {
            High = 3,
            Low = 1,
            Medium = 2,
            Override = 4
        }

        public enum CampaignImportMessageStatus
        {
            Error = 1,
            Info = 4,
            Suggestion = 3,
            Warning = 2
        }

        public enum CampaignImportStatus
        {
            CompletedSucessfully = 2,
            CompletedWithErrors = 3,
            CompletedWithSugestions = 5,
            CompletedWithWarnings = 4,
            Running = 1
        }

        public enum CampaignInteraction
        {
            ACCEPT = 1,
            DECLINE = 3,
            REMIND = 2
        }

        public enum CampaignState
        {
            All,
            Incomplete,
            Valid,
            Active,
            Expired
        }

        public enum CampaignType
        {
            SYTEMINTERNAL,
            STANDARD,
            INTERCEPT
        }

        public enum ComparisonOperators
        {
            Contains = 9,
            DoesNotContain = 10,
            DoesNotEqual = 6,
            EqualTo = 1,
            GreaterThan = 2,
            GreaterThanOrEqualTo = 3,
            IsIn = 7,
            LessThan = 4,
            LessThanOrEqualTo = 5,
            Like = 8
        }

        public class CriterionDataType
        {
            public const string BOOLEAN = "BOOLEAN";
            public const string DATETIME = "DATETIME";
            public const string DECIMAL = "DECIMAL";
            public const string INTEGER = "INTEGER";
            public const string LIST = "LIST";
            public const string MONEY = "MONEY";
            public const string STRING = "STRING";
        }

        public enum DataTypes
        {
            SelectType,
            STRING,
            DATETIME,
            DECIMAL,
            INTEGER,
            MONEY,
            BOOLEAN,
            LIST
        }

        public enum DeleteUnDeleteStatus
        {
            UnDelete,
            Delete
        }

        internal enum FrequencyGroups
        {
            High = 3,
            Low = 1,
            Med = 2
        }

        public enum InclusionFilter
        {
            All = -1,
            No = 0,
            Yes = 1
        }

        public enum McifImportStatus
        {
            IMPORTSTARTING,
            IMPORTING,
            IMPORTSUCCESSFUL,
            IMPORTSUCCESSFULWITHERRORS,
            IMPORTFAILED,
            EXCEEDEDERRORTHRESHOLD,
            TIMEDOUT
        }

        public enum OperandTypes
        {
            Criterion = 2,
            Rule = 1
        }

        public enum RuleFilter
        {
            All = -1,
            No = 0,
            Yes = 1
        }

        public class RuleTokenType
        {
            public const string Add = "+";
            public const string And = "AND";
            public const string Contains = "CONTAINS";
            public const string Criterion = "CRITERION";
            public const string Divide = "/";
            public const string DoesNotContain = "DOESNOTCONTAIN";
            public const string EndSet = ")";
            public const string EndVariable = "]";
            public const string Greaterthan = ">";
            public const string GreaterthanOrEquals = ">=";
            public const string In = "IN";
            public const string Indicator = "INDICATOR";
            public const string IsEqualTo = "=";
            public const string IsTestcell = "ISTESTCELL";
            public const string Lessthan = "<";
            public const string LessthanOrEquals = "<=";
            public const string Like = "LIKE";
            public const string Literal = "LITERAL";
            public const string Multiply = "*";
            public const string NoOperation = "NOOP";
            public const string NotEquals = "!=";
            public const string Or = "OR";
            public const string Payee = "PAYEE";
            public const string Power = "^";
            public const string Rule = "RULE";
            public const string StartSet = "(";
            public const string StartVariable = "[";
            public const string Substract = "-";
            public const string Testcell = "TESTCELL";
        }

        public enum SetOperators
        {
            None,
            And,
            Or
        }

        public enum TokenFilter
        {
            NormalTokens,
            TestCellTokens
        }

        public enum VoyagerCriterion
        {
            Age,
            Birthdate,
            BillPayDays,
            City,
            PostalCode,
            State,
            TaxId,
            RelationshipName,
            EnrollmentDate,
            BusinessUser,
            PrimaryUser,
            PayeeCount,
            PaymentDays
        }
    }
}

