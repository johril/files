namespace Corillian.Marketing.CampaignManager.Common
{
    using System;

    public class CampaignManagerException : ApplicationException
    {
        private string _errorCode;

        public CampaignManagerException(string errorCode, string message) : base(message)
        {
            this._errorCode = errorCode;
        }

        public CampaignManagerException(string errorCode, string message, Exception innerException) : base(message, innerException)
        {
            this._errorCode = errorCode;
        }

        public string ErrorCode
        {
            get
            {
                return this._errorCode;
            }
        }
    }
}

