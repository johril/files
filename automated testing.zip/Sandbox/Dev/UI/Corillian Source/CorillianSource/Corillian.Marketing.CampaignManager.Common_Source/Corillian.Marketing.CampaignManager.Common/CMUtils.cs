namespace Corillian.Marketing.CampaignManager.Common
{
    using System;
    using System.Collections;
    using System.Drawing;
    using System.Drawing.Drawing2D;
    using System.Drawing.Imaging;
    using System.Globalization;
    using System.IO;
    using System.Reflection;
    using System.Text.RegularExpressions;

    public class CMUtils
    {
        private static string[] _dateFormats = new string[] { "MM/dd/yyyy", "M/dd/yyyy", "MM/d/yyyy", "M/d/yyyy" };
        private static Hashtable _htBooleanPatterns = GetAllowedBooleanPatterns();

        public static bool ConvertToBoolean(string val)
        {
            if ((val == null) || (val == string.Empty))
            {
                return false;
            }
            val = val.ToLower();
            return ((((val == "y") || (val == "t")) || (((val == "1") || (val == "true")) || (val == "yes"))) || (((!(val == "n") && !(val == "f")) && ((!(val == "0") && !(val == "false")) && !(val == "no"))) && Convert.ToBoolean(val)));
        }

        private static Hashtable GetAllowedBooleanPatterns()
        {
            Hashtable hashtable = new Hashtable();
            hashtable.Add("true", "true");
            hashtable.Add("false", "false");
            hashtable.Add("t", "t");
            hashtable.Add("f", "f");
            hashtable.Add("y", "y");
            hashtable.Add("n", "n");
            hashtable.Add("yes", "yes");
            hashtable.Add("no", "no");
            hashtable.Add("0", "0");
            hashtable.Add("1", "1");
            return hashtable;
        }

        public static byte[] GetFlashThumbnail()
        {
            using (Stream stream = Assembly.GetExecutingAssembly().GetManifestResourceStream("Corillian.Marketing.CampaignManager.Common.flash-default.jpeg"))
            {
                Image image = Image.FromStream(stream);
                MemoryStream stream2 = new MemoryStream();
                image.Save(stream2, ImageFormat.Jpeg);
                return stream2.GetBuffer();
            }
        }

        public static byte[] GetThumbnail(string text)
        {
            byte[] buffer;
            Size size = new Size(0x80, 0x80);
            using (Image image = new Bitmap(size.Width, size.Height))
            {
                using (Graphics graphics = Graphics.FromImage(image))
                {
                    graphics.CompositingQuality = CompositingQuality.HighQuality;
                    graphics.SmoothingMode = SmoothingMode.HighQuality;
                    graphics.InterpolationMode = InterpolationMode.HighQualityBicubic;
                    Rectangle rect = new Rectangle(0, 0, size.Width, size.Height);
                    graphics.FillRectangle(new SolidBrush(Color.White), rect);
                    SolidBrush brush = new SolidBrush(Color.Black);
                    graphics.DrawString(text, new Font("tahoma", 8f), brush, new PointF(2f, 60f), StringFormat.GenericDefault);
                    using (MemoryStream stream = new MemoryStream())
                    {
                        image.Save(stream, ImageFormat.Jpeg);
                        buffer = stream.GetBuffer();
                    }
                }
            }
            return buffer;
        }

        public static byte[] GetThumbnail(byte[] imgContent)
        {
            byte[] buffer;
            using (MemoryStream stream = new MemoryStream(imgContent))
            {
                Size size = new Size(0x80, 0x80);
                Image image = Image.FromStream(stream);
                Image image2 = new Bitmap(size.Width, size.Height);
                using (Graphics graphics = Graphics.FromImage(image2))
                {
                    graphics.CompositingQuality = CompositingQuality.HighQuality;
                    graphics.SmoothingMode = SmoothingMode.HighQuality;
                    graphics.InterpolationMode = InterpolationMode.HighQualityBicubic;
                    Rectangle rect = new Rectangle(0, 0, size.Width, size.Height);
                    graphics.DrawImage(image, rect);
                    using (MemoryStream stream2 = new MemoryStream())
                    {
                        image2.Save(stream2, ImageFormat.Jpeg);
                        buffer = stream2.GetBuffer();
                    }
                }
            }
            return buffer;
        }

        public static bool IsBoolean(string expression)
        {
            if (expression == null)
            {
                return false;
            }
            return _htBooleanPatterns.Contains(expression.ToLower());
        }

        public static bool IsCSV(string csv)
        {
            return (IsValidString(csv) && Regex.IsMatch(csv, @"^[\u0020]*[\u0021-\u002B\u002D-\u007E]+[\u0020-\u002B\u002D-\u007E]*(?:\,[\u0020]*[\u0021-\u002B\u002D-\u007E][\u0020-\u002B\u002D-\u007E]*)*$", RegexOptions.Compiled));
        }

        public static bool IsDate(object obj)
        {
            string s = Convert.ToString(obj);
            bool flag = false;
            try
            {
                DateTime time = DateTime.ParseExact(s, _dateFormats, null, DateTimeStyles.None);
                if ((time != DateTime.MinValue) && (time != DateTime.MaxValue))
                {
                    flag = true;
                }
            }
            catch
            {
            }
            return flag;
        }

        public static bool IsInteger(string expression)
        {
            double num;
            return double.TryParse(expression, NumberStyles.Integer, (IFormatProvider) NumberFormatInfo.InvariantInfo, out num);
        }

        public static bool IsName(string name)
        {
            return Regex.IsMatch(name, @"^[\u0020]*[\u0021-\u007E]+[\u0020-\u007E]*$", RegexOptions.Compiled);
        }

        public static bool IsNumeric(object expression)
        {
            double num;
            return double.TryParse(Convert.ToString(expression), NumberStyles.Any, (IFormatProvider) NumberFormatInfo.InvariantInfo, out num);
        }

        public static bool IsValid(object expression, Enumeration.DataTypes dataType)
        {
            switch (dataType)
            {
                case Enumeration.DataTypes.STRING:
                    return IsName(Convert.ToString(expression));

                case Enumeration.DataTypes.DATETIME:
                    return IsDate(Convert.ToString(expression));

                case Enumeration.DataTypes.DECIMAL:
                case Enumeration.DataTypes.MONEY:
                    return IsNumeric(expression);

                case Enumeration.DataTypes.INTEGER:
                    return IsInteger(Convert.ToString(expression));

                case Enumeration.DataTypes.BOOLEAN:
                    return IsBoolean(Convert.ToString(expression));

                case Enumeration.DataTypes.LIST:
                    return IsCSV(Convert.ToString(expression));
            }
            throw new NotImplementedException(string.Format("Criterian Type {0} is not defined in IsValid Method", dataType));
        }

        public static bool IsValid(object expression, string dataType)
        {
            return IsValid(expression, (Enumeration.DataTypes) Enum.Parse(typeof(Enumeration.DataTypes), dataType, true));
        }

        public static bool IsValidCriteriaName(string str)
        {
            return Regex.IsMatch(str, @"^[\u005F\u0041-\u005A\u0061-\u007A]+[\u0020-\u007E]*$", RegexOptions.Compiled);
        }

        public static bool IsValidString(string str)
        {
            return Regex.IsMatch(str, @"^[\u0020-\u007E]+$", RegexOptions.Compiled);
        }
    }
}

