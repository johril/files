namespace Corillian.Marketing.CampaignManager.Common
{
    using System;

    [Flags]
    public enum WindowFlags
    {
        AllowWindowResize = 2,
        ShowAddressBar = 8,
        ShowInNewWindow = 1,
        ShowMenuBar = 4,
        ShowScrollBar = 0x40,
        ShowStatusBar = 0x20,
        ShowToolbar = 0x10
    }
}

