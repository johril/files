using System;
using System.Runtime.InteropServices;

[StructLayout(LayoutKind.Sequential)]
public struct CustomerFI
{
    public int fiNumber;
    public int customerNumber;
}

