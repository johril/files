﻿using System;
using System.Text;
using System.Collections.Generic;
using System.Linq;
using System.Xml.Linq;

using Microsoft.VisualStudio.TestTools.UnitTesting;
using Models;

namespace Card.Tests
{
    [TestClass]
    public class CardTest
    {
        [TestMethod]
        public void When_GetCardMapping_Is_Called_With_Cards_Property_Not_Populated_Should_Return_Empty_CardMapping()
        {
            //arrange
            CardRepository cardRepository = new CardRepository();

            //Act
            var cardMapping = cardRepository.GetCardMapping();

            //Assert
            Assert.AreEqual("<CardMapping />", cardMapping, "GetCardMapping did not return the correct response.");
        }

        [TestMethod]
        public void When_GetCardMapping_Is_Called_With_Cards_Property_Populated_Should_Return_CardMapping()
        {
            //arrange
            CardRepository cardRepository = new CardRepository();

            Models.Card card = new Models.Card
                                         {
                                             Alias = "alias",
                                             Email = "email@test.com",
                                             Expiration = "02/15",
                                             Number = "99999999999999999999999",
                                             Phone = "12345677890"
                                         };

            cardRepository.Cards.Add(card);

            //Act
            var cardMapping = cardRepository.GetCardMapping();

            //Assert
            XElement expectedCardMapping = new XElement("CardMapping",
                                                        new XElement("Card", new XElement("alias", card.Alias),
                                                                     new XElement("number", card.Number),
                                                                     new XElement("expiration", card.Expiration),
                                                                     new XElement("phone", card.Phone),
                                                                     new XElement("email", card.Email)));
      
            Assert.AreEqual(expectedCardMapping.ToString(SaveOptions.DisableFormatting), cardMapping, "GetCardMapping did not return the correct response.");
        }


        [TestMethod]
        public void When_GetAliasList_Is_Called_With_Cards_Property_Not_Populated_Should_Return_EmptyCardMapping()
        {
            //arrange
            CardRepository cardRepository = new CardRepository();

            
            //Act
            var aliasList = cardRepository.GetAliasList();

            //Assert
            Assert.AreEqual("<CardMapping />", aliasList, "GetAliasList did not return the correct response.");
        }


        [TestMethod]
        public void When_GetAliasList_Is_Called_With_Cards_Property_Populated_Should_Return_An_AliasList()
        {
            //arrange
            CardRepository cardRepository = new CardRepository();
            Models.Card card = new Models.Card
            {
                Alias = "alias",
                Email = "email@test.com",
                Expiration = "02/15",
                Number = "99999999999999999999999",
                Phone = "12345677890"
            };

            cardRepository.Cards.Add(card);

            //Act
            var aliasList = cardRepository.GetAliasList();

            //Assert
            XElement expectedAliasList = new XElement("CardMapping",
                                                        new XElement("Card", new XElement("alias", string.Format("{0}%", card.Alias))));

            Assert.AreEqual(expectedAliasList.ToString(SaveOptions.DisableFormatting), aliasList.ToString(), "GetAliasList did not return the correct response.");
        }
    }
}
