﻿using System;
using System.Globalization;
using Huntington.OnlineBanking.Common.Extensions;

namespace Huntington.OnlineBanking.Common.Data
{
    public static class DBConvert
    {
        public static bool ToBoolean(object val)
        {
            return ToBoolean(val, false);
        }

        public static bool ToBoolean(object val, bool defaultValue)
        {
            if (val == null || Convert.IsDBNull(val)) return defaultValue;
            if (val is bool) return Convert.ToBoolean(val);
            string sVal = val.ToString();
            if (string.IsNullOrEmpty(sVal)) return defaultValue;

            sVal = sVal.Substring(0, 1).ToLower();
            return (sVal == "t" || sVal == "y" || sVal == "1");
        }

        public static short ToInt16(object val)
        {
            return ToInt16(val, short.MinValue);
        }

        public static short ToInt16(object val, short defaultValue)
        {
            if (val == null || Convert.IsDBNull(val)) return defaultValue;

            short rc;
            return short.TryParse(val.ToString(), out rc) ? rc : defaultValue;
        }

        public static int ToInt32(object val)
        {
            return ToInt32(val, int.MinValue);
        }

        public static int ToInt32(object val, int defaultValue)
        {
            if (val == null || Convert.IsDBNull(val)) return defaultValue;

            int rc;
            return int.TryParse(val.ToString(), out rc) ? rc : defaultValue;
        }

        public static long ToInt64(object val)
        {
            return ToInt64(val, long.MinValue);
        }

        public static long ToInt64(object val, long defaultValue)
        {
            if (val == null || Convert.IsDBNull(val)) return defaultValue;

            long rc;
            return long.TryParse(val.ToString(), out rc) ? rc : defaultValue;
        }

        public static double ToDouble(object val)
        {
            return ToDouble(val, double.MinValue);
        }

        public static double ToDouble(object val, double defaultValue)
        {
            if (val == null || Convert.IsDBNull(val)) return defaultValue;

            double rc;
            return double.TryParse(val.ToString(), out rc) ? rc : defaultValue;
        }

        public static string ToString(object val)
        {
            return ToString(val, null);
        }

        public static string ToString(object val, string defaultValue)
        {
            if (val == null || Convert.IsDBNull(val)) return defaultValue;

            return val.ToString();
        }

        public static DateTime ToDateTime(object val)
        {
            return ToDateTime(val, DateTime.Now.GetNullValue());
        }

        public static DateTime ToDateTime(object val, DateTime defaultValue)
        {
            if (val == null || Convert.IsDBNull(val)) return defaultValue;

            DateTime rc;
            return DateTime.TryParse(val.ToString(), out rc) ? rc : defaultValue;
        }

        public static object ToDBNull(object val)
        {
            return val ?? DBNull.Value;
        }

        public static Decimal ToDecimal(object val)
        {
            //BRT - Reflected Decimal, it passes in NumberStyles.Number by default.
            return ToDecimal(val, default(Decimal), NumberStyles.Number);
        }

        public static Decimal ToDecimal(object val, Decimal defaultValue, NumberStyles numberStyles)
        {
            if (val == null || Convert.IsDBNull(val)) return defaultValue;

            Decimal rc;

            //BRT - Reflected Decimal, it passes in NumberFormatInfo.CurrentInfo by default.
            return Decimal.TryParse(val.ToString(), numberStyles, NumberFormatInfo.CurrentInfo, out rc) ? rc : defaultValue;
        }
    }
}
