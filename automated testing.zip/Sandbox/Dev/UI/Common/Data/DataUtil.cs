﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using System.Linq;
using System.Reflection;
using System.Text;
using Huntington.OnlineBanking.Common.Extensions;
using log4net;
using log4net.Config;
using log4net.Core;

namespace Huntington.OnlineBanking.Common.Data
{
    #region Delegates

    /// <summary>
    /// Encapsulates a method that converts the current row of a <c>System.Data.IDataReader</c> to an object specified by the <c>TResult</c> parameter.
    /// </summary>
    /// <typeparam name="TResult">
    ///     The type of the object returned by the method that this delegate encapsulates.
    /// </typeparam>
    /// <param name="columnDictionary">
    ///     An instance of an <c>IDictionary</c> generic object that holds the mappings between the column name, 
    ///     designated by the <c>System.String</c> dictionary key, and its index, designated as the <c>System.Int32</c> return value. 
    ///     Use the <paramref name="columnDictionary"/> to obtain the index of each column by name.
    /// </param>
    /// <param name="reader">
    ///     An instance of the current <c>System.Data.IDataReader</c> that is processing the data from the database.
    /// </param>
    /// <remarks>
    ///     This delegate is invoked for every row in the <paramref name="reader"/>.
    /// </remarks>
    public delegate TResult ReaderToObjectAction<TResult>( IDictionary<string, int> columnDictionary, IDataReader reader );

    /// <summary>
    /// Encapsulates a method that returns a generic <c>IDictionary</c> object that holds the column name and corresponding index mappings
    /// for the supplied <c>System.Data.IDataReader</c> object.
    /// </summary>
    /// <param name="reader">
    ///     The <c>System.Data.IDataReader</c> instance that is processing the results from the database.
    /// </param>
    /// <returns>
    ///     An instance of a dictionary object.
    /// </returns>
    /// <remarks>
    ///     This delegate is invoked once before the <paramref name="reader"/> begins reading data from the database.
    /// </remarks>
    public delegate IDictionary<string, int> ColumnOrdinalsAction( IDataReader reader );

    #endregion

    /// <summary>
    /// Encapsulates common data access logic for working with ADO.NET.
    /// </summary>
    public static class DataUtil
    {
        /// <summary>
        /// A reference to the Log4net logger.
        /// </summary>
        private static ILog Log
        {
            get
            {
                if (_log == null)
                {
                    XmlConfigurator.Configure();
                    _log = LogManager.GetLogger(typeof (DataUtil));
                }

                return _log;
            }
        }

        private static ILog _log;
        private static int _rowsRead;

        /// <summary>
        /// Returns the value from the specified <c>IDataReader</c> at the specified column index if it's not a <see cref="System.DBNull"/>.
        /// Otherwise, the specified default value is returned.
        /// </summary>
        /// <typeparam name="T">The type of object being returned.</typeparam>
        /// <param name="reader">An instance of a <c>System.Data.IDataReader</c> implementation.</param>
        /// <param name="columnIndex">Index of the column where the value is located.</param>
        /// <param name="readerAction">The method delegate to invoke if the column value is not a <c>System.DBNull</c>.</param>
        /// <param name="defaultValue">The default value to use when the value is <c>System.DBNull</c>.</param>
        /// <returns>
        ///     Either the value at the specified <paramref name="columnIndex"/> or <paramref name="defaultValue"/>.
        /// </returns>
        /// <exception cref="System.ArgumentNullException">
        ///     <paramref name="reader"/> or <paramref name="readerAction"/> is a <c>null</c> reference
        ///     (<c>Nothing</c> in Visual Basic).
        /// </exception>
        public static T GetDataReaderValue<T>( IDataReader reader, int columnIndex, Func<int, T> readerAction, T defaultValue )
        {
            if ( null == reader )
                throw new ArgumentNullException( "reader" );

            if ( null == readerAction )
                throw new ArgumentNullException( "readerAction" );

            if ( reader.IsDBNull( columnIndex ) )
                return defaultValue;
            
            return readerAction( columnIndex );
        }

        #region CreateCommand
        /// <summary>
        /// Creates a SQL command given its database connection and pre-execute action.
        /// </summary>
        /// <param name="connection">
        ///     The active connection object for the current ADO.NET data provider.
        /// </param>
        /// <param name="commandText"></param>
        /// <param name="commandType">The type of command, e.g. stored procedure or text.</param>
        public static IDbCommand CreateCommand(IDbConnection connection, string commandText, CommandType commandType = CommandType.StoredProcedure)
        {
            return CreateCommand(connection, commandText, commandType, (Action<IDbCommand>)null);
        }

        private static Action<IDbCommand> GetParameterAction(Dictionary<string, object> parameters)
        {
            Action<IDbCommand> parameterSetup = null;
            if (parameters != null && parameters.Count > 0)
            {
                parameterSetup = cmd =>
                {
                    foreach (KeyValuePair<string, object> parameter in parameters)
                    {
                        if (string.IsNullOrEmpty(parameter.Key)) continue;

                        string key = parameter.Key;
                        if (!key.StartsWith("@")) key = "@" + key;
                        cmd.AddInputParameterWithValue(key, parameter.Value);
                    }
                };
            }

            return parameterSetup;
        }

        /// <summary>
        /// Creates a SQL command given its database connection and pre-execute action.
        /// </summary>
        /// <param name="connection">
        ///     The active connection object for the current ADO.NET data provider.
        /// </param>
        /// <param name="commandText"></param>
        /// <param name="parameters">A collection of parameters</param>
        /// <returns>A reference to a <c>System.Data.IDbCommand</c> for the current
        /// ADO.NET data provider associated with the supplied <paramref name="connection"/>.
        /// </returns>
        /// <exception cref="ArgumentNullException">
        ///         <paramref name="connection"/> is a <c>null</c> reference (<c>Nothing</c> in Visual Basic).
        /// </exception>
        /// <exception cref="System.ArgumentException">
        ///         <paramref name="commandText"/> is a <c>null</c> reference (<c>Nothing</c> in Visual Basic)
        ///         or an empty string.
        /// </exception>
        public static IDbCommand CreateCommand(IDbConnection connection, string commandText, Dictionary<string, object> parameters)
        {
            Action<IDbCommand> parameterSetup = GetParameterAction(parameters);

            return CreateCommand(connection, commandText, CommandType.StoredProcedure, parameterSetup);
        }

        /// <summary>
        /// Creates a SQL command given its database connection and pre-execute action.
        /// </summary>
        /// <param name="connection">
        ///     The active connection object for the current ADO.NET data provider.
        /// </param>
        /// <param name="commandText"></param>
        /// <param name="preExecuteAction">
        ///     The method to invoke before the SQL command is executed. 
        ///     This is normally used for setting up command parameters.
        ///     This parameter can be set to <c>null</c>, which indicates that no pre-execute action is required.
        ///     <returns>
        ///         A reference to a <c>System.Data.IDbCommand</c> for the current
        ///         ADO.NET data provider associated with the supplied <paramref name="connection"/>.
        ///     </returns>
        ///     <exception cref="ArgumentNullException">
        ///         <paramref name="connection"/> is a <c>null</c> reference (<c>Nothing</c> in Visual Basic).
        ///     </exception>
        ///     <exception cref="System.ArgumentException">
        ///         <paramref name="commandText"/> is a <c>null</c> reference (<c>Nothing</c> in Visual Basic)
        ///         or an empty string.
        ///     </exception>
        /// </param>
        public static IDbCommand CreateCommand(IDbConnection connection, string commandText, Action<IDbCommand> preExecuteAction)
        {
            return CreateCommand(connection, commandText, CommandType.StoredProcedure, preExecuteAction);
        }

        /// <summary>
        /// Creates a SQL command given its database connection and pre-execute action.
        /// </summary>
        /// <param name="connection">
        ///     The active connection object for the current ADO.NET data provider.
        /// </param>
        /// <param name="commandText"></param>
        /// <param name="commandType">The type of command, e.g. stored procedure or text.</param>
        /// <param name="parameters">A collection of parameters</param>
        /// <returns>
        ///         A reference to a <c>System.Data.IDbCommand</c> for the current
        ///         ADO.NET data provider associated with the supplied <paramref name="connection"/>.
        /// </returns>
        /// <exception cref="ArgumentNullException">
        ///         <paramref name="connection"/> is a <c>null</c> reference (<c>Nothing</c> in Visual Basic).
        /// </exception>
        /// <exception cref="System.ArgumentException">
        ///         <paramref name="commandText"/> is a <c>null</c> reference (<c>Nothing</c> in Visual Basic)
        ///         or an empty string.
        /// </exception>
        public static IDbCommand CreateCommand(IDbConnection connection, string commandText, CommandType commandType, Dictionary<string, object> parameters)
        {
            Action<IDbCommand> parameterSetup = GetParameterAction(parameters);

            return CreateCommand(connection, commandText, commandType, parameterSetup);
        }

        /// <summary>
        /// Creates a SQL command given its database connection and pre-execute action.
        /// </summary>
        /// <param name="connection">
        ///     The active connection object for the current ADO.NET data provider.
        /// </param>
        /// <param name="commandText"></param>
        /// <param name="commandType">The type of command, e.g. stored procedure or text.</param>
        /// <param name="preExecuteAction">
        ///     The method to invoke before the SQL command is executed. 
        ///     This is normally used for setting up command parameters.
        ///     This parameter can be set to <c>null</c>, which indicates that no pre-execute action is required.
        /// </param>
        /// <returns>
        ///         A reference to a <c>System.Data.IDbCommand</c> for the current
        ///         ADO.NET data provider associated with the supplied <paramref name="connection"/>.
        /// </returns>
        /// <exception cref="ArgumentNullException">
        ///         <paramref name="connection"/> is a <c>null</c> reference (<c>Nothing</c> in Visual Basic).
        /// </exception>
        /// <exception cref="System.ArgumentException">
        ///         <paramref name="commandText"/> is a <c>null</c> reference (<c>Nothing</c> in Visual Basic)
        ///         or an empty string.
        /// </exception>
        public static IDbCommand CreateCommand(IDbConnection connection, string commandText, CommandType commandType, Action<IDbCommand> preExecuteAction)
        {
            if (null == connection)
                throw new ArgumentNullException( "connection" );

            if ( String.IsNullOrEmpty( commandText ) )
                throw new ArgumentException( "The SQL command cannot be a null reference or empty string", "commandText" );

            IDbCommand cmd = connection.CreateCommand();

            // Set up command
            cmd.CommandText = commandText;
            cmd.CommandType = commandType;

            // Set up parameters
            if ( null != preExecuteAction )
            {
                preExecuteAction( cmd );
            }

            return cmd;
        }
        #endregion

        #region Parameter-related functions
        /// <summary>
        /// Creates an input parameter compatible with the given command object and returns the parameter.
        /// The parameter is not automatically added to the command object. It is your responsibility to do so.
        /// </summary>
        /// <param name="cmd">The command object for the current database connection.</param>
        /// <param name="parameterName">The name of the parameter that is compatible with the ADO.NET data provider in use.</param>
        /// <param name="parameterType">The data type of the parameter.</param>
        /// <param name="size">The size (in bytes) of the parameter.</param>
        /// <param name="value">The value of the parameter. Can be set to <c>null</c>, in which case it will be replaced with <see cref="System.DBNull.Value"/>.</param>
        /// <returns>
        ///     A reference to a <c>System.Data.IDbDataParameter</c>. 
        ///     The parameter will need to be added to the <paramref name="cmd"/> in your code.
        /// </returns>
        public static IDbDataParameter CreateInputParameter( IDbCommand cmd, string parameterName, DbType parameterType, int size, object value )
        {
            IDbDataParameter myParam = CreateInputParameterWithValue( cmd, parameterName, value );
            myParam.DbType = parameterType;
            myParam.Size = size;

            return myParam;
        }

        /// <summary>
        /// Creates an input parameter compatible with the given command object and value, and returns the parameter.
        /// The parameter is not automatically added to the command object. It is your responsibility to do so.
        /// </summary>
        /// <param name="cmd">The command object for the current database connection.</param>
        /// <param name="parameterName">The name of the parameter that is compatible with the ADO.NET data provider in use.</param>
        /// <param name="value">The value of the parameter. Can be set to <c>null</c>, in which case it will be replaced with <see cref="System.DBNull.Value"/>.</param>
        /// <returns>
        ///     A reference to a <c>System.Data.IDbDataParameter</c>. 
        ///     The parameter will need to be added to the <paramref name="cmd"/> in your code.
        /// </returns>
        public static IDbDataParameter CreateInputParameterWithValue(IDbCommand cmd, string parameterName, object value)
        {
            IDbDataParameter myParam = cmd.CreateParameter();
            myParam.ParameterName = parameterName;
            myParam.Direction = ParameterDirection.Input;

            myParam.Value = IsNull(value) ? DBNull.Value : value;

            return myParam;
        }

        public static bool IsNull (object value)
        {
            if (value == null) return true;

            if (value is short)
            {
                short val = (short)value;
                return val.IsNull();
            }
            if (value is int)
            {
                int val = (int)value;
                return val.IsNull();
            }
            if (value is long)
            {
                long val = (long)value;
                return val.IsNull();
            }
            if (value is float)
            {
                float val = (float)value;
                return val.IsNull();
            }
            if (value is double)
            {
                double val = (double)value;
                return val.IsNull();
            }
            if (value is decimal)
            {
                decimal val = (decimal)value;
                return val.IsNull();
            }
            if (value is DateTime)
            {
                DateTime val = (DateTime)value;
                return val.IsNull();
            }

            return false;
        }

        /// <summary>
        /// Creates an output parameter that is compatible with the given command object and returns the parameter.
        /// The parameter is not automatically added to the command object. It is your responsibility to do so.
        /// </summary>
        /// <param name="cmd">The command object for the current database connection.</param>
        /// <param name="parameterName">The name of the parameter that is compatible with the ADO.NET data provider in use.</param>
        /// <param name="parameterType">The data type of the parameter.</param>
        /// <param name="size">The size (in bytes) of the parameter.</param>
        /// <param name="value">The value of the parameter. Can be set to <c>null</c>, in which case it will be replaced with <see cref="System.DBNull.Value"/>.</param>
        /// <returns>
        ///     A reference to a <c>System.Data.IDbDataParameter</c>. 
        ///     The parameter will need to be added to the <paramref name="cmd"/> in your code.
        /// </returns>
        public static IDbDataParameter CreateOutputParameter( IDbCommand cmd, string parameterName, DbType parameterType, int size, object value )
        {
            IDbDataParameter myParam = cmd.CreateParameter();
            myParam.ParameterName = parameterName;
            myParam.Direction = ParameterDirection.InputOutput;
            myParam.DbType = parameterType;
            myParam.Size = size;
            myParam.Value = value ?? DBNull.Value;

            return myParam;
        }

        /// <summary>
        /// Returns a reference to a <c>System.Data.IDbDataParameter</c>, given the command object where it is located 
        /// and the parameter's name.
        /// </summary>
        /// <param name="cmd">The command object for the current database connection.</param>
        /// <param name="parameterName">The name of the parameter that is compatible with the ADO.NET data provider in use.</param>
        /// <returns>
        ///     A reference to the <c>System.Data.IDbDataParameter</c> that matches the supplied <paramref name="parameterName"/>.
        /// </returns>
        public static IDbDataParameter GetParameter( IDbCommand cmd, string parameterName )
        {
            return (IDbDataParameter)cmd.Parameters[ parameterName ];
        }

        /// <summary>
        /// Appends a stored procedure's return value parameter (<c>@RETURN_VALUE</c>) to the collection of parameters of the
        /// given command object.
        /// </summary>
        /// <param name="cmd">The command object for the current database connection.</param>
        /// <returns>
        ///     A reference to the return value parameter.
        /// </returns>
        /// <remarks>
        ///     This method is compatible with SQL Server only.
        /// </remarks>
        public static IDbDataParameter AppendReturnValueParameter( IDbCommand cmd )
        {
            return AppendReturnValueParameter( cmd, "@RETURN_VALUE" );
        }

        /// <summary>
        /// Appends a stored procedure's return value parameter to the collection of parameters of the
        /// given command object.
        /// </summary>
        /// <param name="cmd">
        ///     The command object for the current database connection.
        /// </param>
        /// <param name="returnValueParameterName">
        ///     The name of the return value parameter that is compatible with the ADO.NET data provider in use.
        /// </param>
        /// <returns>
        ///     A reference to the return value parameter.
        /// </returns>
        /// <remarks>
        ///     It is assumed that the return value parameter's data type is <see cref="DbType.Int32"/>.
        /// </remarks>
        public static IDbDataParameter AppendReturnValueParameter( IDbCommand cmd, string returnValueParameterName )
        {
            // Return value parameter
            IDbDataParameter retValParam = cmd.CreateParameter();
            retValParam.ParameterName = returnValueParameterName;
            retValParam.Direction = ParameterDirection.ReturnValue;
            retValParam.DbType = DbType.Int32;
            retValParam.Size = 4;
            cmd.Parameters.Add( retValParam );

            return retValParam;
        }
        #endregion

        #region ExecuteNonQuery
        /// <summary>
        /// Executes a specified SQL command against the given connection object of a .NET Framework data provider. 
        /// This method implements a common pattern when working with the ADO.NET IDbCommand object's ExecuteNonQuery() method,
        /// where pre-execution and post-execution logic needs to be run.
        /// </summary>
        /// <param name="providerFactory">The database provider factory.</param>
        /// <param name="connectionString">The database connection string.</param>
        /// <param name="commandText">
        ///     The SQL command to execute against the database.
        /// </param>
        /// <param name="parameters">A collection of parameters</param>
        /// <param name="postExecuteAction">
        ///     The method to invoke after the SQL command has successfully completed.
        ///     This is normally used for checking the result of a return value from a stored procedure and/or
        ///     for reading output parameters.
        ///     This parameter can be set to <c>null</c>, which indicates that no post-execute action is needed.
        /// </param>
        /// <param name="errorHandlerAction">
        ///     The method to invoke in case an error occurs. The method contains a single parameter
        ///     of type <see cref="System.Exception"/>, which holds a reference to the actual exception.
        ///     This method is normally used to prevent bubbling up of exceptions and for logging errors.
        ///     This parameter can be set to <c>null</c> (<c>Nothing</c> in Visual Basic), at which point 
        ///     the error will be propagated to the calling method.
        /// </param>
        /// <exception cref="ArgumentNullException">
        ///     <paramref name="providerFactory"/> is a <c>null</c> reference (<c>Nothing</c> in Visual Basic).
        /// </exception>
        /// <exception cref="System.ArgumentException">
        ///     <paramref name="commandText"/> is a <c>null</c> reference (<c>Nothing</c> in Visual Basic)
        ///     or an empty string.
        /// </exception>
        /// <exception cref="System.Exception">
        ///     Thrown only when <paramref name="errorHandlerAction"/> is a <c>null</c> reference (<c>Nothing</c> in Visual Basic)
        ///     and an error occurs within this method.
        /// </exception>
        public static int ExecuteNonQuery(DbProviderFactory providerFactory, string connectionString, string commandText,
            Dictionary<string, object> parameters, Action<IDbCommand> postExecuteAction = null, Action<Exception> errorHandlerAction = null)
        {
            Action<IDbCommand> parameterSetup = GetParameterAction(parameters);

            return ExecuteNonQuery(providerFactory, connectionString, commandText, parameterSetup, postExecuteAction, errorHandlerAction);
        }

        /// <summary>
        /// Executes a specified SQL command against the given connection object of a .NET Framework data provider. 
        /// This method implements a common pattern when working with the ADO.NET IDbCommand object's ExecuteNonQuery() method,
        /// where pre-execution and post-execution logic needs to be run.
        /// </summary>
        /// <param name="providerFactory">The database provider factory.</param>
        /// <param name="connectionString">The database connection string.</param>
        /// <param name="commandText">
        ///     The SQL command to execute against the database.
        /// </param>
        /// <param name="preExecuteAction">
        ///     The method to invoke before the SQL command is executed. 
        ///     This is normally used for setting up command parameters.
        ///     This parameter can be set to <c>null</c>, which indicates that no pre-execute action is required.
        /// </param>
        /// <param name="postExecuteAction">
        ///     The method to invoke after the SQL command has successfully completed.
        ///     This is normally used for checking the result of a return value from a stored procedure and/or
        ///     for reading output parameters.
        ///     This parameter can be set to <c>null</c>, which indicates that no post-execute action is needed.
        /// </param>
        /// <param name="errorHandlerAction">
        ///     The method to invoke in case an error occurs. The method contains a single parameter
        ///     of type <see cref="System.Exception"/>, which holds a reference to the actual exception.
        ///     This method is normally used to prevent bubbling up of exceptions and for logging errors.
        ///     This parameter can be set to <c>null</c> (<c>Nothing</c> in Visual Basic), at which point 
        ///     the error will be propagated to the calling method.
        /// </param>
        /// <exception cref="ArgumentNullException">
        ///     <paramref name="providerFactory"/> is a <c>null</c> reference (<c>Nothing</c> in Visual Basic).
        /// </exception>
        /// <exception cref="System.ArgumentException">
        ///     <paramref name="commandText"/> is a <c>null</c> reference (<c>Nothing</c> in Visual Basic)
        ///     or an empty string.
        /// </exception>
        /// <exception cref="System.Exception">
        ///     Thrown only when <paramref name="errorHandlerAction"/> is a <c>null</c> reference (<c>Nothing</c> in Visual Basic)
        ///     and an error occurs within this method.
        /// </exception>
        public static int ExecuteNonQuery(DbProviderFactory providerFactory, string connectionString, string commandText,
            Action<IDbCommand> preExecuteAction = null, Action<IDbCommand> postExecuteAction = null, Action<Exception> errorHandlerAction = null)
        {
            return ExecuteNonQuery(providerFactory, connectionString, commandText, CommandType.StoredProcedure, preExecuteAction, postExecuteAction, errorHandlerAction);
        }

        /// <summary>
        /// Executes a specified SQL command against the given connection object of a .NET Framework data provider. 
        /// This method implements a common pattern when working with the ADO.NET IDbCommand object's ExecuteNonQuery() method,
        /// where pre-execution and post-execution logic needs to be run.
        /// </summary>
        /// <param name="providerFactory">The database provider factory.</param>
        /// <param name="connectionString">The database connection string.</param>
        /// <param name="commandText">
        ///     The SQL command to execute against the database.
        /// </param>
        /// <param name="commandType">The type of command to execute.</param>
        /// <param name="parameters">A collection of parameters</param>
        /// <param name="postExecuteAction">
        ///     The method to invoke after the SQL command has successfully completed.
        ///     This is normally used for checking the result of a return value from a stored procedure and/or
        ///     for reading output parameters.
        ///     This parameter can be set to <c>null</c>, which indicates that no post-execute action is needed.
        /// </param>
        /// <param name="errorHandlerAction">
        ///     The method to invoke in case an error occurs. The method contains a single parameter
        ///     of type <see cref="System.Exception"/>, which holds a reference to the actual exception.
        ///     This method is normally used to prevent bubbling up of exceptions and for logging errors.
        ///     This parameter can be set to <c>null</c> (<c>Nothing</c> in Visual Basic), at which point 
        ///     the error will be propagated to the calling method.
        /// </param>
        /// <param name="rethrowException">Whether to rethrow any exception.</param>
        /// <exception cref="ArgumentNullException">
        ///     <paramref name="providerFactory"/> is a <c>null</c> reference (<c>Nothing</c> in Visual Basic).
        /// </exception>
        /// <exception cref="System.ArgumentException">
        ///     <paramref name="commandText"/> is a <c>null</c> reference (<c>Nothing</c> in Visual Basic)
        ///     or an empty string.
        /// </exception>
        /// <exception cref="System.Exception">
        ///     Thrown only when <paramref name="errorHandlerAction"/> is a <c>null</c> reference (<c>Nothing</c> in Visual Basic)
        ///     and an error occurs within this method.
        /// </exception>
        public static int ExecuteNonQuery(DbProviderFactory providerFactory, string connectionString, string commandText,
            CommandType commandType, Dictionary<string, object> parameters,
            Action<IDbCommand> postExecuteAction = null, Action<Exception> errorHandlerAction = null, bool rethrowException = false)
        {
            Action<IDbCommand> parameterSetup = GetParameterAction(parameters);

            return ExecuteNonQuery(providerFactory, connectionString, commandText, commandType, parameterSetup, postExecuteAction, errorHandlerAction,
                                   rethrowException);
        }

        /// <summary>
        /// Executes a specified SQL command against the given connection object of a .NET Framework data provider. 
        /// This method implements a common pattern when working with the ADO.NET IDbCommand object's ExecuteNonQuery() method,
        /// where pre-execution and post-execution logic needs to be run.
        /// </summary>
        /// <param name="providerFactory">The database provider factory.</param>
        /// <param name="connectionString">The database connection string.</param>
        /// <param name="commandText">
        ///     The SQL command to execute against the database.
        /// </param>
        /// <param name="commandType">The type of command to execute.</param>
        /// <param name="preExecuteAction">
        ///     The method to invoke before the SQL command is executed. 
        ///     This is normally used for setting up command parameters.
        ///     This parameter can be set to <c>null</c>, which indicates that no pre-execute action is required.
        /// </param>
        /// <param name="postExecuteAction">
        ///     The method to invoke after the SQL command has successfully completed.
        ///     This is normally used for checking the result of a return value from a stored procedure and/or
        ///     for reading output parameters.
        ///     This parameter can be set to <c>null</c>, which indicates that no post-execute action is needed.
        /// </param>
        /// <param name="errorHandlerAction">
        ///     The method to invoke in case an error occurs. The method contains a single parameter
        ///     of type <see cref="System.Exception"/>, which holds a reference to the actual exception.
        ///     This method is normally used to prevent bubbling up of exceptions and for logging errors.
        ///     This parameter can be set to <c>null</c> (<c>Nothing</c> in Visual Basic), at which point 
        ///     the error will be propagated to the calling method.
        /// </param>
        /// <param name="rethrowException">Whether to rethrow any exception.</param>
        /// <exception cref="ArgumentNullException">
        ///     <paramref name="providerFactory"/> is a <c>null</c> reference (<c>Nothing</c> in Visual Basic).
        /// </exception>
        /// <exception cref="System.ArgumentException">
        ///     <paramref name="commandText"/> is a <c>null</c> reference (<c>Nothing</c> in Visual Basic)
        ///     or an empty string.
        /// </exception>
        /// <exception cref="System.Exception">
        ///     Thrown only when <paramref name="errorHandlerAction"/> is a <c>null</c> reference (<c>Nothing</c> in Visual Basic)
        ///     and an error occurs within this method.
        /// </exception>
        public static int ExecuteNonQuery(DbProviderFactory providerFactory, string connectionString, string commandText,
            CommandType commandType, Action<IDbCommand> preExecuteAction = null,
			Action<IDbCommand> postExecuteAction = null, Action<Exception> errorHandlerAction = null, bool rethrowException = false)
        {
            if (providerFactory == null) throw new ArgumentException("Missing required parameter 'providerFactory'!");

            using (DbConnection connection = providerFactory.CreateConnection())
            {
                connection.ConnectionString = connectionString;
                return ExecuteNonQuery(connection, commandText, commandType, preExecuteAction, postExecuteAction, errorHandlerAction, rethrowException);
            }
        }

        /// <summary>
        /// Executes a specified SQL command against the given connection object of a .NET Framework data provider. 
        /// This method implements a common pattern when working with the ADO.NET IDbCommand object's ExecuteNonQuery() method,
        /// where pre-execution and post-execution logic needs to be run.
        /// </summary>
        /// <param name="connection">
        ///     A connection object. The connection will be automatically opened and closed by this method.
        /// </param>
        /// <param name="commandText">
        ///     The SQL command to execute against the database.
        /// </param>
        /// <param name="parameters">A collection of parameters</param>
        /// <param name="postExecuteAction">
        ///     The method to invoke after the SQL command has successfully completed.
        ///     This is normally used for checking the result of a return value from a stored procedure and/or
        ///     for reading output parameters.
        ///     This parameter can be set to <c>null</c>, which indicates that no post-execute action is needed.
        /// </param>
        /// <param name="errorHandlerAction">
        ///     The method to invoke in case an error occurs. The method contains a single parameter
        ///     of type <see cref="System.Exception"/>, which holds a reference to the actual exception.
        ///     This method is normally used to prevent bubbling up of exceptions and for logging errors.
        ///     This parameter can be set to <c>null</c> (<c>Nothing</c> in Visual Basic), at which point 
        ///     the error will be propagated to the calling method.
        /// </param>
        /// <param name="rethrowException">Whether to rethrow any exception.</param>
        /// <exception cref="ArgumentNullException">
        ///     <paramref name="connection"/> is a <c>null</c> reference (<c>Nothing</c> in Visual Basic).
        /// </exception>
        /// <exception cref="System.ArgumentException">
        ///     <paramref name="commandText"/> is a <c>null</c> reference (<c>Nothing</c> in Visual Basic)
        ///     or an empty string.
        /// </exception>
        /// <exception cref="System.Exception">
        ///     Thrown only when <paramref name="errorHandlerAction"/> is a <c>null</c> reference (<c>Nothing</c> in Visual Basic)
        ///     and an error occurs within this method.
        /// </exception>
        public static int ExecuteNonQuery(IDbConnection connection, string commandText, Dictionary<string, object> parameters,
            Action<IDbCommand> postExecuteAction = null, Action<Exception> errorHandlerAction = null, bool rethrowException = false)
        {
            Action<IDbCommand> parameterSetup = GetParameterAction(parameters);

            return ExecuteNonQuery(connection, commandText, CommandType.StoredProcedure, parameterSetup, postExecuteAction, errorHandlerAction, rethrowException);
        }

        /// <summary>
        /// Executes a specified SQL command against the given connection object of a .NET Framework data provider. 
        /// This method implements a common pattern when working with the ADO.NET IDbCommand object's ExecuteNonQuery() method,
        /// where pre-execution and post-execution logic needs to be run.
        /// </summary>
        /// <param name="connection">
        ///     A connection object. The connection will be automatically opened and closed by this method.
        /// </param>
        /// <param name="commandText">
        ///     The SQL command to execute against the database.
        /// </param>
        /// <param name="preExecuteAction">
        ///     The method to invoke before the SQL command is executed. 
        ///     This is normally used for setting up command parameters.
        ///     This parameter can be set to <c>null</c>, which indicates that no pre-execute action is required.
        /// </param>
        /// <param name="postExecuteAction">
        ///     The method to invoke after the SQL command has successfully completed.
        ///     This is normally used for checking the result of a return value from a stored procedure and/or
        ///     for reading output parameters.
        ///     This parameter can be set to <c>null</c>, which indicates that no post-execute action is needed.
        /// </param>
        /// <param name="errorHandlerAction">
        ///     The method to invoke in case an error occurs. The method contains a single parameter
        ///     of type <see cref="System.Exception"/>, which holds a reference to the actual exception.
        ///     This method is normally used to prevent bubbling up of exceptions and for logging errors.
        ///     This parameter can be set to <c>null</c> (<c>Nothing</c> in Visual Basic), at which point 
        ///     the error will be propagated to the calling method.
        /// </param>
        /// <param name="rethrowException">Whether to rethrow any exception.</param>
        /// <exception cref="ArgumentNullException">
        ///     <paramref name="connection"/> is a <c>null</c> reference (<c>Nothing</c> in Visual Basic).
        /// </exception>
        /// <exception cref="System.ArgumentException">
        ///     <paramref name="commandText"/> is a <c>null</c> reference (<c>Nothing</c> in Visual Basic)
        ///     or an empty string.
        /// </exception>
        /// <exception cref="System.Exception">
        ///     Thrown only when <paramref name="errorHandlerAction"/> is a <c>null</c> reference (<c>Nothing</c> in Visual Basic)
        ///     and an error occurs within this method.
        /// </exception>
        public static int ExecuteNonQuery(IDbConnection connection, string commandText, Action<IDbCommand> preExecuteAction,
			Action<IDbCommand> postExecuteAction = null, Action<Exception> errorHandlerAction = null, bool rethrowException = false)
        {
            return ExecuteNonQuery(connection, commandText, CommandType.StoredProcedure, preExecuteAction, postExecuteAction, errorHandlerAction, rethrowException);
        }

        /// <summary>
        /// Executes a specified SQL command against the given connection object of a .NET Framework data provider. 
        /// This method implements a common pattern when working with the ADO.NET IDbCommand object's ExecuteNonQuery() method,
        /// where pre-execution and post-execution logic needs to be run.
        /// </summary>
        /// <param name="connection">
        ///     A connection object. The connection will be automatically opened and closed by this method.
        /// </param>
        /// <param name="commandText">
        ///     The SQL command to execute against the database.
        /// </param>
        /// <param name="commandType">The type of command to execute.</param>
        /// <param name="parameters">A collection of parameters</param>
        /// <param name="postExecuteAction">
        ///     The method to invoke after the SQL command has successfully completed.
        ///     This is normally used for checking the result of a return value from a stored procedure and/or
        ///     for reading output parameters.
        ///     This parameter can be set to <c>null</c>, which indicates that no post-execute action is needed.
        /// </param>
        /// <param name="errorHandlerAction">
        ///     The method to invoke in case an error occurs. The method contains a single parameter
        ///     of type <see cref="System.Exception"/>, which holds a reference to the actual exception.
        ///     This method is normally used to prevent bubbling up of exceptions and for logging errors.
        ///     This parameter can be set to <c>null</c> (<c>Nothing</c> in Visual Basic), at which point 
        ///     the error will be propagated to the calling method.
        /// </param>
        /// <param name="rethrowException">Whether to rethrow any exception.</param>
        /// <exception cref="ArgumentNullException">
        ///     <paramref name="connection"/> is a <c>null</c> reference (<c>Nothing</c> in Visual Basic).
        /// </exception>
        /// <exception cref="System.ArgumentException">
        ///     <paramref name="commandText"/> is a <c>null</c> reference (<c>Nothing</c> in Visual Basic)
        ///     or an empty string.
        /// </exception>
        /// <exception cref="System.Exception">
        ///     Thrown only when <paramref name="errorHandlerAction"/> is a <c>null</c> reference (<c>Nothing</c> in Visual Basic)
        ///     and an error occurs within this method.
        /// </exception>
        public static int ExecuteNonQuery(IDbConnection connection, string commandText, CommandType commandType, Dictionary<string, object> parameters,
            Action<IDbCommand> postExecuteAction = null, Action<Exception> errorHandlerAction = null, bool rethrowException = false)
        {
            Action<IDbCommand> parameterSetup = GetParameterAction(parameters);

            return ExecuteNonQuery(connection, commandText, commandType, parameterSetup, postExecuteAction, errorHandlerAction, rethrowException);
        }

        /// <summary>
        /// Executes a specified SQL command against the given connection object of a .NET Framework data provider. 
        /// This method implements a common pattern when working with the ADO.NET IDbCommand object's ExecuteNonQuery() method,
        /// where pre-execution and post-execution logic needs to be run.
        /// </summary>
        /// <param name="connection">
        ///     A connection object. The connection will be automatically opened and closed by this method.
        /// </param>
        /// <param name="commandText">
        ///     The SQL command to execute against the database.
        /// </param>
        /// <param name="commandType">The type of command to execute.</param>
        /// <param name="preExecuteAction">
        ///     The method to invoke before the SQL command is executed. 
        ///     This is normally used for setting up commnand parameters.
        ///     This parameter can be set to <c>null</c>, which indicates that no pre-execute action is required.
        /// </param>
        /// <param name="postExecuteAction">
        ///     The method to invoke after the SQL command has successfully completed.
        ///     This is normally used for checking the result of a return value from a stored procedure and/or
        ///     for reading output parameters.
        ///     This parameter can be set to <c>null</c>, which indicates that no post-execute action is needed.
        /// </param>
        /// <param name="errorHandlerAction">
        ///     The method to invoke in case an error occurs. The method contains a single parameter
        ///     of type <see cref="System.Exception"/>, which holds a reference to the actual exception.
        ///     This method is normally used to prevent bubbling up of exceptions and for logging errors.
        ///     This parameter can be set to <c>null</c> (<c>Nothing</c> in Visual Basic), at which point 
        ///     the error will be propagated to the calling method.
        /// </param>
        /// <param name="rethrowException">Whether to rethrow any exception.</param>
        /// <exception cref="ArgumentNullException">
        ///     <paramref name="connection"/> is a <c>null</c> reference (<c>Nothing</c> in Visual Basic).
        /// </exception>
        /// <exception cref="System.ArgumentException">
        ///     <paramref name="commandText"/> is a <c>null</c> reference (<c>Nothing</c> in Visual Basic)
        ///     or an empty string.
        /// </exception>
        /// <exception cref="System.Exception">
        ///     Thrown only when <paramref name="errorHandlerAction"/> is a <c>null</c> reference (<c>Nothing</c> in Visual Basic)
        ///     and an error occurs within this method.
        /// </exception>
        public static int ExecuteNonQuery(IDbConnection connection, string commandText, CommandType commandType, Action<IDbCommand> preExecuteAction, 
            Action<IDbCommand> postExecuteAction = null, Action<Exception> errorHandlerAction = null, bool rethrowException = false)
        {
            if ( null == connection )
                throw new ArgumentNullException( "connection" );

            if ( String.IsNullOrEmpty( commandText ) )
                throw new ArgumentException("The SQL command cannot be a null reference or empty string", "commandText");

            try
            {
                using ( connection )
                {
                    connection.Open();

                    return ExecuteNonQueryWithSharedConnection( connection, commandText, commandType, preExecuteAction, postExecuteAction );
                }
            }
            catch ( Exception ex )
            {
                if (Log != null) Log.Error(string.Format("Error calling '{0}'", commandText), ex);

                if (null == errorHandlerAction)
                    throw;
                
                errorHandlerAction( ex );

				if (rethrowException)
					throw;

                return -1;
            }
        }

        /// <summary>
        /// Executes a specified SQL command against the given connection object of a .NET Framework data provider. 
        /// The connection object is an already existing open connection that is being used in a transaction.
        /// This method implements a common pattern when working with the ADO.NET IDbCommand object's ExecuteNonQuery() method,
        /// where pre-execution and post-execution logic needs to be run. The caller is responsible for handling any exceptions.
        /// </summary>
        /// <param name="connection">
        ///     A connection object. The connection will be automatically opened and closed by this method.
        /// </param>
        /// <param name="commandText">
        ///     The SQL command to execute against the database.
        /// </param>
        /// <param name="parameters">A collection of parameters</param>
        /// <param name="postExecuteAction">
        ///     The method to invoke after the SQL command has successfully completed.
        ///     This is normally used for checking the result of a return value from a stored procedure and/or
        ///     for reading output parameters.
        ///     This parameter can be set to <c>null</c>, which indicates that no post-execute action is needed.
        /// </param>
        /// <exception cref="ArgumentNullException">
        ///     <paramref name="connection"/> is a <c>null</c> reference (<c>Nothing</c> in Visual Basic).
        /// </exception>
        /// <exception cref="System.ArgumentException">
        ///     <paramref name="commandText"/> is a <c>null</c> reference (<c>Nothing</c> in Visual Basic)
        ///     or an empty string.
        /// </exception>
        /// <exception cref="System.Exception">
        ///     Thrown when an error occurs.
        /// </exception>
        public static int ExecuteNonQueryWithSharedConnection(IDbConnection connection, string commandText,
            Dictionary<string, object> parameters, Action<IDbCommand> postExecuteAction = null)
        {
            Action<IDbCommand> parameterSetup = GetParameterAction(parameters);

            return ExecuteNonQueryWithSharedConnection(connection, commandText, parameterSetup, postExecuteAction);
        }

        /// <summary>
        /// Executes a specified SQL command against the given connection object of a .NET Framework data provider. 
        /// The connection object is an already existing open connection that is being used in a transaction.
        /// This method implements a common pattern when working with the ADO.NET IDbCommand object's ExecuteNonQuery() method,
        /// where pre-execution and post-execution logic needs to be run. The caller is responsible for handling any exceptions.
        /// </summary>
        /// <param name="connection">
        ///     A connection object. The connection will be automatically opened and closed by this method.
        /// </param>
        /// <param name="commandText">
        ///     The SQL command to execute against the database.
        /// </param>
        /// <param name="preExecuteAction">
        ///     The method to invoke before the SQL command is executed. 
        ///     This is normally used for setting up command parameters.
        ///     This parameter can be set to <c>null</c>, which indicates that no pre-execute action is required.
        /// </param>
        /// <param name="postExecuteAction">
        ///     The method to invoke after the SQL command has successfully completed.
        ///     This is normally used for checking the result of a return value from a stored procedure and/or
        ///     for reading output parameters.
        ///     This parameter can be set to <c>null</c>, which indicates that no post-execute action is needed.
        /// </param>
        /// <exception cref="ArgumentNullException">
        ///     <paramref name="connection"/> is a <c>null</c> reference (<c>Nothing</c> in Visual Basic).
        /// </exception>
        /// <exception cref="System.ArgumentException">
        ///     <paramref name="commandText"/> is a <c>null</c> reference (<c>Nothing</c> in Visual Basic)
        ///     or an empty string.
        /// </exception>
        /// <exception cref="System.Exception">
        ///     Thrown when an error occurs.
        /// </exception>
        public static int ExecuteNonQueryWithSharedConnection(IDbConnection connection, string commandText, 
            Action<IDbCommand> preExecuteAction = null, Action<IDbCommand> postExecuteAction = null)
        {
            return ExecuteNonQueryWithSharedConnection(connection, commandText, CommandType.StoredProcedure, preExecuteAction, postExecuteAction);
        }

        /// <summary>
        /// Executes a specified SQL command against the given connection object of a .NET Framework data provider. 
        /// The connection object is an already existing open connection that is being used in a transaction.
        /// This method implements a common pattern when working with the ADO.NET IDbCommand object's ExecuteNonQuery() method,
        /// where pre-execution and post-execution logic needs to be run. The caller is responsible for handling any exceptions.
        /// </summary>
        /// <param name="connection">
        ///     A connection object. The connection will be automatically opened and closed by this method.
        /// </param>
        /// <param name="commandText">
        ///     The SQL command to execute against the database.
        /// </param>
        /// <param name="commandType">The type of command to execute.</param>
        /// <param name="parameters">A collection of parameters</param>
        /// <param name="postExecuteAction">
        ///     The method to invoke after the SQL command has successfully completed.
        ///     This is normally used for checking the result of a return value from a stored procedure and/or
        ///     for reading output parameters.
        ///     This parameter can be set to <c>null</c>, which indicates that no post-execute action is needed.
        /// </param>
        /// <exception cref="ArgumentNullException">
        ///     <paramref name="connection"/> is a <c>null</c> reference (<c>Nothing</c> in Visual Basic).
        /// </exception>
        /// <exception cref="System.ArgumentException">
        ///     <paramref name="commandText"/> is a <c>null</c> reference (<c>Nothing</c> in Visual Basic)
        ///     or an empty string.
        /// </exception>
        /// <exception cref="System.Exception">
        ///     Thrown when an error occurs.
        /// </exception>
        public static int ExecuteNonQueryWithSharedConnection(IDbConnection connection, string commandText, CommandType commandType,
            Dictionary<string, object> parameters, Action<IDbCommand> postExecuteAction = null)
        {
            Action<IDbCommand> parameterSetup = GetParameterAction(parameters);

            return ExecuteNonQueryWithSharedConnection(connection, commandText, commandType, parameterSetup, postExecuteAction);
        }

        /// <summary>
        /// Executes a specified SQL command against the given connection object of a .NET Framework data provider. 
        /// The connection object is an already existing open connection that is being used in a transaction.
        /// This method implements a common pattern when working with the ADO.NET IDbCommand object's ExecuteNonQuery() method,
        /// where pre-execution and post-execution logic needs to be run. The caller is responsible for handling any exceptions.
        /// </summary>
        /// <param name="connection">
        ///     A connection object. The connection will be automatically opened and closed by this method.
        /// </param>
        /// <param name="commandText">
        ///     The SQL command to execute against the database.
        /// </param>
        /// <param name="commandType">The type of command to execute.</param>
        /// <param name="preExecuteAction">
        ///     The method to invoke before the SQL command is executed. 
        ///     This is normally used for setting up command parameters.
        ///     This parameter can be set to <c>null</c>, which indicates that no pre-execute action is required.
        /// </param>
        /// <param name="postExecuteAction">
        ///     The method to invoke after the SQL command has successfully completed.
        ///     This is normally used for checking the result of a return value from a stored procedure and/or
        ///     for reading output parameters.
        ///     This parameter can be set to <c>null</c>, which indicates that no post-execute action is needed.
        /// </param>
        /// <exception cref="ArgumentNullException">
        ///     <paramref name="connection"/> is a <c>null</c> reference (<c>Nothing</c> in Visual Basic).
        /// </exception>
        /// <exception cref="System.ArgumentException">
        ///     <paramref name="commandText"/> is a <c>null</c> reference (<c>Nothing</c> in Visual Basic)
        ///     or an empty string.
        /// </exception>
        /// <exception cref="System.Exception">
        ///     Thrown when an error occurs.
        /// </exception>
        public static int ExecuteNonQueryWithSharedConnection(IDbConnection connection, string commandText, CommandType commandType, 
            Action<IDbCommand> preExecuteAction = null, Action<IDbCommand> postExecuteAction = null)
        {
            if ( null == connection )
                throw new ArgumentNullException( "connection" );

            if ( String.IsNullOrEmpty( commandText ) )
                throw new ArgumentException("The SQL command cannot be a null reference or empty string", "commandText");

            using (IDbCommand cmd = CreateCommand(connection, commandText, commandType, preExecuteAction))
            {
                // Log the command we're about to execute.
                LogCommand(cmd);

                // Execute command
                int rc = cmd.ExecuteNonQuery();

                if ( null != postExecuteAction )
                {
                    postExecuteAction( cmd );
                }

                return rc;
            }
        }
        #endregion

        #region ExecuteReader
        /// <summary>
        /// Executes a <see cref="System.Data.IDataReader"/> against the specified connection, given the SQL command that returns
        /// the result set to process, the method that generates a dictionary of column indexes, and the method that converts
        /// each row in the result set to an object of type <typeparamref name="T"/>.
        /// </summary>
        /// <typeparam name="T">
        ///     The type of the object being created for each row in the result set.
        /// </typeparam>
        /// <param name="providerFactory">The database provider factory.</param>
        /// <param name="connectionString">The database connection string.</param>
        /// <param name="storedProcName">
        ///     The SQL command to execute./>.
        /// </param>
        /// <param name="ordinalColumns">
        ///     The list of columns that will be indexed for quicker access. The column list will be converted to a ColumnOrdinalsAction 
        ///     before data are read from the data reader.
        /// </param>
        /// <param name="actionPerRow">
        ///     The method to invoke to convert each item in the result set to an object of type <typeparamref name="T"/>.
        /// </param>
        /// <param name="parameterSetupAction">
        ///     The method to invoke to set up the SQL command's parameters. Can be set to <c>null</c>
        ///     (<c>Nothing</c> in Visual Basic) if the command accepts no parameters.
        /// </param>
        /// <param name="errorHandlerAction">
        ///     The method to invoke in case an error occurs. The method contains a single parameter
        ///     of type <see cref="System.Exception"/>, which holds a reference to the actual exception.
        ///     This method is normally used to prevent propagation of exceptions and for logging errors.
        /// </param>
        /// <exception cref="System.Exception">
        ///     An unhandled error occurred due to a database or program logic error.
        /// </exception>
        public static int ExecuteReader<T>(DbProviderFactory providerFactory, string connectionString, string storedProcName, List<string> ordinalColumns,
            ReaderToObjectAction<T> actionPerRow, Action<IDbCommand> parameterSetupAction = null, Action<Exception> errorHandlerAction = null)
        {
            if (providerFactory == null) throw new ArgumentException("Missing required parameter 'providerFactory'!");

            ColumnOrdinalsAction columnOrdinalsAction = GetColumnOrdinals(ordinalColumns);

            return ExecuteReader(providerFactory, connectionString, storedProcName, columnOrdinalsAction, actionPerRow, parameterSetupAction, errorHandlerAction);
        }

        /// <summary>
        /// Executes a <see cref="System.Data.IDataReader"/> against the specified connection, given the SQL command that returns
        /// the result set to process, the method that generates a dictionary of column indexes, and the method that converts
        /// each row in the result set to an object of type <typeparamref name="T"/>.
        /// </summary>
        /// <typeparam name="T">
        ///     The type of the object being created for each row in the result set.
        /// </typeparam>
        /// <param name="providerFactory">The database provider factory.</param>
        /// <param name="connectionString">The database connection string.</param>
        /// <param name="storedProcName">
        ///     The SQL command to execute./>.
        /// </param>
        /// <param name="columnOrdinalsAction">
        ///     The method that creates a dictionary of column indexes. This action is executed before data are read from the
        ///     data reader.
        /// </param>
        /// <param name="actionPerRow">
        ///     The method to invoke to convert each item in the result set to an object of type <typeparamref name="T"/>.
        /// </param>
        /// <param name="parameterSetupAction">
        ///     The method to invoke to set up the SQL command's parameters. Can be set to <c>null</c>
        ///     (<c>Nothing</c> in Visual Basic) if the command accepts no parameters.
        /// </param>
        /// <param name="errorHandlerAction">
        ///     The method to invoke in case an error occurs. The method contains a single parameter
        ///     of type <see cref="System.Exception"/>, which holds a reference to the actual exception.
        ///     This method is normally used to prevent propagation of exceptions and for logging errors.
        /// </param>
        /// <exception cref="System.Exception">
        ///     An unhandled error occurred due to a database or program logic error.
        /// </exception>
        public static int ExecuteReader<T>(DbProviderFactory providerFactory, string connectionString, string storedProcName, ColumnOrdinalsAction columnOrdinalsAction,
            ReaderToObjectAction<T> actionPerRow, Action<IDbCommand> parameterSetupAction = null, Action<Exception> errorHandlerAction = null)
        {
            if (providerFactory == null) throw new ArgumentException("Missing required parameter 'providerFactory'!");

            using (DbConnection connection = providerFactory.CreateConnection())
            {
                connection.ConnectionString = connectionString;
                return ExecuteReader(connection, storedProcName, columnOrdinalsAction, actionPerRow, parameterSetupAction, errorHandlerAction);
            }
        }

        /// <summary>
        /// Executes a <see cref="System.Data.IDataReader"/> against the specified connection, given the SQL command that returns
        /// the result set to process, the method that generates a dictionary of column indexes, and the method that converts
        /// each row in the result set to an object of type <typeparamref name="T"/>.
        /// </summary>
        /// <typeparam name="T">
        ///     The type of the object being created for each row in the result set.
        /// </typeparam>
        /// <param name="connection">
        ///     The current database connection. The connection is automatically opened and closed by this method.
        /// </param>
        /// <param name="storedProcName">
        ///     The SQL command to execute against the <paramref name="connection"/>.
        /// </param>
        /// <param name="ordinalColumns">
        ///     The list of columns that will be indexed for quicker access. The column list will be converted to a ColumnOrdinalsAction 
        ///     before data are read from the data reader.
        /// </param>
        /// <param name="actionPerRow">
        ///     The method to invoke to convert each item in the result set to an object of type <typeparamref name="T"/>.
        /// </param>
        /// <param name="parameterSetupAction">
        ///     The method to invoke to set up the SQL command's parameters. Can be set to <c>null</c>
        ///     (<c>Nothing</c> in Visual Basic) if the command accepts no parameters.
        /// </param>
        /// <param name="errorHandlerAction">
        ///     The method to invoke in case an error occurs. The method contains a single parameter
        ///     of type <see cref="System.Exception"/>, which holds a reference to the actual exception.
        ///     This method is normally used to prevent propagation of exceptions and for logging errors.
        /// </param>
        /// <param name="rethrowException">
        ///     Should this method rethrow exception?  If not it will log exceptions and consume them.
        /// </param>
        /// <exception cref="System.Exception">
        ///     An unhandled error occurred due to a database or program logic error.
        /// </exception>
        public static int ExecuteReader<T>(IDbConnection connection, string storedProcName, List<string> ordinalColumns, ReaderToObjectAction<T> actionPerRow,
            Action<IDbCommand> parameterSetupAction = null, Action<Exception> errorHandlerAction = null, bool rethrowException = false)
        {
            ColumnOrdinalsAction columnOrdinalsAction = GetColumnOrdinals(ordinalColumns);

            return ExecuteReader(connection, storedProcName, CommandType.StoredProcedure, columnOrdinalsAction,
                                 actionPerRow, parameterSetupAction, errorHandlerAction, rethrowException);
        }

        /// <summary>
        /// Executes a <see cref="System.Data.IDataReader"/> against the specified connection, given the SQL command that returns
        /// the result set to process, the method that generates a dictionary of column indexes, and the method that converts
        /// each row in the result set to an object of type <typeparamref name="T"/>.
        /// </summary>
        /// <typeparam name="T">
        ///     The type of the object being created for each row in the result set.
        /// </typeparam>
        /// <param name="connection">
        ///     The current database connection. The connection is automatically opened and closed by this method.
        /// </param>
        /// <param name="storedProcName">
        ///     The SQL command to execute against the <paramref name="connection"/>.
        /// </param>
        /// <param name="columnOrdinalsAction">
        ///     The method that creates a dictionary of column indexes. This action is executed before data are read from the
        ///     data reader.
        /// </param>
        /// <param name="actionPerRow">
        ///     The method to invoke to convert each item in the result set to an object of type <typeparamref name="T"/>.
        /// </param>
        /// <param name="parameterSetupAction">
        ///     The method to invoke to set up the SQL command's parameters. Can be set to <c>null</c>
        ///     (<c>Nothing</c> in Visual Basic) if the command accepts no parameters.
        /// </param>
        /// <param name="errorHandlerAction">
        ///     The method to invoke in case an error occurs. The method contains a single parameter
        ///     of type <see cref="System.Exception"/>, which holds a reference to the actual exception.
        ///     This method is normally used to prevent propagation of exceptions and for logging errors.
        /// </param>
        /// <param name="rethrowException">
        ///     Should this method rethrow exception?  If not it will log exceptions and consume them.
        /// </param>
        /// <exception cref="System.Exception">
        ///     An unhandled error occurred due to a database or program logic error.
        /// </exception>
        public static int ExecuteReader<T>(IDbConnection connection, string storedProcName, ColumnOrdinalsAction columnOrdinalsAction, 
            ReaderToObjectAction<T> actionPerRow, Action<IDbCommand> parameterSetupAction = null, Action<Exception> errorHandlerAction = null,
            bool rethrowException = false)
        {
            return ExecuteReader(connection, storedProcName, CommandType.StoredProcedure, columnOrdinalsAction,
                actionPerRow, parameterSetupAction, errorHandlerAction, rethrowException);
        }

        /// <summary>
        /// Executes a <see cref="System.Data.IDataReader"/> against the specified connection, given the SQL command that returns
        /// the result set to process, the method that generates a dictionary of column indexes, and the method that converts
        /// each row in the result set to an object of type <typeparamref name="T"/>.
        /// </summary>
        /// <typeparam name="T">
        ///     The type of the object being created for each row in the result set.
        /// </typeparam>
        /// <param name="providerFactory">The database provider factory.</param>
        /// <param name="connectionString">The database connection string.</param>
        /// <param name="commandText">
        ///     The SQL command to execute./>.
        /// </param>
        /// <param name="commandType">The type of command (e.g. stored procedure or text)</param>
        /// <param name="ordinalColumns">
        ///     The list of columns that will be indexed for quicker access. The column list will be converted to a ColumnOrdinalsAction 
        ///     before data are read from the data reader.
        /// </param>
        /// <param name="actionPerRow">
        ///     The method to invoke to convert each item in the result set to an object of type <typeparamref name="T"/>.
        /// </param>
        /// <param name="parameterSetupAction">
        ///     The method to invoke to set up the SQL command's parameters. Can be set to <c>null</c>
        ///     (<c>Nothing</c> in Visual Basic) if the command accepts no parameters.
        /// </param>
        /// <param name="errorHandlerAction">
        ///     The method to invoke in case an error occurs. The method contains a single parameter
        ///     of type <see cref="System.Exception"/>, which holds a reference to the actual exception.
        ///     This method is normally used to prevent propagation of exceptions and for logging errors.
        /// </param>
        /// <param name="rethrowException">
        ///     Should this method rethrow exception?  If not it will log exceptions and consume them.
        /// </param>
        /// <exception cref="ArgumentNullException">
        ///     <paramref name="providerFactory"/>, <paramref name="ordinalColumns"/> or 
        ///     <paramref name="actionPerRow"/> is a <c>null</c> reference (<c>Nothing</c> in Visual Basic).
        /// </exception>
        /// <exception cref="System.ArgumentException">
        ///     <paramref name="commandText"/> is a <c>null</c> reference (<c>Nothing</c> in Visual Basic)
        ///     or an empty string.
        /// </exception>
        /// <exception cref="System.Exception">
        ///     Thrown only when <paramref name="errorHandlerAction"/> is a <c>null</c> reference (<c>Nothing</c> in Visual Basic)
        ///     and an error occurs within this method.
        /// </exception>
        public static int ExecuteReader<T>(DbProviderFactory providerFactory, string connectionString, string commandText, CommandType commandType,
            List<string> ordinalColumns, ReaderToObjectAction<T> actionPerRow, Action<IDbCommand> parameterSetupAction = null,
            Action<Exception> errorHandlerAction = null, bool rethrowException = false)
        {
            if (providerFactory == null) throw new ArgumentException("Missing required parameter 'providerFactory'!");

            ColumnOrdinalsAction columnOrdinalsAction = GetColumnOrdinals(ordinalColumns);

            return ExecuteReader(providerFactory, connectionString, commandText, commandType, columnOrdinalsAction, actionPerRow,
                parameterSetupAction, errorHandlerAction, rethrowException);
        }

        /// <summary>
        /// Executes a <see cref="System.Data.IDataReader"/> against the specified connection, given the SQL command that returns
        /// the result set to process, the method that generates a dictionary of column indexes, and the method that converts
        /// each row in the result set to an object of type <typeparamref name="T"/>.
        /// </summary>
        /// <typeparam name="T">
        ///     The type of the object being created for each row in the result set.
        /// </typeparam>
        /// <param name="providerFactory">The database provider factory.</param>
        /// <param name="connectionString">The database connection string.</param>
        /// <param name="commandText">
        ///     The SQL command to execute./>.
        /// </param>
        /// <param name="commandType">The type of command (e.g. stored procedure or text)</param>
        /// <param name="columnOrdinalsAction">
        ///     The method that creates a dictionary of column indexes. This action is executed before data are read from the
        ///     data reader.
        /// </param>
        /// <param name="actionPerRow">
        ///     The method to invoke to convert each item in the result set to an object of type <typeparamref name="T"/>.
        /// </param>
        /// <param name="parameterSetupAction">
        ///     The method to invoke to set up the SQL command's parameters. Can be set to <c>null</c>
        ///     (<c>Nothing</c> in Visual Basic) if the command accepts no parameters.
        /// </param>
        /// <param name="errorHandlerAction">
        ///     The method to invoke in case an error occurs. The method contains a single parameter
        ///     of type <see cref="System.Exception"/>, which holds a reference to the actual exception.
        ///     This method is normally used to prevent propagation of exceptions and for logging errors.
        /// </param>
        /// <param name="rethrowException">
        ///     Should this method rethrow exception?  If not it will log exceptions and consume them.
        /// </param>
        /// <exception cref="ArgumentNullException">
        ///     <paramref name="providerFactory"/>, <paramref name="columnOrdinalsAction"/> or 
        ///     <paramref name="actionPerRow"/> is a <c>null</c> reference (<c>Nothing</c> in Visual Basic).
        /// </exception>
        /// <exception cref="System.ArgumentException">
        ///     <paramref name="commandText"/> is a <c>null</c> reference (<c>Nothing</c> in Visual Basic)
        ///     or an empty string.
        /// </exception>
        /// <exception cref="System.Exception">
        ///     Thrown only when <paramref name="errorHandlerAction"/> is a <c>null</c> reference (<c>Nothing</c> in Visual Basic)
        ///     and an error occurs within this method.
        /// </exception>
        public static int ExecuteReader<T>(DbProviderFactory providerFactory, string connectionString, string commandText, CommandType commandType,
            ColumnOrdinalsAction columnOrdinalsAction, ReaderToObjectAction<T> actionPerRow, Action<IDbCommand> parameterSetupAction = null,
            Action<Exception> errorHandlerAction = null, bool rethrowException = false)
        {
            if (providerFactory == null) throw new ArgumentException("Missing required parameter 'providerFactory'!");

            using (DbConnection connection = providerFactory.CreateConnection())
            {
                connection.ConnectionString = connectionString;
                return ExecuteReader(connection, commandText, commandType, columnOrdinalsAction, actionPerRow,
                    parameterSetupAction, errorHandlerAction, rethrowException);
            }
        }

        /// <summary>
        /// Executes a <see cref="System.Data.IDataReader"/> against the specified connection, given the SQL command that returns
        /// the result set to process, the method that generates a dictionary of column indexes, and the method that converts
        /// each row in the result set to an object of type <typeparamref name="T"/>.
        /// </summary>
        /// <typeparam name="T">
        ///     The type of the object being created for each row in the result set.
        /// </typeparam>
        /// <param name="connection">
        ///     The current database connection. The connection is automatically opened and closed by this method.
        /// </param>
        /// <param name="commandText">
        ///     The SQL command to execute against the <paramref name="connection"/>.
        /// </param>
        /// <param name="commandType">The type of command (e.g. stored procedure or text)</param>
        /// <param name="ordinalColumns">
        ///     The list of columns that will be indexed for quicker access. The column list will be converted to a ColumnOrdinalsAction 
        ///     before data are read from the data reader.
        /// </param>
        /// <param name="actionPerRow">
        ///     The method to invoke to convert each item in the result set to an object of type <typeparamref name="T"/>.
        /// </param>
        /// <param name="parameterSetupAction">
        ///     The method to invoke to set up the SQL command's parameters. Can be set to <c>null</c>
        ///     (<c>Nothing</c> in Visual Basic) if the command accepts no parameters.
        /// </param>
        /// <param name="errorHandlerAction">
        ///     The method to invoke in case an error occurs. The method contains a single parameter
        ///     of type <see cref="System.Exception"/>, which holds a reference to the actual exception.
        ///     This method is normally used to prevent propagation of exceptions and for logging errors.
        /// </param>
        /// <param name="rethrowException">
        ///     Should this method rethrow exception?  If not it will log exceptions and consume them.
        /// </param>
        /// <exception cref="ArgumentNullException">
        ///     <paramref name="connection"/>, <paramref name="ordinalColumns"/> or 
        ///     <paramref name="actionPerRow"/> is a <c>null</c> reference (<c>Nothing</c> in Visual Basic).
        /// </exception>
        /// <exception cref="System.ArgumentException">
        ///     <paramref name="commandText"/> is a <c>null</c> reference (<c>Nothing</c> in Visual Basic)
        ///     or an empty string.
        /// </exception>
        /// <exception cref="System.Exception">
        ///     Thrown only when <paramref name="errorHandlerAction"/> is a <c>null</c> reference (<c>Nothing</c> in Visual Basic)
        ///     and an error occurs within this method.
        /// </exception>
        public static int ExecuteReader<T>(IDbConnection connection, string commandText, CommandType commandType, List<string> ordinalColumns,
            ReaderToObjectAction<T> actionPerRow, Action<IDbCommand> parameterSetupAction = null, Action<Exception> errorHandlerAction = null, 
            bool rethrowException = false)
        {
            ColumnOrdinalsAction columnOrdinalsAction = GetColumnOrdinals(ordinalColumns);

            return ExecuteReader(connection, commandText, commandType, columnOrdinalsAction, actionPerRow, parameterSetupAction, errorHandlerAction, rethrowException);
        }

        /// <summary>
        /// Executes a <see cref="System.Data.IDataReader"/> against the specified connection, given the SQL command that returns
        /// the result set to process, the method that generates a dictionary of column indexes, and the method that converts
        /// each row in the result set to an object of type <typeparamref name="T"/>.
        /// </summary>
        /// <typeparam name="T">
        ///     The type of the object being created for each row in the result set.
        /// </typeparam>
        /// <param name="connection">
        ///     The current database connection. The connection is automatically opened and closed by this method.
        /// </param>
        /// <param name="commandText">
        ///     The SQL command to execute against the <paramref name="connection"/>.
        /// </param>
        /// <param name="commandType">The type of command (e.g. stored procedure or text)</param>
        /// <param name="columnOrdinalsAction">
        ///     The method that creates a dictionary of column indexes. This action is executed before data are read from the
        ///     data reader.
        /// </param>
        /// <param name="actionPerRow">
        ///     The method to invoke to convert each item in the result set to an object of type <typeparamref name="T"/>.
        /// </param>
        /// <param name="parameterSetupAction">
        ///     The method to invoke to set up the SQL command's parameters. Can be set to <c>null</c>
        ///     (<c>Nothing</c> in Visual Basic) if the command accepts no parameters.
        /// </param>
        /// <param name="errorHandlerAction">
        ///     The method to invoke in case an error occurs. The method contains a single parameter
        ///     of type <see cref="System.Exception"/>, which holds a reference to the actual exception.
        ///     This method is normally used to prevent propagation of exceptions and for logging errors.
        /// </param>
        /// <param name="rethrowException">
        ///     Should this method rethrow exception?  If not it will log exceptions and consume them.
        /// </param>
        /// <exception cref="ArgumentNullException">
        ///     <paramref name="connection"/>, <paramref name="columnOrdinalsAction"/> or 
        ///     <paramref name="actionPerRow"/> is a <c>null</c> reference (<c>Nothing</c> in Visual Basic).
        /// </exception>
        /// <exception cref="System.ArgumentException">
        ///     <paramref name="commandText"/> is a <c>null</c> reference (<c>Nothing</c> in Visual Basic)
        ///     or an empty string.
        /// </exception>
        /// <exception cref="System.Exception">
        ///     Thrown only when <paramref name="errorHandlerAction"/> is a <c>null</c> reference (<c>Nothing</c> in Visual Basic)
        ///     and an error occurs within this method.
        /// </exception>
        public static int ExecuteReader<T>( IDbConnection connection, string commandText, CommandType commandType, ColumnOrdinalsAction columnOrdinalsAction,
			ReaderToObjectAction<T> actionPerRow, Action<IDbCommand> parameterSetupAction = null, Action<Exception> errorHandlerAction = null, 
            bool rethrowException = false)
        {
            if ( null == connection )
                throw new ArgumentNullException( "connection" );

            if ( null == columnOrdinalsAction )
                throw new ArgumentNullException( "columnOrdinalsAction" );

            if ( null == actionPerRow )
                throw new ArgumentNullException( "actionPerRow" );

            if ( String.IsNullOrWhiteSpace( commandText ) )
                throw new ArgumentException("The SQL command cannot be a null reference or empty string", "commandText");

            _rowsRead = 0;
            Action<IDataReader> processDataReaderAction = reader =>
            {
                IDictionary<string, int> columnDict = columnOrdinalsAction( reader );
                while ( reader.Read() )
                {
                    _rowsRead++;
                    actionPerRow( columnDict, reader );
                }
            };

            ExecuteReader(connection, commandText, commandType, processDataReaderAction, parameterSetupAction, errorHandlerAction, rethrowException);
            return _rowsRead;
        }

        /// <summary>
        /// Executes a <see cref="System.Data.IDataReader"/> against the specified connection, given the SQL command that returns
        /// one or more result sets to process, and the method delegate that processes each batch in the result sets.
        /// </summary>
        /// <param name="providerFactory">The database provider factory.</param>
        /// <param name="connectionString">The database connection string.</param>
        /// <param name="commandText">
        ///     The SQL command to execute./>.
        /// </param>
        /// <param name="processBatchAction">
        ///     The method delegate to execute against the <see cref="System.Data.IDataReader"/>. This delegate is used to
        ///     process more than one result set and allows you to invoke the <c>Read()</c> method of the <c>IDataReader</c>. 
        ///     You do not need to call the <c>Close()</c> method of the data reader as this is done for you.
        ///     See <see cref="System.Data.IDataReader.NextResult()"/>.
        /// </param>
        /// <param name="parameterSetupAction">
        ///     The method to invoke to set up the SQL command's parameters. Can be set to <c>null</c>
        ///     (<c>Nothing</c> in Visual Basic) if the command accepts no parameters.
        /// </param>
        /// <param name="errorHandlerAction">
        ///     The method to invoke in case an error occurs. The method contains a single parameter
        ///     of type <see cref="System.Exception"/>, which holds a reference to the actual exception.
        ///     This method is normally used to prevent propagation of exceptions and for logging errors.
        /// </param>
        /// <param name="rethrowException">
        ///     Should this method rethrow exception?  If not it will log exceptions and consume them.
        /// </param>
        /// <exception cref="ArgumentNullException">
        /// 	<paramref name="providerFactory"/> or <paramref name="processBatchAction"/> is a <c>null</c> reference (<c>Nothing</c> in Visual Basic).
        /// </exception>
        /// <exception cref="System.ArgumentException">
        /// 	<paramref name="commandText"/> is a <c>null</c> reference (<c>Nothing</c> in Visual Basic)
        ///     or an empty string.
        /// </exception>
        /// <exception cref="System.Exception">
        ///     Thrown only when <paramref name="errorHandlerAction"/> is a <c>null</c> reference (<c>Nothing</c> in Visual Basic)
        ///     and an error occurs within this method.
        /// </exception>
        public static int ExecuteReader(DbProviderFactory providerFactory, string connectionString, string commandText, Action<IDataReader> processBatchAction,
			Action<IDbCommand> parameterSetupAction = null, Action<Exception> errorHandlerAction = null, bool rethrowException = false)
        {
            if (providerFactory == null) throw new ArgumentException("Missing required parameter 'providerFactory'!");

            using (DbConnection connection = providerFactory.CreateConnection())
            {
                connection.ConnectionString = connectionString;
                return ExecuteReader(connection, commandText, processBatchAction, parameterSetupAction, errorHandlerAction, rethrowException);
            }
        }

        /// <summary>
        /// Executes a <see cref="System.Data.IDataReader"/> against the specified connection, given the SQL command that returns
        /// one or more result sets to process, and the method delegate that processes each batch in the result sets.
        /// </summary>
        /// <param name="connection">
        ///     The current database connection. The connection is automatically opened and closed by this method.
        /// </param>
        /// <param name="commandText">
        ///     The SQL command to execute against the <paramref name="connection"/>.
        /// </param>
        /// <param name="processBatchAction">
        ///     The method delegate to execute against the <see cref="System.Data.IDataReader"/>. This delegate is used to
        ///     process more than one result set and allows you to invoke the <c>Read()</c> method of the <c>IDataReader</c>. 
        ///     You do not need to call the <c>Close()</c> method of the data reader as this is done for you.
        ///     See <see cref="System.Data.IDataReader.NextResult()"/>.
        /// </param>
        /// <param name="parameterSetupAction">
        ///     The method to invoke to set up the SQL command's parameters. Can be set to <c>null</c>
        ///     (<c>Nothing</c> in Visual Basic) if the command accepts no parameters.
        /// </param>
        /// <param name="errorHandlerAction">
        ///     The method to invoke in case an error occurs. The method contains a single parameter
        ///     of type <see cref="System.Exception"/>, which holds a reference to the actual exception.
        ///     This method is normally used to prevent propagation of exceptions and for logging errors.
        /// </param>
        /// <param name="rethrowException">
        ///     Should this method rethrow exception?  If not it will log exceptions and consume them.
        /// </param>
        /// <exception cref="ArgumentNullException">
        /// 	<paramref name="connection"/> or <paramref name="processBatchAction"/> is a <c>null</c> reference (<c>Nothing</c> in Visual Basic).
        /// </exception>
        /// <exception cref="System.ArgumentException">
        /// 	<paramref name="commandText"/> is a <c>null</c> reference (<c>Nothing</c> in Visual Basic)
        ///     or an empty string.
        /// </exception>
        /// <exception cref="System.Exception">
        ///     Thrown only when <paramref name="errorHandlerAction"/> is a <c>null</c> reference (<c>Nothing</c> in Visual Basic)
        ///     and an error occurs within this method.
        /// </exception>
        public static int ExecuteReader(IDbConnection connection, string commandText, Action<IDataReader> processBatchAction,
			Action<IDbCommand> parameterSetupAction = null, Action<Exception> errorHandlerAction = null, bool rethrowException = false)
        {
            return ExecuteReader(connection, commandText, CommandType.StoredProcedure, processBatchAction, parameterSetupAction, errorHandlerAction, rethrowException);
        }

        /// <summary>
        /// Executes a <see cref="System.Data.IDataReader"/> against the specified connection, given the SQL command that returns
        /// one or more result sets to process, and the method delegate that processes each batch in the result sets.
        /// </summary>
        /// <param name="providerFactory">The database provider factory.</param>
        /// <param name="connectionString">The database connection string.</param>
        /// <param name="commandText">
        ///     The SQL command to execute./>.
        /// </param>
        /// <param name="commandType">The type of command (e.g. stored procedure or text)</param>
        /// <param name="processBatchAction">
        ///     The method delegate to execute against the <see cref="System.Data.IDataReader"/>. This delegate is used to
        ///     process more than one result set and allows you to invoke the <c>Read()</c> method of the <c>IDataReader</c>. 
        ///     You do not need to call the <c>Close()</c> method of the data reader as this is done for you.
        ///     See <see cref="System.Data.IDataReader.NextResult()"/>.
        /// </param>
        /// <param name="parameterSetupAction">
        ///     The method to invoke to set up the SQL command's parameters. Can be set to <c>null</c>
        ///     (<c>Nothing</c> in Visual Basic) if the command accepts no parameters.
        /// </param>
        /// <param name="errorHandlerAction">
        ///     The method to invoke in case an error occurs. The method contains a single parameter
        ///     of type <see cref="System.Exception"/>, which holds a reference to the actual exception.
        ///     This method is normally used to prevent propagation of exceptions and for logging errors.
        /// </param>
        /// <param name="rethrowException">
        ///     Should this method rethrow exception?  If not it will log exceptions and consume them.
        /// </param>
        /// <exception cref="ArgumentNullException">
        /// 	<paramref name="providerFactory"/> or <paramref name="processBatchAction"/> is a <c>null</c> reference (<c>Nothing</c> in Visual Basic).
        /// </exception>
        /// <exception cref="System.ArgumentException">
        /// 	<paramref name="commandText"/> is a <c>null</c> reference (<c>Nothing</c> in Visual Basic)
        ///     or an empty string.
        /// </exception>
        /// <exception cref="System.Exception">
        ///     Thrown only when <paramref name="errorHandlerAction"/> is a <c>null</c> reference (<c>Nothing</c> in Visual Basic)
        ///     and an error occurs within this method.
        /// </exception>
        public static int ExecuteReader(DbProviderFactory providerFactory, string connectionString, string commandText, CommandType commandType,
			Action<IDataReader> processBatchAction, Action<IDbCommand> parameterSetupAction = null, Action<Exception> errorHandlerAction = null, 
            bool rethrowException = false)
        {
            if (providerFactory == null) throw new ArgumentException("Missing required parameter 'providerFactory'!");

            using (DbConnection connection = providerFactory.CreateConnection())
            {
                connection.ConnectionString = connectionString;
                return ExecuteReader(connection, commandText, commandType, processBatchAction, parameterSetupAction, errorHandlerAction, rethrowException);
            }
        }

        /// <summary>
        /// Executes a <see cref="System.Data.IDataReader"/> against the specified connection, given the SQL command that returns
        /// one or more result sets to process, and the method delegate that processes each batch in the result sets.
        /// </summary>
        /// <param name="connection">
        ///     The current database connection. The connection is automatically opened and closed by this method.
        /// </param>
        /// <param name="commandText">
        ///     The SQL command to execute against the <paramref name="connection"/>.
        /// </param>
        /// <param name="commandType">The type of command (e.g. stored procedure or text)</param>
        /// <param name="processBatchAction">
        ///     The method delegate to execute against the <see cref="System.Data.IDataReader"/>. This delegate is used to
        ///     process more than one result set and allows you to invoke the <c>Read()</c> method of the <c>IDataReader</c>. 
        ///     You do not need to call the <c>Close()</c> method of the data reader as this is done for you.
        ///     See <see cref="System.Data.IDataReader.NextResult()"/>.
        /// </param>
        /// <param name="parameterSetupAction">
        ///     The method to invoke to set up the SQL command's parameters. Can be set to <c>null</c>
        ///     (<c>Nothing</c> in Visual Basic) if the command accepts no parameters.
        /// </param>
        /// <param name="errorHandlerAction">
        ///     The method to invoke in case an error occurs. The method contains a single parameter
        ///     of type <see cref="System.Exception"/>, which holds a reference to the actual exception.
        ///     This method is normally used to prevent propagation of exceptions and for logging errors.
        /// </param>
        /// <param name="rethrowException">
        ///     Should this method rethrow exception?  If not it will log exceptions and consume them.
        /// </param>
        /// <exception cref="ArgumentNullException">
        /// 	<paramref name="connection"/> or <paramref name="processBatchAction"/> is a <c>null</c> reference (<c>Nothing</c> in Visual Basic).
        /// </exception>
        /// <exception cref="System.ArgumentException">
        /// 	<paramref name="commandText"/> is a <c>null</c> reference (<c>Nothing</c> in Visual Basic)
        ///     or an empty string.
        /// </exception>
        /// <exception cref="System.Exception">
        ///     Thrown only when <paramref name="errorHandlerAction"/> is a <c>null</c> reference (<c>Nothing</c> in Visual Basic)
        ///     and an error occurs within this method.
        /// </exception>
        public static int ExecuteReader(IDbConnection connection, string commandText, CommandType commandType, Action<IDataReader> processBatchAction,
			Action<IDbCommand> parameterSetupAction = null, Action<Exception> errorHandlerAction = null, bool rethrowException = false)
        {
            if (null == connection)
                throw new ArgumentNullException( "connection" );

            if ( null == processBatchAction )
                throw new ArgumentNullException( "processBatchAction" );

            if (String.IsNullOrEmpty(commandText))
                throw new ArgumentException("The SQL command cannot be a null reference or empty string", "commandText");

            try
            {
                using ( connection )
                {
                    connection.Open();

                    using (IDbCommand cmd = CreateCommand(connection, commandText, commandType, parameterSetupAction))
                    {
                        // Log the command we're about to execute.
                        LogCommand(cmd);

                        // Execute command
                        _rowsRead = 0;  // This is incremented when executing the batch command.
                        using ( IDataReader reader = cmd.ExecuteReader() )
                        {
                            processBatchAction( reader );
                        }
                    }
                }

                return _rowsRead;
            }
            catch ( Exception ex )
            {
                if (Log != null) Log.Error(string.Format("Error calling '{0}'", commandText), ex);

                if ( null == errorHandlerAction )
                    throw;

				if (rethrowException)
					throw;
                
                errorHandlerAction( ex );
                return _rowsRead;
            }
        }

        /// <summary>
        /// Executes a <see cref="System.Data.IDataReader"/> against the specified connection and returns the result set as a generic <c>IEnumerable</c> reference
        /// of objects of type <typeparamref name="T"/>, given the SQL command that returns the result set to process, the method that 
        /// generates a dictionary of column indexes, and the method that converts each row in the result set to an object of type <typeparamref name="T"/>.
        /// </summary>
        /// <typeparam name="T">
        ///     The type of the object being created for each row in the result set.
        /// </typeparam>
        /// <param name="connection">
        ///     The current database connection. The connection is automatically opened and closed by this method.
        /// </param>
        /// <param name="storedProcName">
        ///     The SQL command to execute against the <paramref name="connection"/>.
        /// </param>
        /// <param name="ordinalColumns">
        ///     The list of columns that will be indexed for quicker access. The column list will be converted to a ColumnOrdinalsAction 
        ///     before data are read from the data reader.
        /// </param>
        /// <param name="actionPerRow">
        ///     The method to invoke to convert each item in the result set to an object of type <typeparamref name="T"/>.
        /// </param>
        /// <param name="parameterSetupAction">
        ///     The method to invoke to set up the SQL command's parameters. Can be set to <c>null</c>
        ///     (<c>Nothing</c> in Visual Basic) if the command accepts no parameters.
        /// </param>
        /// <param name="errorHandlerAction">
        ///     The method to invoke in case an error occurs. The method contains a single parameter
        ///     of type <see cref="System.Exception"/>, which holds a reference to the actual exception.
        ///     This method is normally used to prevent bubbling up of exceptions and for logging errors.
        /// </param>
        /// <param name="rethrowException">
        ///     Should this method rethrow exception?  If not it will log exceptions and consume them.
        /// </param>
        /// <returns>
        ///     The enumerator that holds the collection generated from the data reader.
        /// </returns>
        /// <exception cref="ArgumentNullException">
        ///     <paramref name="connection"/>, <paramref name="ordinalColumns"/> or 
        ///     <paramref name="actionPerRow"/> is a <c>null</c> reference (<c>Nothing</c> in Visual Basic).
        /// </exception>
        /// <exception cref="System.ArgumentException">
        ///     <paramref name="storedProcName"/> is a <c>null</c> reference (<c>Nothing</c> in Visual Basic)
        ///     or an empty string.
        /// </exception>
        /// <exception cref="System.Exception">
        ///     Thrown only when <paramref name="errorHandlerAction"/> is a <c>null</c> reference (<c>Nothing</c> in Visual Basic)
        ///     and an error occurs within this method.
        /// </exception>
        public static IEnumerable<T> ExecuteReaderToList<T>(IDbConnection connection, string storedProcName, List<string> ordinalColumns,
            ReaderToObjectAction<T> actionPerRow, Action<IDbCommand> parameterSetupAction, Action<Exception> errorHandlerAction, bool rethrowException = false)
        {
            ColumnOrdinalsAction columnOrdinalsAction = GetColumnOrdinals(ordinalColumns);

            return ExecuteReaderToList(connection, storedProcName, columnOrdinalsAction, actionPerRow, parameterSetupAction, errorHandlerAction, rethrowException);
        }

        /// <summary>
        /// Executes a <see cref="System.Data.IDataReader"/> against the specified connection and returns the result set as a generic <c>IEnumerable</c> reference
        /// of objects of type <typeparamref name="T"/>, given the SQL command that returns the result set to process, the method that 
        /// generates a dictionary of column indexes, and the method that converts each row in the result set to an object of type <typeparamref name="T"/>.
        /// </summary>
        /// <typeparam name="T">
        ///     The type of the object being created for each row in the result set.
        /// </typeparam>
        /// <param name="connection">
        ///     The current database connection. The connection is automatically opened and closed by this method.
        /// </param>
        /// <param name="storedProcName">
        ///     The SQL command to execute against the <paramref name="connection"/>.
        /// </param>
        /// <param name="columnOrdinalsAction">
        ///     The method that creates a dictionary of column indexes. This action is executed before data are read from the
        ///     data reader.
        /// </param>
        /// <param name="actionPerRow">
        ///     The method to invoke to convert each item in the result set to an object of type <typeparamref name="T"/>.
        /// </param>
        /// <param name="parameterSetupAction">
        ///     The method to invoke to set up the SQL command's parameters. Can be set to <c>null</c>
        ///     (<c>Nothing</c> in Visual Basic) if the command accepts no parameters.
        /// </param>
        /// <param name="errorHandlerAction">
        ///     The method to invoke in case an error occurs. The method contains a single parameter
        ///     of type <see cref="System.Exception"/>, which holds a reference to the actual exception.
        ///     This method is normally used to prevent bubbling up of exceptions and for logging errors.
        /// </param>
        /// <param name="rethrowException">
        ///     Should this method rethrow exception?  If not it will log exceptions and consume them.
        /// </param>
        /// <returns>
        ///     The enumerator that holds the collection generated from the data reader.
        /// </returns>
        /// <exception cref="ArgumentNullException">
        ///     <paramref name="connection"/>, <paramref name="columnOrdinalsAction"/> or 
        ///     <paramref name="actionPerRow"/> is a <c>null</c> reference (<c>Nothing</c> in Visual Basic).
        /// </exception>
        /// <exception cref="System.ArgumentException">
        ///     <paramref name="storedProcName"/> is a <c>null</c> reference (<c>Nothing</c> in Visual Basic)
        ///     or an empty string.
        /// </exception>
        /// <exception cref="System.Exception">
        ///     Thrown only when <paramref name="errorHandlerAction"/> is a <c>null</c> reference (<c>Nothing</c> in Visual Basic)
        ///     and an error occurs within this method.
        /// </exception>
        public static IEnumerable<T> ExecuteReaderToList<T>( IDbConnection connection, string storedProcName, ColumnOrdinalsAction columnOrdinalsAction,
			ReaderToObjectAction<T> actionPerRow, Action<IDbCommand> parameterSetupAction, Action<Exception> errorHandlerAction, bool rethrowException = false)
        {
            var results = new List<T>();

            ReaderToObjectAction<T> appendItemToList = (columnOrdinalsDict, reader) =>
            {
                T item = actionPerRow( columnOrdinalsDict, reader );
                results.Add( item );
                return item;
            };

            ExecuteReader( connection, storedProcName, columnOrdinalsAction, appendItemToList, parameterSetupAction, errorHandlerAction, rethrowException );

            return results;
        }

        /// <summary>
        /// Executes a <see cref="System.Data.IDataReader"/> against the connection returned by the specified data provider and returns 
        /// the result set as a generic <c>IEnumerable</c> reference of objects of type <typeparamref name="T"/>, given the SQL command 
        /// that returns the result set to process, the method that generates a dictionary of column indexes, the method that 
        /// converts each row in the result set to an object of type <typeparamref name="T"/>, the parameter set up method, and
        /// an error handler action.
        /// </summary>
        /// <typeparam name="T">
        ///     The type of the object being created for each row in the result set.
        /// </typeparam>
        /// <param name="providerFactory">
        ///     The database provider factory.
        /// </param>
        /// <param name="connectionString">
        ///     The database connection string.
        /// </param>
        /// <param name="commandText">
        ///     The SQL command to execute against the database.
        /// </param>
        /// <param name="commandType">
        ///     The type of command to execute.
        /// </param>
        /// <param name="ordinalColumns">
        ///     The list of columns that will be indexed for quicker access. The column list will be converted to a ColumnOrdinalsAction 
        ///     before data are read from the data reader.
        /// </param>
        /// <param name="actionPerRow">
        ///     The method to invoke to convert each item in the result set to an object of type <typeparamref name="T"/>.
        /// </param>
        /// <param name="parameterSetupAction">
        ///     The method to invoke to set up the SQL command's parameters. Can be set to <c>null</c>
        ///     (<c>Nothing</c> in Visual Basic) if the command accepts no parameters.
        /// </param>
        /// <param name="errorHandlerAction">
        ///     The method to invoke in case an error occurs. The method contains a single parameter
        ///     of type <see cref="System.Exception"/>, which holds a reference to the actual exception.
        ///     This method is normally used to prevent bubbling up of exceptions and for logging errors.
        /// </param>
        /// <param name="rethrowException">
        ///     Should this method rethrow exception?  If not it will log exceptions and consume them.
        /// </param>
        /// <returns>
        ///     The enumerator that holds the collection generated from the data reader.
        /// </returns>
        /// <exception cref="ArgumentNullException">
        ///     <paramref name="providerFactory"/>, <paramref name="ordinalColumns"/> or 
        ///     <paramref name="actionPerRow"/> is a <c>null</c> reference (<c>Nothing</c> in Visual Basic).
        /// </exception>
        /// <exception cref="System.ArgumentException">
        ///     <paramref name="commandText"/> is a <c>null</c> reference (<c>Nothing</c> in Visual Basic)
        ///     or an empty string.
        /// </exception>
        /// <exception cref="System.Exception">
        ///     Thrown only when <paramref name="errorHandlerAction"/> is a <c>null</c> reference (<c>Nothing</c> in Visual Basic)
        ///     and an error occurs within this method.
        /// </exception>
        public static IEnumerable<T> ExecuteReaderToList<T>(DbProviderFactory providerFactory, string connectionString, string commandText, CommandType commandType,
            List<string> ordinalColumns, ReaderToObjectAction<T> actionPerRow, Action<IDbCommand> parameterSetupAction,
            Action<Exception> errorHandlerAction, bool rethrowException = false)
        {
            ColumnOrdinalsAction columnOrdinalsAction = GetColumnOrdinals(ordinalColumns);

            return ExecuteReaderToList(providerFactory, connectionString, commandText, commandType, columnOrdinalsAction, actionPerRow, parameterSetupAction,
                                       errorHandlerAction, rethrowException);
        }

        /// <summary>
        /// Executes a <see cref="System.Data.IDataReader"/> against the connection returned by the specified data provider and returns 
        /// the result set as a generic <c>IEnumerable</c> reference of objects of type <typeparamref name="T"/>, given the SQL command 
        /// that returns the result set to process, the method that generates a dictionary of column indexes, the method that 
        /// converts each row in the result set to an object of type <typeparamref name="T"/>, the parameter set up method, and
        /// an error handler action.
        /// </summary>
        /// <typeparam name="T">
        ///     The type of the object being created for each row in the result set.
        /// </typeparam>
        /// <param name="providerFactory">
        ///     The database provider factory.
        /// </param>
        /// <param name="connectionString">
        ///     The database connection string.
        /// </param>
        /// <param name="commandText">
        ///     The SQL command to execute against the database.
        /// </param>
        /// <param name="commandType">
        ///     The type of command to execute.
        /// </param>
        /// <param name="columnOrdinalsAction">
        ///     The method that creates a dictionary of column indexes. This action is executed before data are read from the
        ///     data reader.
        /// </param>
        /// <param name="actionPerRow">
        ///     The method to invoke to convert each item in the result set to an object of type <typeparamref name="T"/>.
        /// </param>
        /// <param name="parameterSetupAction">
        ///     The method to invoke to set up the SQL command's parameters. Can be set to <c>null</c>
        ///     (<c>Nothing</c> in Visual Basic) if the command accepts no parameters.
        /// </param>
        /// <param name="errorHandlerAction">
        ///     The method to invoke in case an error occurs. The method contains a single parameter
        ///     of type <see cref="System.Exception"/>, which holds a reference to the actual exception.
        ///     This method is normally used to prevent bubbling up of exceptions and for logging errors.
        /// </param>
        /// <param name="rethrowException">
        ///     Should this method rethrow exception?  If not it will log exceptions and consume them.
        /// </param>
        /// <returns>
        ///     The enumerator that holds the collection generated from the data reader.
        /// </returns>
        /// <exception cref="ArgumentNullException">
        ///     <paramref name="providerFactory"/>, <paramref name="columnOrdinalsAction"/> or 
        ///     <paramref name="actionPerRow"/> is a <c>null</c> reference (<c>Nothing</c> in Visual Basic).
        /// </exception>
        /// <exception cref="System.ArgumentException">
        ///     <paramref name="commandText"/> is a <c>null</c> reference (<c>Nothing</c> in Visual Basic)
        ///     or an empty string.
        /// </exception>
        /// <exception cref="System.Exception">
        ///     Thrown only when <paramref name="errorHandlerAction"/> is a <c>null</c> reference (<c>Nothing</c> in Visual Basic)
        ///     and an error occurs within this method.
        /// </exception>
		public static IEnumerable<T> ExecuteReaderToList<T>(DbProviderFactory providerFactory, string connectionString, string commandText, CommandType commandType, 
            ColumnOrdinalsAction columnOrdinalsAction, ReaderToObjectAction<T> actionPerRow, Action<IDbCommand> parameterSetupAction, 
            Action<Exception> errorHandlerAction, bool rethrowException = false)
        {
            var results = new List<T>();

            ReaderToObjectAction<T> appendItemToList = (columnOrdinalsDict, reader) =>
            {
                T item = actionPerRow(columnOrdinalsDict, reader);
                results.Add(item);
                return item;
            };

            ExecuteReader(providerFactory, connectionString, commandText, commandType, columnOrdinalsAction, appendItemToList, parameterSetupAction, errorHandlerAction, rethrowException);

            return results;
        }

        #endregion

        #region ExecuteScalar
        /// <summary>
        /// Executes the query and returns the first column of the first row in the resultset returned by the query. 
        /// This method implements a common pattern when working with the ADO.NET IDbCommand object's ExecuteScalar() method,
        /// where pre-execution and post-execution logic needs to be run.
        /// </summary>
        /// <param name="providerFactory">The database provider factory.</param>
        /// <param name="connectionString">The database connection string.</param>
        /// <param name="commandText">
        ///     The SQL command to execute against the database.
        /// </param>
        /// <param name="parameters">A collection of parameters</param>
        /// <param name="postExecuteAction">
        ///     The method to invoke after the SQL command has successfully completed.
        ///     This is normally used for checking the result of a return value from a stored procedure and/or
        ///     for reading output parameters.
        ///     This parameter can be set to <c>null</c>, which indicates that no post-execute action is needed.
        /// </param>
        /// <param name="errorHandlerAction">
        ///     The method to invoke in case an error occurs. The method contains a single parameter
        ///     of type <see cref="System.Exception"/>, which holds a reference to the actual exception.
        ///     This method is normally used to prevent bubbling up of exceptions and for logging errors.
        ///     This parameter can be set to <c>null</c> (<c>Nothing</c> in Visual Basic), at which point 
        ///     the error will be propagated to the calling method.
        /// </param>
        /// <exception cref="ArgumentNullException">
        ///     <paramref name="providerFactory"/> is a <c>null</c> reference (<c>Nothing</c> in Visual Basic).
        /// </exception>
        /// <exception cref="System.ArgumentException">
        ///     <paramref name="commandText"/> is a <c>null</c> reference (<c>Nothing</c> in Visual Basic)
        ///     or an empty string.
        /// </exception>
        /// <exception cref="System.Exception">
        ///     Thrown only when <paramref name="errorHandlerAction"/> is a <c>null</c> reference (<c>Nothing</c> in Visual Basic)
        ///     and an error occurs within this method.
        /// </exception>
        public static object ExecuteScalar(DbProviderFactory providerFactory, string connectionString, string commandText,
            Dictionary<string, object> parameters, Action<IDbCommand> postExecuteAction = null, Action<Exception> errorHandlerAction = null)
        {
            Action<IDbCommand> parameterSetup = GetParameterAction(parameters);

            return ExecuteScalar(providerFactory, connectionString, commandText, parameterSetup, postExecuteAction, errorHandlerAction);
        }

        /// <summary>
        /// Executes the query and returns the first column of the first row in the resultset returned by the query. 
        /// This method implements a common pattern when working with the ADO.NET IDbCommand object's ExecuteScalar() method,
        /// where pre-execution and post-execution logic needs to be run.
        /// </summary>
        /// <param name="providerFactory">The database provider factory.</param>
        /// <param name="connectionString">The database connection string.</param>
        /// <param name="commandText">
        ///     The SQL command to execute against the database.
        /// </param>
        /// <param name="preExecuteAction">
        ///     The method to invoke before the SQL command is executed. 
        ///     This is normally used for setting up command parameters.
        ///     This parameter can be set to <c>null</c>, which indicates that no pre-execute action is required.
        /// </param>
        /// <param name="postExecuteAction">
        ///     The method to invoke after the SQL command has successfully completed.
        ///     This is normally used for checking the result of a return value from a stored procedure and/or
        ///     for reading output parameters.
        ///     This parameter can be set to <c>null</c>, which indicates that no post-execute action is needed.
        /// </param>
        /// <param name="errorHandlerAction">
        ///     The method to invoke in case an error occurs. The method contains a single parameter
        ///     of type <see cref="System.Exception"/>, which holds a reference to the actual exception.
        ///     This method is normally used to prevent bubbling up of exceptions and for logging errors.
        ///     This parameter can be set to <c>null</c> (<c>Nothing</c> in Visual Basic), at which point 
        ///     the error will be propagated to the calling method.
        /// </param>
        /// <exception cref="ArgumentNullException">
        ///     <paramref name="providerFactory"/> is a <c>null</c> reference (<c>Nothing</c> in Visual Basic).
        /// </exception>
        /// <exception cref="System.ArgumentException">
        ///     <paramref name="commandText"/> is a <c>null</c> reference (<c>Nothing</c> in Visual Basic)
        ///     or an empty string.
        /// </exception>
        /// <exception cref="System.Exception">
        ///     Thrown only when <paramref name="errorHandlerAction"/> is a <c>null</c> reference (<c>Nothing</c> in Visual Basic)
        ///     and an error occurs within this method.
        /// </exception>
        public static object ExecuteScalar(DbProviderFactory providerFactory, string connectionString, string commandText,
            Action<IDbCommand> preExecuteAction = null, Action<IDbCommand> postExecuteAction = null, Action<Exception> errorHandlerAction = null)
        {
            return ExecuteScalar(providerFactory, connectionString, commandText, CommandType.StoredProcedure, preExecuteAction, postExecuteAction, errorHandlerAction);
        }

        /// <summary>
        /// Executes the query and returns the first column of the first row in the resultset returned by the query. 
        /// This method implements a common pattern when working with the ADO.NET IDbCommand object's ExecuteScalar() method,
        /// where pre-execution and post-execution logic needs to be run.
        /// </summary>
        /// <param name="providerFactory">The database provider factory.</param>
        /// <param name="connectionString">The database connection string.</param>
        /// <param name="commandText">
        ///     The SQL command to execute against the database.
        /// </param>
        /// <param name="commandType">The type of command to execute.</param>
        /// <param name="parameters">A collection of parameters</param>
        /// <param name="postExecuteAction">
        ///     The method to invoke after the SQL command has successfully completed.
        ///     This is normally used for checking the result of a return value from a stored procedure and/or
        ///     for reading output parameters.
        ///     This parameter can be set to <c>null</c>, which indicates that no post-execute action is needed.
        /// </param>
        /// <param name="errorHandlerAction">
        ///     The method to invoke in case an error occurs. The method contains a single parameter
        ///     of type <see cref="System.Exception"/>, which holds a reference to the actual exception.
        ///     This method is normally used to prevent bubbling up of exceptions and for logging errors.
        ///     This parameter can be set to <c>null</c> (<c>Nothing</c> in Visual Basic), at which point 
        ///     the error will be propagated to the calling method.
        /// </param>
        /// <param name="rethrowException">Whether to rethrow any exception.</param>
        /// <exception cref="ArgumentNullException">
        ///     <paramref name="providerFactory"/> is a <c>null</c> reference (<c>Nothing</c> in Visual Basic).
        /// </exception>
        /// <exception cref="System.ArgumentException">
        ///     <paramref name="commandText"/> is a <c>null</c> reference (<c>Nothing</c> in Visual Basic)
        ///     or an empty string.
        /// </exception>
        /// <exception cref="System.Exception">
        ///     Thrown only when <paramref name="errorHandlerAction"/> is a <c>null</c> reference (<c>Nothing</c> in Visual Basic)
        ///     and an error occurs within this method.
        /// </exception>
        public static object ExecuteScalar(DbProviderFactory providerFactory, string connectionString, string commandText,
            CommandType commandType, Dictionary<string, object> parameters, Action<IDbCommand> postExecuteAction = null, 
            Action<Exception> errorHandlerAction = null, bool rethrowException = false)
        {
            Action<IDbCommand> parameterSetup = GetParameterAction(parameters);

            return ExecuteScalar(providerFactory, connectionString, commandText, commandType, parameterSetup, postExecuteAction, errorHandlerAction, rethrowException);
        }

        /// <summary>
        /// Executes the query and returns the first column of the first row in the resultset returned by the query. 
        /// This method implements a common pattern when working with the ADO.NET IDbCommand object's ExecuteScalar() method,
        /// where pre-execution and post-execution logic needs to be run.
        /// </summary>
        /// <param name="providerFactory">The database provider factory.</param>
        /// <param name="connectionString">The database connection string.</param>
        /// <param name="commandText">
        ///     The SQL command to execute against the database.
        /// </param>
        /// <param name="commandType">The type of command to execute.</param>
        /// <param name="preExecuteAction">
        ///     The method to invoke before the SQL command is executed. 
        ///     This is normally used for setting up command parameters.
        ///     This parameter can be set to <c>null</c>, which indicates that no pre-execute action is required.
        /// </param>
        /// <param name="postExecuteAction">
        ///     The method to invoke after the SQL command has successfully completed.
        ///     This is normally used for checking the result of a return value from a stored procedure and/or
        ///     for reading output parameters.
        ///     This parameter can be set to <c>null</c>, which indicates that no post-execute action is needed.
        /// </param>
        /// <param name="errorHandlerAction">
        ///     The method to invoke in case an error occurs. The method contains a single parameter
        ///     of type <see cref="System.Exception"/>, which holds a reference to the actual exception.
        ///     This method is normally used to prevent bubbling up of exceptions and for logging errors.
        ///     This parameter can be set to <c>null</c> (<c>Nothing</c> in Visual Basic), at which point 
        ///     the error will be propagated to the calling method.
        /// </param>
        /// <param name="rethrowException">Whether to rethrow any exception.</param>
        /// <exception cref="ArgumentNullException">
        ///     <paramref name="providerFactory"/> is a <c>null</c> reference (<c>Nothing</c> in Visual Basic).
        /// </exception>
        /// <exception cref="System.ArgumentException">
        ///     <paramref name="commandText"/> is a <c>null</c> reference (<c>Nothing</c> in Visual Basic)
        ///     or an empty string.
        /// </exception>
        /// <exception cref="System.Exception">
        ///     Thrown only when <paramref name="errorHandlerAction"/> is a <c>null</c> reference (<c>Nothing</c> in Visual Basic)
        ///     and an error occurs within this method.
        /// </exception>
        public static object ExecuteScalar(DbProviderFactory providerFactory, string connectionString, string commandText,
            CommandType commandType, Action<IDbCommand> preExecuteAction = null,
            Action<IDbCommand> postExecuteAction = null, Action<Exception> errorHandlerAction = null, bool rethrowException = false)
        {
            if (providerFactory == null) throw new ArgumentException("Missing required parameter 'providerFactory'!");

            using (DbConnection connection = providerFactory.CreateConnection())
            {
                connection.ConnectionString = connectionString;
                return ExecuteScalar(connection, commandText, commandType, preExecuteAction, postExecuteAction, errorHandlerAction, rethrowException);
            }
        }

        /// <summary>
        /// Executes the query and returns the first column of the first row in the resultset returned by the query. 
        /// This method implements a common pattern when working with the ADO.NET IDbCommand object's ExecuteScalar() method,
        /// where pre-execution and post-execution logic needs to be run.
        /// </summary>
        /// <param name="connection">
        ///     A connection object. The connection will be automatically opened and closed by this method.
        /// </param>
        /// <param name="commandText">
        ///     The SQL command to execute against the database.
        /// </param>
        /// <param name="parameters">A collection of parameters</param>
        /// <param name="postExecuteAction">
        ///     The method to invoke after the SQL command has successfully completed.
        ///     This is normally used for checking the result of a return value from a stored procedure and/or
        ///     for reading output parameters.
        ///     This parameter can be set to <c>null</c>, which indicates that no post-execute action is needed.
        /// </param>
        /// <param name="errorHandlerAction">
        ///     The method to invoke in case an error occurs. The method contains a single parameter
        ///     of type <see cref="System.Exception"/>, which holds a reference to the actual exception.
        ///     This method is normally used to prevent bubbling up of exceptions and for logging errors.
        ///     This parameter can be set to <c>null</c> (<c>Nothing</c> in Visual Basic), at which point 
        ///     the error will be propagated to the calling method.
        /// </param>
        /// <param name="rethrowException">Whether to rethrow any exception.</param>
        /// <exception cref="ArgumentNullException">
        ///     <paramref name="connection"/> is a <c>null</c> reference (<c>Nothing</c> in Visual Basic).
        /// </exception>
        /// <exception cref="System.ArgumentException">
        ///     <paramref name="commandText"/> is a <c>null</c> reference (<c>Nothing</c> in Visual Basic)
        ///     or an empty string.
        /// </exception>
        /// <exception cref="System.Exception">
        ///     Thrown only when <paramref name="errorHandlerAction"/> is a <c>null</c> reference (<c>Nothing</c> in Visual Basic)
        ///     and an error occurs within this method.
        /// </exception>
        public static object ExecuteScalar(IDbConnection connection, string commandText, Dictionary<string, object> parameters,
            Action<IDbCommand> postExecuteAction = null, Action<Exception> errorHandlerAction = null, bool rethrowException = false)
        {
            Action<IDbCommand> parameterSetup = GetParameterAction(parameters);

            return ExecuteScalar(connection, commandText, parameterSetup, postExecuteAction, errorHandlerAction, rethrowException);
        }

        /// <summary>
        /// Executes the query and returns the first column of the first row in the resultset returned by the query. 
        /// This method implements a common pattern when working with the ADO.NET IDbCommand object's ExecuteScalar() method,
        /// where pre-execution and post-execution logic needs to be run.
        /// </summary>
        /// <param name="connection">
        ///     A connection object. The connection will be automatically opened and closed by this method.
        /// </param>
        /// <param name="commandText">
        ///     The SQL command to execute against the database.
        /// </param>
        /// <param name="preExecuteAction">
        ///     The method to invoke before the SQL command is executed. 
        ///     This is normally used for setting up command parameters.
        ///     This parameter can be set to <c>null</c>, which indicates that no pre-execute action is required.
        /// </param>
        /// <param name="postExecuteAction">
        ///     The method to invoke after the SQL command has successfully completed.
        ///     This is normally used for checking the result of a return value from a stored procedure and/or
        ///     for reading output parameters.
        ///     This parameter can be set to <c>null</c>, which indicates that no post-execute action is needed.
        /// </param>
        /// <param name="errorHandlerAction">
        ///     The method to invoke in case an error occurs. The method contains a single parameter
        ///     of type <see cref="System.Exception"/>, which holds a reference to the actual exception.
        ///     This method is normally used to prevent bubbling up of exceptions and for logging errors.
        ///     This parameter can be set to <c>null</c> (<c>Nothing</c> in Visual Basic), at which point 
        ///     the error will be propagated to the calling method.
        /// </param>
        /// <param name="rethrowException">Whether to rethrow any exception.</param>
        /// <exception cref="ArgumentNullException">
        ///     <paramref name="connection"/> is a <c>null</c> reference (<c>Nothing</c> in Visual Basic).
        /// </exception>
        /// <exception cref="System.ArgumentException">
        ///     <paramref name="commandText"/> is a <c>null</c> reference (<c>Nothing</c> in Visual Basic)
        ///     or an empty string.
        /// </exception>
        /// <exception cref="System.Exception">
        ///     Thrown only when <paramref name="errorHandlerAction"/> is a <c>null</c> reference (<c>Nothing</c> in Visual Basic)
        ///     and an error occurs within this method.
        /// </exception>
        public static object ExecuteScalar(IDbConnection connection, string commandText, Action<IDbCommand> preExecuteAction,
            Action<IDbCommand> postExecuteAction = null, Action<Exception> errorHandlerAction = null, bool rethrowException = false)
        {
            return ExecuteScalar(connection, commandText, CommandType.StoredProcedure, preExecuteAction, postExecuteAction, errorHandlerAction, rethrowException);
        }

        /// <summary>
        /// Executes the query and returns the first column of the first row in the resultset returned by the query. 
        /// This method implements a common pattern when working with the ADO.NET IDbCommand object's ExecuteScalar() method,
        /// where pre-execution and post-execution logic needs to be run.
        /// </summary>
        /// <param name="connection">
        ///     A connection object. The connection will be automatically opened and closed by this method.
        /// </param>
        /// <param name="commandText">
        ///     The SQL command to execute against the database.
        /// </param>
        /// <param name="commandType">The type of command to execute.</param>
        /// <param name="parameters">A collection of parameters</param>
        /// <param name="postExecuteAction">
        ///     The method to invoke after the SQL command has successfully completed.
        ///     This is normally used for checking the result of a return value from a stored procedure and/or
        ///     for reading output parameters.
        ///     This parameter can be set to <c>null</c>, which indicates that no post-execute action is needed.
        /// </param>
        /// <param name="errorHandlerAction">
        ///     The method to invoke in case an error occurs. The method contains a single parameter
        ///     of type <see cref="System.Exception"/>, which holds a reference to the actual exception.
        ///     This method is normally used to prevent bubbling up of exceptions and for logging errors.
        ///     This parameter can be set to <c>null</c> (<c>Nothing</c> in Visual Basic), at which point 
        ///     the error will be propagated to the calling method.
        /// </param>
        /// <param name="rethrowException">Whether to rethrow any exception.</param>
        /// <exception cref="ArgumentNullException">
        ///     <paramref name="connection"/> is a <c>null</c> reference (<c>Nothing</c> in Visual Basic).
        /// </exception>
        /// <exception cref="System.ArgumentException">
        ///     <paramref name="commandText"/> is a <c>null</c> reference (<c>Nothing</c> in Visual Basic)
        ///     or an empty string.
        /// </exception>
        /// <exception cref="System.Exception">
        ///     Thrown only when <paramref name="errorHandlerAction"/> is a <c>null</c> reference (<c>Nothing</c> in Visual Basic)
        ///     and an error occurs within this method.
        /// </exception>
        public static object ExecuteScalar(IDbConnection connection, string commandText, CommandType commandType, Dictionary<string, object> parameters,
            Action<IDbCommand> postExecuteAction = null, Action<Exception> errorHandlerAction = null, bool rethrowException = false)
        {
            Action<IDbCommand> parameterSetup = GetParameterAction(parameters);

            return ExecuteScalar(connection, commandText, commandType, parameterSetup, postExecuteAction, errorHandlerAction, rethrowException);
        }

        /// <summary>
        /// Executes the query and returns the first column of the first row in the resultset returned by the query. 
        /// This method implements a common pattern when working with the ADO.NET IDbCommand object's ExecuteScalar() method,
        /// where pre-execution and post-execution logic needs to be run.
        /// </summary>
        /// <param name="connection">
        ///     A connection object. The connection will be automatically opened and closed by this method.
        /// </param>
        /// <param name="commandText">
        ///     The SQL command to execute against the database.
        /// </param>
        /// <param name="commandType">The type of command to execute.</param>
        /// <param name="preExecuteAction">
        ///     The method to invoke before the SQL command is executed. 
        ///     This is normally used for setting up commnand parameters.
        ///     This parameter can be set to <c>null</c>, which indicates that no pre-execute action is required.
        /// </param>
        /// <param name="postExecuteAction">
        ///     The method to invoke after the SQL command has successfully completed.
        ///     This is normally used for checking the result of a return value from a stored procedure and/or
        ///     for reading output parameters.
        ///     This parameter can be set to <c>null</c>, which indicates that no post-execute action is needed.
        /// </param>
        /// <param name="errorHandlerAction">
        ///     The method to invoke in case an error occurs. The method contains a single parameter
        ///     of type <see cref="System.Exception"/>, which holds a reference to the actual exception.
        ///     This method is normally used to prevent bubbling up of exceptions and for logging errors.
        ///     This parameter can be set to <c>null</c> (<c>Nothing</c> in Visual Basic), at which point 
        ///     the error will be propagated to the calling method.
        /// </param>
        /// <param name="rethrowException">Whether to rethrow any exception.</param>
        /// <exception cref="ArgumentNullException">
        ///     <paramref name="connection"/> is a <c>null</c> reference (<c>Nothing</c> in Visual Basic).
        /// </exception>
        /// <exception cref="System.ArgumentException">
        ///     <paramref name="commandText"/> is a <c>null</c> reference (<c>Nothing</c> in Visual Basic)
        ///     or an empty string.
        /// </exception>
        /// <exception cref="System.Exception">
        ///     Thrown only when <paramref name="errorHandlerAction"/> is a <c>null</c> reference (<c>Nothing</c> in Visual Basic)
        ///     and an error occurs within this method.
        /// </exception>
        public static object ExecuteScalar(IDbConnection connection, string commandText, CommandType commandType, Action<IDbCommand> preExecuteAction,
            Action<IDbCommand> postExecuteAction = null, Action<Exception> errorHandlerAction = null, bool rethrowException = false)
        {
            if (null == connection)
                throw new ArgumentNullException("connection");

            if (String.IsNullOrEmpty(commandText))
                throw new ArgumentException("The SQL command cannot be a null reference or empty string", "commandText");

            try
            {
                using (connection)
                {
                    connection.Open();

                    return ExecuteScalarWithSharedConnection(connection, commandText, commandType, preExecuteAction, postExecuteAction);
                }
            }
            catch (Exception ex)
            {
                if (Log != null) Log.Error(string.Format("Error calling '{0}'", commandText), ex);

                if (null == errorHandlerAction)
                    throw;

                errorHandlerAction(ex);

                if (rethrowException)
                    throw;

                return null;
            }
        }

        /// <summary>
        /// Executes the query and returns the first column of the first row in the resultset returned by the query. 
        /// The connection object is an already existing open connection that is being used in a transaction.
        /// This method implements a common pattern when working with the ADO.NET IDbCommand object's ExecuteScalar() method,
        /// where pre-execution and post-execution logic needs to be run. The caller is responsible for handling any exceptions.
        /// </summary>
        /// <param name="connection">
        ///     A connection object. The connection will be automatically opened and closed by this method.
        /// </param>
        /// <param name="commandText">
        ///     The SQL command to execute against the database.
        /// </param>
        /// <param name="parameters">A collection of parameters</param>
        /// <param name="postExecuteAction">
        ///     The method to invoke after the SQL command has successfully completed.
        ///     This is normally used for checking the result of a return value from a stored procedure and/or
        ///     for reading output parameters.
        ///     This parameter can be set to <c>null</c>, which indicates that no post-execute action is needed.
        /// </param>
        /// <exception cref="ArgumentNullException">
        ///     <paramref name="connection"/> is a <c>null</c> reference (<c>Nothing</c> in Visual Basic).
        /// </exception>
        /// <exception cref="System.ArgumentException">
        ///     <paramref name="commandText"/> is a <c>null</c> reference (<c>Nothing</c> in Visual Basic)
        ///     or an empty string.
        /// </exception>
        /// <exception cref="System.Exception">
        ///     Thrown when an error occurs.
        /// </exception>
        public static object ExecuteScalarWithSharedConnection(IDbConnection connection, string commandText,
            Dictionary<string, object> parameters, Action<IDbCommand> postExecuteAction = null)
        {
            Action<IDbCommand> parameterSetup = GetParameterAction(parameters);

            return ExecuteScalarWithSharedConnection(connection, commandText, parameterSetup, postExecuteAction);
        }

        /// <summary>
        /// Executes the query and returns the first column of the first row in the resultset returned by the query. 
        /// The connection object is an already existing open connection that is being used in a transaction.
        /// This method implements a common pattern when working with the ADO.NET IDbCommand object's ExecuteScalar() method,
        /// where pre-execution and post-execution logic needs to be run. The caller is responsible for handling any exceptions.
        /// </summary>
        /// <param name="connection">
        ///     A connection object. The connection will be automatically opened and closed by this method.
        /// </param>
        /// <param name="commandText">
        ///     The SQL command to execute against the database.
        /// </param>
        /// <param name="preExecuteAction">
        ///     The method to invoke before the SQL command is executed. 
        ///     This is normally used for setting up command parameters.
        ///     This parameter can be set to <c>null</c>, which indicates that no pre-execute action is required.
        /// </param>
        /// <param name="postExecuteAction">
        ///     The method to invoke after the SQL command has successfully completed.
        ///     This is normally used for checking the result of a return value from a stored procedure and/or
        ///     for reading output parameters.
        ///     This parameter can be set to <c>null</c>, which indicates that no post-execute action is needed.
        /// </param>
        /// <exception cref="ArgumentNullException">
        ///     <paramref name="connection"/> is a <c>null</c> reference (<c>Nothing</c> in Visual Basic).
        /// </exception>
        /// <exception cref="System.ArgumentException">
        ///     <paramref name="commandText"/> is a <c>null</c> reference (<c>Nothing</c> in Visual Basic)
        ///     or an empty string.
        /// </exception>
        /// <exception cref="System.Exception">
        ///     Thrown when an error occurs.
        /// </exception>
        public static object ExecuteScalarWithSharedConnection(IDbConnection connection, string commandText,
            Action<IDbCommand> preExecuteAction = null, Action<IDbCommand> postExecuteAction = null)
        {
            return ExecuteScalarWithSharedConnection(connection, commandText, CommandType.StoredProcedure, preExecuteAction, postExecuteAction);
        }

        /// <summary>
        /// Executes the query and returns the first column of the first row in the resultset returned by the query. 
        /// The connection object is an already existing open connection that is being used in a transaction.
        /// This method implements a common pattern when working with the ADO.NET IDbCommand object's ExecuteScalar() method,
        /// where pre-execution and post-execution logic needs to be run. The caller is responsible for handling any exceptions.
        /// </summary>
        /// <param name="connection">
        ///     A connection object. The connection will be automatically opened and closed by this method.
        /// </param>
        /// <param name="commandText">
        ///     The SQL command to execute against the database.
        /// </param>
        /// <param name="commandType">The type of command to execute.</param>
        /// <param name="parameters">A collection of parameters</param>
        /// <param name="postExecuteAction">
        ///     The method to invoke after the SQL command has successfully completed.
        ///     This is normally used for checking the result of a return value from a stored procedure and/or
        ///     for reading output parameters.
        ///     This parameter can be set to <c>null</c>, which indicates that no post-execute action is needed.
        /// </param>
        /// <exception cref="ArgumentNullException">
        ///     <paramref name="connection"/> is a <c>null</c> reference (<c>Nothing</c> in Visual Basic).
        /// </exception>
        /// <exception cref="System.ArgumentException">
        ///     <paramref name="commandText"/> is a <c>null</c> reference (<c>Nothing</c> in Visual Basic)
        ///     or an empty string.
        /// </exception>
        /// <exception cref="System.Exception">
        ///     Thrown when an error occurs.
        /// </exception>
        public static object ExecuteScalarWithSharedConnection(IDbConnection connection, string commandText, CommandType commandType,
            Dictionary<string, object> parameters, Action<IDbCommand> postExecuteAction = null)
        {
            Action<IDbCommand> parameterSetup = GetParameterAction(parameters);

            return ExecuteScalarWithSharedConnection(connection, commandText, commandType, parameterSetup, postExecuteAction);
        }

        /// <summary>
        /// Executes the query and returns the first column of the first row in the resultset returned by the query. 
        /// The connection object is an already existing open connection that is being used in a transaction.
        /// This method implements a common pattern when working with the ADO.NET IDbCommand object's ExecuteScalar() method,
        /// where pre-execution and post-execution logic needs to be run. The caller is responsible for handling any exceptions.
        /// </summary>
        /// <param name="connection">
        ///     A connection object. The connection will be automatically opened and closed by this method.
        /// </param>
        /// <param name="commandText">
        ///     The SQL command to execute against the database.
        /// </param>
        /// <param name="commandType">The type of command to execute.</param>
        /// <param name="preExecuteAction">
        ///     The method to invoke before the SQL command is executed. 
        ///     This is normally used for setting up command parameters.
        ///     This parameter can be set to <c>null</c>, which indicates that no pre-execute action is required.
        /// </param>
        /// <param name="postExecuteAction">
        ///     The method to invoke after the SQL command has successfully completed.
        ///     This is normally used for checking the result of a return value from a stored procedure and/or
        ///     for reading output parameters.
        ///     This parameter can be set to <c>null</c>, which indicates that no post-execute action is needed.
        /// </param>
        /// <exception cref="ArgumentNullException">
        ///     <paramref name="connection"/> is a <c>null</c> reference (<c>Nothing</c> in Visual Basic).
        /// </exception>
        /// <exception cref="System.ArgumentException">
        ///     <paramref name="commandText"/> is a <c>null</c> reference (<c>Nothing</c> in Visual Basic)
        ///     or an empty string.
        /// </exception>
        /// <exception cref="System.Exception">
        ///     Thrown when an error occurs.
        /// </exception>
        public static object ExecuteScalarWithSharedConnection(IDbConnection connection, string commandText, CommandType commandType,
            Action<IDbCommand> preExecuteAction = null, Action<IDbCommand> postExecuteAction = null)
        {
            if (null == connection)
                throw new ArgumentNullException("connection");

            if (String.IsNullOrEmpty(commandText))
                throw new ArgumentException("The SQL command cannot be a null reference or empty string", "commandText");

            using (IDbCommand cmd = CreateCommand(connection, commandText, commandType, preExecuteAction))
            {
                // Log the command we're about to execute.
                LogCommand(cmd);

                // Execute command
                object rc = cmd.ExecuteScalar();

                if (null != postExecuteAction)
                {
                    postExecuteAction(cmd);
                }

                return rc;
            }
        }
        #endregion

        /// <summary>
        /// Copies the values from all properties in the supplied <paramref name="source"/> object to the same properties
        /// in the specified <paramref name="destination"/> object. Read-only, assign-only and indexed properties will be ignored.
        /// </summary>
        /// <typeparam name="T">
        ///     The type of the object whose properties will be copied.
        /// </typeparam>
        /// <param name="source">The source object.</param>
        /// <param name="destination">The destination object.</param>
        public static void CopyProperties<T>( T source, T destination ) where T : class
        {
            Type sourceType = source.GetType();
            PropertyInfo[] destProperties = destination.GetType().GetProperties();

            foreach ( PropertyInfo currDestProperty in destProperties )
            {
                if ( 0 == currDestProperty.GetIndexParameters().Length )
                {
                    if ( currDestProperty.CanWrite && currDestProperty.CanRead )
                    {
                        PropertyInfo sourceProperty = sourceType.GetProperty( currDestProperty.Name );
                        currDestProperty.SetValue( destination, sourceProperty.GetValue( source, null ), null );
                    }
                }
            }
        }

        /// <summary>
        /// Returns an action for getting the column ordinals.
        /// </summary>
        /// <param name="ordinalColumns">A list of columns to be indexed for subsequent access.</param>
        /// <returns>The action for getting column ordinals.</returns>
        public static ColumnOrdinalsAction GetColumnOrdinals(List<string> ordinalColumns)
        {
            if (ordinalColumns == null || ordinalColumns.Count <= 0) return null;

            ColumnOrdinalsAction columnOrdinalsAction =
                reader =>
                {
                    Dictionary<string, int> columnOrdinals = ordinalColumns.ToDictionary(o => o, reader.GetOrdinal);
                    
                    return columnOrdinals;
                };

            return columnOrdinalsAction;
        }

        #region ExecuteDataSet
        /// <summary>
        /// Executes a SQL command against the specified connection and returns the resulting DataSet.
        /// </summary>
        /// <param name="providerFactory">The database provider factory.</param>
        /// <param name="connectionString">
        ///     The current database connection string.
        /// </param>
        /// <param name="commandText">
        ///     The SQL command to execute./>.
        /// </param>
        /// <param name="parameters">A collection of parameters</param>
        /// <param name="postExecuteAction"></param>
        /// <param name="errorHandlerAction">
        ///     The method to invoke in case an error occurs. The method contains a single parameter
        ///     of type <see cref="System.Exception"/>, which holds a reference to the actual exception.
        ///     This method is normally used to prevent propagation of exceptions and for logging errors.
        /// </param>
        /// <exception cref="System.ArgumentException">
        /// 	<paramref name="commandText"/> is a <c>null</c> reference (<c>Nothing</c> in Visual Basic)
        ///     or an empty string.
        /// </exception>
        /// <exception cref="System.Exception">
        ///     Thrown only when <paramref name="errorHandlerAction"/> is a <c>null</c> reference (<c>Nothing</c> in Visual Basic)
        ///     and an error occurs within this method.
        /// </exception>
        public static DataSet ExecuteDataSet(DbProviderFactory providerFactory, string connectionString, string commandText,
            Dictionary<string, object> parameters, Action<IDbCommand> postExecuteAction = null, Action<Exception> errorHandlerAction = null)
        {
            Action<IDbCommand> parameterSetup = GetParameterAction(parameters);

            return ExecuteDataSet(providerFactory, connectionString, commandText, parameterSetup, postExecuteAction, errorHandlerAction);
        }

        /// <summary>
        /// Executes a SQL command against the specified connection and returns the resulting DataSet.
        /// </summary>
        /// <param name="providerFactory">The database provider factory.</param>
        /// <param name="connectionString">
        ///     The current database connection string.
        /// </param>
        /// <param name="commandText">
        ///     The SQL command to execute./>.
        /// </param>
        /// <param name="preExecuteAction">
        ///     The method to invoke to set up the command's parameters. Can be set to <c>null</c>
        ///     (<c>Nothing</c> in Visual Basic) if the SQL command accepts no parameters.
        /// </param>
        /// <param name="postExecuteAction"></param>
        /// <param name="errorHandlerAction">
        ///     The method to invoke in case an error occurs. The method contains a single parameter
        ///     of type <see cref="System.Exception"/>, which holds a reference to the actual exception.
        ///     This method is normally used to prevent propagation of exceptions and for logging errors.
        /// </param>
        /// <exception cref="System.ArgumentException">
        /// 	<paramref name="commandText"/> is a <c>null</c> reference (<c>Nothing</c> in Visual Basic)
        ///     or an empty string.
        /// </exception>
        /// <exception cref="System.Exception">
        ///     Thrown only when <paramref name="errorHandlerAction"/> is a <c>null</c> reference (<c>Nothing</c> in Visual Basic)
        ///     and an error occurs within this method.
        /// </exception>
        public static DataSet ExecuteDataSet(DbProviderFactory providerFactory, string connectionString, string commandText,
            Action<IDbCommand> preExecuteAction = null, Action<IDbCommand> postExecuteAction = null, Action<Exception> errorHandlerAction = null)
        {
            if (providerFactory == null) throw new ArgumentException("Missing required parameter 'providerFactory'!");

            using (DbConnection connection = providerFactory.CreateConnection())
            {
                connection.ConnectionString = connectionString;
                return ExecuteDataSet(providerFactory, connection, commandText, preExecuteAction, postExecuteAction,errorHandlerAction);
            }
        }

        /// <summary>
        /// Executes a SQL command against the specified connection and returns the resulting DataSet.
        /// </summary>
        /// <param name="providerFactory">The database provider factory.</param>
        /// <param name="connectionString">
        ///     The current database connection string.
        /// </param>
        /// <param name="commandText">
        ///     The SQL command to execute./>.
        /// </param>
        /// <param name="commandType">The type of command (e.g. stored procedure or text)</param>
        /// <param name="parameters">A collection of parameters</param>
        /// <param name="postExecuteAction"></param>
        /// <param name="errorHandlerAction">
        ///     The method to invoke in case an error occurs. The method contains a single parameter
        ///     of type <see cref="System.Exception"/>, which holds a reference to the actual exception.
        ///     This method is normally used to prevent propagation of exceptions and for logging errors.
        /// </param>
        /// <exception cref="System.ArgumentException">
        /// 	<paramref name="commandText"/> is a <c>null</c> reference (<c>Nothing</c> in Visual Basic)
        ///     or an empty string.
        /// </exception>
        /// <exception cref="System.Exception">
        ///     Thrown only when <paramref name="errorHandlerAction"/> is a <c>null</c> reference (<c>Nothing</c> in Visual Basic)
        ///     and an error occurs within this method.
        /// </exception>
        public static DataSet ExecuteDataSet(DbProviderFactory providerFactory, string connectionString, string commandText,
            CommandType commandType, Dictionary<string, object> parameters, Action<IDbCommand> postExecuteAction = null, Action<Exception> errorHandlerAction = null)
        {
            Action<IDbCommand> parameterSetup = GetParameterAction(parameters);

            return ExecuteDataSet(providerFactory, connectionString, commandText, commandType, parameterSetup, postExecuteAction, errorHandlerAction);
        }

        /// <summary>
        /// Executes a SQL command against the specified connection and returns the resulting DataSet.
        /// </summary>
        /// <param name="providerFactory">The database provider factory.</param>
        /// <param name="connectionString">
        ///     The current database connection string.
        /// </param>
        /// <param name="commandText">
        ///     The SQL command to execute./>.
        /// </param>
        /// <param name="commandType">The type of command (e.g. stored procedure or text)</param>
        /// <param name="preExecuteAction">
        ///     The method to invoke to set up the command's parameters. Can be set to <c>null</c>
        ///     (<c>Nothing</c> in Visual Basic) if the SQL command accepts no parameters.
        /// </param>
        /// <param name="postExecuteAction"></param>
        /// <param name="errorHandlerAction">
        ///     The method to invoke in case an error occurs. The method contains a single parameter
        ///     of type <see cref="System.Exception"/>, which holds a reference to the actual exception.
        ///     This method is normally used to prevent propagation of exceptions and for logging errors.
        /// </param>
        /// <exception cref="System.ArgumentException">
        /// 	<paramref name="commandText"/> is a <c>null</c> reference (<c>Nothing</c> in Visual Basic)
        ///     or an empty string.
        /// </exception>
        /// <exception cref="System.Exception">
        ///     Thrown only when <paramref name="errorHandlerAction"/> is a <c>null</c> reference (<c>Nothing</c> in Visual Basic)
        ///     and an error occurs within this method.
        /// </exception>
        public static DataSet ExecuteDataSet(DbProviderFactory providerFactory, string connectionString, string commandText,
            CommandType commandType, Action<IDbCommand> preExecuteAction = null,
            Action<IDbCommand> postExecuteAction = null, Action<Exception> errorHandlerAction = null)
        {
            if (providerFactory == null) throw new ArgumentException("Missing required parameter 'providerFactory'!");

            using (DbConnection connection = providerFactory.CreateConnection())
            {
                connection.ConnectionString = connectionString;
                return ExecuteDataSet(providerFactory, connection, commandText, commandType, preExecuteAction, postExecuteAction, errorHandlerAction);
            }
        }

        /// <summary>
        /// Executes a SQL command against the specified connection and returns the resulting DataSet.
        /// </summary>
        /// <param name="providerFactory">The database provider factory.</param>
        /// <param name="connection">
        ///     The current database connection. The connection is automatically opened and closed by this method.
        /// </param>
        /// <param name="commandText">
        ///     The SQL command to execute against the <paramref name="connection"/>.
        /// </param>
        /// <param name="parameters">A collection of parameters</param>
        /// <param name="postExecuteAction"></param>
        /// <param name="errorHandlerAction">
        ///     The method to invoke in case an error occurs. The method contains a single parameter
        ///     of type <see cref="System.Exception"/>, which holds a reference to the actual exception.
        ///     This method is normally used to prevent propagation of exceptions and for logging errors.
        /// </param>
        /// <exception cref="System.ArgumentException">
        /// 	<paramref name="commandText"/> is a <c>null</c> reference (<c>Nothing</c> in Visual Basic)
        ///     or an empty string.
        /// </exception>
        /// <exception cref="System.Exception">
        ///     Thrown only when <paramref name="errorHandlerAction"/> is a <c>null</c> reference (<c>Nothing</c> in Visual Basic)
        ///     and an error occurs within this method.
        /// </exception>
        public static DataSet ExecuteDataSet(DbProviderFactory providerFactory, IDbConnection connection, string commandText,
            Dictionary<string, object> parameters, Action<IDbCommand> postExecuteAction = null, Action<Exception> errorHandlerAction = null)
        {
            Action<IDbCommand> parameterSetup = GetParameterAction(parameters);

            return ExecuteDataSet(providerFactory, connection, commandText, parameterSetup, postExecuteAction, errorHandlerAction);
        }

        /// <summary>
        /// Executes a SQL command against the specified connection and returns the resulting DataSet.
        /// </summary>
        /// <param name="providerFactory">The database provider factory.</param>
        /// <param name="connection">
        ///     The current database connection. The connection is automatically opened and closed by this method.
        /// </param>
        /// <param name="commandText">
        ///     The SQL command to execute against the <paramref name="connection"/>.
        /// </param>
        /// <param name="preExecuteAction">
        ///     The method to invoke to set up the command's parameters. Can be set to <c>null</c>
        ///     (<c>Nothing</c> in Visual Basic) if the SQL command accepts no parameters.
        /// </param>
        /// <param name="postExecuteAction"></param>
        /// <param name="errorHandlerAction">
        ///     The method to invoke in case an error occurs. The method contains a single parameter
        ///     of type <see cref="System.Exception"/>, which holds a reference to the actual exception.
        ///     This method is normally used to prevent propagation of exceptions and for logging errors.
        /// </param>
        /// <exception cref="System.ArgumentException">
        /// 	<paramref name="commandText"/> is a <c>null</c> reference (<c>Nothing</c> in Visual Basic)
        ///     or an empty string.
        /// </exception>
        /// <exception cref="System.Exception">
        ///     Thrown only when <paramref name="errorHandlerAction"/> is a <c>null</c> reference (<c>Nothing</c> in Visual Basic)
        ///     and an error occurs within this method.
        /// </exception>
        public static DataSet ExecuteDataSet(DbProviderFactory providerFactory, IDbConnection connection, string commandText,
            Action<IDbCommand> preExecuteAction = null, Action<IDbCommand> postExecuteAction = null, Action<Exception> errorHandlerAction = null)
        {
            return ExecuteDataSet(providerFactory, connection, commandText, CommandType.StoredProcedure, 
                preExecuteAction, postExecuteAction, errorHandlerAction);
        }

        /// <summary>
        /// Executes a SQL command against the specified connection and returns the resulting DataSet.
        /// </summary>
        /// <param name="providerFactory">The database provider factory.</param>
        /// <param name="connection">
        ///     The current database connection. The connection is automatically opened and closed by this method.
        /// </param>
        /// <param name="commandText">
        ///     The SQL command to execute against the <paramref name="connection"/>.
        /// </param>
        /// <param name="commandType">The type of command (e.g. stored procedure or text)</param>
        /// <param name="parameters">A collection of parameters</param>
        /// <param name="postExecuteAction"></param>
        /// <param name="errorHandlerAction">
        ///     The method to invoke in case an error occurs. The method contains a single parameter
        ///     of type <see cref="System.Exception"/>, which holds a reference to the actual exception.
        ///     This method is normally used to prevent propagation of exceptions and for logging errors.
        /// </param>
        /// <exception cref="System.ArgumentException">
        /// 	<paramref name="commandText"/> is a <c>null</c> reference (<c>Nothing</c> in Visual Basic)
        ///     or an empty string.
        /// </exception>
        /// <exception cref="System.Exception">
        ///     Thrown only when <paramref name="errorHandlerAction"/> is a <c>null</c> reference (<c>Nothing</c> in Visual Basic)
        ///     and an error occurs within this method.
        /// </exception>
        public static DataSet ExecuteDataSet(DbProviderFactory providerFactory, IDbConnection connection, string commandText,
            CommandType commandType, Dictionary<string, object> parameters,
            Action<IDbCommand> postExecuteAction = null, Action<Exception> errorHandlerAction = null)
        {
            Action<IDbCommand> parameterSetup = GetParameterAction(parameters);

            return ExecuteDataSet(providerFactory, connection, commandText, commandType, parameterSetup, postExecuteAction, errorHandlerAction);
        }

        /// <summary>
        /// Executes a SQL command against the specified connection and returns the resulting DataSet.
        /// </summary>
        /// <param name="providerFactory">The database provider factory.</param>
        /// <param name="connection">
        ///     The current database connection. The connection is automatically opened and closed by this method.
        /// </param>
        /// <param name="commandText">
        ///     The SQL command to execute against the <paramref name="connection"/>.
        /// </param>
        /// <param name="commandType">The type of command (e.g. stored procedure or text)</param>
        /// <param name="preExecuteAction">
        ///     The method to invoke to set up the command's parameters. Can be set to <c>null</c>
        ///     (<c>Nothing</c> in Visual Basic) if the SQL command accepts no parameters.
        /// </param>
        /// <param name="postExecuteAction"></param>
        /// <param name="errorHandlerAction">
        ///     The method to invoke in case an error occurs. The method contains a single parameter
        ///     of type <see cref="System.Exception"/>, which holds a reference to the actual exception.
        ///     This method is normally used to prevent propagation of exceptions and for logging errors.
        /// </param>
        /// <exception cref="System.ArgumentException">
        /// 	<paramref name="commandText"/> is a <c>null</c> reference (<c>Nothing</c> in Visual Basic)
        ///     or an empty string.
        /// </exception>
        /// <exception cref="System.Exception">
        ///     Thrown only when <paramref name="errorHandlerAction"/> is a <c>null</c> reference (<c>Nothing</c> in Visual Basic)
        ///     and an error occurs within this method.
        /// </exception>
        public static DataSet ExecuteDataSet(DbProviderFactory providerFactory, IDbConnection connection, string commandText, 
            CommandType commandType, Action<IDbCommand> preExecuteAction = null, 
            Action<IDbCommand> postExecuteAction = null, Action<Exception> errorHandlerAction = null)
        {
            if (providerFactory == null) throw new ArgumentException("Missing required parameter 'providerFactory'!");
            if (connection == null) throw new ArgumentException("Missing required parameter 'connection'!");
            if (string.IsNullOrEmpty(commandText)) throw new ArgumentException("Missing required parameter 'commandText'!");

            try
            {
                using (DataSet ds = new DataSet())
                {
                    using (IDbCommand cmd = CreateCommand(connection, commandText, commandType, preExecuteAction))
                    {
                        // Log the command we're about to execute.
                        LogCommand(cmd);

                        // Execute command
                        using (DbDataAdapter da = providerFactory.CreateDataAdapter())
                        {
                            da.SelectCommand = (DbCommand) cmd;
                            da.Fill(ds);

                            if (null != postExecuteAction)
                            {
                                postExecuteAction(cmd);
                            }

                            return ds;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                if (Log != null) Log.Error(string.Format("Error calling '{0}'", commandText), ex);

                if (null == errorHandlerAction)
                    throw;
                
                errorHandlerAction(ex);
            }
            return null;
        }
        #endregion

        /// <summary>
        /// Writes to the log the SQL command and any parameters in the DBCommand.
        /// </summary>
        /// <param name="cmd">The command to be logged.</param>
        public static void LogCommand(IDbCommand cmd)
        {
            if (cmd == null || string.IsNullOrEmpty(cmd.CommandText)) return;
            if (Log == null || !Log.Logger.Repository.Configured || !Log.Logger.IsEnabledFor(Level.Debug)) return;

            try
            {
                StringBuilder sb = new StringBuilder();
                sb.Append("\nCommand: ").Append(cmd.CommandText);

                int i = 0;
                foreach (DbParameter parm in cmd.Parameters)
                {
                    if (i == 0)
                    {
                        sb.Append("\nParameters: ");
                    }
                    sb.Append(parm.ParameterName).Append("='").Append(parm.Value).Append("'");
                    if (i < cmd.Parameters.Count - 1) sb.Append(", ");

                    i++;
                }
                Log.Debug(sb.ToString());
            }
            catch
            {
                // Consume.
            }
        }
    }
}
