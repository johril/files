﻿using System;
using System.Data;

namespace Huntington.OnlineBanking.Common.Data
{
    /// <summary>
    /// Contains extension methods for some interfaces in the <see cref="System.Data"/> namespace.
    /// </summary>
    public static class AdoDotNetExtensions
    {
        /// <summary>
        /// Returns the value from the current <c>IDataReader</c> at the specified column index if it's not a <see cref="System.DBNull"/>.
        /// Otherwise, the specified default value is returned.
        /// </summary>
        /// <typeparam name="T">The type of object being returned.</typeparam>
        /// <param name="reader">An instance of a <c>System.Data.IDataReader</c> implementation.</param>
        /// <param name="columnIndex">Index of the column where the value is located.</param>
        /// <param name="readerAction">The method delegate to invoke if the column value is not a <c>System.DBNull</c>.</param>
        /// <param name="defaultValue">The default value to use when the value is <c>System.DBNull</c>.</param>
        /// <returns>
        /// Either the value at the specified <paramref name="columnIndex"/> or <paramref name="defaultValue"/>.
        /// </returns>
        /// <exception cref="System.ArgumentNullException">
        /// 	<paramref name="reader"/> or <paramref name="readerAction"/> is a <c>null</c> reference
        /// (<c>Nothing</c> in Visual Basic).
        /// </exception>
        public static T GetValueOrDefault<T>( this IDataReader reader, int columnIndex, Func<int, T> readerAction, T defaultValue )
        {
            return DataUtil.GetDataReaderValue( reader, columnIndex, readerAction, defaultValue );
        }

        public static Nullable<T> GetNullableValue<T>( this IDataReader reader, int columnIndex, Func<int, T> readerAction, Nullable<T> defaultValue ) where T : struct
        {
            return GetValueOrDefault( reader, columnIndex, ( index ) => new Nullable<T>( readerAction( index ) ), defaultValue );
        }

        /// <summary>
        /// Creates and appends an input parameter to the current <see cref="System.Data.IDbCommand"/> implementation.
        /// </summary>
        /// <param name="cmd">The <see cref="System.Data.IDbCommand"/> being extended.</param>
        /// <param name="parameterName">The name of the parameter that is compatible with the ADO.NET data provider in use.</param>
        /// <param name="parameterType">The data type of the parameter.</param>
        /// <param name="size">The size (in bytes) of the parameter.</param>
        /// <param name="value">The value of the parameter. Can be set to <c>null</c>, in which case it will be replaced with <see cref="System.DBNull.Value"/>.</param>
        /// <returns>
        ///     A reference to a <c>System.Data.IDbDataParameter</c> that was appended to the <see cref="System.Data.IDbCommand"/> object's
        ///     list of parameters.
        /// </returns>
        public static IDbDataParameter AddInputParameter( this IDbCommand cmd, string parameterName, DbType parameterType, int size, object value )
        {
            IDbDataParameter myParam = DataUtil.CreateInputParameter( cmd, parameterName, parameterType, size, value );
            cmd.Parameters.Add( myParam );

            return myParam;
        }

        /// <summary>
        /// Creates and appends an input parameter with the specified value to the current <see cref="System.Data.IDbCommand"/> implementation.
        /// </summary>
        /// <param name="cmd">The <see cref="System.Data.IDbCommand"/> being extended.</param>
        /// <param name="parameterName">The name of the parameter that is compatible with the ADO.NET data provider in use.</param>
        /// <param name="value">The value of the parameter. Can be set to <c>null</c>, in which case it will be replaced with <see cref="System.DBNull.Value"/>.</param>
        /// <returns>
        ///     A reference to a <c>System.Data.IDbDataParameter</c> that was appended to the <see cref="System.Data.IDbCommand"/> object's
        ///     list of parameters.
        /// </returns>
        public static IDbDataParameter AddInputParameterWithValue(this IDbCommand cmd, string parameterName, object value)
        {
            IDbDataParameter myParam = DataUtil.CreateInputParameterWithValue(cmd, parameterName, value);
            cmd.Parameters.Add(myParam);

            return myParam;
        }

        /// <summary>
        /// Creates and appends an output parameter to the current <see cref="System.Data.IDbCommand"/> implementation.
        /// </summary>
        /// <param name="cmd">The <see cref="System.Data.IDbCommand"/> being extended.</param>
        /// <param name="parameterName">The name of the parameter that is compatible with the ADO.NET data provider in use.</param>
        /// <param name="parameterType">The data type of the parameter.</param>
        /// <param name="size">The size (in bytes) of the parameter.</param>
        /// <param name="value">The value of the parameter. Can be set to <c>null</c>, in which case it will be replaced with <see cref="System.DBNull.Value"/>.</param>
        /// <returns>
        ///     A reference to a <c>System.Data.IDbDataParameter</c> that was appended to the <see cref="System.Data.IDbCommand"/> object's
        ///     list of parameters.
        /// </returns>
        public static IDbDataParameter AddOutputParameter(this IDbCommand cmd, string parameterName, DbType parameterType, int size, object value)
        {
            IDbDataParameter myParam = DataUtil.CreateOutputParameter( cmd, parameterName, parameterType, size, value );
            cmd.Parameters.Add( myParam );

            return myParam;
        }

        /// <summary>
        /// Gets the value of a <see cref="System.Data.IDbDataParameter"/>, given the name of the parameter.
        /// </summary>
        /// <typeparam name="T">The type of the value being returned.</typeparam>
        /// <param name="cmd">The <see cref="System.Data.IDbCommand"/> being extended.</param>
        /// <param name="parameterName">The name of the <c>System.Data.IDbDataParameter</c> in the <see cref="System.Data.IDbCommand.Parameters"/> collection.</param>
        /// <returns>
        ///     The value of the parameter.
        /// </returns>
        /// <exception cref="System.ArgumentException">
        ///     <paramref name="parameterName"/> is a <c>null</c> reference or an empty string;
        ///    or the specified parameter name was not found.
        /// </exception>
        /// <exception cref="System.IndexOutOfRangeException">
        ///     The specified <paramref name="parameterName"/> was not found.
        /// </exception>
        public static T GetParameterValue<T>(this IDbCommand cmd, string parameterName)
        {
            if (String.IsNullOrWhiteSpace(parameterName))
                throw new ArgumentException("parameterName");

            return (T)DataUtil.GetParameter(cmd, parameterName).Value;
        }

        /// <summary>
        /// Appends a stored procedure's return value parameter (<c>@RETURN_VALUE</c>) to the collection of parameters of the
        /// given command object.
        /// </summary>
        /// <param name="cmd">The command object for the current database connection.</param>
        /// <returns>
        ///     A reference to the return value parameter.
        /// </returns>
        /// <remarks>
        ///     This method is compatible with SQL Server only.
        /// </remarks>
        public static IDbDataParameter AddReturnValueParameter(this IDbCommand cmd)
        {
            return DataUtil.AppendReturnValueParameter(cmd);
        }

        /// <summary>
        /// Returns the value from a stored procedure's return value parameter (<c>@RETURN_VALUE</c>) given command object.
        /// </summary>
        /// <param name="cmd">The command object for the current database connection.</param>
        /// <returns>
        ///     A reference to the return value parameter.
        /// </returns>
        /// <remarks>
        ///     This method is compatible with SQL Server only.
        /// </remarks>
        public static int GetReturnValue(this IDbCommand cmd)
        {
            return (int)DataUtil.GetParameter(cmd, "@RETURN_VALUE").Value;
        }
    }
}