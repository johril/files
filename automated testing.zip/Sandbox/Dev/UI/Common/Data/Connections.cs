﻿namespace Huntington.OnlineBanking.Common.Data
{
    public static class Connections
    {
        public const string CommonInfoConnectionStringKey = "CommonInfoConnectString";
        public const string VoyagerDatabaseConnectionStringKey = "VoyagerConnectString";
        public const string CampaignDatabaseConnectionStringKey = "CampaignConnectString";
        public const string AlertsDatabaseConnectionStringKey = "AlertsConnectString";
        public const string AuditBillingDatabaseConnectionStringKey = "AuditBillingConnectString";
        public const string InterfacesDatabaseConnectionStringKey = "InterfacesConnectString";
        public const string PositivePayDatabaseConnectionStringKey = "PositivePayConnectString";
        public const string TokenManagementDatabaseConnectionStringKey = "TokenManagementConnectString";
        public const string AuthDatabaseConnectionStringKey = "AuthConnectString";
        public const string VoyagerHuntingtonCustomConnectStringKey = "VoyagerHuntingtonCustomConnectString";
        public const string SupportConnectStringKey = "SupportConnectString";
        public const string IAConnectString = "IAConnectString";
        public const string GAConnectString = "GAConnectString";
        public const string SwiftConnectString = "SwiftDataConnectString";
        public const string SubmitConnectString = "SummitConnectString";
        public const string SummitUpdateString = "SummitUpdateString";
		public const string IBSnetConnectString = "IBSnetConnectString";
        public const string GTAConnectionString = "GTAConnectString";
        public const string FileNetConnectString = "FileNetConnectString";
        public const string GTAReportingConnectString = "GTAReportingConnectString";
    }
}
