﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Reflection;

namespace Huntington.OnlineBanking.Common.Testing
{
    /*******************************************************************************************
     * Unit Test Helper Class that stream lines integration test using Reflection.  
     * Can test prexisting interfaces without Mocking the concrete implementation.  
     * Allows developer to conduct integration testing on private, public, and static methods.
     ******************************************************************************************/
    public class UnitTestHelper
    {
        public static object RunStaticMethod(System.Type t, string strMethod, object[] objParams)
        {
            BindingFlags eFlags = BindingFlags.Static | BindingFlags.Public | BindingFlags.NonPublic;
            return RunMethod(t, strMethod, null, objParams, eFlags);
        }

        public static object RunInstanceMethod(System.Type t, string strMethod, object objInstance, object[] objParams)
        {
            BindingFlags eFlags = BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic;
            return RunMethod(t, strMethod, objInstance, objParams, eFlags);
        }

        private static object RunMethod(System.Type t, string strMethod, object objInstance, object[] aobjParams, BindingFlags eFlags)
        {
            MethodInfo m;
            try
            {
                m = t.GetMethod(strMethod, eFlags);
                if (m == null)
                {
                    throw new ArgumentException("There is no method '" + strMethod + "' for type '" + t.ToString() + "'.");
                }

                object objRet = m.Invoke(objInstance, aobjParams);
                return objRet;
            }
            catch
            {
                throw;
            }
        }
    }
}