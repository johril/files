﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.Common;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using Huntington.OnlineBanking.Common.ConfigurationManagement;
using Huntington.OnlineBanking.Common.Data;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace Huntington.OnlineBanking.Common.Testing
{
    public class BaseDataFactory
    {
        public static Random _rand = new Random(DateTime.Now.Millisecond);

        protected static ConnectionStringSettings GetConnectionStringSettings(string configurationKey)
        {
            AssemblyConfigurationManager.UseRootAppConfigFile = true;
            return AssemblyConfigurationManager.Default.ConnectionStrings[configurationKey];
        }

        public static string BuildWhereClause(Dictionary<string, object> criteria)
        {
            StringBuilder sb = new StringBuilder();
            if (criteria != null && criteria.Count() > 0)
            {
                sb.Append("\nwhere 1 = 1");
                foreach (KeyValuePair<string, object> pair in criteria)
                {
                    sb.Append("\n  and ");
                    if (pair.Key.Trim().ToLower() == "where")
                    {
                        // This is raw SQL.
                        sb.Append("(").Append(pair.Value).Append(")");
                    }
                    else
                    {
                        sb.Append("(").Append(pair.Key).Append(" = '").Append(pair.Value).Append("'").Append(")");
                    }
                }
            }
            return sb.ToString();
        }

        public static DataTable GetSampleData(DbProviderFactory provider, string connectionString, string tableName,
            Dictionary<string, object> criteria = null, bool verifyResults = true)
        {
            string sql = "select * from " + tableName;
            return GetSampleData(provider, connectionString, sql, tableName, criteria, verifyResults);
        }

        public static DataTable GetSampleData(DbProviderFactory provider, string connectionString, string sql, string tableName,
            Dictionary<string, object> criteria = null, bool verifyResults = true)
        {
            if (provider == null) throw new ArgumentNullException("provider");
            if (string.IsNullOrEmpty(connectionString)) throw new ArgumentNullException("connectionString");
            if (string.IsNullOrEmpty(sql)) throw new ArgumentNullException("sql");
            if (string.IsNullOrEmpty(tableName)) throw new ArgumentNullException("tableName");

            if (criteria != null && criteria.Count > 0)
            {
                sql += BuildWhereClause(criteria);
            }

            using (DataSet ds = DataUtil.ExecuteDataSet(provider, connectionString, sql, CommandType.Text))
            {
                if (verifyResults)
                    Assert.IsTrue(ds != null && ds.Tables.Count > 0 && ds.Tables[0].Rows.Count > 0, "Failed to return a sample " + tableName + "!");

                return ds.Tables[0];
            }
        }

        public static string ReturnIsNotNullOrEmptyWhereClause(string field)
        {
            return String.Format("{0} is not null and Len ({0}) > 0", field);
        }

        public static object GetSampleValue(SqlParameter parameter)
        {
            return GetSampleValue(parameter.SqlDbType, parameter.Size);
        }

        public static object GetSampleValue(SqlDbType sqlType, int size)
        {
            size = Math.Max(size, 1);
            switch (sqlType)
            {
                case SqlDbType.Bit:
                    return _rand.Next(1);

                case SqlDbType.Char:
                case SqlDbType.VarChar:
                    size = _rand.Next(1, size);
                    StringBuilder sb = new StringBuilder(size);
                    for (int i = 0; i < size; i++)
                    {
                        // A-Z | a-z.
                        sb.Append((char)(_rand.Next(0, 1) == 0 ? _rand.Next(65, 90) : _rand.Next(97, 122)));
                    }
                    return sb.ToString();

                case SqlDbType.DateTime:
                case SqlDbType.SmallDateTime:
                    DateTime sampleDate = DateTime.Now.AddDays(_rand.Next(-9999, 9999));
                    if (sqlType == SqlDbType.SmallDateTime)
                    {
                        sampleDate = sampleDate.AddSeconds(-sampleDate.Second).AddMilliseconds(-sampleDate.Millisecond);
                    }
                    return sampleDate;

                case SqlDbType.Decimal:
                case SqlDbType.Float:
                    return Math.Round(_rand.NextDouble() * (Math.Pow(10, size) - 1), 2);

                case SqlDbType.Int:
                case SqlDbType.SmallInt:
                    return _rand.Next(-(int)(Math.Pow(10, size) - 1), (int)Math.Pow(10, size) - 1);

                default:
                    throw new Exception("Unhandled sample data type: " + sqlType);
            }
        }

        private static string GetInsertStatement(string tableName, IEnumerable<SqlParameter> tableDefinition,
            Dictionary<string, object> sampleValues = null)
        {
            if (string.IsNullOrEmpty(tableName)) throw new ArgumentNullException("tableName");
            if (tableDefinition == null) throw new ArgumentNullException("tableDefinition");
            if (tableDefinition.Count() <= 0) throw new ArgumentException("tableDefinition");

            // Loop through the table definition and build the SQL insert statement.
            StringBuilder sbColumns = new StringBuilder();
            StringBuilder sbValues = new StringBuilder();
            foreach (SqlParameter parameter in tableDefinition)
            {
                sbColumns.Append(parameter.SourceColumn).Append(", ");
                sbValues.Append(parameter.ParameterName).Append(", ");
            }

            // See if there are additional columns defined in the sample values.
            if (sampleValues != null && sampleValues.Count > 0)
            {
                foreach (KeyValuePair<string, object> sampleValue in sampleValues)
                {
                    KeyValuePair<string, object> value = sampleValue;
                    var parameter = tableDefinition.FirstOrDefault(p => p.ParameterName == "@" + value.Key);
                    if (parameter == null)
                    {
                        sbColumns.Append(sampleValue.Key).Append(", ");
                        sbValues.Append("@" + sampleValue.Key).Append(", ");
                    }
                }
            }
            // Remove the trailing comma.
            sbColumns.Remove(sbColumns.Length - 2, 2);
            sbValues.Remove(sbValues.Length - 2, 2);

            StringBuilder sbSql = new StringBuilder();
            sbSql.AppendFormat("insert into {0}{1}", tableName, Environment.NewLine);
            sbSql.AppendFormat("({0}{1})", sbColumns, Environment.NewLine);
            sbSql.AppendFormat("values ({0})", sbValues);

            return sbSql.ToString();
        }

        private static Action<IDbCommand> GetParameterCommand(string tableName, IEnumerable<SqlParameter> tableDefinition,
            Dictionary<string, object> sampleValues = null)
        {
            if (string.IsNullOrEmpty(tableName)) throw new ArgumentNullException("tableName");
            if (tableDefinition == null) throw new ArgumentNullException("tableDefinition");
            if (tableDefinition.Count() <= 0) throw new ArgumentException("tableDefinition");

            Action<IDbCommand> parameterSetup = cmd =>
            {
                foreach (SqlParameter parameter in tableDefinition)
                {
                    cmd.AddInputParameterWithValue(parameter.ParameterName, GetSampleValue(parameter));
                }

                // See if there are sample values that should overwrite the generated values, or add new sample values.
                if (sampleValues != null && sampleValues.Count > 0)
                {
                    foreach (KeyValuePair<string, object> sampleValue in sampleValues)
                    {
                        KeyValuePair<string, object> value = sampleValue;
                        var parameter = cmd.Parameters.Cast<IDbDataParameter>().FirstOrDefault(p => p.ParameterName == "@" + value.Key);
                        if (parameter != null)
                        {
                            parameter.Value = sampleValue.Value;
                        }
                        else
                        {
                            cmd.AddInputParameterWithValue("@" + sampleValue.Key, sampleValue.Value);
                        }
                    }
                }
            };

            return parameterSetup;
        }

        /// <summary>
        /// Adds a row to the specified table and returns the results.
        /// </summary>
        /// <param name="provider">The data provider factory.</param>
        /// <param name="connectionString">The database connection string.</param>
        /// <param name="tableName">The name of the table where the row will be added.</param>
        /// <param name="tableDefinition">The definition of the table's columns (must include columns defined as not null).</param>
        /// <param name="identityKey">The table's identity column.</param>
        /// <param name="sampleValues">A collection of sample values to add to the row.</param>
        /// <returns>The row.</returns>
        public static DataTable AddSampleSqlRow(DbProviderFactory provider, string connectionString, string tableName, IEnumerable<SqlParameter> tableDefinition,
            string identityKey, Dictionary<string, object> sampleValues = null)
        {
            if (provider == null) throw new ArgumentNullException("provider");
            if (string.IsNullOrEmpty(connectionString)) throw new ArgumentNullException("connectionString");
            if (string.IsNullOrEmpty(tableName)) throw new ArgumentNullException("tableName");
            if (string.IsNullOrEmpty(identityKey)) throw new ArgumentNullException("identityKey");

            Func<string, Action<IDbCommand>, DataTable> getResultsCommand =
                (sql, parameterSetup) =>
                {
                    sql += ";Select Scope_Identity()";
                    object o = DataUtil.ExecuteScalar(provider, connectionString, sql, CommandType.Text, parameterSetup);
                    int index = DBConvert.ToInt32(o);
                    if (index <= 0) throw new Exception("Failed to get a valid identity key value!");

                    parameterSetup = cmd => cmd.AddInputParameterWithValue("@IdentityKey", index);

                    sql = string.Format("select * from {0} where {1} = @IdentityKey", tableName, identityKey);
                    using (DataSet ds = DataUtil.ExecuteDataSet(provider, connectionString, sql, CommandType.Text, parameterSetup))
                    {
                        if (ds == null || ds.Tables.Count <= 0) return null;
                        return ds.Tables[0];
                    }
                };

            return AddSampleRow(provider, connectionString, tableName, tableDefinition, sampleValues, getResultsCommand);
        }

        /// <summary>
        /// Adds a row to the specified table and returns the results.
        /// </summary>
        /// <param name="provider">The data provider factory.</param>
        /// <param name="connectionString">The database connection string.</param>
        /// <param name="tableName">The name of the table where the row will be added.</param>
        /// <param name="tableDefinition">The definition of the table's columns (must include columns defined as not null).</param>
        /// <param name="primaryKeys">The table's primary key columns  These should be defined in <paramref name="tableDefinition"/>.</param>
        /// <param name="sampleValues">A collection of sample values to add to the row.</param>
        /// <returns>The row.</returns>
        public static DataTable AddSampleRow(DbProviderFactory provider, string connectionString, string tableName, IEnumerable<SqlParameter> tableDefinition,
            string[] primaryKeys, Dictionary<string, object> sampleValues)
        {
            if (provider == null) throw new ArgumentNullException("provider");
            if (string.IsNullOrEmpty(connectionString)) throw new ArgumentNullException("connectionString");
            if (string.IsNullOrEmpty(tableName)) throw new ArgumentNullException("tableName");
            if (primaryKeys == null || primaryKeys.Length <= 0) throw new ArgumentNullException("primaryKeys");
            if (tableDefinition == null || tableDefinition.Count() <= 0) throw new ArgumentNullException("tableDefinition");
            if (!primaryKeys.Any(k => tableDefinition.Any(c => c.SourceColumn == k)))
            {
                throw new ArgumentException("All primary key columns must be defined in the tableDefinition parameter!");
            }

            if (sampleValues == null) sampleValues = new Dictionary<string, object>();
            foreach (string key in primaryKeys)
            {
                if (sampleValues.ContainsKey(key)) continue;

                SqlParameter parm = tableDefinition.First(p => string.Compare(p.SourceColumn, key, true) == 0);
                sampleValues[parm.SourceColumn] = GetSampleValue(parm.SqlDbType, parm.Size);
            }

            Func<string, Action<IDbCommand>, DataTable> executeSqlFunc =
                (sql, parameterSetup) =>
                {
                    DataUtil.ExecuteNonQuery(provider, connectionString, sql, CommandType.Text, parameterSetup);

                    parameterSetup = cmd =>
                    {
                        foreach (string primaryKey in primaryKeys)
                        {
                            object val = sampleValues[primaryKey];
                            cmd.AddInputParameterWithValue("@" + primaryKey, val);
                        }
                    };

                    StringBuilder sbSql = new StringBuilder();
                    sbSql.AppendFormat("select * from {0} where 1=1", tableName);
                    foreach (string primaryKey in primaryKeys)
                    {
                        sbSql.AppendFormat(" and {0} = @{0}", primaryKey);
                    }
                    using (DataSet ds = DataUtil.ExecuteDataSet(provider, connectionString, sbSql.ToString(), CommandType.Text, parameterSetup))
                    {
                        if (ds == null || ds.Tables.Count <= 0) return null;
                        return ds.Tables[0];
                    }
                };

            return AddSampleRow(provider, connectionString, tableName, tableDefinition, sampleValues, executeSqlFunc);
        }

        /// <summary>
        /// Adds a row to the specified table and returns the results.
        /// </summary>
        /// <param name="provider">The data provider factory.</param>
        /// <param name="connectionString">The database connection string.</param>
        /// <param name="tableName">The name of the table where the row will be added.</param>
        /// <param name="tableDefinition">The definition of the table's columns (must include columns defined as not null).</param>
        /// <param name="sampleValues">A collection of sample values to add to the row.</param>
        /// <param name="executeSqlFunc">The function to execute to add the row and retrieve results.</param>
        /// <returns>The row.</returns>
        public static DataTable AddSampleRow(DbProviderFactory provider, string connectionString, string tableName, IEnumerable<SqlParameter> tableDefinition,
            Dictionary<string, object> sampleValues = null, Func<string, Action<IDbCommand>, DataTable> executeSqlFunc = null)
        {
            if (provider == null) throw new ArgumentNullException("provider");
            if (string.IsNullOrEmpty(connectionString)) throw new ArgumentNullException("connectionString");
            if (string.IsNullOrEmpty(tableName)) throw new ArgumentNullException("tableName");
            if (tableDefinition == null || tableDefinition.Count() <= 0) throw new ArgumentNullException("tableDefinition");

            Action<IDbCommand> parameterSetup = GetParameterCommand(tableName, tableDefinition, sampleValues);
            string sql = GetInsertStatement(tableName, tableDefinition, sampleValues);

            if (executeSqlFunc == null) return null;

            return executeSqlFunc(sql, parameterSetup);
        }

        /// <summary>
        /// Queries for sample data, and if none is found it adds a sample row.
        /// </summary>
        /// <param name="provider">The data provider factory.</param>
        /// <param name="connectionString">The database connection string.</param>
        /// <param name="tableName">The name of the table where the row will be added.</param>
        /// <param name="tableDefinition">The definition of the table's columns (must include columns defined as not null).</param>
        /// <param name="identityKey">The table's identity column.</param>
        /// <param name="addedRow">Returns whether or not a sample row was added, which indicates whether that row should be deleted in the end.</param>
        /// <param name="criteria">The criteria to use when querying for sample data.</param>
        /// <param name="sampleValues">A collection of sample values to add to the row.</param>
        /// <param name="verifyResults">Whether to assert that sample data was found.</param>
        /// <returns>The found/added sample data.</returns>
        public static DataTable FindOrAddSampleSqlData(DbProviderFactory provider, string connectionString, string tableName,
            IEnumerable<SqlParameter> tableDefinition, string identityKey, out bool addedRow, Dictionary<string, object> criteria = null,
            Dictionary<string, object> sampleValues = null, bool verifyResults = true)
        {
            addedRow = false;
            string sql = string.Format("select top 1 * from {0}", tableName);
            using (DataTable dt = GetSampleData(provider, connectionString, sql, tableName, criteria, false))
            {
                if (dt != null && dt.Rows.Count > 0) return dt;
            }

            using (DataTable dt = AddSampleSqlRow(provider, connectionString, tableName, tableDefinition, identityKey, sampleValues))
            {
                addedRow = true;
                if (dt != null && dt.Rows.Count > 0) return dt;
            }

            if (verifyResults) Assert.Fail("Failed to find or add sample data!");

            return null;
        }

        /// <summary>
        /// Queries for sample data, and if none is found it adds a sample row.
        /// </summary>
        /// <param name="provider">The data provider factory.</param>
        /// <param name="connectionString">The database connection string.</param>
        /// <param name="tableName">The name of the table where the row will be added.</param>
        /// <param name="tableDefinition">The definition of the table's columns (must include columns defined as not null).</param>
        /// <param name="identityKey">The table's identity column.</param>
        /// <param name="addedRow">Returns whether or not a sample row was added, which indicates whether that row should be deleted in the end.</param>
        /// <param name="criteria">The criteria to use when querying for sample data.</param>
        /// <param name="getSampleValuesFunc">A delegate that is called only if no existing sample data is found, and sample values are needed for adding a sample row.</param>
        /// <param name="verifyResults">Whether to assert that sample data was found.</param>
        /// <returns>The found/added sample data.</returns>
        public static DataTable FindOrAddSampleSqlData(DbProviderFactory provider, string connectionString, string tableName,
            IEnumerable<SqlParameter> tableDefinition, string identityKey, out bool addedRow, Dictionary<string, object> criteria,
            Func<Dictionary<string, object>> getSampleValuesFunc, bool verifyResults = true)
        {
            addedRow = false;
            string sql = string.Format("select top 1 * from {0}", tableName);
            using (DataTable dt = GetSampleData(provider, connectionString, sql, tableName, criteria, false))
            {
                if (dt != null && dt.Rows.Count > 0) return dt;
            }

            Dictionary<string, object> sampleValues = getSampleValuesFunc();
            using (DataTable dt = AddSampleSqlRow(provider, connectionString, tableName, tableDefinition, identityKey, sampleValues))
            {
                addedRow = true;
                if (dt != null && dt.Rows.Count > 0) return dt;
            }

            if (verifyResults) Assert.Fail("Failed to find or add sample data!");

            return null;
        }

        /// <summary>
        /// Queries for sample data, and if none is found it adds a sample row.
        /// </summary>
        /// <param name="provider">The data provider factory.</param>
        /// <param name="connectionString">The database connection string.</param>
        /// <param name="tableName">The name of the table where the row will be added.</param>
        /// <param name="tableDefinition">The definition of the table's columns (must include columns defined as not null).</param>
        /// <param name="primaryKeys">The table's primary key columns.</param>
        /// <param name="addedRow">Returns whether or not a sample row was added, which indicates whether that row should be deleted in the end.</param>
        /// <param name="criteria">The criteria to use when querying for sample data.</param>
        /// <param name="sampleValues">A collection of sample values to add to the row.</param>
        /// <param name="verifyResults">Whether to assert that sample data was found.</param>
        /// <returns>The found/added sample data.</returns>
        public static DataTable FindOrAddSampleData(DbProviderFactory provider, string connectionString, string tableName,
            IEnumerable<SqlParameter> tableDefinition, string[] primaryKeys, out bool addedRow, Dictionary<string, object> criteria = null,
            Dictionary<string, object> sampleValues = null, bool verifyResults = true)
        {
            addedRow = false;
            string sql = string.Format("select top 1 * from {0}", tableName);
            using (DataTable dt = GetSampleData(provider, connectionString, sql, tableName, criteria, false))
            {
                if (dt != null && dt.Rows.Count > 0) return dt;
            }

            using (DataTable dt = AddSampleRow(provider, connectionString, tableName, tableDefinition, primaryKeys, sampleValues))
            {
                addedRow = true;
                if (dt != null && dt.Rows.Count > 0) return dt;
            }

            if (verifyResults) Assert.Fail("Failed to find or add sample data!");

            return null;
        }

        public static void DeleteRow(DbProviderFactory provider, string connectionString, string tableName, Dictionary<string, object> criteria)
        {
            if (provider == null) throw new ArgumentNullException("provider");
            if (string.IsNullOrEmpty(connectionString)) throw new ArgumentNullException("connectionString");
            if (string.IsNullOrEmpty(tableName)) throw new ArgumentNullException("tableName");
            if (criteria == null || criteria.Count <= 0) throw new ArgumentNullException("criteria");

            try
            {
                string sql = string.Format("delete from {0} {1}", tableName, BuildWhereClause(criteria));

                DataUtil.ExecuteNonQuery(provider, connectionString, sql, CommandType.Text);
            }
            catch
            {
                // Consume.
            }
        }
    }
}
