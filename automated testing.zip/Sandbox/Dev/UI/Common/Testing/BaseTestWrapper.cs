﻿namespace Huntington.OnlineBanking.Common.Testing
{
    public class BaseTestWrapper<T>
    {
        protected T _testConfig;

        protected virtual void When(T config)
        {
            _testConfig = config;
        }

        public virtual void Then()
        {

        }

        protected virtual void Should()
        {

        }
    }
}
