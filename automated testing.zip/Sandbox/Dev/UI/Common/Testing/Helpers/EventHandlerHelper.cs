﻿using System;

namespace Huntington.OnlineBanking.Common.Testing.Helpers
{
    /// <summary>
    /// A helper class for handling events and determining whether the event was raised.
    /// </summary>
    /// <typeparam name="TEventArgs">The type of the event data class.</typeparam>
    /// <remarks>
    ///     This class is intended for use within a unit test.
    /// </remarks>
    public class EventHandlerHelper<TEventArgs> where TEventArgs : EventArgs
    {
        #region Properties

        /// <summary>
        /// Gets a value indicating whether the event was handled.
        /// </summary>
        /// <value>
        ///   <c>true</c> if event was handled; otherwise, <c>false</c>.
        /// </value>
        public bool WasEventHandled { get; private set; }

        /// <summary>
        /// Gets a reference to the object that raised the event.
        /// </summary>
        public object ActualSender { get; private set; }

        /// <summary>
        /// Gets the event data supplied by the event.
        /// </summary>
        public TEventArgs ActualEventArgs { get; private set; }

        #endregion

        #region Operations

        /// <summary>
        /// Gets a method that will handle the event denoted by the 
        /// generic <see cref="System.EventHandler&lt;T&gt;"/> delegate.
        /// </summary>
        /// <returns>
        ///     The method that will handle a generic event handler using the 
        ///     <typeparamref name="TEventArgs"/> represented by this instance.
        /// </returns>
        public EventHandler<TEventArgs> GetGenericEventHandler()
        {
            return HandleEvent;
        }

        /// <summary>
        /// Handles an event using a custom event handler matching the signature 
        /// <c>void MethodName(object sender, <typeparamref name="TEventArgs"/> e)</c>.
        /// </summary>
        /// <param name="sender">The object that raised the event.</param>
        /// <param name="eventArgs">The <see cref="TEventArgs"/> instance containing the event data.</param>
        public void HandleEvent(object sender, TEventArgs eventArgs)
        {
            WasEventHandled = true;
            ActualSender = sender;
            ActualEventArgs = eventArgs;
        }

        #endregion

        #region Constructor

        public EventHandlerHelper()
        {
            WasEventHandled = false;
            ActualSender = null;
            ActualEventArgs = null;
        }

        #endregion
    }
}