﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.IO;
using System.Linq;
using Huntington.OnlineBanking.Common.Extensions;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace Huntington.OnlineBanking.Common.Testing
{
    public class BaseUnitTest
    {
        protected void ChangeAppSetting(string key, string value)
        {
            Configuration config = ConfigurationManager.OpenExeConfiguration(ConfigurationUserLevel.None);
            config.ChangeAppSetting(key, value);
            ConfigurationManager.RefreshSection("appSettings");
        }

        /// <summary>
        /// This function is for copying files into the test execution folder, which can be useful since MSTest only copies binaries and skips
        /// other file types.
        /// </summary>
        /// <param name="file"></param>
        /// <param name="sourceFolder"></param>
        protected void CopyFileToTest(string file, string sourceFolder)
        {
            if (string.IsNullOrEmpty(file)) return;
            if (string.IsNullOrEmpty(sourceFolder)) return;
            if (!sourceFolder.EndsWith("\\")) sourceFolder += "\\";
            if (!File.Exists(sourceFolder + file)) return;

            string targetFolder = Environment.CurrentDirectory;
            if (!targetFolder.EndsWith("\\")) targetFolder += "\\";

            try
            {
                File.Copy(sourceFolder + file, targetFolder + file, true);
            }
            catch
            {
            }
        }

        public static void VerifyDataColumns(DataTable dt, IEnumerable<string> columns, bool matchSequence = false)
        {
            Assert.IsNotNull(dt, "Invalid DataTable!");
            if (columns == null || columns.Count() <= 0) return;

            Assert.IsTrue(dt.Columns != null && dt.Columns.Count > 0, "No columns in the DataTable!");

            var colNames = dt.Columns.Cast<DataColumn>().Select(c => c.ColumnName);
            for (int i = 0; i < columns.Count(); i++)
            {
                string column = columns.ElementAt(i);
                if (string.IsNullOrEmpty(column)) continue;

                if (matchSequence)
                {
                    Assert.IsTrue(string.Compare(column, colNames.ElementAt(i), true) == 0,
                        string.Format("Column '{0}' does not match retrieved column '{1}' at position {2}", column, colNames.ElementAt(i), i));
                }
                else
                {

                    Assert.IsTrue(colNames.Any(c => string.Compare(c, column, true) == 0), "Column '" + column + "' is not in the retrieved DataTable!");
                }
            }
        }

        protected static void RunTest(Action when, Action then, Action should)
        {
            RunTest(null, when, then, should);
        }

        protected static void RunTest(Action given, Action when, Action then, Action should)
        {
            if (when == null) throw new ArgumentNullException("when");
            if (then == null) throw new ArgumentNullException("then");
            if (should == null) throw new ArgumentNullException("should");

            // Given
            if (given != null) given();
            // Arrange
            when();
            // Act
            then();
            // Assert
            should();
        }
    }
}
