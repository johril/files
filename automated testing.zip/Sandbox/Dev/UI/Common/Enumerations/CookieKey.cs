﻿using System.Web;

namespace Huntington.OnlineBanking.Common.Enumerations
{
    /// <summary>
    /// A helper class for centralizing the different HTTP cookies and subkeys used in Online Banking.
    /// </summary>
    public static class CookieKey
    {
        /// <summary>
        /// Represents the key of the main Online Banking cookie. 
        /// The Online Banking HTTP cookie encompasses a collection of sub values.
        /// For more information see <see cref="HttpCookie.Values"/>.
        /// </summary>
        public const string OnlineBanking = "OnlineBanking";

        /// <summary>
        /// Represents the cookie key that identifies a unique user session. 
        /// The value identified by this key can be used for operations unique 
        /// to the current user.
        /// </summary>
        public const string SessionKey = "SessionKey";

        public const string HasBillPay = "HasBillPay";
    }
}