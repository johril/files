﻿namespace Huntington.OnlineBanking.Common.Enumerations
{
    /// <summary>
    /// A helper class that exposes common regular expression patterns.
    /// </summary>
    public class RegexPatterns
    {
        /// <summary>
        /// Represents a 10-digit numeric string that when used in the context
        /// of a phone number, it represents a phone number with no separators,
        /// such as dashes, periods, etc.
        /// </summary>
		public const string PhoneNumberWithoutSeparatorsPattern = @"^[0-9]{10,10}$";

        /// <summary>
        /// Represents a 10-digit numeric string that when used in the context
        /// of a phone number, it represents a phone number of many formats,
        /// including all numbers, with parentheses, with dashes, and with spaces.
        /// </summary>
		public const string PhoneNumberPattern = @"^(?:\([2-9]\d{2}\)\ ?|[2-9]\d{2}(?:\-?|\ ?))[2-9]\d{2}[- ]?\d{4}$";

        /// <summary>
        /// Represents a pattern that matches a valid Internet e-mail address.
        /// Accepts e-mails that contain the symbols "-", "+", and "." before the
        /// "@" symbol. Matches from the beginning to end of the string.
        /// </summary>
        public const string EmailAddressPattern = @"^\w+([-+.]\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*$";

        /// <summary>
        /// Represents a transfer ID with explicit capture for the confirmation number (Group name: <c>ConfirmationNumber</c>).
        /// Matches the following string: <c>"2011-11-07-13.50.26.1380890004544"</c>
        /// </summary>
        public const string TransferIdPattern = @"^\d{4,4}-\d\d-\d\d-(\d\d\.){3,3}(?<ConfirmationNumber>\d{13,13})$";

        /// <summary>
        /// Matches a valid social security number.
        /// </summary>
        public const string SocialSecurityNumberPattern = @"\d{3}-\d{2}-\d{4}";
    }
}
