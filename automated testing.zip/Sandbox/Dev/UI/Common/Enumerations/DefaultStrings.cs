﻿namespace Huntington.OnlineBanking.Common.Enumerations
{
    /// <summary>
    /// A helper class that contains common default strings for specific scenarios.
    /// </summary>
    public class DefaultStrings
    {
        /// <summary>
        /// Represents an empty phone number as <c>"000-000-0000"</c>.
        /// </summary>
        public const string EmptyPhoneNumber = "";
    }
}
