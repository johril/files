﻿namespace Huntington.OnlineBanking.Common.Enumerations
{
    /// <summary>
    /// Exposes standard and reusable format strings.
    /// </summary>
    public class FormatStrings
    {
        /// <summary>
        /// Represents the standard currency format string.
        /// </summary>
        public const string Currency = "C";

        /// <summary>
        /// Represents the format string for a date in the format MM/dd/yyyy, 
        /// where month and day parts are padded with a zero if less than 10.
        /// </summary>
        public const string ZeroPaddedShortDateWithFourDigitYear = "MM/dd/yyyy";

        /// <summary>
        /// Represents a phone number where each component is separated by a dash.
        /// The format string contains three placeholders: 
        /// <c>{0}</c> is the area code;
        /// <c>{1}</c> is the prefix;
        /// <c>{2}</c> is the four-digit suffix.
        /// For example, the phone number 614-333-5555 has an area code of 614, a prefix of 333
        /// and a suffix of 5555.
        /// </summary>
        public const string PhoneNumberWithDashSeparators = "{0}-{1}-{2}";
    }
}
