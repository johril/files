﻿using System.Collections;
using System.Collections.Generic;

namespace Huntington.OnlineBanking.Common.Extensions
{
    public static class IEnumerableExtensions
    {
        public static U ConvertToCollectionBase<T, U>(this IEnumerable<T> enumerable)  where U : CollectionBase, IList, new()
        {
            U collectionBase = new U();
            using(IEnumerator<T> enumerator = enumerable.GetEnumerator())
            {
                while(enumerator.MoveNext())
                {
                    collectionBase.Add(enumerator.Current);
                }
            }
            return collectionBase;
        }
    }
}
