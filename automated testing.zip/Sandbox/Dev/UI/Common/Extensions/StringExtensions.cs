﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using Huntington.OnlineBanking.Common.Plugins;
using System.Threading;
using System.Globalization;

namespace Huntington.OnlineBanking.Common.Extensions
{
    /// <summary>
    /// Contains useful additional methods for the <see cref="System.String"/> class.
    /// </summary>
    public static class StringExtensions
    {
        /// <summary>
        /// Removes all leading and trailing white-space characters from the specified string if the string is not a <c>null</c> reference.
        /// </summary>
        /// <param name="s">The string to trim</param>
        /// <returns>
        ///     A <see cref="System.String"/> without leading and trailing white spaces.
        /// </returns>
        /// <remarks>
        ///     Helps avoid writing code that checks for a <c>null</c> string before invoking the <see cref="System.String.Trim()"/> method.
        /// </remarks>
        public static string SafeTrim(this string s)
        {
            return String.IsNullOrWhiteSpace(s) ? String.Empty : s.Trim();
        }

        public static string LeftSubstring(this string s, int length)
        {
            if (length > s.Length)
            {
                return s;
            }

            return String.IsNullOrWhiteSpace(s) ? String.Empty : s.Substring(0, length);
        }

        /// <summary>
        /// Assuming that the string represents a valid <see cref="System.DateTime"/>, returns the equivalent representation
        /// as a <see cref="System.DateTime"/>.
        /// </summary>
        /// <param name="s">The string to convert.</param>
        /// <returns>
        ///     A <see cref="System.DateTime"/> that is equivalent to the string. Returns <see cref="System.DateTime.Now"/>
        ///     if it can't be converted.
        /// </returns>
        public static DateTime ToDateTime(this String s)
        {
            DateTime dt;
            if (DateTime.TryParse(s, out dt))
            {
                return dt;
            }
            else
            {
                CultureInfo currentCulture = Thread.CurrentThread.CurrentCulture;
                
                string[] possibleFormats = new [] 
                {
                    VoyagerConstants.DateTimeFormat,
                    "yyyyMMddhhmmss",
                    "yyyyMMdd"
                };

                if (DateTime.TryParseExact(s, possibleFormats, currentCulture, DateTimeStyles.None, out dt))
                {
                    return dt;
                }
            }

            return DateTime.Now;
        }

        /// <summary>
        /// Determines whether the current string matches any of the supplied strings by performing a case-sensitive comparison.
        /// </summary>
        /// <param name="s">The string being extended.</param>
        /// <param name="values">The set of strings to match against.</param>
        /// <returns>
        ///   <c>true</c> if the string is a <c>null</c> reference or is a value in the specified list of values; otherwise, <c>false</c>.
        /// </returns>
        /// <exception cref="System.ArgumentNullException">
        ///     <paramref name="values"/> is a <c>null</c> reference.
        /// </exception>
        public static bool IsInSet(this string s, params string[] values)
        {
            return s.IsInSet(values, false);
        }

        /// <summary>
        /// Determines whether the current string matches any of the supplied strings.
        /// </summary>
        /// <param name="s">The string being extended.</param>
        /// <param name="ignoreCase">if set to <c>true</c> performs a case-insensitive comparison.</param>
        /// <param name="values">The set of strings to match against.</param>
        /// <returns>
        ///   <c>true</c> if the string is a <c>null</c> reference or is a value in the specified list of values; otherwise, <c>false</c>.
        /// </returns>
        /// <exception cref="System.ArgumentNullException">
        ///     <paramref name="values"/> is a <c>null</c> reference.
        /// </exception>
        public static bool IsInSet(this string s, bool ignoreCase, params string[] values)
        {
            return s.IsInSet(values, ignoreCase);
        }

        /// <summary>
        /// Determines whether the current string matches any of the strings in the specified sequence of strings.
        /// </summary>
        /// <param name="s">The string being extended.</param>
        /// <param name="values">The sequence of strings to match against.</param>
        /// <param name="ignoreCase">if set to <c>true</c> performs a case-insensitive comparison.</param>
        /// <returns>
        ///   <c>true</c> if the string is a <c>null</c> reference or is a value in the specified list of values; otherwise, <c>false</c>.
        /// </returns>
        /// <exception cref="System.ArgumentNullException">
        ///     <paramref name="values"/> is a <c>null</c> reference.
        /// </exception>
        public static bool IsInSet(this string s, IEnumerable<string> values, bool ignoreCase)
        {
            if (null == values)
                throw new ArgumentNullException("values");

            if (null == s)
                return false;

            return ignoreCase
                ? values.Any(x => s.Equals(x, StringComparison.InvariantCultureIgnoreCase))
                : values.Any(x => s == x);
        }

        /// <summary>
        /// Truncates the current string if it exceeds the specified maximum length.
        /// </summary>
        /// <param name="s">The string being truncated.</param>
        /// <param name="maximumLength">The maximum length.</param>
        /// <returns>
        ///     A <see cref="System.String"/> that is <paramref name="maximumLength"/> characters in length or less.
        ///     If the string is a <c>null</c> reference, returns <see cref="System.String.Empty"/>.
        /// </returns>
        public static string Truncate(this string s, int maximumLength)
        {
            if (null == s)
                return String.Empty;

            return (s.Length > maximumLength) ? s.Substring(0, maximumLength) : s;
        }

        /// <summary>
        /// Returns a copy of the string converted to titlecase (Pascal Case).
        /// </summary>
        /// <param name="s"></param>
        /// <returns>
        ///     <see cref="System.String.Empty"/> if the string is a null reference or empty string; otherwise,
        ///     a string converted to titlecase.
        /// </returns>
        public static string ToCurrentCultureTitleCase(this string s)
        {
            if (String.IsNullOrWhiteSpace(s))
                return String.Empty;

            CultureInfo currentCulture = Thread.CurrentThread.CurrentCulture;
            TextInfo textInfo = currentCulture.TextInfo;

            // We convert the string to lowercase first because at time of writing, the implementation of TextInfo.ToTitleCase
            // could not properly handle a string that consisted entirely of uppercase letters
            // See: http://msdn.microsoft.com/en-us/library/cy44dx26.aspx (.NET 4.0)
            return textInfo.ToTitleCase(s.ToLower(currentCulture));
        }

        /// <summary>
        /// Removes the HTML tags specified in the given list and their contents.
        /// </summary>
        /// <param name="html">The HTML being handled.</param>
        /// <param name="tagNames">The list of tag names. Case is ignored.</param>
        /// <returns>
        ///     The supplied string without the specified tags. If the string is
        ///     a <c>null</c> reference or consists of white spaces, 
        ///     <see cref="System.String.Empty"/> is returned.
        /// </returns>
        /// <exception cref="System.ArgumentException">
        ///     <paramref name="tagNames"/> is a <c>null</c> reference or empty array.
        /// </exception>
        public static string RemoveHtmlTagAndBody(this string html, params string[] tagNames)
        {
            if (tagNames == null || tagNames.Length == 0)
                throw new ArgumentException("List of HTML tag names must be supplied", "tagNames");

            if (String.IsNullOrWhiteSpace(html))
                return String.Empty;

            string evilTagPattern = String.Format(@"\<({0})([^\>]*)\>([\s\S]*?\</\1\>)?", String.Join("|", tagNames));
            var evilTagCleanser = new Regex(evilTagPattern, RegexOptions.Compiled | RegexOptions.IgnoreCase);

            return evilTagCleanser.Replace(html, String.Empty);
        }

        /// <summary>
        /// Removes the following tags from the string: <c>SCRIPT</c>, <c>META</c>, <c>LINK</c>, <c>STYLE</c> in
        /// order to mitigate cross-site scripting attacks.
        /// </summary>
        /// <param name="html">The HTML being handled.</param>
        /// <returns>
        ///     The supplied string without the 
        ///     <c>SCRIPT</c>, <c>META</c>, <c>LINK</c>, and <c>STYLE</c> 
        ///     tags. If the string is a <c>null</c> reference or consists 
        ///     of white spaces, <see cref="System.String.Empty"/> is returned.
        /// </returns>
        public static string RemoveEvilTagsAndBody(this string html)
        {
            var evilTags = new[] { "script", "meta", "link", "style" };
            return RemoveHtmlTagAndBody(html, evilTags);
        }

        /// <summary>
        /// Executes the specified action if this string is not null or composed of white spaces.
        /// </summary>
        /// <param name="s">The string being acted upon.</param>
        /// <param name="action">The action to execute if the string <paramref name="s"/> is not a <c>null</c> reference or made up of white spaces.</param>
        /// <returns>
        ///     The specified string or the modified string as specified in <paramref name="action"/>.
        /// </returns>
        public static string ExecuteIfNotNullOrWhiteSpace(this string s, Func<string, string> action)
        {
            if (String.IsNullOrWhiteSpace(s))
                return s;

            return action(s);
        }
    }
}
