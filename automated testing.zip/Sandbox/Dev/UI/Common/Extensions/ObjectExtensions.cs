﻿using System;


namespace Huntington.OnlineBanking.Common.Extensions
{
    public static class ObjectExtensions
    {
        /// <summary>
        /// 
        /// </summary>
        /// <param name="o"></param>
        /// <returns></returns>
        public static string SafeToString(this object o)
        {
            if (o == null)
                return String.Empty;

            return o.ToString();
        }
    }

}
