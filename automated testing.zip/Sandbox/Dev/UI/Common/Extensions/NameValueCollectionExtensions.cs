﻿using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Linq;
using System.Text;
using System.Web;

namespace Huntington.OnlineBanking.Common.Extensions
{
    /// <summary>
    /// Contains operations that operate upon and extend the <see cref="System.Collections.Specialized.NameValueCollection"/>.
    /// </summary>
    public static class NameValueCollectionExtensions
    {
        /// <summary>
        /// Converts the <see cref="System.Collections.Specialized.NameValueCollection"/> to its query string form.
        /// </summary>
        /// <param name="qs">The <c>NameValueCollection</c> to convert.</param>
        /// <returns>
        ///     A URL-encoded HTTP query string.
        /// </returns>
        public static string ToQueryString(this NameValueCollection qs)
        {
            // Source: http://stackoverflow.com/questions/1667150/is-converting-a-namevaluecollection-to-a-querystring-using-a-c-lamdba-efficient

            return string.Join("&", qs.AllKeys.Select(key => String.Format("{0}={1}", HttpUtility.UrlEncode(key), HttpUtility.UrlEncode(qs[key]))).ToArray());
        }
    }
}
