﻿using System.Configuration;

namespace Huntington.OnlineBanking.Common.Extensions
{
    public static class ConfigurationExtensions
    {
        public static void ChangeAppSetting(this Configuration config, string key, string value)
        {
            config.AppSettings.Settings.Remove(key);
            config.AppSettings.Settings.Add(key, value);
            config.Save(ConfigurationSaveMode.Modified);
        }
    }
}
