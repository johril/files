﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Huntington.OnlineBanking.Common.Extensions
{
    public static class NumericExtensions
    {
        public static bool IsNull(this short s)
        {
            return s == short.MinValue;
        }

        public static short GetNullValue(this short s)
        {
            return short.MinValue;
        }

        public static bool IsNull(this int i)
        {
            return i == int.MinValue;
        }

        public static int GetNullValue(this int i)
        {
            return int.MinValue;
        }

        public static bool IsNull(this long l)
        {
            return l == long.MinValue;
        }

        public static long GetNullValue(this long l)
        {
            return long.MinValue;
        }

        public static bool IsNull(this float f)
        {
            return f == float.MinValue;
        }

        public static float GetNullValue(this float f)
        {
            return float.MinValue;
        }

        public static bool IsNull(this double d)
        {
            return d == double.MinValue;
        }

        public static double GetNullValue(this double d)
        {
            return double.MinValue;
        }

        public static bool IsNull(this decimal d)
        {
            return d == decimal.MinValue;
        }

        public static decimal GetNullValue(this decimal d)
        {
            return decimal.MinValue;
        }
    }
}
