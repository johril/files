﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Huntington.OnlineBanking.Common.Extensions
{
    public static class DateTimeExtensions
    {
        public static bool IsNull(this DateTime dt)
        {
            return dt == DateTime.MinValue;
        }

        public static DateTime GetNullValue(this DateTime dt)
        {
            return DateTime.MinValue;
        }
    }
}
