﻿using System;
using System.Linq;
using System.Xml.Linq;

namespace Huntington.OnlineBanking.Common.Extensions
{
    public static class XElementExtensions
    {
        public static string SafeGetValue(this XElement o)
        {
            if (o == null)
                return String.Empty;

            return o.Value.SafeToString();
        }

        public static XElement SafeElement(this XElement o,string elementName)
        {
            XElement xElement;
            if(o.Element(elementName) == null )
            {
                xElement = new XElement(elementName);    
            }
            else
            {
                xElement = o.Element(elementName);
            }

            return xElement;
        }
    }
    
}
