﻿using System.Xml;

namespace Huntington.OnlineBanking.Common.Util
{
    public static class SerializationUtil
    {
        /// <summary>
        /// This method returns "0" if false is passed in for value, or "1" if true is passed in.
        /// It was created because apparently the mainframe cannot deserialize "true" or "false"
        /// as a boolean, so all bools have to be deserialized as 1 or 0.
        /// </summary>
        public static string GetZeroOrOneStringFromBool(bool value)
        {
            return value ? "1" : "0";
        }

        /// <summary>
        /// This method returns 0 if "0" or "false" is passed in, and 1 if "1" or "true" is passed in.
        /// It was created because apparently the mainframe cannot deserialize "true" or "false"
        /// as a boolean, so all bools have to be deserialized as 1 or 0.
        /// </summary>
        public static bool GetBoolFromZeroOrOneString(string value)
        {
            return XmlConvert.ToBoolean(value);
        }
    }
}
