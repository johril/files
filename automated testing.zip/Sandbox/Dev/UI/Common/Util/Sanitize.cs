﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;

namespace Huntington.OnlineBanking.Common.Util
{
    public static class Sanitize
    {

        public static string Cleanup(string userInput)
        {
            Regex rx = new Regex(@"([<>""'%;()&])");
            return rx.Replace(userInput, "");
        }

    }
}
