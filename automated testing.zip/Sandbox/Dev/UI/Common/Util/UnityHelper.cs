﻿using System;
using System.Configuration;
using Huntington.OnlineBanking.Common.ConfigurationManagement;
using Microsoft.Practices.Unity;
using Microsoft.Practices.Unity.Configuration;

namespace Huntington.OnlineBanking.Common.Util
{
	public class UnityHelper
	{
		public static UnityContainer Container
		{
			get { return GetContainer(); }
		}

		private static UnityContainer GetContainer()
		{
			AppDomain appDomain = AppDomain.CurrentDomain;
			UnityContainer container = (UnityContainer)appDomain.GetData("UnityContainer");

			if (container == null)
			{
				Singleton singleton = Singleton.Instance;
				container = (UnityContainer)appDomain.GetData("UnityContainer");
			}

			return container;
		}

		private sealed class Singleton
		{
			private Singleton()
			{
				AppDomain appDomain = AppDomain.CurrentDomain;
				UnityContainer container = new UnityContainer();
                
				UnityConfigurationSection section = (UnityConfigurationSection)ConfigurationManager.GetSection("unity");
				if (section != null)
				{
				    section.Configure(container);
				}

				appDomain.SetData("UnityContainer", container);
			}

			public static Singleton Instance
			{
				get
				{
					return InnerSingleton.instance;
				}
			}

			private class InnerSingleton
			{
				static InnerSingleton() { }

				internal static readonly Singleton instance = new Singleton();
			}
		}
	}
}