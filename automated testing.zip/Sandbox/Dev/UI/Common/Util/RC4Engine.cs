﻿using System;
using System.Globalization;
using System.Text;
using System.Collections;


namespace Huntington.OnlineBanking.Common.Util
{
	/// <summary>
	/// Represents a class that implements the RC4 encryption algorithm.
	/// </summary>
	public class RC4Engine
	{
		#region Costructor

		public RC4Engine()
		{
		}

		#endregion

		#region Public Method

		/// <summary>
		/// Encript InClear Text using RC4 method using EncriptionKey
		/// Put the result into CryptedText 
		/// </summary>
		/// <returns>true if success, else false</returns>
		public bool Encrypt()
		{
		    try
		    {
                var rc4 = new Rc4EngineInternal
                {
                    Password = EncryptionKey, 
                    PlainText = InClearText
                };

		        CryptedText = rc4.EnDeCrypt();

		        return true;
		    }
		    catch (Exception)
		    {
		        return false;
		    }


		}

		/// <summary>
		/// Decript CryptedText into InClearText using EncriptionKey
		/// </summary>
		/// <returns>true if success else false</returns>
		public bool Decrypt()
		{
			//
			// toRet is used to store function retcode
			//
			bool toRet = true;

			try
			{
				this.m_sInClearText = this.m_sCryptedText;
				m_sCryptedText = String.Empty;
                toRet = Encrypt();
				if (toRet)
				{
					m_sInClearText = m_sCryptedText;
				}
			
			}
			catch
			{
				//
				// error occured - set retcode to false.
				// 
				toRet = false;
			}
			
			//
			// return retcode
			//
			return toRet;
		}
		
		#endregion

		#region Prop definitions
		/// <summary>
		/// Get or set Encryption Key
		/// </summary>
		public string EncryptionKey
		{
			get
			{
				return ( this.m_sEncryptionKey );
			}
			set { this.m_sEncryptionKey = value; }
		}

		public string InClearText
		{
			get
			{
				return ( this.m_sInClearText );
			}
			set
			{
				//
				// assign value only if it is a new value
				//
				if (this.m_sInClearText	!= value)
				{	
					this.m_sInClearText	= value;
				}
			}
		}

		public string CryptedText
		{
			get
			{
				return ( this.m_sCryptedText );
			}
			set
			{
				//
				// assign value only if it is a new value
				//
				if ( this.m_sCryptedText != value )
				{	
					this.m_sCryptedText = value;
				}
			}
		}
		#endregion

		#region Private Fields
		
		//
		// Encryption Key  - Unicode 
		//
		private string m_sEncryptionKey		 = String.Empty;

		
		//
		// In Clear Text
		//
		private string m_sInClearText	= String.Empty;
		private string m_sCryptedText	= String.Empty;
		
		#endregion

	}
}
