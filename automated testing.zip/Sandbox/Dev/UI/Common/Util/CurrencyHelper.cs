﻿using System.Globalization;
using System.Web.UI.WebControls;
using Huntington.OnlineBanking.Common.Extensions;

namespace Huntington.OnlineBanking.Common.Util
{
    public static class CurrencyHelper
    {
        /// <summary>
        /// Can be databound to as a way to consistently format dollar strings for inputs whose currency display may vary.
        /// Expected input is a currency-formatted string or decimal-parseable object, output is a currency-formatted string. 
        /// Explicit decimal conversion is performed to validate expected input.
        /// </summary>
        /// <param name="item"></param>
        /// <param name="isDebit">If set to true, the return value will be negative.</param>
        /// <returns></returns>
        public static string FormatDollars(object item, bool isDebit = false)
        {
            decimal? dollars = ParseCurrency(item);
            if (dollars.HasValue)
            {
                decimal dollarValue = dollars.Value;
                if (isDebit && dollarValue > 0)
                    dollarValue *= -1;
                return dollarValue.ToString("c");
            }
            return string.Empty;
        }

        /// <summary>
        /// Style the label based on the dollar value.
        /// </summary>
        /// <param name="control"></param>
        /// <param name="formattedDollars"></param>
        public static void FormatDollars(Label control, string formattedDollars)
        {
            if (control == null || string.IsNullOrEmpty(formattedDollars)) return;

            control.Text = formattedDollars;
            if (formattedDollars.Contains("-")) control.Style["color"] = "#D60000";
        }

        /// <summary>
        /// Safely attempts to parse an object that represents a dollar value into a decimal. 
        /// </summary>
        /// <param name="item"></param>
        /// <returns></returns>
        public static decimal? ParseCurrency(object item)
        {
            return ParseCurrency(item.SafeToString());
        }

        /// <summary>
        /// Takes a currency-formatted string (i.e. for US, has a dollar sign in it) and parses it into a decimal. 
        /// </summary>
        /// <param name="formattedString">A string formatted using the current culture's currency format.</param>
        /// <returns></returns>
        public static decimal? ParseCurrency(string formattedString)
        {
            int multiplier = 1;
            if(formattedString.Contains("("))
            {
                formattedString = formattedString.Substring(1, formattedString.Length - 2);
                multiplier = -1;
            }

            decimal value;
            return decimal.TryParse(formattedString, NumberStyles.Currency, CultureInfo.CurrentCulture.NumberFormat,
                                    out value)
                       ? (decimal?)(value * multiplier)
                       : null;
        }

        /// <summary>
        /// Takes a decimal-convertible value type or currency-formatted string and returns a styled currency representation. 
        /// </summary>
        /// <param name="eval">An object to format into currency representation.</param>
        /// <param name="colorDebits">Whether or not to color negative values</param>
        /// <returns>A string consisting of the currency string contained within a styled HTML span.</returns>
        public static string GetStyledCurrency(object eval, bool colorDebits = true)
        {
            string dollars = FormatDollars(eval);
            if(colorDebits)
                return string.Format("<span{0}>{1}</span>",
                                     dollars.Contains("-") ? " style='color:#D60000;'" : string.Empty, dollars);
            return string.Format("<span>{0}</span>", dollars);
        }
    }
}