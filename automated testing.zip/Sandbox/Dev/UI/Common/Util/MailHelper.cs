﻿using System.Net.Mail;

namespace Huntington.OnlineBanking.Common.Util
{
    public class MailHelper
    {
        public static void SendEmail(string emailFrom, string emailTo, string subject, string body, string host)
        {
            var mailClient = new SmtpClient
            {
                Host = host
            };

            mailClient.Send(new MailMessage(emailFrom, emailTo, subject, body));
        }
    }
}