﻿using System;
using System.Text.RegularExpressions;
using Huntington.OnlineBanking.Common.Enumerations;

namespace Huntington.OnlineBanking.Common.Formatters
{
    public class PhoneNumberFormat : IFormatProvider, ICustomFormatter
    {
        #region IFormatProvider Implementation

        public object GetFormat(Type formatType)
        {
            return (formatType == typeof(ICustomFormatter)) ? this : null;
        }

        #endregion

        #region ICustomFormatter Implementation

        public string Format(string format, object arg, IFormatProvider formatProvider)
        {
            string valueToFormat = Convert.ToString(arg, formatProvider);

            return FormatAsPhoneNumber(valueToFormat);
        }

        #endregion

        #region Helper Methods

        private string FormatAsPhoneNumber(string phoneNumber)
        {
            if (String.IsNullOrWhiteSpace(phoneNumber) || IsPhoneNumberAllZeroes(phoneNumber))
            {
                return DefaultStrings.EmptyPhoneNumber;
            }

            if (Regex.IsMatch(phoneNumber, RegexPatterns.PhoneNumberWithoutSeparatorsPattern))
            {
                return String.Format(FormatStrings.PhoneNumberWithDashSeparators, 
                                     ExtractAreaCode(phoneNumber), 
                                     ExtractPrefix(phoneNumber), 
                                     ExtractSuffix(phoneNumber));
            }

            return phoneNumber;
        }

        private string ExtractSuffix(string phoneNumber)
        {
            return phoneNumber.Substring(6);
        }

        private string ExtractPrefix(string phoneNumber)
        {
            return phoneNumber.Substring(3, 3);
        }

        private string ExtractAreaCode(string phoneNumber)
        {
            return phoneNumber.Substring(0, 3);
        }

        private bool IsPhoneNumberAllZeroes(string phoneNumber)
        {
            return phoneNumber.Equals("0000000000");
        }

        #endregion
    }
}