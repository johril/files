using System.Diagnostics;
using System;
using System.Configuration;
using System.Data;
using System.Data.Common;
using System.Collections;
using System.Data.SqlClient;
using System.IO;
using Huntington.OnlineBanking.Common;
using Huntington.OnlineBanking.Common.Data;
using Huntington.OnlineBanking.Common.ConfigurationManagement;

namespace Huntington.OnlineBanking.Common.RetailBroadcastMessages
{
	public class DB
	{
		
		
		private string _ConnectString = string.Empty;
        private DbProviderFactory _providerFactory;
        private ConnectionStringSettings _connStringSettings;

		public DB(string connectString)
		{
            _connStringSettings = AssemblyConfigurationManager.Default.ConnectionStrings[connectString];
            _ConnectString = _connStringSettings.ConnectionString;
            _providerFactory = DbProviderFactories.GetFactory(_connStringSettings.ProviderName);
		}

		public string InsertMessageRequest(MessageRequest NewRequest, string logFile)
		{
			int NewMsgId = -1;
			string sErrText;
			FileStream fs;
			StreamWriter swErr;
            string sqlText = "HNB_InsertBroadcastMessage";
		
			try
			{
                using (DbConnection conn = _providerFactory.CreateConnection())
                {
                    conn.ConnectionString = _connStringSettings.ConnectionString;
                    Action<IDbCommand> parameterSetupAction = cmd =>
                    {
                        cmd.AddInputParameterWithValue("@Sender", NewRequest.Sender);
                        cmd.AddInputParameterWithValue("@MessageBody", NewRequest.MessageBody);
                        cmd.AddInputParameterWithValue("@Target", NewRequest.Target);
                        cmd.AddInputParameterWithValue("@MessageSubject", NewRequest.MessageSubject);
                        cmd.AddInputParameterWithValue("@Processed", NewRequest.Processed);
                        cmd.AddInputParameterWithValue("@UserId", NewRequest.UserId);
                        cmd.AddInputParameterWithValue("@SendEmail", NewRequest.SendEmail);
                        cmd.AddInputParameterWithValue("@OverRideEmail", NewRequest.OverRideEmail);
                        cmd.AddOutputParameter("@NewMsgId", DbType.Int32, 4, null);

                        //BRT.05.31.2011 - set the timeout if one has been configured.  This is because some of these inserts are taking over 4 minutes!
                        var timeout = AssemblyConfigurationManager.Default.AppSettings["InsertMessageRequestTimeoutOverride"];
                        if (!string.IsNullOrWhiteSpace(timeout))
                        {
                            cmd.CommandTimeout = DBConvert.ToInt32(timeout);
                        }
                    };

                    Action<IDbCommand> checkResultsAction = cmd =>
                    {
                        NewMsgId = cmd.GetParameterValue<int>("@NewMsgId");
                    };

                    DataUtil.ExecuteNonQuery(conn, sqlText, parameterSetupAction, checkResultsAction);
                }
				return string.Concat("New request ", NewMsgId.ToString(), " submitted.");
				
			}
			catch (Exception dbex)
			{
				sErrText = string.Concat(DateTime.Now, " DB.InsertMessageRequest ", dbex.Message, " Error creating new message id.\r\n");
				fs = new FileStream(logFile, FileMode.Append);
				swErr = new StreamWriter(fs);
				swErr.Write(sErrText);
				swErr.Close();
				return sErrText;
			}
		}
		
		public int InsertUsers(User User, string logFile)
		{
			int Result = -1;
			string sErrText;
			FileStream fs;
			StreamWriter swErr;
			string sqlText = "HNB_InsertBroadcastUser";

			try
			{
                using (DbConnection conn = _providerFactory.CreateConnection())
                {
                    conn.ConnectionString = _connStringSettings.ConnectionString;
                    Action<IDbCommand> parameterSetupAction = cmd =>
                    {
                        cmd.AddInputParameterWithValue("@UserId", User.UserId);
                        cmd.AddInputParameterWithValue("@MsgId", User.MsgId);
                        cmd.AddOutputParameter("@Result", DbType.Int32, 4, null);

                        //BRT.05.31.2011 - set the timeout if one has been configured.  This is because some of these inserts are taking over 4 minutes!
                        var timeout = AssemblyConfigurationManager.Default.AppSettings["InsertUsersTimeoutOverride"];
                        if (!string.IsNullOrWhiteSpace(timeout))
                        {
                            cmd.CommandTimeout = DBConvert.ToInt32(timeout);
                        }
                    };

                    Action<IDbCommand> checkResultsAction = cmd =>
                    {
                        Result = cmd.GetParameterValue<int>("@Result");
                    };

                    DataUtil.ExecuteNonQuery(conn, sqlText, parameterSetupAction, checkResultsAction);
                }
				
				return Result;
				
			}
			catch (Exception dbex)
			{
				sErrText = string.Concat(DateTime.Now, " DB.InsertUsers ", dbex.Message, " Error inserting user ", User.UserId, "\r\n");
				fs = new FileStream(logFile, FileMode.Append);
				swErr = new StreamWriter(fs);
				swErr.Write(sErrText);
				swErr.Close();
				return -1;
			}
		}
		
		public int InsertRetailUsers(int MsgId, string logFile)
		{
			int Result = -1;
			string sErrText;
			FileStream fs;
			StreamWriter swErr;
			string sqlText = "HNB_InsertBroadcastRetailUser";
			
			try
			{
                using (DbConnection conn = _providerFactory.CreateConnection())
                {
                    conn.ConnectionString = _connStringSettings.ConnectionString;
                    Action<IDbCommand> parameterSetupAction = cmd =>
                    {
                        cmd.AddInputParameterWithValue("@MsgId", MsgId);
                        cmd.AddOutputParameter("@Result", DbType.Int32, 4, null);

                        //BRT.05.31.2011 - set the timeout if one has been configured.  This is because some of these inserts are taking over 4 minutes!
                        var timeout = AssemblyConfigurationManager.Default.AppSettings["InsertRetailUsersTimeoutOverride"];
                        if (!string.IsNullOrWhiteSpace(timeout))
                        {
                            cmd.CommandTimeout = DBConvert.ToInt32(timeout);
                        }
                    };

                    Action<IDbCommand> checkResultsAction = cmd =>
                    {
                        Result = cmd.GetParameterValue<int>("@Result");
                    };

                    DataUtil.ExecuteNonQuery(conn, sqlText, parameterSetupAction, checkResultsAction);
                }

				if (Result != 0)
				{
					sErrText = string.Concat(DateTime.Now, " DB.InsertRetailUsers ", Result, " Error inserting users MSGID:", MsgId, "\r\n");
					fs = new FileStream(logFile, FileMode.Append);
					swErr = new StreamWriter(fs);
					swErr.Write(sErrText);
					swErr.Close();
					return -1;
				}

				return Result;
				
			}
			catch (Exception dbex)
			{
				sErrText = string.Concat(DateTime.Now, " DB.InsertRetailUsers ", dbex.Message, " Error inserting users MSGID:", MsgId, "\r\n");
				fs = new FileStream(logFile, FileMode.Append);
				swErr = new StreamWriter(fs);
				swErr.Write(sErrText);
				swErr.Close();
				return -1;
			}
		}
		
		public MessageRequest GetNewMessage(string logFile)
		{
			string sErrText;
			FileStream fs;
			StreamWriter swErr;
            MessageRequest oMsg = null;
			try
			{
                using (DbConnection conn = _providerFactory.CreateConnection())
                {
                    conn.ConnectionString = _connStringSettings.ConnectionString;
                    string sqlText = "HNB_GetBroadcastMessage";
                    Action<IDataReader> processResultsAction = reader =>
                    {
                        SqlDataReader sqlReader = (SqlDataReader)reader;
                        if (sqlReader.HasRows)
                        {
                            while (sqlReader.Read())
                            {
                                oMsg = new MessageRequest();
                                oMsg.MessageBody = System.Convert.ToString(sqlReader["MessageBody"]);
                                oMsg.MessageSubject = System.Convert.ToString(sqlReader["MessageSubject"]);
                                oMsg.MsgId = System.Convert.ToInt32(sqlReader["MsgId"]);
                                oMsg.OverRideEmail = System.Convert.ToString(sqlReader["OverRideEmail"]);
                                oMsg.Processed = System.Convert.ToString(sqlReader["Processed"]);
                                oMsg.SendEmail = System.Convert.ToString(sqlReader["SendEmail"]);
                                oMsg.Sender = System.Convert.ToString(sqlReader["Sender"]);
                                oMsg.Target = System.Convert.ToString(sqlReader["Target"]);
                                oMsg.UserId = System.Convert.ToString(sqlReader["UserId"]);
                            }
                        }
                    };

                    DataUtil.ExecuteReader(conn, sqlText, processResultsAction);
                }
				
				return oMsg;
				
			}
			catch (Exception ex)
			{
				sErrText = string.Concat(DateTime.Now, " DB.GetNewMessages() ", ex.Message, " Error getting broadcast messages \r\n");
				fs = new FileStream(logFile, FileMode.Append);
				swErr = new StreamWriter(fs);
				swErr.Write(sErrText);
				swErr.Close();
                return null;
			}
			finally
			{
			}
		}
		
		public MessageRequest GetMessage(string MsgId, string logFile)
		{
			string sErrText;
			FileStream fs;
			StreamWriter swErr;
            MessageRequest oMsg = null;
			try
			{
                using (DbConnection conn = _providerFactory.CreateConnection())
                {
                    conn.ConnectionString = _connStringSettings.ConnectionString;
                    string sqlText = "HNB_GetSingleBroadcastMessage";

                    Action<IDbCommand> parameterSetupAction = cmd =>
                    {
                        cmd.AddInputParameterWithValue("@MsgId", MsgId);
                    };

                    Action<IDataReader> processResultsAction = reader =>
                    {
                        SqlDataReader sqlReader = (SqlDataReader)reader;
                        if (sqlReader.HasRows)
                        {
                            while (sqlReader.Read())
                            {
                                oMsg = new MessageRequest();
                                oMsg.MessageBody = System.Convert.ToString(sqlReader["MessageBody"]);
                                oMsg.MessageSubject = System.Convert.ToString(sqlReader["MessageSubject"]);
                                oMsg.MsgId = System.Convert.ToInt32(sqlReader["MsgId"]);
                                oMsg.OverRideEmail = System.Convert.ToString(sqlReader["OverRideEmail"]);
                                oMsg.Processed = System.Convert.ToString(sqlReader["Processed"]);
                                oMsg.SendEmail = System.Convert.ToString(sqlReader["SendEmail"]);
                                oMsg.Sender = System.Convert.ToString(sqlReader["Sender"]);
                                oMsg.Target = System.Convert.ToString(sqlReader["Target"]);
                                oMsg.UserId = System.Convert.ToString(sqlReader["UserId"]);
                            }
                        }
                    };

                    DataUtil.ExecuteReader(conn, sqlText, processResultsAction, parameterSetupAction);
                }

				return oMsg;
				
			}
			catch (Exception ex)
			{
				sErrText = string.Concat(DateTime.Now, " DB.GetMessages() ", ex.Message, " Error getting message \r\n");
				fs = new FileStream(logFile, FileMode.Append);
				swErr = new StreamWriter(fs);
				swErr.Write(sErrText);
				swErr.Close();
                return null;
			}
			finally
			{
			}
		}
		
		public void UpdateBroadcastMessage(int MsgId, string Processed, string logFile)
		{
			string sqlText;
			string sErrText;
			FileStream fs;
			StreamWriter swErr;
			try
			{
				sqlText = string.Format("Update HNBBroadcastMessage Set Processed = '{0}' WHERE MsgId = '{1}'", Processed, MsgId);
                DataUtil.ExecuteNonQuery(_providerFactory, _ConnectString, sqlText, CommandType.Text);
			}
			catch (Exception ex)
			{
				sErrText = string.Concat(DateTime.Now, " DB.UpdateBroadcastMessage ", ex.Message, " Error marking message complete. \r\n");
				fs = new FileStream(logFile, FileMode.Append);
				swErr = new StreamWriter(fs);
				swErr.Write(sErrText);
				swErr.Close();
			}
		}
		
		public int InsertPCUsers(MessageRequest NewRequest, string All, string logFile)
		{
			// PC Banking users will need the message into CCMessageToUser so that it can be
			// picked up by the Corillian OFX engine.  OFX can't pick up from the custom HNB
			// broadcast message table.
			
			int Result = -1;
			string sErrText;
			FileStream fs;
			StreamWriter swErr;
			string sqlText = "HNB_InsertBroadcastPCUser";

			try
			{
                using (DbConnection conn = _providerFactory.CreateConnection())
                {
                    conn.ConnectionString = _connStringSettings.ConnectionString;
                    Action<IDbCommand> parameterSetupAction = cmd =>
                    {
                        cmd.AddInputParameterWithValue("@Sender", NewRequest.Sender);
                        cmd.AddInputParameterWithValue("@Subject", NewRequest.MessageSubject);
                        cmd.AddInputParameterWithValue("@Message", NewRequest.MessageBody);
                        cmd.AddInputParameterWithValue("@All", All);
                        cmd.AddOutputParameter("@Result", DbType.Int32, 4, null);

                        //BRT.05.31.2011 - set the timeout if one has been configured.  This is because some of these inserts are taking over 4 minutes!
                        var timeout = AssemblyConfigurationManager.Default.AppSettings["InsertPCUsersTimeoutOverride"];
                        if (!string.IsNullOrWhiteSpace(timeout))
                        {
                            cmd.CommandTimeout = DBConvert.ToInt32(timeout);
                        }
                    };

                    Action<IDbCommand> checkResultsAction = cmd =>
                    {
                        Result = cmd.GetParameterValue<int>("@Result");
                    };

                    DataUtil.ExecuteNonQuery(conn, sqlText, parameterSetupAction, checkResultsAction);
                };

				if (Result != 0)
				{
					sErrText = string.Concat(DateTime.Now, " DB.InsertPCUsers ", Result, " Error inserting PC users \r\n");
					fs = new FileStream(logFile, FileMode.Append);
					swErr = new StreamWriter(fs);
					swErr.Write(sErrText);
					swErr.Close();
					return -1;
				}
				
				return Result;
				
			}
			catch (Exception dbex)
			{
				sErrText = string.Concat(DateTime.Now, " DB.InsertPCUsers ", dbex.Message, " Error inserting PC users \r\n");
				fs = new FileStream(logFile, FileMode.Append);
				swErr = new StreamWriter(fs);
				swErr.Write(sErrText);
				swErr.Close();
				return -1;
			}
		}
		
		public DataSet BroadcastHistory(string logFile)
		{
			int Result;
			string sErrText;
			FileStream fs;
			StreamWriter swErr;

			DataSet ds = null;
            string sqlText = "HNB_GetBroadcastHistory";
			try
			{
                ds = DataUtil.ExecuteDataSet(_providerFactory, _ConnectString, sqlText);

			}
			catch (System.Data.SqlClient.SqlException ex)
			{
				sErrText = string.Concat(DateTime.Now, " DB.BroadcastHistory ", ex.Message, " Error getting history");
				fs = new FileStream(logFile, FileMode.Append);
				swErr = new StreamWriter(fs);
				swErr.Write(sErrText);
				swErr.Close();
			}
			
			return ds;
		}
	}
	
}
