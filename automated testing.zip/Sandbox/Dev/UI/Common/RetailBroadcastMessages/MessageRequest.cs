using System.Diagnostics;
using Microsoft.VisualBasic;
using System;
using System.Data;
using System.Collections;

namespace Huntington.OnlineBanking.Common.RetailBroadcastMessages
{
	public class MessageRequest
	{
		
		private int _MsgId = 0;
		private string _Sender = string.Empty;
		private string _Target = string.Empty;
		private string _MessageBody = string.Empty;
		private string _MessageSubject = string.Empty;
		private string _Processed = string.Empty;
		private string _UserId = string.Empty;
		private string _SendEmail = string.Empty;
		private string _OverRideEmail = string.Empty;
		
		public int MsgId
		{
			get
			{
				return _MsgId;
			}
			set
			{
				_MsgId = value;
			}
		}
		
		public string Sender
		{
			get
			{
				return _Sender;
			}
			set
			{
				_Sender = value;
			}
		}
		public string Target
		{
			get
			{
				return _Target;
			}
			set
			{
				_Target = value;
			}
		}
		public string MessageBody
		{
			get
			{
				return _MessageBody;
			}
			set
			{
				_MessageBody = value;
			}
		}
		public string MessageSubject
		{
			get
			{
				return _MessageSubject;
			}
			set
			{
				_MessageSubject = value;
			}
		}
		public string Processed
		{
			get
			{
				return _Processed;
			}
			set
			{
				_Processed = value;
			}
		}
		public string UserId
		{
			get
			{
				return _UserId;
			}
			set
			{
				_UserId = value;
			}
		}
		public string SendEmail
		{
			get
			{
				return _SendEmail;
			}
			set
			{
				_SendEmail = value;
			}
		}
		public string OverRideEmail
		{
			get
			{
				return _OverRideEmail;
			}
			set
			{
				_OverRideEmail = value;
			}
		}
	}
}
