using System.Diagnostics;
using Microsoft.VisualBasic;
using System;
using System.Data;
using System.Collections;

namespace Huntington.OnlineBanking.Common.RetailBroadcastMessages
{
	public class User
	{
		
		private int _MsgId = 0;
		public int MsgId
		{
			get
			{
				return _MsgId;
			}
			set
			{
				_MsgId = value;
			}
		}
		
		private string _Status = string.Empty;
		public string Status
		{
			get
			{
				return _Status;
			}
			set
			{
				_Status = value;
			}
		}
		
		private string _UserId = string.Empty;
		public string UserId
		{
			get
			{
				return _UserId;
			}
			set
			{
				_UserId = value;
			}
		}
	}
}
