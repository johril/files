﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Huntington.OnlineBanking.Common.Plugins
{
    public class PluginException : System.Exception
    {
        public PluginException()
        {            
        }

        public PluginException(string message) : base(message)
        {            
        }

        public PluginException(string message, Exception exception) : base(message,exception)
        {            
        }

    }
}
