﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Timers;
using Huntington.OnlineBanking.Common.ConfigurationManagement;
using Huntington.OnlineBanking.Common.Data;
using log4net;
using log4net.Core;

namespace Huntington.OnlineBanking.Common.Plugins
{
    public static class PluginMemoryManager
    {
        private static readonly ILog _log = LogManager.GetLogger(typeof(PluginMemoryManager));
        private static ILog Log
        {
            get
            {
                if (_log != null && (!_log.Logger.Repository.Configured || _log.Logger.Repository.GetAppenders().Length <= 0))
                {
                    ConfigureLog(AssemblyConfigurationManager.Default.ConfigFilePath);
                }
                return _log;
            }
        }
        private static Level _logLevel=Level.Info;
        private static double _logDelta;

        private static bool ConfigureLog(string filename)
        {
            if (!Path.IsPathRooted(filename))
            {
                FileInfo assemblyFile = new FileInfo(Assembly.GetAssembly(typeof (PluginMemoryManager)).Location);
                filename = Path.Combine(assemblyFile.DirectoryName, filename);
            }
            FileInfo configFile = new FileInfo(filename);
            if (!configFile.Exists) return false;

            log4net.Config.XmlConfigurator.Configure(configFile);
            return true;
        }

        private static Timer _timer;
        private static readonly object syncLock = new object();

        public static void Initialize()
        {
            lock (syncLock)
            {
                if (_timer != null) return;

                try
                {
                    _timer = new Timer();
                    string setting = AssemblyConfigurationManager.Default.AppSettings["HostServerGCInterval"];
                    if (!string.IsNullOrEmpty(setting))
                    {
                        double interval = DBConvert.ToDouble(setting, 10*60*1000);
                        if (interval > 0)
                        {
                            setting = AssemblyConfigurationManager.Default.AppSettings["HostServerGCLogLevel"];
                            if (!string.IsNullOrEmpty(setting))
                            {
                                switch (setting.ToLower())
                                {
                                    case "debug":
                                        _logLevel = Level.Debug;
                                        break;
                                    case "info":
                                        _logLevel = Level.Info;
                                        break;
                                    case "warn":
                                        _logLevel = Level.Warn;
                                        break;
                                    case "error":
                                        _logLevel = Level.Error;
                                        break;
                                    case "fatal":
                                        _logLevel = Level.Fatal;
                                        break;
                                }
                            }

                            setting = AssemblyConfigurationManager.Default.AppSettings["HostServerGCLogMinDelta"];
                            if (!string.IsNullOrEmpty(setting))
                            {
                                double.TryParse(setting, out _logDelta);
                            }

                            _timer.Elapsed += OnTimedEvent;
                            _timer.Interval = interval;
                            _timer.Enabled = true;
                            Log.InfoFormat("The plugin memory manager is initialized to force garbage collection in {0} minutes.  It will log at the {1} level{2}.", 
                                interval/1000/60, _logLevel.DisplayName, (_logDelta > 0 ? ", but only if the amount of memory freed is >= " + _logDelta : ""));
                        }
                    }
                }
                catch
                {
                }
            }
        }

        private static void OnTimedEvent(object source, ElapsedEventArgs e)
        {
            try
            {
                long memBefore = Environment.WorkingSet;
                DateTime timeBefore = DateTime.Now;

                GC.Collect(GC.MaxGeneration);
                GC.WaitForPendingFinalizers();
                GC.Collect(GC.MaxGeneration);

                long memAfter = Environment.WorkingSet;

                // Only log the details if we collected more than the minimum amount of memory configured.
                if (_logDelta > 0 && memBefore - memAfter < _logDelta) return;

                DateTime timeAfter = DateTime.Now;
                const float toMb = 1024*1024;
                string msg =
                    string.Format(
                        "Forced TP (process ID={0}) garbage collection at {1}.  Memory before = {2:F2}MB, after = {3:F2}MB, delta = {4:F2}MB.  Collection duration = {5:F2}s",
                        Process.GetCurrentProcess().Id, timeBefore, memBefore/toMb, memAfter/toMb, (memBefore - memAfter)/toMb, (timeAfter - timeBefore).TotalSeconds);
                Log.Logger.Log(typeof(PluginMemoryManager), _logLevel, msg, null);
            }
            catch{}
        }
    }
}
