﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Huntington.OnlineBanking.Common.Plugins
{
    /// <summary>
    /// Contains common constants for use by Voyager plugins or Voyager calls.
    /// </summary>
    public static class VoyagerConstants
    {
        /// <summary>
        /// Represents the date time format as expected by Voyager calls, namely the request string.
        /// </summary>
        public const string DateTimeFormat = "yyyyMMdd";

        /// <summary>
        /// Represents the '\u0001' character delimiter for Voyager transaction strings.
        /// </summary>
        public const char TransactionStringDelimiter = '\u0001';

        /// <summary>
        /// Represents the numeric format for currencies as expected by Voyager calls, namely the request string.
        /// </summary>
        public const string CurrencyFormat = "F2";
    }
}
