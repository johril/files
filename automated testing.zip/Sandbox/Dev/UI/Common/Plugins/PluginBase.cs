﻿using System;
using System.IO;
using System.Reflection;
using Corillian.Platform.Interop.TrxObject;
using Huntington.OnlineBanking.Common.ConfigurationManagement;
using log4net;

namespace Huntington.OnlineBanking.Common.Plugins
{
    public class PluginBase
    {
        #region Fields

        private static readonly ILog _log = LogManager.GetLogger(typeof(PluginBase));

        #endregion

        #region Properties

        protected static ILog Log
        {
            get
            {
                if (_log != null && (!_log.Logger.Repository.Configured || _log.Logger.Repository.GetAppenders().Length <= 0))
                {
                    ConfigureLog(AssemblyConfigurationManager.Default.ConfigFilePath);
                }
                return _log;
            }
        }

        public PluginBase()
        {
            PluginMemoryManager.Initialize();
        }

        private static bool ConfigureLog(string filename)
        {
            if (!Path.IsPathRooted(filename))
            {
                FileInfo assemblyFile = new FileInfo(Assembly.GetAssembly(typeof(PluginMemoryManager)).Location);
                filename = Path.Combine(assemblyFile.DirectoryName, filename);
            }
            FileInfo configFile = new FileInfo(filename);
            if (!configFile.Exists) return false;

            log4net.Config.XmlConfigurator.Configure(configFile);
            return true;
        }

        protected AssemblyConfiguration Config
        {
            get
            {
                return AssemblyConfigurationManager.Default;
            }
        }

        #endregion

        #region Implementation of Corillian.Platform.Interop.TrxObject.ITrxObject (Not included in this project, but to be included in derived class)
        public virtual void Execute(IScriptLangExtension pLangExt)
        {
        }

        public virtual void Initialize()
        {
        }

        public virtual void UnIntialize()
        {
        }

        #endregion

        #region Helper Methods for Logging

        /// <summary>
        /// Logs that the plugin is being initialized.
        /// </summary>
        /// <param name="currentPlugin">The currently executing plugin.</param>
        protected static void LogPluginInitializing(PluginBase currentPlugin)
        {
            Log.InfoFormat("[{0}] is initializing.", currentPlugin.GetType());
        }

        /// <summary>
        /// Logs that the plugin has been initialized.
        /// </summary>
        /// <param name="currentPlugin">The currently executing plugin.</param>
        protected static void LogPluginInitialized(PluginBase currentPlugin)
        {
            Log.InfoFormat("[{0}] has initialized.", currentPlugin.GetType());
        }

        /// <summary>
        /// Logs that the plugin is being uninitialized.
        /// </summary>
        /// <param name="currentPlugin">The currently executing plugin.</param>
        protected static void LogPluginUninitializing(PluginBase currentPlugin)
        {
            Log.InfoFormat("[{0}] is being uninitialized.", currentPlugin.GetType());
        }

        /// <summary>
        /// Logs that the plugin has completed its uninitialization code.
        /// </summary>
        /// <param name="currentPlugin">The currently executing plugin.</param>
        protected static void LogPluginUninitialized(PluginBase currentPlugin)
        {
            Log.InfoFormat("[{0}] has been uninitialized.", currentPlugin.GetType());
        }

        /// <summary>
        /// Logs that the plugin is being executed by the host server. Use at the very  beginning of the method's logic.
        /// </summary>
        /// <param name="currentMethod">The currently executing method.</param>
        protected static void LogPluginExecuting(MethodBase currentMethod)
        {
            Log.InfoFormat("[{0}] executing method [{1}].", currentMethod.DeclaringType, currentMethod);
        }

        /// <summary>
        /// Logs that the plugin has finished execution. Use after all transaction code has completed.
        /// </summary>
        /// <param name="currentMethod">The currently executing method.</param>
        protected static void LogPluginExecuted(MethodBase currentMethod)
        {
            Log.InfoFormat("[{0}] has finished executing method [{1}].", currentMethod.DeclaringType, currentMethod);
        }

        /// <summary>
        /// Logs the specified error given the originating method information and a custom error handler that logs the same exception to a different source.
        /// </summary>
        /// <param name="callingMethod">
        ///     The calling method.
        /// </param>
        /// <param name="originalException">
        ///     The exception that occurred.
        /// </param>
        /// <param name="customErrorHandler">
        ///     The custom error handler that logs <paramref name="originalException"/> to a different logging provider. 
        ///     If that logging provider throws an exception that new error is logged using this instance's separate logging provider but not propagated.
        /// </param>
        protected static void LogError(MethodBase callingMethod, Exception originalException, Action<Exception> customErrorHandler)
        {
            MethodBase thisMethod = MethodBase.GetCurrentMethod();  // For logging purposes

            Log.Error(String.Format("{0} - Method [{1}] - An error occurred. Error details ", callingMethod.DeclaringType, callingMethod), originalException);

            try
            {
                if (null != customErrorHandler)
                {
                    Log.DebugFormat("{0} - Method [{1}] - Attempting to log above exception [{2}] (Error Message [{3}]) to custom error handler", thisMethod.DeclaringType, thisMethod, originalException.GetType(), originalException.Message);
                    customErrorHandler(originalException);
                    Log.DebugFormat("{0} - Method [{1}] - Error logged in custom error handler", thisMethod.DeclaringType, thisMethod);
                }
            }
            catch (Exception ex)
            {
                // An error occurred while calling custom error handler. Log it.
                Log.Error(String.Format("{0} - Method [{1}] - An error occurred while attempting to log above error using customErrorHandler. Error details", thisMethod.DeclaringType, thisMethod), ex);
            }
        }

        #endregion
    }
}
