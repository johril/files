﻿using System.Reflection;
using System;

namespace Huntington.OnlineBanking.Common.ConfigurationManagement
{
    /// <summary>
    /// Represents the registration details of an assembly. Also contains a reference to the actual configuration settings.
    /// </summary>
    internal class InternalAssemblyRegistration
    {
        #region Fields

        private object _thisLock = new object();

        private AssemblyConfiguration _configuration;

        #endregion

        #region Properties

        /// <summary>
        /// Gets the assembly to register
        /// </summary>
        public Assembly Assembly { get; private set; }

        /// <summary>
        /// Gets the directory path where the <see cref="Assembly"/> is located. Can be a <c>null</c> reference,
        /// which means that the assembly's configuration file will be retrieved from the same location
        /// as the assembly.
        /// </summary>
        public string BasePath { get; private set; }

        /// <summary>
        /// Gets the configuration file settings for the <see cref="Assembly"/> registered in
        /// this instance.
        /// </summary>
        public AssemblyConfiguration Configuration
        {
            get
            {
                // Lazy-load the configuration. We use double-checked locking, so leave as is.
                // More information: http://msdn.microsoft.com/en-us/library/ff650316.aspx
                if (null == _configuration)
                {
                    lock (_thisLock)
                    {
                        if (null == _configuration)
                        {
                            _configuration = new AssemblyConfiguration(this.Assembly, this.BasePath);
                        }
                    }
                }

                return _configuration;
            }
        }

        #endregion

        /// <summary>
        /// Initializes a new instance of the <see cref="InternalAssemblyRegistration"/> class.
        /// </summary>
        /// <param name="assembly">The assembly to use.</param>
        /// <param name="basePath">The base directory path of the assembly's configuration file. Can be <c>null</c>.</param>
        public InternalAssemblyRegistration(Assembly assembly, string basePath)
        {
            this.Assembly = assembly;
            this.BasePath = basePath;
        }
    }
}
