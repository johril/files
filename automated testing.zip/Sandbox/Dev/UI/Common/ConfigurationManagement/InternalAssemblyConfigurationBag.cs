﻿using System;
using System.Collections.Generic;
using System.Reflection;

namespace Huntington.OnlineBanking.Common.ConfigurationManagement
{
    /// <summary>
    /// Represents the dictionary of assembly configurations used by <see cref="AssemblyConfigurationManager"/>.
    /// </summary>
    internal sealed class InternalAssemblyConfigurationBag
    {
        #region About This Implementation of the Singleton Pattern

        // The implementation of this class uses the fifth version of the Singleton pattern
        // as defined here: http://csharpindepth.com/Articles/General/Singleton.aspx

        #endregion

        #region Nested Class for Full Lazy Loading

        /// <summary>
        /// Allows full lazy instantiation.
        /// </summary>
        private class Nested
        {
            /// <summary>
            /// Explicit static constructor to tell C# compiler not to mark type as beforefieldinit. Do not remove.
            /// </summary>
            static Nested()
            {

            }

            /// <summary>
            /// Actual instance of <c>InternalAssemblyConfigurationBag</c>.
            /// </summary>
            internal static readonly InternalAssemblyConfigurationBag ActualInstance = new InternalAssemblyConfigurationBag();
        }

        #endregion

        #region Fields

        private IDictionary<Assembly, InternalAssemblyRegistration> _registeredAssemblies;

        #endregion

        #region Properties

        /// <summary>
        /// Gets the <see cref="AssemblyConfiguration"/> associated with the specified registered assembly.
        /// </summary>
        public AssemblyConfiguration this[Assembly registeredAssembly]
        {
            get
            {
                return _registeredAssemblies[registeredAssembly].Configuration;
            }
        }

        /// <summary>
        /// Gets the current instance of the <see cref="InternalAssemblyConfigurationBag"/> class.
        /// </summary>
        public static InternalAssemblyConfigurationBag Instance
        {
            get { return Nested.ActualInstance; }
        }

        #endregion

        #region Operations

        /// <summary>
        /// Adds the specified assembly to the bag.
        /// </summary>
        /// <param name="registration">The assembly registration information.</param>
        /// <exception cref="System.ArgumentNullException">
        ///     <paramref name="registration"/> is a <c>null</c> reference.
        /// </exception>
        public void Register(InternalAssemblyRegistration registration)
        {
            if (null == registration)
                throw new ArgumentNullException("registration");

            _registeredAssemblies.Add(registration.Assembly, registration);
        }

        /// <summary>
        /// Determines whether the specified assembly is registered in this instance.
        /// </summary>
        /// <param name="assembly">The assembly to check.</param>
        /// <returns>
        ///   <c>true</c> if the specified assembly has been registered; otherwise, <c>false</c>.
        /// </returns>
        public bool Contains(Assembly assembly)
        {
            return _registeredAssemblies.ContainsKey(assembly);
        }

        public void Clear()
        {
            _registeredAssemblies.Clear();
        }

        #endregion

        #region Constructor

        /// <summary>
        /// Prevents a default instance of the <see cref="InternalAssemblyConfigurationBag"/> class 
        /// from being created by an outside client class.
        /// </summary>
        private InternalAssemblyConfigurationBag()
        {
            _registeredAssemblies = new Dictionary<Assembly, InternalAssemblyRegistration>();
        }

        #endregion
    }
}
