﻿using System;
using System.Reflection;
using System.IO;
using System.ServiceModel;

namespace Huntington.OnlineBanking.Common.ConfigurationManagement
{
    /// <summary>
    /// Allows registration and retrieval of assembly configuration files.
    /// </summary>
    public sealed class AssemblyConfigurationManager
    {
        #region Fields

        private static object _syncRoot = new object();

        private static AssemblyConfiguration _defaultConfig = null;

        #endregion

        #region Properties

        /// <summary>
        /// Gets or sets whether or not to force usage of the App.config file that exists in the 
        /// root application. Set this property to <c>true</c> to force the <see ref="Default" /> property
        /// to return the settings defined in the root application's App.config file, rather than
        /// potentially returning the configuration defined in the <c>AssemblyConfigurationManager</c>'s
        /// assembly configuration file, namely Huntington.OnlineBanking.Common.dll.config.
        /// Default value is <c>false</c> so that the behavior of the <see ref="Default" /> property 
        /// remains unchanged for existing code.
        /// </summary>
        public static bool UseRootAppConfigFile { get; set; }

        /// <summary>
        /// Gets the configuration information for the <c>AssemblyConfigurationManager</c>'s assembly.
        /// The location of the calling assembly is used to locate the configuration file.
        /// </summary>
        public static AssemblyConfiguration Default
        {
            get
            {
                if (null == _defaultConfig)
                {
                    lock (_syncRoot)
                    {
                        if (null == _defaultConfig)
                        {
                            // determine if web context, and make sure caller has not specified to use the parent app config file.
                            if (!UseRootAppConfigFile && System.Web.HttpContext.Current == null && OperationContext.Current == null)
                            {
                                // no web context: calling from library or exe
                                Assembly myAssembly = Assembly.GetExecutingAssembly();

                                // We get a reference to the calling assembly to avoid situations where
                                // the AssemblyConfigurationManager's own assembly is initialized in a different location.
                                Assembly callingAssembly = Assembly.GetCallingAssembly();
                                string basePath = Path.GetDirectoryName(callingAssembly.Location);

                                _defaultConfig = new AssemblyConfiguration(myAssembly, basePath);
                            }
                            else
                            {
                                // web context: pull from web.config/ConfigurationManager
                                _defaultConfig = new AssemblyConfiguration(
                                    System.Configuration.ConfigurationManager.AppSettings,
                                    System.Configuration.ConfigurationManager.ConnectionStrings);
                            }
                        }
                    }
                }
                
                return _defaultConfig;
            }
        }

        #endregion

        #region Operations

        /// <summary>
        /// Registers the configuration file for the assembly in which the specified type is located. 
        /// It is assumed that the configuration file is located in the same path as the assembly.
        /// </summary>
        /// <param name="type">The type whose assembly will be registered.</param>
        public static void RegisterAssemblyOf(Type type)
        {
            RegisterAssemblyOf(type, null);
        }

        /// <summary>
        /// Registers the assembly in which the specified type is located and uses the given
        /// base path where the assembly's configuration file can be found.
        /// </summary>
        /// <param name="type">
        ///     The type whose assembly will be registered.
        /// </param>
        /// <param name="basePath">
        ///     The directory path where the specified <paramref name="type"/>'s assembly configuration file
        ///     is located. Can be set to <c>null</c>, in which case the assembly's current location will be
        ///     used.
        /// </param>
        public static void RegisterAssemblyOf(Type type, string basePath)
        {
            if (null == type)
                throw new ArgumentNullException("type");

            lock (_syncRoot)
            {
                if (!InternalAssemblyConfigurationBag.Instance.Contains(type.Assembly))
                    InternalAssemblyConfigurationBag.Instance.Register(new InternalAssemblyRegistration(type.Assembly, basePath));
            }
        }

        /// <summary>
        /// Registers the assembly in which the specified type is located and uses the given
        /// base path where the assembly's configuration file can be found.
        /// </summary>
        /// <typeparam name="T">
        ///     The type whose assembly will be registered.
        /// </typeparam>
        /// <param name="basePath">
        ///     The directory path where the specified type <typeparamref name="T"/>'s assembly configuration file
        ///     is located. Can be set to <c>null</c>, in which case the assembly's current location will be
        ///     used.
        /// </param>
        public static void RegisterAssemblyOf<T>(string basePath)
        {
            RegisterAssemblyOf(typeof (T), basePath);
        }

        /// <summary>
        /// Registers the configuration file for the assembly in which the specified type is located. 
        /// It is assumed that the configuration file is located in the same path as the assembly.
        /// </summary>
        /// <typeparam name="T">The type whose assembly will be registered.</typeparam>
        public static void RegisterAssemblyOf<T>()
        {
            RegisterAssemblyOf(typeof (T), null);
        }

        /// <summary>
        /// Registers the assembly in which the given instance is declared, using the existing path of the
        /// assembly as the location of the assembly's configuration file.
        /// </summary>
        /// <typeparam name="T">Any type.</typeparam>
        /// <param name="instanceOfT">The object instance whose assembly will be registered.</param>
        public static void RegisterAssemblyOf<T>(T instanceOfT)
        {
            RegisterAssemblyOf(typeof (T), null);
        }

        /// <summary>
        /// Registers the assembly in which the given instance is declared, using the supplied directory path
        /// as the base location of the assembly's configuration file.
        /// </summary>
        /// <typeparam name="T">Any type.</typeparam>
        /// <param name="instanceOfT">The object instance whose assembly will be registered.</param>
        /// <param name="basePath">
        ///     The directory path where the specified type <typeparamref name="T"/>'s assembly configuration file
        ///     is located. Can be set to <c>null</c>, in which case the assembly's current location will be
        ///     used.
        /// </param>
        public static void RegisterAssemblyOf<T>(T instanceOfT, string basePath)
        {
            RegisterAssemblyOf(typeof (T), basePath);
        }

        /// <summary>
        /// Gets the <see cref="AssemblyConfiguration"/> settings associated with the given type.
        /// </summary>
        /// <typeparam name="T">
        ///     The type whose configuration settings will be returned.
        /// </typeparam>
        /// <returns>
        ///     An instance of the <see cref="AssemblyConfiguration"/> class, containing
        ///     application and connection string settings defined in the assembly's configuration 
        ///     file.
        /// </returns>
        /// <exception cref="AssemblyNotRegisteredException">
        ///     The given type <typeparamref name="T"/>'s assembly hasn't been registered.
        /// </exception>
        public static AssemblyConfiguration GetConfigFor<T>()
        {
            return GetConfigFor(typeof (T));
        }

        /// <summary>
        /// Gets the <see cref="AssemblyConfiguration"/> settings associated with the given type.
        /// </summary>
        /// <param name="type">
        ///     The type whose configuration settings will be returned.
        /// </param>
        /// <returns>
        ///     An instance of the <see cref="AssemblyConfiguration"/> class, containing
        ///     application and connection string settings defined in the assembly's configuration
        ///     file.
        /// </returns>
        /// <exception cref="AssemblyNotRegisteredException">
        ///     The given <paramref name="type"/>'s assembly hasn't been registered.
        /// </exception>
        public static AssemblyConfiguration GetConfigFor(Type type)
        {
            if (!InternalAssemblyConfigurationBag.Instance.Contains(type.Assembly))
                throw new AssemblyNotRegisteredException(type);

            return InternalAssemblyConfigurationBag.Instance[type.Assembly];
        }

        /// <summary>
        /// Gets the <see cref="AssemblyConfiguration"/> settings associated with the specified object's assembly.
        /// </summary>
        /// <typeparam name="T">
        ///     Any type.
        /// </typeparam>
        /// <param name="instanceOfT">
        ///     The instance of <typeparamref name="T"/> whose assembly's configuration will be returned.
        /// </param>
        /// <returns>
        ///     An instance of the <see cref="AssemblyConfiguration"/> class, containing
        ///     application and connection string settings defined in the assembly's configuration file.
        /// </returns>
        /// <exception cref="AssemblyNotRegisteredException">
        ///     The given object's assembly hasn't been registered.
        /// </exception>
        public static AssemblyConfiguration GetConfigFor<T>(T instanceOfT)
        {
            return GetConfigFor(instanceOfT.GetType());
        }

        /// <summary>
        /// Removes all registered assembly configurations from the configuration bag.
        /// </summary>
        /// <remarks>
        ///     Be careful when invoking this method as it will affect other clients of
        ///     this class. Invoke only when ending an application.
        /// </remarks>
        public static void UnregisterAll()
        {
            InternalAssemblyConfigurationBag.Instance.Clear();
        }

        #endregion
    }
}
