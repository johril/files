﻿using System;

namespace Huntington.OnlineBanking.Common.ConfigurationManagement
{
    /// <summary>
    /// Represents the error thrown when an assembly was not registered in the <see cref="AssemblyConfigurationManager"/>.
    /// </summary>
    public class AssemblyNotRegisteredException : Exception
    {
        #region Fields

        private readonly string _message;

        #endregion

        #region Overrides

        /// <summary>
        /// Gets a message that describes the current exception.
        /// </summary>
        /// <returns>The error message that explains the reason for the exception.</returns>
        public override string Message
        {
            get
            {
                return _message;
            }
        }

        #endregion

        #region Constructor

        /// <summary>
        /// Initializes a new instance of the <see cref="AssemblyNotRegisteredException"/> class.
        /// </summary>
        /// <param name="type">The type whose assembly was not registered.</param>
        public AssemblyNotRegisteredException(Type type)
        {
            if (null == type)
                throw new ArgumentNullException("type");

            _message = String.Format("Could not find registered assembly \"{0}\" for type {1}", type.Assembly, type);
        }

        #endregion
    }
}
