﻿using System;
using System.Collections.Specialized;
using System.Configuration;
using System.IO;
using System.Reflection;

namespace Huntington.OnlineBanking.Common.ConfigurationManagement
{
    /// <summary>
    /// Represents the configuration settings for an assembly's configuration file registered via the 
    /// <see cref="AssemblyConfigurationManager"/>.
    /// </summary>
    public class AssemblyConfiguration
    {
        #region Fields

        private readonly NameValueCollection _appSettings;
        private readonly ConnectionStringSettingsCollection _connectionStrings;

        #endregion

        #region Properties

         /// <summary>
        /// Gets the <see cref="System.Configuration.AppSettingsSection"/> data for the 
        /// current application's default configuration.
        /// </summary>
        public NameValueCollection AppSettings
        {
            get 
            {
                return _appSettings; 
            }
        }

        /// <summary>
        /// Gets the <see cref="System.Configuration.ConnectionStringsSection"/> data for the 
        /// current application's default configuration.
        /// </summary>
        public ConnectionStringSettingsCollection ConnectionStrings
        {
            get
            {
                return _connectionStrings;
            }
        }

        public string ConfigFilePath { get; private set; }

        private System.Configuration.Configuration CurrentConfiguration { get; set; }

        #endregion

        #region Helper Methods

        //private void EnsureCurrentConfiguration()
        //{
        //    if (null == CurrentConfiguration)
        //    {
        //        CurrentConfiguration = GetConfiguration(_configFilePath);
        //    }
        //}

        private void LoadAppSettings(NameValueCollection target)
        {
            if (CurrentConfiguration.AppSettings.Settings.Count > 0)
            {
                KeyValueConfigurationCollection settings = CurrentConfiguration.AppSettings.Settings;
                Array.ForEach(settings.AllKeys, key => target.Add(key, settings[key].Value));
            }
        }

        private ConnectionStringSettingsCollection GetConnectionStrings()
        {
            return CurrentConfiguration.ConnectionStrings.ConnectionStrings;
        }

        private System.Configuration.Configuration GetConfiguration(string configFilePath)
        {
            ExeConfigurationFileMap map = new ExeConfigurationFileMap()
            {
                ExeConfigFilename = configFilePath
            };

            return ConfigurationManager.OpenMappedExeConfiguration(map, ConfigurationUserLevel.None);
        }

        private static string BuildAssemblyConfigurationFilePath(Assembly assembly, string basePath)
        {
            string configFile = String.Format("{0}.config", assembly.Location);

            if (String.IsNullOrEmpty(basePath))
            {
                return configFile;
            }

            return Path.Combine(basePath, Path.GetFileName(configFile));
        }

        #endregion

        #region Constructor

        /// <summary>
        /// Initializes a new instance of the <see cref="AssemblyConfiguration"/> class. This class
        /// cannot be instantiated outside of this assembly.
        /// </summary>
        /// <param name="assembly">
        ///     The assembly whose configuration file will be associated with this instance.
        /// </param>
        /// <param name="basePath">
        ///     The directory path where the <paramref name="assembly"/>'s configuration
        ///     file can be found. Can be set to <c>null</c>, in which case the assembly's
        ///     location will be used.
        /// </param>
        internal AssemblyConfiguration(Assembly assembly, string basePath)
        {
            if (null == assembly)
                throw new ArgumentNullException("assembly");

            string configFilePath = BuildAssemblyConfigurationFilePath(assembly, basePath);

            CurrentConfiguration = GetConfiguration(configFilePath);
            ConfigFilePath = configFilePath;
            
            this._appSettings = new NameValueCollection();
            LoadAppSettings(this._appSettings);
            this._connectionStrings = GetConnectionStrings();
        }

        /// <summary>
        /// When pulling configuration for a web site, the calling assembly isn't the web site, it's the 
        /// a loaded assembly. Thus, it can't be loaded. So, we're loading it directly from ConfigurationManager. 
        /// </summary>
        /// <param name="appSettings">Collection of application settings</param>
        /// <param name="connectionStrings">Collection of connection strings</param>
        internal AssemblyConfiguration(NameValueCollection appSettings, 
            ConnectionStringSettingsCollection connectionStrings)
        {
            this._appSettings = appSettings;           
            this._connectionStrings = connectionStrings;
        }
        

        #endregion
    }
}
