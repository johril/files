﻿using System;
using System.Reflection;
using System.Text;
using System.Web;


namespace Huntington.OnlineBanking.Common.HttpModule
{
    class ClientIPTransformer : IHttpModule
    {
        private HttpApplication CurrentApplication = null;

        public ClientIPTransformer()
        {

        }

        public void Init(HttpApplication application)
        {

            application.BeginRequest += new EventHandler(application_BeginRequest);

            CurrentApplication = application;
        }

        void application_BeginRequest(object sender, EventArgs e)
        {
            if (CurrentApplication != null)
            {
                string strUserIP = CurrentApplication.Request.ServerVariables["REMOTE_ADDR"];

                if (!string.IsNullOrEmpty(CurrentApplication.Request.ServerVariables["HTTP_X_FORWARDED_FOR"]))
                {
                    //To get the IP address of the machine and not the proxy
                    string IPAddresses = CurrentApplication.Request.ServerVariables["HTTP_X_FORWARDED_FOR"].ToString();
                    string[] ipArray = IPAddresses.Split(new char[] { ',' });
                    strUserIP = ipArray[0];
                    this.SetServerVariable("REMOTE_ADDR", strUserIP);
                }

                //Update the Trace File with the Right IP, the Remote_Addr will still show the Proxy IP in the Trace Server Variables
                //section because the tracing module gets executed before this module is executed.  This gives some traceability of the
                //actual client IP address.  Could also use log4net, however that comes wtih overhead.
                if (CurrentApplication.Context.Trace.IsEnabled)
                {
                    CurrentApplication.Context.Trace.Write("Current Client IP Address: " + strUserIP);
                }
            }

        }

        public void Dispose()
        {

        }

        #region SetServerVariable
        protected void SetServerVariable(string key, string newValue)
        {
            if (CurrentApplication != null)
            {
                HttpRequest Request = CurrentApplication.Request;

                Type tRequest = typeof(HttpRequest);
                Type tVar;
                Type tServerVars = Request.ServerVariables.GetType();

                // Do this call to make sure everything is filled in
                string temp = Request.ServerVariables[key];

                if (temp != null)
                {
                    // Create new HttpServerVarsCollection
                    Object[] input = new Object[1];
                    input[0] = Request;

                    // Do a BaseGet to get the HttpServerVarsCollectionEntry type
                    Object[] inputBaseGet = new Object[1];
                    inputBaseGet[0] = 1;
                    tVar = tServerVars.InvokeMember("BaseGet", BindingFlags.NonPublic |
                    BindingFlags.Public | BindingFlags.Instance | BindingFlags.InvokeMethod,
                    null, Request.ServerVariables, inputBaseGet).GetType();

                    // Create new HttpServerVarsCollectionEntry object for our "override"
                    Object[] inputCreate = new Object[2];
                    inputCreate[0] = key;
                    inputCreate[1] = newValue;
                    Object theVar = tVar.InvokeMember(null, BindingFlags.NonPublic |
                    BindingFlags.Public | BindingFlags.Instance |
                    BindingFlags.CreateInstance, null, null, inputCreate);

                    // Set _readOnly to false so that we can modify the collection
                    Object[] inputReadOnly = new Object[1];
                    inputReadOnly[0] = false;
                    tServerVars.InvokeMember("IsReadOnly", BindingFlags.NonPublic |
                    BindingFlags.Public | BindingFlags.Instance | BindingFlags.SetProperty,
                    null, Request.ServerVariables, inputReadOnly);

                    // Remove old object
                    Object[] inputBaseRemove = new Object[1];
                    inputBaseRemove[0] = key;
                    tServerVars.InvokeMember("BaseRemove", BindingFlags.NonPublic |
                    BindingFlags.Public | BindingFlags.Instance | BindingFlags.InvokeMethod,
                    null, Request.ServerVariables, inputBaseRemove);

                    // Add new one
                    Object[] inputAdd = new Object[2];
                    inputAdd[0] = key;
                    inputAdd[1] = theVar;
                    tServerVars.InvokeMember("BaseAdd", BindingFlags.NonPublic |
                    BindingFlags.Public | BindingFlags.Instance | BindingFlags.InvokeMethod,
                    null, Request.ServerVariables, inputAdd);
                }
            }
        }
        #endregion
    }
}
