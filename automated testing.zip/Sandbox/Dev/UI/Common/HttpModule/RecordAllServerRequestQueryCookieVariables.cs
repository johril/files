﻿using System;
using System.Reflection;
using System.Text;
using System.Web;

namespace Huntington.OnlineBanking.Common.HttpModule
{
    class RecordAllServerRequestQueryCookieVariables : IHttpModule
    {
        #region Implementation of IHttpModule

        public static log4net.ILog Log = log4net.LogManager.GetLogger(MethodBase.GetCurrentMethod().DeclaringType);
        /// <summary>
        /// Initializes a module and prepares it to handle requests.
        /// </summary>
        /// <param name="context">An <see cref="T:System.Web.HttpApplication"/> that provides access to the methods, properties, and events common to all application objects within an ASP.NET application </param>
        public void Init(HttpApplication context)
        {
            context.Error += new EventHandler(LogAllServerRequestAndQueryStringVariables);
        }

        /// <summary>
        /// Disposes of the resources (other than memory) used by the module that implements <see cref="T:System.Web.IHttpModule"/>.
        /// </summary>
        public void Dispose()
        {
        }

        /// <summary>
        /// Will record at the time of exception all Request.ServerVariables, QueryString variables, and Cookies for instrumentation purposes.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        public void LogAllServerRequestAndQueryStringVariables(object sender, EventArgs e)
        {
            StringBuilder variablesCollectionToLog = new StringBuilder();

            #region Log the current URL for the request.

            variablesCollectionToLog.AppendFormat("{0}----------------------------------------------{0}",Environment.NewLine);
            variablesCollectionToLog.AppendFormat("The Current URL for the logged error is : {0}.{1}",
                                                  HttpContext.Current.Request.RawUrl,Environment.NewLine);
            #endregion

            #region Record Log of Online Banking Cookies

            variablesCollectionToLog.AppendFormat("Cookie Collection of Request.Cookies[OnlineBanking]: {0}",Environment.NewLine);
            if (HttpContext.Current.Request.Cookies["OnlineBanking"] != null && HttpContext.Current.Request.Cookies["OnlineBanking"].Values.Count > 0)
            {
                var onlineBankingCookieValues = HttpContext.Current.Request.Cookies["OnlineBanking"].Values;
                foreach (string httpCookie in onlineBankingCookieValues)
                {
                    if (httpCookie != null)
                        variablesCollectionToLog.AppendFormat("Cookies[OnlineBanking][{0}] = {1}{2}", httpCookie, onlineBankingCookieValues[httpCookie],Environment.NewLine);
                }
            }
            else
                variablesCollectionToLog.AppendFormat("Cookie Collection of Request.Cookies[OnlineBanking] is null and has no values.{0}", Environment.NewLine);

            #endregion

            #region Record Log of current Server Variables

            variablesCollectionToLog.AppendFormat("Variables Collection of HttpContext.Current.Request.ServerVariables{0}",Environment.NewLine);
            if (HttpContext.Current.Request.ServerVariables.Count > 0)
            {
                foreach (string serverVariableKey in HttpContext.Current.Request.ServerVariables.AllKeys)
                {
                    string nameValueValue = String.IsNullOrEmpty(HttpContext.Current.Request.ServerVariables[serverVariableKey]) ? "Value is null or Empty." : HttpContext.Current.Request.ServerVariables[serverVariableKey];
                    variablesCollectionToLog.AppendFormat("HttpContext.Current.Request.ServerVariables[{0}] = {1}{2}",
                                                              serverVariableKey,
                                                              nameValueValue,
                                                              Environment.NewLine
                                                         );
                }
            }
            else
                variablesCollectionToLog.AppendLine("Server Variables of HttpContext.Current.Request.ServerVariables and has returned with no values.");

            #endregion

            #region Record Log of Query String Variables

            if (HttpContext.Current.Request.QueryString.Count > 0)
            {
                foreach (string queryStringKey in HttpContext.Current.Request.QueryString.AllKeys)
                {
                    string queryStringValue = String.IsNullOrEmpty(HttpContext.Current.Request.QueryString[queryStringKey])
                                             ? "Value is null or Empty."
                                             : HttpContext.Current.Request.QueryString[queryStringKey];

                    variablesCollectionToLog.AppendFormat("HttpContext.Current.Request.QueryString[{0}] = {1}{2}",
                                                          queryStringKey, queryStringValue,Environment.NewLine);

                }
            }

            #endregion

            Log.Error(variablesCollectionToLog.ToString());
        }

        #endregion
    }
}
