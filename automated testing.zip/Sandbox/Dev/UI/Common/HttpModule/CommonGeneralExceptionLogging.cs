﻿using System;
using System.Reflection;
using System.Text;
using System.Web;

namespace Huntington.OnlineBanking.Common.HttpModule
{
    class CommonGeneralExceptionLogging : IHttpModule
    {
        public static log4net.ILog Log = log4net.LogManager.GetLogger(MethodBase.GetCurrentMethod().DeclaringType);

        #region Implementation of IHttpModule

        /// <summary>
        /// Initializes a module and prepares it to handle requests.
        /// </summary>
        /// <param name="context">An <see cref="T:System.Web.HttpApplication"/> that provides access to the methods, properties, and events common to all application objects within an ASP.NET application </param>
        public void Init(HttpApplication context)
        {
            context.Error += new EventHandler(LogGeneralExceptions);
        }

        /// <summary>
        /// Disposes of the resources (other than memory) used by the module that implements <see cref="T:System.Web.IHttpModule"/>.
        /// </summary>
        public void Dispose()
        {            
        }

        public void LogGeneralExceptions(object sender, EventArgs e)
        {
            // Log any unhandled exceptions
            var httpCurrent = HttpContext.Current;
            Exception baseException = httpCurrent.Server.GetLastError().GetBaseException();
            
            string err = String.Format("{3}Exception Message{3}Error Caught in Application_Error event\nError in: {0}\nError Message:{1}\nStack Trace:{2}{3}{3}",
            httpCurrent.Request.Url,
            baseException.Message,
            baseException.StackTrace,
            Environment.NewLine);

            Log.Error(err, baseException);    
            
            
        }

        #endregion
    }
}
