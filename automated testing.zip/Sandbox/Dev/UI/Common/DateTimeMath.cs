﻿using System;

namespace Huntington.OnlineBanking.Common
{
    /// <summary>
    /// Exposes operations that perform mathematical calculations on dates and times.
    /// </summary>
    public class DateTimeMath
    {
        /// <summary>
        /// Returns the largest of two given dates.
        /// </summary>
        /// <param name="a">The first <c>System.DateTime</c> to compare.</param>
        /// <param name="b">The second <c>System.DateTime</c> to compare against date/time <paramref name="a"/>.</param>
        /// <returns>
        ///     The largest of the two dates, that is, the one that occurs later.
        /// </returns>
        public static DateTime Max(DateTime a, DateTime b)
        {
            return (a.CompareTo(b) > 0) ? a : b;
        }

        /// <summary>
        /// Returns the smallest of two given dates.
        /// </summary>
        /// <param name="a">The first <c>System.DateTime</c> to compare.</param>
        /// <param name="b">The second <c>System.DateTime</c> to compare against date/time <paramref name="a"/>.</param>
        /// <returns>
        ///     The smallest of the two dates, that is, the one that occurs earlier.
        /// </returns>
        public static DateTime Min(DateTime a, DateTime b)
        {
            return (a.CompareTo(b) < 0) ? a : b;
        }
    }
}
