﻿using System;
using System.Web.UI.WebControls;
using Huntington.OnlineBanking.Common.Extensions;

namespace Huntington.OnlineBanking.Common.Web
{
    public static class WebControlExtensions
    {
        /// <summary>
        /// Assuming that the <see cref="System.Web.UI.WebControls.TextBox"/> contains a valid <see cref="System.DateTime"/>, returns the equivalent representation
        /// as a <see cref="System.DateTime"/>.
        /// </summary>
        /// <param name="textBox">The TextBox control whose <c>Text</c> property's value will be converted to a <see cref="System.DateTime"/>.</param>
        /// <returns>
        ///     A <see cref="System.DateTime"/> that is equivalent to the <paramref name="textbox"/>'s <c>Text</c> property. 
        ///     Returns <see cref="System.DateTime.Now"/> if it can't be converted.
        /// </returns>
        public static DateTime ConvertToDateTime(this TextBox textBox)
        {
            return textBox.Text.ToDateTime();
        }
    }
}
