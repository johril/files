﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Huntington.OnlineBanking.Common.Web.UI.WebControls
{
    public class DynamicValidatorFactory
    {
        /// <summary>
        /// The client JavaScript function that validates text to be sent in a message to Voyager.
        /// </summary>
        public const string VOYAGER_MESSAGE_CLIENT_VALIDATION_FUNCTION = "validateVoyagerMessageText";
        /// <summary>
        /// The error message format string for text that is invalid for sending via Voyager messages.  
        /// Requires string.Format(VOYAGER_MESSAGE_CLIENT_ERROR_MESSAGE, "friendly name").
        /// </summary>
        public const string VOYAGER_MESSAGE_CLIENT_ERROR_MESSAGE = "The {0} cannot contain the characters <, >, or &";

        public void CreateValidators(string controlName, Control parent)
        {
            if (string.IsNullOrEmpty(controlName)) return;
            if (parent == null) return;

            CreateRegularExpressionValidators(controlName, parent);
            CreateCustomValidators(controlName, parent);
        }

        #region RegularExpressionValidators
        private class RegularExpressionValidatorRegistration
        {
            public string ControlName { get; set; }
            public string ValidationExpression { get; set; }
            public string ErrorMessage { get; set; }
            public string Text { get; set; }
        }

        private List<RegularExpressionValidatorRegistration> _regularExpressionValidators;

        public void AddRegularExpressionValidator(string controlName, string validationExpression, string errorMessage, string text)
        {
            if (string.IsNullOrEmpty(validationExpression)) throw new ArgumentNullException("validationExpression");
            if (string.IsNullOrEmpty(errorMessage)) throw new ArgumentNullException("errorMessage");

            if (_regularExpressionValidators == null) _regularExpressionValidators = new List<RegularExpressionValidatorRegistration>();

            RegularExpressionValidatorRegistration registration = new RegularExpressionValidatorRegistration
            {
                ControlName = controlName,
                ValidationExpression = validationExpression,
                ErrorMessage = errorMessage,
                Text = text,
            };
            _regularExpressionValidators.Add(registration);
        }

        public void CreateRegularExpressionValidators(string controlName, Control parent)
        {
            if (_regularExpressionValidators == null || _regularExpressionValidators.Count <= 0) return;
            if (parent == null) return;

            try
            {
                _regularExpressionValidators.Where(r => r.ControlName == controlName).ToList()
                    .ForEach(r => CreateRegularExpressionValidator(controlName, r, parent));
            }
            catch
            {
                // Consume.
            }
        }

        private static void CreateRegularExpressionValidator(string controlName, RegularExpressionValidatorRegistration registration, Control parent)
        {
            if (string.IsNullOrEmpty(controlName)) return;
            if (parent == null) return;

            RegularExpressionValidator validator = new RegularExpressionValidator
            {
                ControlToValidate = controlName,
                ValidationExpression = registration.ValidationExpression,
                ErrorMessage = registration.ErrorMessage,
                Display = ValidatorDisplay.None,
                Text = "*",
                ID = string.Format("regval{0}_{1}", controlName, parent.Controls.Count),
            };
            parent.Controls.Add(validator);
        }
        #endregion

        #region CustomValidators
        private class CustomValidatorRegistration
        {
            public string ControlName { get; set; }
            public string ClientValidationFunction { get; set; }
            public string ErrorMessage { get; set; }
            public string Text { get; set; }
        }

        private List<CustomValidatorRegistration> _customValidators;

        public void AddCustomValidator(string controlName, string clientValidationFunction, string errorMessage, string text)
        {
            if (string.IsNullOrEmpty(clientValidationFunction)) throw new ArgumentNullException("clientValidationFunction");
            if (string.IsNullOrEmpty(errorMessage)) throw new ArgumentNullException("errorMessage");

            if (_customValidators == null) _customValidators = new List<CustomValidatorRegistration>();

            CustomValidatorRegistration registration = new CustomValidatorRegistration
            {
                ControlName = controlName,
                ClientValidationFunction = clientValidationFunction,
                ErrorMessage = errorMessage,
                Text = text,
            };
            _customValidators.Add(registration);
        }

        public void CreateCustomValidators(string controlName, Control parent)
        {
            if (_customValidators == null || _customValidators.Count <= 0) return;
            if (parent == null) return;

            try
            {
                _customValidators.Where(r => r.ControlName == controlName).ToList()
                    .ForEach(r => CreateRegularExpressionValidator(controlName, r, parent));
            }
            catch
            {
                // Consume.
            }
        }

        private static void CreateRegularExpressionValidator(string controlName, CustomValidatorRegistration registration, Control parent)
        {
            if (string.IsNullOrEmpty(controlName)) return;
            if (parent == null) return;

            CustomValidator validator = new CustomValidator
            {
                ControlToValidate = controlName,
                ClientValidationFunction = registration.ClientValidationFunction,
                ErrorMessage = registration.ErrorMessage,
                Display = ValidatorDisplay.None,
                Text = "*",
                ID = string.Format("regval{0}_{1}", controlName, parent.Controls.Count),
            };
            parent.Controls.Add(validator);
        }
        #endregion
    }
}
