﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Huntington.OnlineBanking.Common.Web.UI.WebControls
{
    /// <summary>
    /// Represents the type of message supported by the <see cref="StatusMessage"/> Web control.
    /// </summary>
    public enum MessageType
    {
        /// <summary>
        /// The message represents a successful action.
        /// </summary>
        Success,

        /// <summary>
        /// The message is for informational purposes.
        /// </summary>
        Information,

        /// <summary>
        /// The message represents a warning.
        /// </summary>
        Warning
    }
}
