﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Huntington.OnlineBanking.Common.Extensions;

namespace Huntington.OnlineBanking.Common.Web.UI.WebControls
{
    /// <summary>
    /// This control allows displaying a message to the user. The message helps the user become aware of the 
    /// state of a particular action that just occurred on the page.
    /// </summary>
    [DefaultProperty("Text")]
    [ToolboxData("<{0}:StatusMessage runat=server></{0}:StatusMessage>")]
    public class StatusMessage : WebControl
    {
        #region Constants

        /// <summary>
        /// Represents the CSS class used for styling a successful message.
        /// </summary>
        public const string SuccessCssClass = "status-message-success";

        /// <summary>
        /// Represents the CSS class used for styling an informational message.
        /// </summary>
        public const string InformationCssClass = "status-message-info";

        /// <summary>
        /// Represents the CSS class used for styling a warning message.
        /// </summary>
        public const string WarningCssClass = "status-message-warning";

        #endregion

        #region Properties

        /// <summary>
        /// Gets or sets the message to display to the user.
        /// </summary>
        /// <value>
        /// The text.
        /// </value>
        [Bindable(true)]
        [Category("Appearance")]
        [DefaultValue("")]
        [Localizable(true)]
        [Description("The message to display to the user.")]
        public string Text
        {
            get
            {
                return (string)ViewState["Text"] ?? String.Empty;
            }

            set
            {
                ViewState["Text"] = value.SafeTrim();
            }
        }

        #endregion

        #region Overrides

        protected override void RenderContents(HtmlTextWriter output)
        {
            output.RenderBeginTag(HtmlTextWriterTag.Div);
            output.RenderBeginTag(HtmlTextWriterTag.Span);
            output.Write(Text);
            output.RenderEndTag();
            output.RenderEndTag();
        }

        #endregion

        #region Methods

        /// <summary>
        /// Gets the default CSS class name represented by the given message type.
        /// </summary>
        /// <param name="messageType">Type of the message.</param>
        /// <returns>
        ///     A <see cref="System.String"/> that represents a CSS class name.
        /// </returns>
        public static string GetCssClassByMessageType(MessageType messageType)
        {
            switch (messageType)
            {
                case MessageType.Information:
                    return InformationCssClass;

                case MessageType.Warning:
                    return WarningCssClass;

                default:
                    return SuccessCssClass;
            }
        }

        #endregion

        #region Constructor

        /// <summary>
        /// Initializes a new instance of the <see cref="StatusMessage"/> class.
        /// </summary>
        public StatusMessage(): base(HtmlTextWriterTag.Div)
        {

        }

        #endregion
    }
}
