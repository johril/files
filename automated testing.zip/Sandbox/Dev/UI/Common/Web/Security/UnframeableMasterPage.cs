﻿using System;
using System.Web.UI;

namespace Huntington.OnlineBanking.Common.Web.Security
{
    /// <summary>
    /// Implements code that prevents any page that uses this master page from being included in a frame.
    /// </summary>
    public class UnframeableMasterPage : MasterPage
    {
        // NOTE: This implementation assumes that IIS has been configured to output the "X-Frame-Options: sameorigin" HTTP response header!

        protected override void OnPreRender(EventArgs e)
        {
            base.OnPreRender(e);

            ClickjackingMitigator.InjectFrameBustingCode(Page);
        }
    }
}
