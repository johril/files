﻿using System;
using System.Web.UI;

namespace Huntington.OnlineBanking.Common.Web.Security
{
    /// <summary>
    /// Implements code that prevents this page from being included in a frame.
    /// </summary>
    public class UnframeablePage : Page
    {
        // NOTE: This implementation assumes that IIS has been configured to output the "X-Frame-Options: sameorigin" HTTP response header!

        protected override void OnPreRender(EventArgs e)
        {
            base.OnPreRender(e);

            ClickjackingMitigator.InjectFrameBustingCode(this);
        }
    }
}
