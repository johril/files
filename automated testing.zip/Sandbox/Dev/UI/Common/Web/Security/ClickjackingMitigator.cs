﻿using System;
using System.Runtime.Remoting.Messaging;
using System.Web.UI.WebControls;

namespace Huntington.OnlineBanking.Common.Web.Security
{
    /// <summary>
    /// Clickjacking prevention utility. For more information about this code see:
    /// <list type="bullet">
    ///     <item>
    ///         http://en.wikipedia.org/wiki/Clickjacking
    ///     </item>
    ///     <item>
    ///         http://seclab.stanford.edu/websec/framebusting/framebust.pdf 
    ///     </item>
    /// </list>
    /// </summary>
    public static class ClickjackingMitigator
    {
        #region Constants

        private const string ScriptKey = "ClickjackingMitigator";

        /// <summary>
        /// Represents the HTML <c>&lt;style&gt;</c> tag and CSS that hides the 
        /// contents in the page. Inject this code before the closing HTML <c>&lt;/head&gt;</c> tag.
        /// </summary>
        /// <example>
        ///     <code>
        ///         &lt;%@ Page Language=&quot;C#&quot; %&gt;
        ///         &lt;%@ Import Namespace=&quot;Huntington.OnlineBanking.Common.Web.Security&quot; %&gt;
        ///         &lt;html&gt;
        ///         &lt;head id=&quot;head&quot; runat=&quot;server&quot;&gt;
        ///         &lt;!-- Your HTML here... --&gt;
        ///
        ///         &lt;%= ClickjackingMitigator.HiddenContentHtml %&gt;
        ///         &lt;/head&gt;
        ///         &lt;body&gt;
        ///         &lt;!-- Your HTML here... --&gt;
        ///         &lt;/body&gt;
        ///         &lt;%= ClickjackingMitigator.FrameBustingJavaScript %&gt;
        ///         &lt;/html&gt;
        ///     </code>
        /// </example>
        private const string HiddenContentHtml = "<style type='text/css'>body { display: none; }</style>";

        /// <summary>
        /// Represents the frame busting JavaScript code. Inject this code preferably between the closing &lt;/body&gt; and &lt;/html&gt; tags
        /// or inside of the &lt;body&gt; tag. The idea is to get it to execute after the &lt;body&gt; tag has been processed by the browser.
        /// </summary>
        /// <returns>
        ///     The HTML &lt;script&gt; tag with frame-busting JavaScript code.
        /// </returns>
        /// <example>
        ///     <code>
        ///         &lt;%@ Page Language=&quot;C#&quot; %&gt;
        ///         &lt;%@ Import Namespace=&quot;Huntington.OnlineBanking.Common.Web.Security&quot; %&gt;
        ///         &lt;html&gt;
        ///         &lt;head id=&quot;head&quot; runat=&quot;server&quot;&gt;
        ///         &lt;!-- Your HTML here... --&gt;
        ///
        ///         &lt;%= ClickjackingMitigator.HiddenContentHtml %&gt;
        ///         &lt;/head&gt;
        ///         &lt;body&gt;
        ///         &lt;!-- Your HTML here... --&gt;
        ///         &lt;/body&gt;
        ///         &lt;%= ClickjackingMitigator.FrameBustingJavaScript %&gt;
        ///         &lt;/html&gt;
        ///     </code>
        /// </example>
        private const string FrameBustingJavaScript = @"
            <script type='text/javascript'>
                if (self == top) {
                    document.getElementsByTagName('body')[0].style.display = 'block';
                }
                else {
                    top.location = self.location;
                }
            </script>" + "\n";

        #endregion

        /// <summary>
        /// Injects framebusting JavaScript and CSS code into the current page. The specified page's &lt;head&gt; tag
        /// must be marked with the <c>runat="server"</c> attribute.
        /// </summary>
        /// <param name="currentPage">The current page.</param>
        /// <remarks>
        ///     If you get the following error "The Controls collection cannot be modified because the control contains code blocks (i.e. &lt;% ... %&gt;).",
        ///     make sure you use databinding syntax (&lt;%# ... &gt;%>) inside of the &lt;head&gt; tag instead of &lt;%= ... &gt; and then call 
        ///     <c>Page.Header.DataBind()</c> in the <c>Page_Load</c> event handler.
        /// </remarks>
        /// <exception cref="System.ArgumentNullException">
        ///     <paramref name="currentPage"/> is a <c>null</c> reference.
        /// </exception>
        /// <exception cref="System.InvalidOperationException">
        ///     The &lt;head&gt; tag hasn't been marked with the <c>runat="server"</c> attribute.
        /// </exception>
        public static void InjectFrameBustingCode(System.Web.UI.Page currentPage)
        {
            if (null == currentPage)
                throw new ArgumentNullException("currentPage");

            if (null == currentPage.Header)
                throw new InvalidOperationException("You must mark the HTML Head tag with the runat=\"server\" attribute. Open the current .aspx or master page and apply the runat=\"server\" attribute to the head tag: <head id=\"head\" runat=\"server\">...</head>");

            // Preferably, the FrameBustingJavaScript would be placed between the closing </body> and </html> tags, 
            // but I decided to inject the framebusting code this way. It worked during local testing.  -- MJV - 4/22/2011
            if (!currentPage.ClientScript.IsStartupScriptRegistered(typeof(ClickjackingMitigator), ScriptKey))
            {
                currentPage.Header.Controls.Add(new Literal() { Text = String.Format("{0}{1}{0}", Environment.NewLine, HiddenContentHtml) });

                currentPage.ClientScript.RegisterStartupScript(typeof(ClickjackingMitigator), ScriptKey, FrameBustingJavaScript, false);
            }
            
        }
    }
}
