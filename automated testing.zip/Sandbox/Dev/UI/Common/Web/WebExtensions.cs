﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web;

namespace Huntington.OnlineBanking.Common.Web
{
    /// <summary>
    /// Contains extension methods for HTTP-specific types.
    /// </summary>
    public static class WebExtensions
    {
        /// <summary>
        /// Appropriately redirects the client to the specified URL and completes the request.
        /// </summary>
        /// <param name="response">The current <see cref="System.Web.HttpResponse"/> that is being extended by this method.</param>
        /// <param name="url">The relative or fully-qualified URL to which the client will be redirected.</param>
        public static void SafeRedirect(this HttpResponse response, string url)
        {
            if (null == HttpContext.Current)
                throw new InvalidOperationException("Not running in the context of a Web application");

            HttpContext.Current.Response.Redirect(url, false);
            HttpContext.Current.ApplicationInstance.CompleteRequest();
        }
    }
}
