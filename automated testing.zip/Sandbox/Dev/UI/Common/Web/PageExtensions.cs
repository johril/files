﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web.UI;
using System.Web;
using Huntington.OnlineBanking.Common.Web.UI.WebControls;
using System.Web.UI.WebControls;

namespace Huntington.OnlineBanking.Common.Web
{
    /// <summary>
    /// Contains extension methods for the <see cref="System.Web.UI.Page"/> class.
    /// </summary>
    public static class PageExtensions
    {
        /// <summary>
        /// Displays the specified error message on the current page.
        /// </summary>
        /// <param name="page">The page where the error message will be registered.</param>
        /// <param name="errorMessage">The error message to display.</param>
        /// <remarks>
        ///     It is best to use this method when a <see cref="System.Web.UI.WebControls.ValidationSummary"/>
        ///     has been added to the page.
        /// </remarks>
        public static void DisplayErrorMessage(this Page page, string errorMessage)
        {
            if (String.IsNullOrWhiteSpace(errorMessage))
                throw new ArgumentException("Error message cannot be a null reference or empty string.", "errorMessage");

            page.Validators.Add(new ValidationError(errorMessage));
        }

        /// <summary>
        /// Displays an error message with the specified format string.
        /// </summary>
        /// <param name="page">The page where the error message will be registered.</param>
        /// <param name="format">A composite format string containing the error message and argument placeholders.</param>
        /// <param name="args">The array of objects to format.</param>
        public static void DisplayErrorMessageFormat(this Page page, string format, params object[] args)
        {
            string errorMessage = String.Format(format, args);

            DisplayErrorMessage(page, errorMessage);
        }

        /// <summary>
        /// Displays the specified success message on the current page. An existing <see cref="System.Web.UI.WebControls.PlaceHolder"/>
        /// control with its ID set to <c>"statusMessagePlaceHolder"</c> must exist in the Master page or page extended by this method.
        /// </summary>
        /// <param name="page">The page being extended.</param>
        /// <param name="message">The message to display to the user.</param>
        /// <exception cref="System.InvalidOperationException">
        ///     A <see cref="System.Web.UI.WebControls.PlaceHolder"/> control with its ID set to <c>"statusMessagePlaceHolder"</c>
        ///     was not found.
        /// </exception>
        public static void DisplaySuccessMessage(this Page page, string message)
        {
            InjectStatusMessageControl(page, message, MessageType.Success);
        }

        /// <summary>
        /// Displays a success message using the specified format string and argument list. An existing 
        /// <see cref="System.Web.UI.WebControls.PlaceHolder"/> control with its ID set to 
        /// <c>"statusMessagePlaceHolder"</c> must exist in the Master page or page extended by this method.
        /// </summary>
        /// <param name="page">The page being extended.</param>
        /// <param name="format">A composite format string containing the status message and argument placeholders.</param>
        /// <param name="args">The array of objects to format.</param>
        /// <exception cref="System.InvalidOperationException">
        ///     A <see cref="System.Web.UI.WebControls.PlaceHolder"/> control with its ID set to <c>"statusMessagePlaceHolder"</c>
        ///     was not found.
        /// </exception>
        public static void DisplaySuccessMessageFormat(this Page page, string format, params object[] args)
        {
            DisplaySuccessMessage(page, String.Format(format, args));
        }

        /// <summary>
        /// Displays the specified informational message on the current page. An existing <see cref="System.Web.UI.WebControls.PlaceHolder"/>
        /// control with its ID set to <c>"statusMessagePlaceHolder"</c> must exist in the Master page or page extended by this method.
        /// </summary>
        /// <param name="page">The page being extended.</param>
        /// <param name="message">The message to display to the user.</param>
        /// <exception cref="System.InvalidOperationException">
        ///     A <see cref="System.Web.UI.WebControls.PlaceHolder"/> control with its ID set to <c>"statusMessagePlaceHolder"</c>
        ///     was not found.
        /// </exception>
        public static void DisplayInformationMessage(this Page page, string message)
        {
            InjectStatusMessageControl(page, message, MessageType.Information);
        }

        /// <summary>
        /// Displays an informational message using the specified format string and argument list. An existing 
        /// <see cref="System.Web.UI.WebControls.PlaceHolder"/> control with its ID set to 
        /// <c>"statusMessagePlaceHolder"</c> must exist in the Master page or page extended by this method.
        /// </summary>
        /// <param name="page">The page being extended.</param>
        /// <param name="format">A composite format string containing the status message and argument placeholders.</param>
        /// <param name="args">The array of objects to format.</param>
        /// <exception cref="System.InvalidOperationException">
        ///     A <see cref="System.Web.UI.WebControls.PlaceHolder"/> control with its ID set to <c>"statusMessagePlaceHolder"</c>
        ///     was not found.
        /// </exception>
        public static void DisplayInformationMessageFormat(this Page page, string format, params object[] args)
        {
            DisplayInformationMessage(page, String.Format(format, args));
        }

        /// <summary>
        /// Displays the specified warning message on the current page. An existing <see cref="System.Web.UI.WebControls.PlaceHolder"/>
        /// control with its ID set to <c>"statusMessagePlaceHolder"</c> must exist in the Master page or page extended by this method.
        /// </summary>
        /// <param name="page">The page being extended.</param>
        /// <param name="message">The message to display to the user.</param>
        /// <exception cref="System.InvalidOperationException">
        ///     A <see cref="System.Web.UI.WebControls.PlaceHolder"/> control with its ID set to <c>"statusMessagePlaceHolder"</c>
        ///     was not found.
        /// </exception>
        public static void DisplayWarningMessage(this Page page, string message)
        {
            InjectStatusMessageControl(page, message, MessageType.Warning);
        }

        /// <summary>
        /// Searches the page naming container for a server control with the specified identifier, starting with the page's master page.
        /// </summary>
        /// <param name="id">The identifier for the control to be found.</param>
        /// <returns>The specified control, or null if the specified control does not exist.</returns>
        public static Control FindMasterControl(this Page page, string id)
        {
            Control rc = null;
            if (page.Master != null) rc = page.Master.FindControl(id);

            return rc ?? page.FindControl(id);
        }

        /// <summary>
        /// Searches the page naming container for a server control with the specified identifier, searching through container controls as needed.
        /// </summary>
        /// <param name="page"></param>
        /// <param name="id"></param>
        /// <returns></returns>
        public static Control FindNestedControl(this Page page, string id)
        {
            Control ctl = page;
            LinkedList<Control> ctls = new LinkedList<Control>();

            while (ctl != null)
            {
                if (ctl.ID == id)
                    return ctl;
                foreach (Control child in ctl.Controls)
                {
                    if (child.ID == id)
                        return child;
                    if (child.HasControls())
                        ctls.AddLast(child);
                }
                ctl = ctls.First.Value;
                ctls.Remove(ctl);
            }
            return null;
        }

        /// <summary>
        /// Determine if the specified control is the target of the postback (i.e. if the specified control caused the postback).
        /// </summary>
        /// <param name="page"></param>
        /// <param name="control"></param>
        /// <returns>Whether the specified control caused the postback.</returns>
        public static bool IsPostBackControl(this Page page, Control control)
        {
            if (control == null) throw new ArgumentNullException("control");

            //return page.Request["__EVENTTARGET"] == control.UniqueID;
            return page.Request.Params["__EVENTTARGET"] == control.UniqueID; 
            //07-22-11 JMR.  Changed to use the Params collection to deal with a Value Shadowing vulnerability.  This function isn't currently called anywhere.
            //This change will need to be validated if this function is ever used.
        }

        #region Helper Methods

        private static void InjectStatusMessageControl(Page page, string message, MessageType messageType)
        {
            Control statusMessagePlaceHolder = EnsureHasStatusMessagePlaceHolder(page);
            statusMessagePlaceHolder.Controls.Clear();
            statusMessagePlaceHolder.Controls.Add(CreateStatusMessageControl(messageType, message));
        }

        private static Control EnsureHasStatusMessagePlaceHolder(Page page)
        {
            PlaceHolder statusMessagePlaceHolder = page.FindMasterControl("statusMessagePlaceHolder") as PlaceHolder;
            if (null == statusMessagePlaceHolder)
            {
                throw new InvalidOperationException("Unable to display given message. The required control could not be found in current page or its master page. You must add a PlaceHolder control to the page or master page with its ID set to \"statusMessagePlaceHolder\".");
            }

            return statusMessagePlaceHolder;
        }

        private static StatusMessage CreateStatusMessageControl(MessageType messageType, string message)
        {
            return new StatusMessage()
            {
                Text = message,
                EnableViewState = false,
                CssClass = StatusMessage.GetCssClassByMessageType(messageType)
            };
        }

        #endregion
    }
}