﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.UI;

namespace Huntington.OnlineBanking.Common.Web
{
    public class CookieManager
    {
        /// <summary>
        /// Remove a cookie from the browser's cache.
        /// </summary>
        /// <param name="name">The cookie name.</param>
        public static void RemoveCookie(string name)
        {
            if (HttpContext.Current == null) return;

            HttpCookie cookie = HttpContext.Current.Response.Cookies[name];
            if (cookie != null)
            {
                cookie.Expires = DateTime.Now.AddDays(-1);
            }
            else
            {
                cookie = new HttpCookie(name) { Expires = DateTime.Now.AddDays(-1) };
                HttpContext.Current.Response.Cookies.Add(cookie);
            }
        }

        /// <summary>
        /// Remove a cookie from the browser's cache.
        /// </summary>
        /// <param name="page">The page whose cookie should be removed.</param>
        /// <param name="name">The cookie name.</param>
        public static void RemoveCookie(Page page, string name)
        {
            if (page == null) return;

            HttpCookie cookie = page.Response.Cookies[name];
            if (cookie != null)
            {
                cookie.Expires = DateTime.Now.AddDays(-1);
            }
            else
            {
                cookie = new HttpCookie(name) { Expires = DateTime.Now.AddDays(-1) };
                page.Response.Cookies.Add(cookie);
            }
        }

        public static void CreateCookie(string name)
        {
            if (HttpContext.Current == null) return;

            HttpCookie cookie = HttpContext.Current.Response.Cookies[name];
            if (cookie == null)
            {
                cookie = new HttpCookie(name);
                HttpContext.Current.Response.Cookies.Add(cookie);
            }
            else
            {
                HttpCookie newCookie = new HttpCookie(name);
                HttpContext.Current.Response.Cookies.Set(newCookie);
            }
        }

        public static void CreateCookie(string name, string value)
        {
            if (HttpContext.Current == null) return;

            HttpCookie cookie = HttpContext.Current.Response.Cookies[name];
            if (cookie == null)
            {
                cookie = new HttpCookie(name, value);
                HttpContext.Current.Response.Cookies.Add(cookie);
            }
            else
            {
                if (!String.IsNullOrEmpty(value))
                {
                    HttpCookie newCookie = new HttpCookie(name, value);
                    HttpContext.Current.Response.Cookies.Set(newCookie);
                }
            }
        }


        public static string GetCookieValue(string name)
        {
            string strCookieValue = String.Empty;

            if (HttpContext.Current != null)
            {
                HttpCookie respCookie = HttpContext.Current.Response.Cookies[name];
                HttpCookie reqCookie = HttpContext.Current.Request.Cookies[name];

                if (reqCookie != null)
                {
                    strCookieValue = reqCookie.Value;

                    if (String.IsNullOrEmpty(strCookieValue))
                    {
                        if(respCookie != null)
                        {
                            strCookieValue = reqCookie.Value;
                        }
                    } 
                }
                else
                {
                    if (respCookie != null)
                    {
                        strCookieValue = reqCookie.Value;
                    }
                }
            }

            return strCookieValue;
        }

    
    }
}
