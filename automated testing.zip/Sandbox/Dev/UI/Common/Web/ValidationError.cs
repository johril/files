﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.UI;

namespace Huntington.OnlineBanking.Common.Web
{
    /// <summary>
    /// Used by the <see cref="PageExtensions"/> class for injecting a validation error in a 
    /// <see cref="System.Web.UI.WebControls.ValidationSummary"/> control.
    /// </summary>
    /// <remarks>
    /// Source: http://blogs.msdn.com/b/simonince/archive/2008/02/28/adding-messages-to-a-validation-summary.aspx
    /// </remarks>
    public class ValidationError : IValidator
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="ValidationError"/> class with the given error message.
        /// </summary>
        /// <param name="message">The error message to display in this instance.</param>
        public ValidationError(string message)
        {
            ErrorMessage = message;

            IsValid = false;
        }

        /// <summary>
        /// Gets or sets the error message text generated when the condition being validated fails.
        /// </summary>
        /// <returns>The error message to generate.</returns>
        public string ErrorMessage { get; set; }

        /// <summary>
        /// Gets or sets a value indicating whether the user-entered content in the specified control passes validation.
        /// </summary>
        /// <returns>true if the content is valid; otherwise, false.</returns>
        public bool IsValid { get; set; }

        /// <summary>
        /// This operation does not do anything.
        /// </summary>
        public void Validate()
        {
            // no action required
        }
    }
}
